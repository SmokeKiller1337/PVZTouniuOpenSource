using System;
using UnityEngine;

public class Entity1 : MonoBehaviour
{
	[SerializeField]
	[Tooltip("生命值")]
	private int maxHealth;

	[Tooltip("受伤倍率")]
	[SerializeField]
	private float startDamageMultiplier;

	private int health;

	private float damageMultiplier;

	public int MaxHealth => maxHealth;

	public float StartDamageMultiplier => startDamageMultiplier;

	public int Health => health;

	public float DamageMultiplier => damageMultiplier;

	private void Awake()
	{
		health = maxHealth;
		damageMultiplier = startDamageMultiplier;
	}

	public void ModifyHealth(int changeValue)
	{
		health = Math.Clamp(health + changeValue, 0, maxHealth);
	}

	public void ModifyDamageMultiplier(float changeValue)
	{
		damageMultiplier += changeValue;
	}
}
