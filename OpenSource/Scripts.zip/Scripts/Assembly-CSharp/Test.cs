using UnityEngine;

public class Test : MonoBehaviour
{
	public GameObject prefab;

	private void Start()
	{
	}
}
