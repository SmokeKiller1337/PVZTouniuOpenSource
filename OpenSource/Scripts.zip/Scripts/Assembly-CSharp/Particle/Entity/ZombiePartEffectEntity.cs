using UnityEngine;

namespace Particle.Entity
{
	public class ZombiePartEffectEntity : MonoBehaviour
	{
		[Tooltip("水中持续时间")]
		public float waterParticleAge;

		[HideInInspector]
		public bool isInWater;

		private ParticleSystem _particleSystem;

		private ParticleSystem.Particle[] _particles;

		private void Start()
		{
		}

		private void Update()
		{
		}
	}
}
