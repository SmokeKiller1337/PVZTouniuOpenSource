using System.Collections.Generic;
using UnityEngine;

namespace Particle.Entity
{
	public class Zombie90SpotLightEntity : MonoBehaviour
	{
		[Tooltip("颜色集合")]
		public List<Color> colorList;

		[Tooltip("切换时间")]
		public float switchTime;

		private float _switchTimer;

		[Tooltip("渲染器")]
		public List<SpriteRenderer> lightSpriteRendererList;

		private int _colorIndex;

		public void Reset()
		{
		}

		private void Update()
		{
		}

		private void SwitchLightColor()
		{
		}
	}
}
