using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

namespace Particle.Entity
{
	public class ScreenFlash2D : MonoBehaviour
	{
		[CompilerGenerated]
		private sealed class _003CFlashRoutine_003Ed__5 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public float maxAlpha;

			public float duration;

			public ScreenFlash2D _003C_003E4__this;

			public Color color;

			private float _003Celapsed_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CFlashRoutine_003Ed__5(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		public SpriteRenderer flashRenderer;

		private Camera mainCamera;

		private void Start()
		{
		}

		private void UpdateFlashSize()
		{
		}

		public void Flash(Color color, float duration = 0.2f, float maxAlpha = 0.8f)
		{
		}

		[IteratorStateMachine(typeof(_003CFlashRoutine_003Ed__5))]
		private IEnumerator FlashRoutine(Color color, float duration, float maxAlpha)
		{
			return null;
		}

		private void Update()
		{
		}
	}
}
