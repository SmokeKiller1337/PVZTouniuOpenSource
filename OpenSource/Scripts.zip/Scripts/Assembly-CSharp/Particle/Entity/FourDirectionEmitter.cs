using UnityEngine;

namespace Particle.Entity
{
	public class FourDirectionEmitter : MonoBehaviour
	{
		public float speed;

		public float startPosition;

		private ParticleSystem ps;

		private void Start()
		{
		}

		private void Update()
		{
		}

		private void EmitParticleInDirection(Vector3 direction, bool isAngle = false)
		{
		}
	}
}
