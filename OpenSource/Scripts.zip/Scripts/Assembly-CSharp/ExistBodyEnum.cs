public enum ExistBodyEnum
{
	Shovel = 0,
	Clear = 1,
	Cancel = 2
}
