namespace Common.Collider
{
	public class BodyColliderEntity : CommonColliderEntity
	{
	}
}
