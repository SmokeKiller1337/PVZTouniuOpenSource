using Common.Entity;
using Common.Enum;
using UnityEngine;

namespace Common.Collider
{
	public class CommonColliderEntity : MonoBehaviour
	{
		[Tooltip("触发器类型")]
		public BodyColliderType type;

		[Tooltip("自定义类型索引")]
		public int customIndex;

		[HideInInspector]
		public BaseBody baseBody;

		protected virtual void Awake()
		{
		}

		protected virtual void OnTriggerEnter2D(Collider2D col)
		{
		}

		protected virtual void OnTriggerExit2D(Collider2D col)
		{
		}

		protected virtual void OnTriggerStay2D(Collider2D col)
		{
		}
	}
}
