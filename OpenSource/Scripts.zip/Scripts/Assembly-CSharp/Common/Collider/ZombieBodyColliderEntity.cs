using UnityEngine;
using Zombie.Entity;

namespace Common.Collider
{
	public class ZombieBodyColliderEntity : BodyColliderEntity
	{
		[HideInInspector]
		public ZombieEntity zombieEntity;

		protected override void Awake()
		{
			base.Awake();
		}
	}
}
