using UnityEngine;
using Zombie.Entity;

namespace Common.Collider
{
	public class ZombieBodyColliderEntity : BodyColliderEntity
	{
		[HideInInspector]
		public ZombieEntity zombieEntity;

		protected override void Awake()
		{
			// The decompiled body performs a GetComponentInParent<...>() and stores the
			// result into a field at offset 0x28. Per dump.cs, offset 0x28 is NOT a member
			// of this class (the only field here, zombieEntity, lives at 0x30 and is never
			// touched in the pseudocode). Offset 0x28 belongs to the base class
			// BodyColliderEntity, whose field name is not available in stub.cs / dump.cs.
			// The remaining decompiled lines (0x40-0x54) are IL2CPP GC write-barrier /
			// class-init boilerplate, not game logic.
			//
			// TODO: reconstruct — this override resolves a parent component via
			// GetComponentInParent and assigns it to an inaccessible base-class field
			// (offset 0x28). It cannot be reproduced without the base field's name.
			// Deferring to base behavior to keep the parent-component resolution intact.
			base.Awake();
		}
	}
}
