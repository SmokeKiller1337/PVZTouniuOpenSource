using Plant.Entity;
using UnityEngine;

namespace Common.Collider
{
	public class PlantBodyColliderEntity : BodyColliderEntity
	{
		[HideInInspector]
		public PlantEntity plantEntity;

		protected override void Awake()
		{
			plantEntity = GetComponentInParent<PlantEntity>();
		}
	}
}
