using Plant.Entity;
using UnityEngine;

namespace Common.Collider
{
	public class PlantBodyColliderEntity : BodyColliderEntity
	{
		[HideInInspector]
		public PlantEntity plantEntity;

		// RVA: 0x6BA420
		protected override void Awake()
		{
			// Pseudocode resolves the PlantEntity component from the parent hierarchy
			// and stores it into the class's only PlantEntity-typed field.
			// (The leading cRam/GetComponentInParent<T> token and the trailing atomic
			//  bit-set block are IL2CPP class-init interlocks / GC write barriers with
			//  no C# source equivalent, so they are omitted.)
			plantEntity = GetComponentInParent<PlantEntity>();
		}
	}
}
