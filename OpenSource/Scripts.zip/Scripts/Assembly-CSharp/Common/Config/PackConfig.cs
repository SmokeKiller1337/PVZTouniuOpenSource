using UnityEngine;

namespace Common.Config
{
	[CreateAssetMenu(fileName = "MyConfig", menuName = "Common/PackConfig")]
	public class PackConfig : ScriptableObject
	{
	}
}
