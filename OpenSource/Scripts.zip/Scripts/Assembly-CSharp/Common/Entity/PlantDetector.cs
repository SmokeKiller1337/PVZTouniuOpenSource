using UnityEngine;

namespace Common.Entity
{
	public class PlantDetector : MonoBehaviour
	{
		[SerializeField]
		private Camera targetCamera;

		[SerializeField]
		private LayerMask plantLayerMask;

		[SerializeField]
		private float doubleClickThreshold = 0.3f; // .ctor initializes 0x2C to 0x3E99999A == 0.3f

		private Collider2D lastHoveredPlant;

		private Vector3 lastMousePosition;

		private float lastClickTime;

		private Collider2D lastClickedPlant;

		private bool isWaitingForDoubleClick;

		// TODO: The SendMessage method names below are data-pointer string literals in the
		// decompiled pseudocode and could not be recovered exactly. They are named by their
		// role in the hover/click flow; adjust to match the receiver plant scripts' handlers.
		private const string MSG_HOVER_EXIT = "OnPlantHoverExit";    // TODO: verify literal (global @0x182E7E440)
		private const string MSG_HOVER_ENTER = "OnPlantHoverEnter";  // TODO: verify literal (global @0x182E7E3A0)
		private const string MSG_DOUBLE_CLICK = "OnPlantDoubleClick";// TODO: verify literal (global @0x182E7E300)
		private const string MSG_SINGLE_CLICK = "OnPlantClick";      // TODO: verify literal (global @0x182E7E260)

		// TODO: The mouse-move threshold used in Update is a private/global float constant
		// (_DAT_18252D074) compared against the squared mouse-position delta. Value unknown.
		private const float MouseMoveSqrThreshold = 0.01f; // TODO: verify constant (global @0x18252D074)

		private void Update()
		{
			// NOTE: The decompiled Update body begins with a guard against a game-state
			// singleton (globals via ICF-folded accessors) that appears to require the game
			// to be in a specific running/active state (state field == 2) before processing
			// input. The exact singleton and state enum are not resolvable from this class's
			// symbols alone, so the guard is omitted here to avoid inventing wrong logic.
			// TODO: reconstruct game-state guard if the target singleton can be identified.

			Vector3 mousePosition = Input.mousePosition;
			float dx = mousePosition.x - lastMousePosition.x;
			float dy = mousePosition.y - lastMousePosition.y;
			float dz = mousePosition.z - lastMousePosition.z;
			float sqrDelta = dx * dx + dy * dy + dz * dz;

			if (sqrDelta >= MouseMoveSqrThreshold || Input.GetMouseButtonDown(0))
			{
				DetectPlantHover();
				lastMousePosition = Input.mousePosition;
			}

			if (isWaitingForDoubleClick && Time.unscaledTime - lastClickTime > doubleClickThreshold)
			{
				isWaitingForDoubleClick = false;
			}
		}

		private void DetectPlantHover()
		{
			if (targetCamera == null)
			{
				return;
			}

			Vector3 worldPoint = targetCamera.ScreenToWorldPoint(Input.mousePosition);
			Collider2D hit = Physics2D.OverlapPoint(worldPoint, plantLayerMask);

			if (hit != lastHoveredPlant)
			{
				if (lastHoveredPlant != null)
				{
					lastHoveredPlant.SendMessage(MSG_HOVER_EXIT, SendMessageOptions.DontRequireReceiver);
				}

				lastHoveredPlant = hit;

				if (hit != null)
				{
					hit.SendMessage(MSG_HOVER_ENTER, SendMessageOptions.DontRequireReceiver);
				}
			}

			if (!Input.GetMouseButtonDown(0))
			{
				return;
			}

			if (hit == null)
			{
				return;
			}

			float now = Time.unscaledTime;

			if (isWaitingForDoubleClick && now - lastClickTime <= doubleClickThreshold && hit == lastClickedPlant)
			{
				hit.SendMessage(MSG_DOUBLE_CLICK, SendMessageOptions.DontRequireReceiver);
				isWaitingForDoubleClick = false;
			}
			else
			{
				hit.SendMessage(MSG_SINGLE_CLICK, SendMessageOptions.DontRequireReceiver);
				isWaitingForDoubleClick = true;
				lastClickedPlant = hit;
			}

			lastClickTime = now;
		}
	}
}
