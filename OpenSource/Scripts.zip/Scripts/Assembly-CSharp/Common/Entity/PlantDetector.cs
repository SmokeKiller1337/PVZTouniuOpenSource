using UnityEngine;

namespace Common.Entity
{
	public class PlantDetector : MonoBehaviour
	{
		[SerializeField]
		private Camera targetCamera;

		[SerializeField]
		private LayerMask plantLayerMask;

		[SerializeField]
		private float doubleClickThreshold = 0.3f; // .ctor initializes 0x2C to 0x3E99999A == 0.3f

		private Collider2D lastHoveredPlant;

		private Vector3 lastMousePosition;

		private float lastClickTime;

		private Collider2D lastClickedPlant;

		private bool isWaitingForDoubleClick;

		private const string MSG_HOVER_EXIT = "OnPlantHoverExit";
		private const string MSG_HOVER_ENTER = "OnPlantHoverEnter";
		private const string MSG_DOUBLE_CLICK = "OnPlantDoubleClick";
		private const string MSG_SINGLE_CLICK = "OnPlantClick";

		private const float MouseMoveSqrThreshold = 0.01f;

		private void Update()
		{

			Vector3 mousePosition = Input.mousePosition;
			float dx = mousePosition.x - lastMousePosition.x;
			float dy = mousePosition.y - lastMousePosition.y;
			float dz = mousePosition.z - lastMousePosition.z;
			float sqrDelta = dx * dx + dy * dy + dz * dz;

			if (sqrDelta >= MouseMoveSqrThreshold || Input.GetMouseButtonDown(0))
			{
				DetectPlantHover();
				lastMousePosition = Input.mousePosition;
			}

			if (isWaitingForDoubleClick && Time.unscaledTime - lastClickTime > doubleClickThreshold)
			{
				isWaitingForDoubleClick = false;
			}
		}

		private void DetectPlantHover()
		{
			if (targetCamera == null)
			{
				return;
			}

			Vector3 worldPoint = targetCamera.ScreenToWorldPoint(Input.mousePosition);
			Collider2D hit = Physics2D.OverlapPoint(worldPoint, plantLayerMask);

			if (hit != lastHoveredPlant)
			{
				if (lastHoveredPlant != null)
				{
					lastHoveredPlant.SendMessage(MSG_HOVER_EXIT, SendMessageOptions.DontRequireReceiver);
				}

				lastHoveredPlant = hit;

				if (hit != null)
				{
					hit.SendMessage(MSG_HOVER_ENTER, SendMessageOptions.DontRequireReceiver);
				}
			}

			if (!Input.GetMouseButtonDown(0))
			{
				return;
			}

			if (hit == null)
			{
				return;
			}

			float now = Time.unscaledTime;

			if (isWaitingForDoubleClick && now - lastClickTime <= doubleClickThreshold && hit == lastClickedPlant)
			{
				hit.SendMessage(MSG_DOUBLE_CLICK, SendMessageOptions.DontRequireReceiver);
				isWaitingForDoubleClick = false;
			}
			else
			{
				hit.SendMessage(MSG_SINGLE_CLICK, SendMessageOptions.DontRequireReceiver);
				isWaitingForDoubleClick = true;
				lastClickedPlant = hit;
			}

			lastClickTime = now;
		}
	}
}
