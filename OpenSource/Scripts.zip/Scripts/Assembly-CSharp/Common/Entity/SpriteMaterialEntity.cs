using UnityEngine;

namespace Common.Entity
{
	public class SpriteMaterialEntity : MonoBehaviour
	{
		[Tooltip("色相")]
		[Range(0f, 1f)]
		public float hueValue;

		private void Awake()
		{
		}
	}
}
