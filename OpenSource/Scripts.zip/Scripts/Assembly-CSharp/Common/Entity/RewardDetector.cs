using UnityEngine;

namespace Common.Entity
{
	public class RewardDetector : MonoBehaviour
	{
		[SerializeField]
		private Camera targetCamera;

		[SerializeField]
		private LayerMask rewardLayerMask;

		private Collider2D lastHoveredReward;

		private Vector3 lastMousePosition;

		private void Update()
		{
		}

		private void DetectRewardHover()
		{
		}
	}
}
