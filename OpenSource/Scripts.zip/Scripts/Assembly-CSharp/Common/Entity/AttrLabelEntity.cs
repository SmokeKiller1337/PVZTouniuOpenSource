using System;
using UnityEngine;

namespace Common.Entity
{
	[Serializable]
	public class AttrLabelEntity : ICloneable
	{
		[Tooltip("名称")]
		public string title;

		[Tooltip("层数")]
		public int layer;

		[Tooltip("描述")]
		public string desc;

		public object Clone()
		{
			return MemberwiseClone();
		}
	}
}
