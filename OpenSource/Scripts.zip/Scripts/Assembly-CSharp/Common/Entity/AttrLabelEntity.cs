using System;
using UnityEngine;

namespace Common.Entity
{
	[Serializable]
	public class AttrLabelEntity : ICloneable
	{
		[Tooltip("名称")]
		public string title;

		[Tooltip("层数")]
		public int layer;

		[Tooltip("描述")]
		public string desc;

		public object Clone()
		{
			// NOTE: The Ghidra pseudocode for this RVA was collapsed by IL2CPP ICF onto
			// System.Collections.Hashtable+HashtableEnumerator.Clone (a memberwise-clone
			// helper), so the decompiled body does not reflect this method's real logic.
			// AttrLabelEntity is a simple [Serializable] data holder implementing ICloneable;
			// the idiomatic (and structurally consistent) implementation is a shallow clone.
			// TODO: reconstruct — unverifiable due to ICF; confirm shallow vs. deep clone.
			return MemberwiseClone();
		}
	}
}
