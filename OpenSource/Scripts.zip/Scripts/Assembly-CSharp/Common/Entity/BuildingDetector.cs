using UnityEngine;

namespace Common.Entity
{
	public class BuildingDetector : MonoBehaviour
	{
		[SerializeField]
		private Camera targetCamera;

		[SerializeField]
		private LayerMask buildingLayerMask;

		[SerializeField]
		private float doubleClickThreshold;

		private Collider2D lastHoveredBuilding;

		private Vector3 lastMousePosition;

		private float lastClickTime;

		private Collider2D lastClickedBuilding;

		private bool isWaitingForDoubleClick;

		private void Update()
		{
		}

		private void DetectBuildingHover()
		{
		}
	}
}
