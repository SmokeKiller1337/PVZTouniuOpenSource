using System;
using System.Collections.Generic;
using Game.Entity;
using Plant.Entity;
using UnityEngine;

namespace Common.Entity
{
	[Serializable]
	public class PlantBaseAttr
	{
		[Tooltip("总血量")]
		public float maxHealth;

		[Tooltip("当前血量")]
		public float currentHealth;

		[Tooltip("无敌")]
		public bool isInvincible;

		[Tooltip("不可被吃")]
		public bool isNotEat;

		[Tooltip("不可选取1")]
		public bool isNotPick1;

		[Tooltip("不可选取2")]
		public bool isNotPick2;

		[Tooltip("不可铲除")]
		public bool isNotShovel;

		[Tooltip("攻击力")]
		public int attack;

		[Tooltip("魔法力")]
		public int magic;

		[Tooltip("攻击速度")]
		[HideInInspector]
		public float attackSpeed;

		[HideInInspector]
		public float attackIntervalTime;

		[HideInInspector]
		public float attackIntervalTimer;

		[Tooltip("值集合")]
		public List<ValueEntity> valueList;

		[Tooltip("标签集合")]
		public List<AttrLabelEntity> labelList;

		[HideInInspector]
		public List<float> floatValueList;

		private const float MaxAttackSpeed = 10f;

		[Tooltip("攻击速度")]
		public float AttackSpeed
		{
			get
			{
				return attackSpeed;
			}
			set
			{
				attackSpeed = value;
				if (value > MaxAttackSpeed)
				{
					attackSpeed = MaxAttackSpeed;
				}
				attackIntervalTime = 1f / attackSpeed;
			}
		}

		public float HealthRatio => currentHealth / maxHealth;

		public PlantBaseAttr()
		{
			maxHealth = 200f;
			attack = 20;
		}

		public PlantBaseAttr(PlantBaseAttr attr)
		{
			maxHealth = 200f;
			attack = 20;
			if (attr == null)
			{
				return;
			}
			maxHealth = attr.maxHealth;
			currentHealth = attr.currentHealth;
			isInvincible = attr.isInvincible;
			isNotEat = attr.isNotEat;
			isNotPick1 = attr.isNotPick1;
			isNotPick2 = attr.isNotPick2;
			attackSpeed = attr.attackSpeed;
			if (attackSpeed > MaxAttackSpeed)
			{
				attackSpeed = MaxAttackSpeed;
			}
			attackIntervalTime = 1f / attackSpeed;
			attack = attr.attack;
			magic = attr.magic;

			valueList = new List<ValueEntity>();
			if (attr.valueList != null)
			{
				foreach (ValueEntity value in attr.valueList)
				{
					valueList.Add((ValueEntity)value.Clone());
				}
			}

			labelList = new List<AttrLabelEntity>();
			if (attr.labelList != null)
			{
				foreach (AttrLabelEntity label in attr.labelList)
				{
					labelList.Add((AttrLabelEntity)label.Clone());
				}
			}

			floatValueList = new List<float>();
			if (attr.floatValueList != null)
			{
				foreach (float f in attr.floatValueList)
				{
					floatValueList.Add(f);
				}
			}
		}

		public void AddAttr(PlantBaseAttr attr)
		{
			if (attr == null)
			{
				return;
			}
			maxHealth += attr.maxHealth;
			attackSpeed += attr.attackSpeed;
			if (attackSpeed > MaxAttackSpeed)
			{
				attackSpeed = MaxAttackSpeed;
			}
			attackIntervalTime = 1f / attackSpeed;
			attack += attr.attack;
			magic += attr.magic;

			if (attr.valueList == null)
			{
				return;
			}
			foreach (ValueEntity srcValue in attr.valueList)
			{
				foreach (ValueEntity myValue in valueList)
				{
					if (myValue.title != null && myValue.title.Equals(srcValue.title))
					{
						myValue.baseValue += srcValue.baseValue;
					}
				}
			}
		}

		public void Reset()
		{
			currentHealth = maxHealth;
			isInvincible = false;
			labelList = new List<AttrLabelEntity>();
			attackIntervalTimer = attackIntervalTime;
		}

		public float GetValue(PlantEntity plantEntity, int index = 0)
		{
			if (index >= valueList.Count)
			{
				throw new IndexOutOfRangeException();
			}
			return valueList[index].GetValue(plantEntity);
		}

		public int GetValueInt(PlantEntity plantEntity, int index = 0)
		{
			if (index >= valueList.Count)
			{
				throw new IndexOutOfRangeException();
			}
			return (int)valueList[index].GetValue(plantEntity);
		}

		public float GetValue(PlantEntity plantEntity, string title)
		{
			foreach (ValueEntity value in valueList)
			{
				if (value.title != null && value.title.Equals(title))
				{
					return value.GetValue(plantEntity);
				}
			}
			throw new Exception("找不到值:" + title);
		}

		public int GetValueInt(PlantEntity plantEntity, string fieldName)
		{
			return (int)GetValue(plantEntity, fieldName);
		}

		public void AddLabel(string title, int layer = 0, string desc = "")
		{
			foreach (AttrLabelEntity label in labelList)
			{
				if (label.title != null && label.title.Equals(title))
				{
					label.layer += layer;
					if (desc != null && desc.Length > 0)
					{
						label.desc = desc;
					}
					return;
				}
			}
			AttrLabelEntity newLabel = new AttrLabelEntity();
			newLabel.title = title;
			newLabel.layer = layer;
			newLabel.desc = desc;
			labelList.Add(newLabel);
		}

		public void ReduceLabel(string title, int layer = 0)
		{
			foreach (AttrLabelEntity label in labelList)
			{
				if (label.title != null && label.title.Equals(title))
				{
					label.layer -= layer;
					if (label.layer < 1)
					{
						labelList.Remove(label);
					}
					return;
				}
			}
		}

		public int GetLabel(string title)
		{
			foreach (AttrLabelEntity label in labelList)
			{
				if (label.title != null && label.title.Equals(title))
				{
					return label.layer;
				}
			}
			return 0;
		}

		public bool HasLabel(string title)
		{
			foreach (AttrLabelEntity label in labelList)
			{
				if (label.title != null && label.title.Equals(title))
				{
					return true;
				}
			}
			return false;
		}
	}
}
