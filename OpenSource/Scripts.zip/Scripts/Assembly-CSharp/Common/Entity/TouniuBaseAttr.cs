using System;
using System.Collections.Generic;
using Game.Entity;
using UnityEngine;

namespace Common.Entity
{
	[Serializable]
	public class TouniuBaseAttr
	{
		[Tooltip("总血量")]
		public float maxHealth;

		[Tooltip("当前血量")]
		public float currentHealth;

		[Tooltip("无敌")]
		public bool isInvincible;

		[Tooltip("攻击力")]
		public int attack;

		[Tooltip("魔法力")]
		public int magic;

		[Tooltip("攻击速度")]
		[HideInInspector]
		public float attackSpeed;

		[HideInInspector]
		public float attackIntervalTime;

		[HideInInspector]
		public float attackIntervalTimer;

		[Tooltip("值集合")]
		public List<ValueEntity> valueList;

		[Tooltip("标签集合")]
		public List<AttrLabelEntity> labelList;

		[Tooltip("攻击速度")]
		public float AttackSpeed
		{
			get
			{
				return 0f;
			}
			set
			{
			}
		}

		public TouniuBaseAttr()
		{
		}

		public TouniuBaseAttr(TouniuBaseAttr attr)
		{
		}

		public void AddAttr(TouniuBaseAttr attr)
		{
		}

		public void Reset()
		{
		}

		public float GetValue(int index = 0)
		{
			return 0f;
		}

		public int GetValueInt(int index = 0)
		{
			return 0;
		}

		public float GetValue(string title)
		{
			return 0f;
		}

		public int GetValueInt(string fieldName)
		{
			return 0;
		}

		public void AddLabel(string title, int layer = 0, string desc = "")
		{
		}

		public void ReduceLabel(string title, int layer = 0)
		{
		}

		public int GetLabel(string title)
		{
			return 0;
		}

		public bool HasLabel(string title)
		{
			return false;
		}
	}
}
