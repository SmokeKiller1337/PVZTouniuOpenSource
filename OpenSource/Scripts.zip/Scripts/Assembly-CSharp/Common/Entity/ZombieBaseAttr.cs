using System;
using System.Collections.Generic;
using Game.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Common.Entity
{
	[Serializable]
	public class ZombieBaseAttr
	{
		[Tooltip("总血量")]
		[Header("---血量")]
		public float maxHealth;

		[Tooltip("当前血量")]
		public float currentHealth;

		[Tooltip("1类防具血量")]
		public float arm1MaxHealth;

		public float arm1CurrentHealth;

		[Tooltip("2类防具血量")]
		public float arm2MaxHealth;

		public float arm2CurrentHealth;

		[Header("---属性")]
		[Tooltip("无敌")]
		public bool isInvincible;

		[Tooltip("不可选取0")]
		public bool isNotPick0;

		[Tooltip("不可选取1")]
		public bool isNotPick1;

		[Tooltip("不可选取2")]
		public bool isNotPick2;

		[Tooltip("移动速度")]
		public float walkSpeedRatio;

		[Tooltip("攻击力")]
		public int attack;

		[Tooltip("魔法力")]
		public int magic;

		[Tooltip("攻击速度")]
		[HideInInspector]
		public float attackSpeed;

		[HideInInspector]
		public float attackIntervalTime;

		[HideInInspector]
		public float attackIntervalTimer;

		[Tooltip("值集合")]
		public List<ValueEntity> valueList;

		[Tooltip("标签集合")]
		public List<AttrLabelEntity> labelList;

		private const float MaxAttackSpeed = 20f;

		[Tooltip("攻击速度")]
		public float AttackSpeed
		{
			get
			{
				return attackSpeed;
			}
			set
			{
				attackSpeed = value;
				if (value > MaxAttackSpeed)
				{
					attackSpeed = MaxAttackSpeed;
				}
				attackIntervalTime = 1f / attackSpeed;
			}
		}

		public float HealthRatio => (arm1CurrentHealth + currentHealth + arm2CurrentHealth) /
			(arm1MaxHealth + maxHealth + arm2MaxHealth);

		public ZombieBaseAttr()
		{
			maxHealth = 100f;      // 0x42c80000
			walkSpeedRatio = 1f;   // 0x3f800000
			attack = 50;           // 0x32
			attackSpeed = 0.9f;    // 0x3fe66666
		}

		public ZombieBaseAttr(ZombieBaseAttr attr)
		{
			maxHealth = 100f;
			walkSpeedRatio = 1f;
			attack = 50;
			attackSpeed = 0.9f;

			if (attr != null)
			{
				maxHealth = attr.maxHealth;
				currentHealth = attr.currentHealth;
				arm1MaxHealth = attr.arm1MaxHealth;
				arm1CurrentHealth = attr.arm1CurrentHealth;
				arm2MaxHealth = attr.arm2MaxHealth;
				arm2CurrentHealth = attr.arm2CurrentHealth;
				isInvincible = attr.isInvincible;
				isNotPick0 = attr.isNotPick0;
				isNotPick1 = attr.isNotPick1;
				isNotPick2 = attr.isNotPick2;
				attack = attr.attack;
				magic = attr.magic;

				// Go through the AttackSpeed clamp path (writes attackSpeed + attackIntervalTime).
				AttackSpeed = attr.attackSpeed;

				walkSpeedRatio = attr.walkSpeedRatio;

				valueList = new List<ValueEntity>();
				if (attr.valueList != null)
				{
					foreach (ValueEntity value in attr.valueList)
					{
						valueList.Add((ValueEntity)value.Clone());
					}
				}

				labelList = new List<AttrLabelEntity>();
				if (attr.labelList != null)
				{
					foreach (AttrLabelEntity label in attr.labelList)
					{
						// AttrLabelEntity implements ICloneable; Clone() returns object, so cast back.
						labelList.Add((AttrLabelEntity)label.Clone());
					}
				}
			}
		}

		public void Reset()
		{
			currentHealth = maxHealth;
			arm1CurrentHealth = arm1MaxHealth;
			arm2CurrentHealth = arm2MaxHealth;
			isInvincible = false;

			// Re-run the AttackSpeed clamp/interval computation with the current value.
			AttackSpeed = attackSpeed;

			labelList = new List<AttrLabelEntity>();
		}

		public float GetValue(ZombieEntity zombieEntity, int index = 0)
		{
			ValueEntity valueEntity = valueList[index];
			float value = valueEntity.GetValue(zombieEntity);
			return value;
		}

		public int GetValueInt(ZombieEntity zombieEntity, int index = 0)
		{
			ValueEntity valueEntity = valueList[index];
			return (int)valueEntity.GetValue(zombieEntity);
		}

		public float GetValue(ZombieEntity zombieEntity, string title)
		{
			foreach (ValueEntity valueEntity in valueList)
			{
				if (valueEntity.title != null && valueEntity.title.Equals(title))
				{
					return valueEntity.GetValue(zombieEntity);
				}
			}

			throw new Exception("Not found value: " + title);
		}

		public int GetValueInt(ZombieEntity zombieEntity, string fieldName)
		{
			return (int)GetValue(zombieEntity, fieldName);
		}

		public void AddLabel(string title, int layer = 0, string desc = "")
		{
			foreach (AttrLabelEntity label in labelList)
			{
				if (label.title != null && label.title.Equals(title))
				{
					label.layer += layer;
					if (desc != null && desc.Length > 0)
					{
						label.desc = desc;
					}
					return;
				}
			}

			AttrLabelEntity newLabel = new AttrLabelEntity();
			newLabel.title = title;
			newLabel.layer = layer;
			newLabel.desc = desc;
			labelList.Add(newLabel);
		}

		public void ReduceLabel(string title, int layer = 0)
		{
			foreach (AttrLabelEntity label in labelList)
			{
				if (label.title != null && label.title.Equals(title))
				{
					label.layer -= layer;
					if (label.layer < 1)
					{
						labelList.Remove(label);
					}
					return;
				}
			}
		}

		public int GetLabel(string title)
		{
			foreach (AttrLabelEntity label in labelList)
			{
				if (label.title != null && label.title.Equals(title))
				{
					return label.layer;
				}
			}
			return 0;
		}

		public bool HasLabel(string title)
		{
			foreach (AttrLabelEntity label in labelList)
			{
				if (label.title != null && label.title.Equals(title))
				{
					return true;
				}
			}
			return false;
		}
	}
}
