using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Plant.Enum;
using Touniu.Entity.Body;
using UnityEngine;

namespace Common.Entity
{
	public class AttrDetector : MonoBehaviour
	{
		[CompilerGenerated]
		private sealed class _003CClickTarget_003Ed__21 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public BaseBody baseBody;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CClickTarget_003Ed__21(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					// yield return null; (wait one frame before opening the attribute panel)
					_003C_003E2__current = null;
					_003C_003E1__state = 1;
					return true;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (baseBody == null)
				{
					throw new NullReferenceException();
				}
				// The decompiled state machine opens the plant attribute box when the
				// hit body is a plant, and the zombie attribute box when it is a zombie,
				// via an AttrBox UI singleton (FGUI.Entity.UI.AttrBoxEntity). Those
				// concrete entity/UI members are not present in the reconstruction
				// inputs, so the dispatch is left unreconstructed.
				// TODO: reconstruct — AttrBoxEntity.OpenPlant(baseBody) / OpenZombie(baseBody)
				//       based on the runtime type of baseBody.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CClickTarget_003Ed__22 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuBaseBody baseBody;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CClickTarget_003Ed__22(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					// yield return null; (wait one frame before showing attributes)
					_003C_003E2__current = null;
					_003C_003E1__state = 1;
					return true;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (baseBody == null)
				{
					throw new NullReferenceException();
				}
				// Decompilation calls Touniu.Entity.Body.TouniuBaseBody.ShowAttr().
				// TODO: reconstruct — baseBody.ShowAttr();  (method not present in inputs)
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		public List<Camera> cameras;

		public LayerMask zombieLayer;

		public LayerMask plantLayer;

		public LayerMask touniuLayer;

		[Tooltip("双击时间间隔(秒)")]
		public float doubleClickThreshold;

		private float lastLeftClickTime;

		private GameObject lastClickedObject;

		private Camera mainCamera;

		private LayerMask combinedLayers;

		private Touch currentTouch;

		private float touchStartTime;

		private Vector2 touchStartPosition;

		private GameObject currentHitObject;

		private bool isTouchActive;

		private readonly Dictionary<PlaceType, int> _typePriority;

		public AttrDetector()
		{
			cameras = new List<Camera>();
			// 0x3E99999A == 0.3f
			doubleClickThreshold = 0.3f;
			_typePriority = new Dictionary<PlaceType, int>
			{
				// Keys are PlaceType enum members; the dump stores underlying ints
				// 0, 3, 1, 2 mapped to priorities 4, 3, 2, 1 respectively.
				{ (PlaceType)0, 4 },
				{ (PlaceType)3, 3 },
				{ (PlaceType)1, 2 },
				{ (PlaceType)2, 1 }
			};
		}

		private void Start()
		{
			if (mainCamera == null)
			{
				mainCamera = Camera.main;
			}
			if (cameras == null)
			{
				return;
			}
			if (cameras.Count == 0)
			{
				cameras.AddRange(UnityEngine.Object.FindObjectsOfType<Camera>());
				// b__15_0: remove disabled cameras.
				cameras.RemoveAll((Camera camera) => !camera.enabled);
			}
			zombieLayer = LayerMask.GetMask("Zombie"); // TODO: confirm layer name string
			plantLayer = LayerMask.GetMask("Plant");   // TODO: confirm layer name string
			touniuLayer = LayerMask.GetMask("Touniu");  // TODO: confirm layer name string
			combinedLayers = zombieLayer.value | plantLayer.value | touniuLayer.value;
		}

		private void Update()
		{
			// Decompilation first ticks a UI-manager singleton (virtual call at vtable
			// +0x198) and reads a mode flag off a settings/config singleton, then
			// dispatches to either HandlePCInput() or HandleMobileInput(). Neither the
			// UI-manager nor the platform-mode member is present in the reconstruction
			// inputs, so the guard/dispatch cannot be reliably rebuilt.
			// TODO: reconstruct — e.g.
			//   UIManager.Instance.Tick();
			//   if (isMobilePlatform) HandleMobileInput(); else HandlePCInput();
		}

		private void HandlePCInput()
		{
			if (!Input.GetMouseButtonDown(1))
			{
				return;
			}
			if (cameras == null)
			{
				throw new NullReferenceException();
			}
			// b__17_0: order cameras by depth ascending.
			cameras.Sort((Camera x, Camera y) => x.depth.CompareTo(y.depth));
			foreach (Camera camera in cameras)
			{
				if (camera == null)
				{
					throw new NullReferenceException();
				}
				Ray ray = camera.ScreenPointToRay(Input.mousePosition);
				RaycastHit2D[] hits = Physics2D.RaycastAll(ray.origin, ray.direction, float.PositiveInfinity, combinedLayers);
				if (hits == null)
				{
					throw new NullReferenceException();
				}
				if (hits.Length != 0)
				{
					RaycastHit2D? prioritizedHit = GetPrioritizedHit(hits);
					if (prioritizedHit.HasValue)
					{
						HandleHit(prioritizedHit.Value.collider);
						return;
					}
				}
			}
		}

		private void HandleMobileInput()
		{
			if (!Input.GetMouseButtonDown(0))
			{
				return;
			}
			Vector3 mousePosition = Input.mousePosition;
			if (mainCamera == null)
			{
				throw new NullReferenceException();
			}
			mousePosition.z = 0f;
			Ray ray = mainCamera.ScreenPointToRay(mousePosition);
			RaycastHit2D[] hits = Physics2D.RaycastAll(ray.origin, ray.direction, float.PositiveInfinity, combinedLayers);
			if (hits == null)
			{
				throw new NullReferenceException();
			}
			if (hits.Length == 0)
			{
				return;
			}
			RaycastHit2D? prioritizedHit = GetPrioritizedHit(hits);
			if (!prioritizedHit.HasValue)
			{
				return;
			}
			Collider2D hitCollider = prioritizedHit.Value.collider;
			if (hitCollider == null)
			{
				throw new NullReferenceException();
			}
			GameObject hitObject = hitCollider.gameObject;
			if (Time.unscaledTime - lastLeftClickTime < doubleClickThreshold && hitObject == lastClickedObject)
			{
				HandleHit(prioritizedHit.Value.collider);
				lastLeftClickTime = 0f;
				lastClickedObject = null;
				return;
			}
			lastLeftClickTime = Time.unscaledTime;
			lastClickedObject = hitObject;
		}

		private RaycastHit2D? GetPrioritizedHit(RaycastHit2D[] hits)
		{
			if (hits == null)
			{
				throw new NullReferenceException();
			}
			// First pass: prefer any hit whose collider carries a TouniuBaseBody.
			for (int i = 0; i < hits.Length; i++)
			{
				RaycastHit2D hit = hits[i];
				Collider2D collider = hit.collider;
				if (collider == null)
				{
					throw new NullReferenceException();
				}
				TouniuBaseBody touniuBody = collider.GetComponent<TouniuBaseBody>();
				if (touniuBody != null)
				{
					return hit;
				}
			}
			// Second pass: prefer any hit whose collider carries a BaseBody.
			for (int j = 0; j < hits.Length; j++)
			{
				RaycastHit2D hit = hits[j];
				Collider2D collider = hit.collider;
				if (collider == null)
				{
					throw new NullReferenceException();
				}
				BaseBody body = collider.GetComponent<BaseBody>();
				if (body != null)
				{
					return hit;
				}
			}
			// Otherwise fall back to the first hit if any, else null.
			if (hits.Length == 0)
			{
				return null;
			}
			return hits[0];
		}

		private void HandleHit(Collider2D collider1)
		{
			// The decompilation guards on a global gameplay/level context singleton
			// being present and a positive "round active" value, then re-raycasts from
			// the mouse, collects the nearest TouniuBaseBody, and if none is found
			// falls back to GetPrioritizedBodyCollider; finally it StartCoroutine()s the
			// matching ClickTarget overload. The gameplay-context singleton and its
			// gating field are not present in the reconstruction inputs, so the guard
			// cannot be rebuilt without fabricating members.
			//
			// The reconstructable tail (re-raycast + dispatch) is shown below but is
			// intentionally not wired up because it depends on that missing guard.
			//
			// TODO: reconstruct the leading gameplay-context guard, then:
			//   Ray ray = mainCamera.ScreenPointToRay(Input.mousePosition);
			//   RaycastHit2D[] hits = Physics2D.RaycastAll(ray.origin, ray.direction, float.PositiveInfinity, combinedLayers);
			//   if (hits == null || hits.Length == 0) return;
			//   TouniuBaseBody touniuBody = GetPrioritizedTouniuBody(hits);
			//   if (touniuBody != null) { StartCoroutine(ClickTarget(touniuBody)); return; }
			//   BaseBody body = GetPrioritizedBodyCollider(hits);
			//   if (body != null) StartCoroutine(ClickTarget(body));
		}

		[IteratorStateMachine(typeof(_003CClickTarget_003Ed__21))]
		private IEnumerator ClickTarget(BaseBody baseBody)
		{
			return new _003CClickTarget_003Ed__21(0)
			{
				baseBody = baseBody
			};
		}

		[IteratorStateMachine(typeof(_003CClickTarget_003Ed__22))]
		private IEnumerator ClickTarget(TouniuBaseBody baseBody)
		{
			return new _003CClickTarget_003Ed__22(0)
			{
				baseBody = baseBody
			};
		}

		private TouniuBaseBody GetPrioritizedTouniuBody(RaycastHit2D[] hits)
		{
			if (hits == null)
			{
				throw new NullReferenceException();
			}
			TouniuBaseBody result = null;
			float nearest = float.PositiveInfinity;
			for (int i = 0; i < hits.Length; i++)
			{
				RaycastHit2D hit = hits[i];
				Collider2D collider = hit.collider;
				if (collider == null)
				{
					throw new NullReferenceException();
				}
				TouniuBaseBody body = collider.GetComponent<TouniuBaseBody>();
				if (body != null && hit.distance < nearest)
				{
					nearest = hit.distance;
					result = body;
				}
			}
			return result;
		}

		private BaseBody GetPrioritizedBodyCollider(RaycastHit2D[] hits)
		{
			// The decompilation builds a local PlaceType->priority table (identical to
			// _typePriority), then partitions BaseBody hits into a zombie list of
			// (body, distance) and a plant list of (body, priority, distance) keyed off
			// each plant's CardEntity.PlaceType. Zombies win by nearest distance; plants
			// win by highest priority then nearest distance. The body's owning entity,
			// the PlantEntity.CardEntity accessor, and the ZombieEntity/PlantEntity types
			// are not present in the reconstruction inputs, so this selection cannot be
			// rebuilt without fabricating cross-class members.
			//
			// TODO: reconstruct — see structure above; requires BaseBody entity accessor,
			//       PlantEntity.CardEntity.PlaceType, and ZombieEntity/PlantEntity types.
			return null;
		}
	}
}
