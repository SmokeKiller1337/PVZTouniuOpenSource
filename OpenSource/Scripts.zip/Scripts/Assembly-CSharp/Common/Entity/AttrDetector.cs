using System;
using System.Collections;
using System.Collections.Generic;
using Plant.Enum;
using Touniu.Entity.Body;
using UnityEngine;

namespace Common.Entity
{
	public class AttrDetector : MonoBehaviour
	{
		public List<Camera> cameras;

		public LayerMask zombieLayer;

		public LayerMask plantLayer;

		public LayerMask touniuLayer;

		[Tooltip("双击时间间隔(秒)")]
		public float doubleClickThreshold;

		private float lastLeftClickTime;

		private GameObject lastClickedObject;

		private Camera mainCamera;

		private LayerMask combinedLayers;

		private Touch currentTouch;

		private float touchStartTime;

		private Vector2 touchStartPosition;

		private GameObject currentHitObject;

		private bool isTouchActive;

		private readonly Dictionary<PlaceType, int> _typePriority;

		public AttrDetector()
		{
			cameras = new List<Camera>();
			// 0x3E99999A == 0.3f
			doubleClickThreshold = 0.3f;
			_typePriority = new Dictionary<PlaceType, int>
			{
				// Keys are PlaceType enum members; the dump stores underlying ints
				// 0, 3, 1, 2 mapped to priorities 4, 3, 2, 1 respectively.
				{ (PlaceType)0, 4 },
				{ (PlaceType)3, 3 },
				{ (PlaceType)1, 2 },
				{ (PlaceType)2, 1 }
			};
		}

		private void Start()
		{
			if (mainCamera == null)
			{
				mainCamera = Camera.main;
			}
			if (cameras == null)
			{
				return;
			}
			if (cameras.Count == 0)
			{
				cameras.AddRange(UnityEngine.Object.FindObjectsOfType<Camera>());
				// b__15_0: remove disabled cameras.
				cameras.RemoveAll((Camera camera) => !camera.enabled);
			}
			zombieLayer = LayerMask.GetMask("Zombie"); // TODO: confirm layer name string
			plantLayer = LayerMask.GetMask("Plant");   // TODO: confirm layer name string
			touniuLayer = LayerMask.GetMask("Touniu");  // TODO: confirm layer name string
			combinedLayers = zombieLayer.value | plantLayer.value | touniuLayer.value;
		}

		private void Update()
		{
		}

		private void HandlePCInput()
		{
			if (!Input.GetMouseButtonDown(1))
			{
				return;
			}
			if (cameras == null)
			{
				throw new NullReferenceException();
			}
			// b__17_0: order cameras by depth ascending.
			cameras.Sort((Camera x, Camera y) => x.depth.CompareTo(y.depth));
			foreach (Camera camera in cameras)
			{
				if (camera == null)
				{
					throw new NullReferenceException();
				}
				Ray ray = camera.ScreenPointToRay(Input.mousePosition);
				RaycastHit2D[] hits = Physics2D.RaycastAll(ray.origin, ray.direction, float.PositiveInfinity, combinedLayers);
				if (hits == null)
				{
					throw new NullReferenceException();
				}
				if (hits.Length != 0)
				{
					RaycastHit2D? prioritizedHit = GetPrioritizedHit(hits);
					if (prioritizedHit.HasValue)
					{
						HandleHit(prioritizedHit.Value.collider);
						return;
					}
				}
			}
		}

		private void HandleMobileInput()
		{
			if (!Input.GetMouseButtonDown(0))
			{
				return;
			}
			Vector3 mousePosition = Input.mousePosition;
			if (mainCamera == null)
			{
				throw new NullReferenceException();
			}
			mousePosition.z = 0f;
			Ray ray = mainCamera.ScreenPointToRay(mousePosition);
			RaycastHit2D[] hits = Physics2D.RaycastAll(ray.origin, ray.direction, float.PositiveInfinity, combinedLayers);
			if (hits == null)
			{
				throw new NullReferenceException();
			}
			if (hits.Length == 0)
			{
				return;
			}
			RaycastHit2D? prioritizedHit = GetPrioritizedHit(hits);
			if (!prioritizedHit.HasValue)
			{
				return;
			}
			Collider2D hitCollider = prioritizedHit.Value.collider;
			if (hitCollider == null)
			{
				throw new NullReferenceException();
			}
			GameObject hitObject = hitCollider.gameObject;
			if (Time.unscaledTime - lastLeftClickTime < doubleClickThreshold && hitObject == lastClickedObject)
			{
				HandleHit(prioritizedHit.Value.collider);
				lastLeftClickTime = 0f;
				lastClickedObject = null;
				return;
			}
			lastLeftClickTime = Time.unscaledTime;
			lastClickedObject = hitObject;
		}

		private RaycastHit2D? GetPrioritizedHit(RaycastHit2D[] hits)
		{
			if (hits == null)
			{
				throw new NullReferenceException();
			}
			// First pass: prefer any hit whose collider carries a TouniuBaseBody.
			for (int i = 0; i < hits.Length; i++)
			{
				RaycastHit2D hit = hits[i];
				Collider2D collider = hit.collider;
				if (collider == null)
				{
					throw new NullReferenceException();
				}
				TouniuBaseBody touniuBody = collider.GetComponent<TouniuBaseBody>();
				if (touniuBody != null)
				{
					return hit;
				}
			}
			// Second pass: prefer any hit whose collider carries a BaseBody.
			for (int j = 0; j < hits.Length; j++)
			{
				RaycastHit2D hit = hits[j];
				Collider2D collider = hit.collider;
				if (collider == null)
				{
					throw new NullReferenceException();
				}
				BaseBody body = collider.GetComponent<BaseBody>();
				if (body != null)
				{
					return hit;
				}
			}
			// Otherwise fall back to the first hit if any, else null.
			if (hits.Length == 0)
			{
				return null;
			}
			return hits[0];
		}

		private void HandleHit(Collider2D collider1)
		{
		}

		private IEnumerator ClickTarget(BaseBody baseBody)
		{
			// 等待一帧后再打开属性面板
			yield return null;
			if (baseBody == null)
			{
				throw new NullReferenceException();
			}
		}

		private IEnumerator ClickTarget(TouniuBaseBody baseBody)
		{
			// 等待一帧后再显示属性
			yield return null;
			if (baseBody == null)
			{
				throw new NullReferenceException();
			}
		}

		private TouniuBaseBody GetPrioritizedTouniuBody(RaycastHit2D[] hits)
		{
			if (hits == null)
			{
				throw new NullReferenceException();
			}
			TouniuBaseBody result = null;
			float nearest = float.PositiveInfinity;
			for (int i = 0; i < hits.Length; i++)
			{
				RaycastHit2D hit = hits[i];
				Collider2D collider = hit.collider;
				if (collider == null)
				{
					throw new NullReferenceException();
				}
				TouniuBaseBody body = collider.GetComponent<TouniuBaseBody>();
				if (body != null && hit.distance < nearest)
				{
					nearest = hit.distance;
					result = body;
				}
			}
			return result;
		}

		private BaseBody GetPrioritizedBodyCollider(RaycastHit2D[] hits)
		{
			return null;
		}
	}
}
