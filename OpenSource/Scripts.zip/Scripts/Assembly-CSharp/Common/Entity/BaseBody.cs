using System;
using System.Collections;
using System.Collections.Generic;
using Bullet.Entity;
using Common.Enum;
using DG.Tweening;
using FairyGUI;
using Land.Entity;
using Level.Entity;
using Level.Enum;
using NoSLoofah.BuffSystem;
using Plant.Entity;
using Reanim2UnityAnim;
using UnityEngine;
using UnityEngine.Rendering;
using Zombie.Entity;

namespace Common.Entity
{
	public abstract class BaseBody : MonoBehaviour
	{
		private const float FLICKER_HIGHLIGHT_TARGET = 1f;
		private const float FLICKER_HIGHLIGHT_RESET = 0f;
		private const int FLICKER_HIGHLIGHT_PROPERTY = 0; // TODO: real shader property id
		private const float FLICKER_DURATION = 0f; // TODO: real tween duration
		private const float FLICKER_INTERVAL = 0f; // TODO: real WaitForSeconds interval
		private const float HIGHLIGHT_ON_VALUE = 1f; // TODO: real highlight SetFloat value

		[Tooltip("编号")]
		public int id;

		[Tooltip("名称")]
		public string title;

		[Tooltip("子弹集合")]
		public List<BulletAttr> bulletList;

		[Tooltip("免疫Buff集合")]
		public List<int> immuneBuffIdList;

		[HideInInspector]
		public List<LandEntity> currentLandList;

		[HideInInspector]
		public GameObject mainBodyObj;

		[HideInInspector]
		public SpriteRenderer shadowSpriteRenderer;

		[HideInInspector]
		public GameObject sleepObj;

		[HideInInspector]
		public GameObject spriteObj;

		[HideInInspector]
		public GameObject spriteListObj;

		[HideInInspector]
		public int priority;

		[HideInInspector]
		public int addSortingOrder;

		protected Animator _animator;

		protected Rigidbody2D _rigidbody;

		protected BuffHandler _buffHandler;

		protected Collider2D _bodyCollider2D;

		protected SortingGroup _sortingGroup;

		protected UniqueMaterialController _reanimSpriteEntity;

		protected bool _isHighlight;

		protected bool _isFlicker;

		protected DamageTypeEntity _lastDamageType;

		[HideInInspector]
		public Transform uiTransform;

		protected GComponent _healthCom;

		protected GTextField _healthTextField;

		[HideInInspector]
		public long onlyId;

		private static long _nextOnlyId;

		public Action OnDeathAction;

		public virtual LandEntity CurrentLandEntity
		{
			get
			{
				// Returns null when the list is empty, otherwise the first element.
				if (currentLandList.Count < 1)
				{
					return null;
				}
				return currentLandList[0];
			}
			set
			{
			}
		}

		public bool IsInWater
		{
			get
			{
				if (CurrentLandEntity == null)
				{
					return false;
				}
				return false;
			}
		}

		public DamageTypeEntity LastDamageType
		{
			get
			{
				return _lastDamageType;
			}
			set
			{
				_lastDamageType = value;
			}
		}

		public Rigidbody2D Rigidbody
		{
			get
			{
				return _rigidbody;
			}
			set
			{
				_rigidbody = value;
			}
		}

		public Collider2D Collider2D
		{
			get
			{
				return _bodyCollider2D;
			}
			set
			{
				_bodyCollider2D = value;
			}
		}

		public BuffHandler BuffHandler
		{
			get
			{
				return _buffHandler;
			}
			set
			{
				_buffHandler = value;
			}
		}

		public Animator Animator
		{
			get
			{
				return _animator;
			}
			set
			{
				_animator = value;
			}
		}

		public SortingGroup SortingGroup
		{
			get
			{
				return _sortingGroup;
			}
			set
			{
				_sortingGroup = value;
			}
		}

		public UniqueMaterialController ReanimSpriteEntity
		{
			get
			{
				return _reanimSpriteEntity;
			}
			set
			{
				_reanimSpriteEntity = value;
			}
		}

		public bool IsFlipX
		{
			get
			{
				// Flipped when local scale X is negative.
				return base.transform.localScale.x < 0f;
			}
		}

		private static long GetNextOnlyId()
		{
			// Post-increment of the static counter, returning the previous value.
			return _nextOnlyId++;
		}

		public virtual void Reset()
		{
			onlyId = GetNextOnlyId();
			if (_buffHandler != null)
			{
				_buffHandler.Reset();
			}
			OnDeathAction = null;
			_isHighlight = false;
			_isFlicker = false;
			_lastDamageType = DamageTypeEntity.Common;
			if (_reanimSpriteEntity != null && _reanimSpriteEntity.spriteRenderers != null)
			{
				foreach (SpriteRenderer spriteRenderer in _reanimSpriteEntity.spriteRenderers)
				{
					if (spriteRenderer == null)
					{
						return;
					}
					spriteRenderer.color = Color.white;
					if (spriteRenderer.material == null)
					{
						return;
					}
					// TODO: shader property id / reset value unresolved.
					spriteRenderer.material.SetFloat(FLICKER_HIGHLIGHT_PROPERTY, FLICKER_HIGHLIGHT_RESET);
				}
			}
			if (shadowSpriteRenderer != null)
			{
				Color color = shadowSpriteRenderer.color;
				color.a = 1f;
				shadowSpriteRenderer.color = color;
			}
			UpdateSortingOrder();
		}

		protected virtual void Awake()
		{
			Transform child = base.GetComponentInChildren<Transform>(true);
			_bodyCollider2D = child.GetComponent<Collider2D>();
		}

		protected virtual void Start()
		{
			UIPanel componentInChildren = base.GetComponentInChildren<UIPanel>();
			if (componentInChildren != null)
			{
				_healthCom = componentInChildren.ui;
				_healthTextField = componentInChildren.ui.GetChild(HEALTH_TEXT_CHILD_NAME).asTextField;
			}
			ResetShowHealth();
			UpdateSortingOrder();
		}

		private const string HEALTH_TEXT_CHILD_NAME = "healthText";

		protected virtual void Update()
		{
			UpdateSortingOrder();
		}

		public void Highlight(bool isHighlight = true)
		{
			if (!base.enabled)
			{
				return;
			}
			_isHighlight = isHighlight;
			if (_reanimSpriteEntity == null || _reanimSpriteEntity.spriteRenderers == null)
			{
				return;
			}
			foreach (SpriteRenderer spriteRenderer in _reanimSpriteEntity.spriteRenderers)
			{
				if (spriteRenderer == null || spriteRenderer.material == null)
				{
					return;
				}
				// TODO: shader property id / highlight value unresolved.
				spriteRenderer.material.SetFloat(FLICKER_HIGHLIGHT_PROPERTY, HIGHLIGHT_ON_VALUE);
			}
		}

		public void Flicker(DamageType type = DamageType.Common, bool isBackAttack = false)
		{
			if (base.enabled)
			{
				StartCoroutine(FlickerCoroutine(type, isBackAttack));
			}
		}

		protected virtual IEnumerator FlickerCoroutine(DamageType type, bool isBackAttack)
		{
			// 已高亮或已在闪烁时直接跳过
			if (_isHighlight)
			{
				yield break;
			}
			if (_isFlicker)
			{
				yield break;
			}
			_isFlicker = true;
			if (_reanimSpriteEntity == null)
			{
				yield break;
			}
			List<SpriteRenderer> spriteRenderers = _reanimSpriteEntity.spriteRenderers;
			if (spriteRenderers == null)
			{
				yield break;
			}
			// 将所有 SpriteRenderer 材质设为高亮
			foreach (SpriteRenderer spriteRenderer in spriteRenderers)
			{
				if (spriteRenderer == null)
				{
					yield break;
				}
				spriteRenderer.material.DOFloat(FLICKER_HIGHLIGHT_TARGET, FLICKER_HIGHLIGHT_PROPERTY, FLICKER_DURATION);
			}
			yield return new WaitForSeconds(FLICKER_INTERVAL);
			if (spriteRenderers == null)
			{
				yield break;
			}
			// 将所有 SpriteRenderer 材质高亮还原为 0
			foreach (SpriteRenderer spriteRenderer2 in spriteRenderers)
			{
				if (spriteRenderer2 == null)
				{
					yield break;
				}
				spriteRenderer2.material.DOFloat(FLICKER_HIGHLIGHT_RESET, FLICKER_HIGHLIGHT_PROPERTY, FLICKER_DURATION);
			}
			yield return new WaitForSeconds(FLICKER_INTERVAL);
			if (this != null)
			{
				_isFlicker = false;
			}
		}

		public string GetCurrentAnimationName()
		{
			if (_animator != null)
			{
				AnimatorClipInfo[] currentAnimatorClipInfo = _animator.GetCurrentAnimatorClipInfo(0);
				if (currentAnimatorClipInfo != null)
				{
					if (currentAnimatorClipInfo.Length == 0)
					{
						return string.Empty;
					}
					AnimationClip clip = currentAnimatorClipInfo[0].clip;
					if (clip != null)
					{
						return clip.name;
					}
				}
			}
			return null;
		}

		public virtual void ResetShowHealth()
		{
			if (_healthCom == null)
			{
				return;
			}
		}

		public float GetAttrValue(AttrEnum attrEnum)
		{
			return 0f;
		}

		public void ShowAttr()
		{
		}

		public abstract void ChangeMaxHealthAndShow(float value);

		public abstract void ChangeAttackAndShow(int value);

		public abstract void ChangeMagicAndShow(int value);

		public abstract void ChangeAttackSpeedAndShow(float ratio);

		public abstract bool Hit(float value, DamageTypeEntity damageType = null, BulletEntity sourceBullet = null);

		public abstract void HitEat(float value, ZombieEntity zombieEntity);

		public abstract void ChangeHealth(float value);

		public abstract void ChangeMaxHealth(float value);

		public abstract void Death();

		public abstract void DeathHandle();

		public abstract void Clear();

		public abstract void Remove();

		public abstract void OnTriggerBodyEnter(Collider2D col);

		public abstract void OnTriggerBodyExit(Collider2D col);

		public abstract void OnTriggerBodyStay(Collider2D col);

		public abstract void OnTriggerEatEnter(Collider2D col);

		public abstract void OnTriggerEatExit(Collider2D col);

		public abstract void OnTriggerEatStay(Collider2D col);

		public abstract void OnTriggerCustomEnter(Collider2D col, int index);

		public abstract void OnTriggerCustomExit(Collider2D col, int index);

		public abstract void OnTriggerCustomStay(Collider2D col, int index);

		public abstract Vector2 GetPosition();

		public abstract int GetRow();

		public abstract int GetColumn();

		public abstract bool IsNotPick0();

		public abstract bool IsNotPick();

		public abstract bool IsNotEat();

		protected abstract void UpdateHealthTextField();

		protected abstract void UpdateSortingOrder();

		public abstract void SetFlipX(bool isFlipX);

		protected BaseBody()
		{
			currentLandList = new List<LandEntity>();
			_lastDamageType = DamageTypeEntity.Common;
		}

		static BaseBody()
		{
			_nextOnlyId = 1L;
		}
	}
}
