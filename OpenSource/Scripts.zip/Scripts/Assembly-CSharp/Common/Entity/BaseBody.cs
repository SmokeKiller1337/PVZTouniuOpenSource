using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Bullet.Entity;
using Common.Enum;
using DG.Tweening;
using FairyGUI;
using Land.Entity;
using Level.Entity;
using Level.Enum;
using NoSLoofah.BuffSystem;
using Plant.Entity;
using Reanim2UnityAnim;
using UnityEngine;
using UnityEngine.Rendering;
using Zombie.Entity;

namespace Common.Entity
{
	public abstract class BaseBody : MonoBehaviour
	{
		[CompilerGenerated]
		private sealed class _003CFlickerCoroutine_003Ed__62 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public BaseBody _003C_003E4__this;

			private List<SpriteRenderer> _003CspriteRenderers_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CFlickerCoroutine_003Ed__62(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				BaseBody baseBody = _003C_003E4__this;
				switch (num)
				{
				default:
					return false;
				case 0:
				{
					_003C_003E1__state = -1;
					// Guard: skip if already highlighted or already flickering.
					if (baseBody._isHighlight)
					{
						return false;
					}
					if (baseBody._isFlicker)
					{
						return false;
					}
					baseBody._isFlicker = true;
					if (baseBody._reanimSpriteEntity == null)
					{
						return false;
					}
					_003CspriteRenderers_003E5__2 = baseBody._reanimSpriteEntity.spriteRenderers;
					if (_003CspriteRenderers_003E5__2 == null)
					{
						return false;
					}
					// Set flicker highlight on all sprite renderers' materials.
					foreach (SpriteRenderer spriteRenderer in _003CspriteRenderers_003E5__2)
					{
						if (spriteRenderer == null)
						{
							return false;
						}
						// TODO: property/duration constants unresolved in pseudocode.
						spriteRenderer.material.DOFloat(FLICKER_HIGHLIGHT_TARGET, FLICKER_HIGHLIGHT_PROPERTY, FLICKER_DURATION);
					}
					_003C_003E2__current = new WaitForSeconds(FLICKER_INTERVAL);
					_003C_003E1__state = 1;
					return true;
				}
				case 1:
				{
					_003C_003E1__state = -1;
					if (_003CspriteRenderers_003E5__2 == null)
					{
						return false;
					}
					// Restore flicker highlight back to zero on all sprite renderers' materials.
					foreach (SpriteRenderer spriteRenderer2 in _003CspriteRenderers_003E5__2)
					{
						if (spriteRenderer2 == null)
						{
							return false;
						}
						// TODO: property/duration constants unresolved in pseudocode.
						spriteRenderer2.material.DOFloat(FLICKER_HIGHLIGHT_RESET, FLICKER_HIGHLIGHT_PROPERTY, FLICKER_DURATION);
					}
					_003C_003E2__current = new WaitForSeconds(FLICKER_INTERVAL);
					_003C_003E1__state = 2;
					return true;
				}
				case 2:
					_003C_003E1__state = -1;
					if (baseBody != null)
					{
						baseBody._isFlicker = false;
					}
					return false;
				}
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		// TODO: shader property ids / durations were data pointers in the pseudocode; placeholders below.
		private const float FLICKER_HIGHLIGHT_TARGET = 1f;
		private const float FLICKER_HIGHLIGHT_RESET = 0f;
		private const int FLICKER_HIGHLIGHT_PROPERTY = 0; // TODO: real shader property id
		private const float FLICKER_DURATION = 0f; // TODO: real tween duration
		private const float FLICKER_INTERVAL = 0f; // TODO: real WaitForSeconds interval
		private const float HIGHLIGHT_ON_VALUE = 1f; // TODO: real highlight SetFloat value

		[Tooltip("编号")]
		public int id;

		[Tooltip("名称")]
		public string title;

		[Tooltip("子弹集合")]
		public List<BulletAttr> bulletList;

		[Tooltip("免疫Buff集合")]
		public List<int> immuneBuffIdList;

		[HideInInspector]
		public List<LandEntity> currentLandList;

		[HideInInspector]
		public GameObject mainBodyObj;

		[HideInInspector]
		public SpriteRenderer shadowSpriteRenderer;

		[HideInInspector]
		public GameObject sleepObj;

		[HideInInspector]
		public GameObject spriteObj;

		[HideInInspector]
		public GameObject spriteListObj;

		[HideInInspector]
		public int priority;

		[HideInInspector]
		public int addSortingOrder;

		protected Animator _animator;

		protected Rigidbody2D _rigidbody;

		protected BuffHandler _buffHandler;

		protected Collider2D _bodyCollider2D;

		protected SortingGroup _sortingGroup;

		protected UniqueMaterialController _reanimSpriteEntity;

		protected bool _isHighlight;

		protected bool _isFlicker;

		protected DamageTypeEntity _lastDamageType;

		[HideInInspector]
		public Transform uiTransform;

		protected GComponent _healthCom;

		protected GTextField _healthTextField;

		[HideInInspector]
		public long onlyId;

		private static long _nextOnlyId;

		public Action OnDeathAction;

		public virtual LandEntity CurrentLandEntity
		{
			get
			{
				// Returns null when the list is empty, otherwise the first element.
				if (currentLandList.Count < 1)
				{
					return null;
				}
				return currentLandList[0];
			}
			set
			{
				// TODO: reconstruct — pseudocode body throws (compiler-generated NotImplemented/abstract-ish stub).
			}
		}

		public bool IsInWater
		{
			get
			{
				// TODO: reconstruct — pseudocode reads CurrentLandEntity then compares a field at land
				// offset 0x28 to 1 (a water land-type). The member name on LandEntity is unknown, so the
				// null-guard is kept and the comparison is left as a stub to avoid inventing a member.
				if (CurrentLandEntity == null)
				{
					return false;
				}
				return false;
			}
		}

		public DamageTypeEntity LastDamageType
		{
			get
			{
				return _lastDamageType;
			}
			set
			{
				_lastDamageType = value;
			}
		}

		public Rigidbody2D Rigidbody
		{
			get
			{
				return _rigidbody;
			}
			set
			{
				_rigidbody = value;
			}
		}

		public Collider2D Collider2D
		{
			get
			{
				return _bodyCollider2D;
			}
			set
			{
				_bodyCollider2D = value;
			}
		}

		public BuffHandler BuffHandler
		{
			get
			{
				return _buffHandler;
			}
			set
			{
				_buffHandler = value;
			}
		}

		public Animator Animator
		{
			get
			{
				return _animator;
			}
			set
			{
				_animator = value;
			}
		}

		public SortingGroup SortingGroup
		{
			get
			{
				return _sortingGroup;
			}
			set
			{
				_sortingGroup = value;
			}
		}

		public UniqueMaterialController ReanimSpriteEntity
		{
			get
			{
				return _reanimSpriteEntity;
			}
			set
			{
				_reanimSpriteEntity = value;
			}
		}

		public bool IsFlipX
		{
			get
			{
				// Flipped when local scale X is negative.
				return base.transform.localScale.x < 0f;
			}
		}

		private static long GetNextOnlyId()
		{
			// Post-increment of the static counter, returning the previous value.
			return _nextOnlyId++;
		}

		public virtual void Reset()
		{
			onlyId = GetNextOnlyId();
			if (_buffHandler != null)
			{
				_buffHandler.Reset();
			}
			OnDeathAction = null;
			_isHighlight = false;
			_isFlicker = false;
			_lastDamageType = DamageTypeEntity.Common;
			if (_reanimSpriteEntity != null && _reanimSpriteEntity.spriteRenderers != null)
			{
				foreach (SpriteRenderer spriteRenderer in _reanimSpriteEntity.spriteRenderers)
				{
					if (spriteRenderer == null)
					{
						return;
					}
					// TODO: reset color constant was a data pointer; assumed white.
					spriteRenderer.color = Color.white;
					if (spriteRenderer.material == null)
					{
						return;
					}
					// TODO: shader property id / reset value unresolved.
					spriteRenderer.material.SetFloat(FLICKER_HIGHLIGHT_PROPERTY, FLICKER_HIGHLIGHT_RESET);
				}
			}
			if (shadowSpriteRenderer != null)
			{
				Color color = shadowSpriteRenderer.color;
				color.a = 1f;
				shadowSpriteRenderer.color = color;
			}
			UpdateSortingOrder();
		}

		protected virtual void Awake()
		{
			// TODO: component types looked up were data pointers; mainBodyObj / collider assumed.
			Transform child = base.GetComponentInChildren<Transform>(true);
			_bodyCollider2D = child.GetComponent<Collider2D>();
		}

		protected virtual void Start()
		{
			// TODO: the UIPanel component type is a data pointer; assumed UIPanel.
			UIPanel componentInChildren = base.GetComponentInChildren<UIPanel>();
			if (componentInChildren != null)
			{
				_healthCom = componentInChildren.ui;
				// TODO: child name "healthText" is a data pointer placeholder.
				_healthTextField = componentInChildren.ui.GetChild(HEALTH_TEXT_CHILD_NAME).asTextField;
			}
			ResetShowHealth();
			UpdateSortingOrder();
		}

		// TODO: FairyGUI child name resolved from a data pointer.
		private const string HEALTH_TEXT_CHILD_NAME = "healthText";

		protected virtual void Update()
		{
			UpdateSortingOrder();
		}

		public void Highlight(bool isHighlight = true)
		{
			if (!base.enabled)
			{
				return;
			}
			_isHighlight = isHighlight;
			if (_reanimSpriteEntity == null || _reanimSpriteEntity.spriteRenderers == null)
			{
				return;
			}
			foreach (SpriteRenderer spriteRenderer in _reanimSpriteEntity.spriteRenderers)
			{
				if (spriteRenderer == null || spriteRenderer.material == null)
				{
					return;
				}
				// TODO: shader property id / highlight value unresolved.
				spriteRenderer.material.SetFloat(FLICKER_HIGHLIGHT_PROPERTY, HIGHLIGHT_ON_VALUE);
			}
		}

		public void Flicker(DamageType type = DamageType.Common, bool isBackAttack = false)
		{
			if (base.enabled)
			{
				StartCoroutine(FlickerCoroutine(type, isBackAttack));
			}
		}

		[IteratorStateMachine(typeof(_003CFlickerCoroutine_003Ed__62))]
		protected virtual IEnumerator FlickerCoroutine(DamageType type, bool isBackAttack)
		{
			return new _003CFlickerCoroutine_003Ed__62(0)
			{
				_003C_003E4__this = this
			};
		}

		public string GetCurrentAnimationName()
		{
			if (_animator != null)
			{
				AnimatorClipInfo[] currentAnimatorClipInfo = _animator.GetCurrentAnimatorClipInfo(0);
				if (currentAnimatorClipInfo != null)
				{
					if (currentAnimatorClipInfo.Length == 0)
					{
						// TODO: pseudocode returns a cached string constant when empty; assumed empty string.
						return string.Empty;
					}
					AnimationClip clip = currentAnimatorClipInfo[0].clip;
					if (clip != null)
					{
						return clip.name;
					}
				}
			}
			return null;
		}

		public virtual void ResetShowHealth()
		{
			// TODO: reconstruct — this method's pseudocode is heavily obscured (ICF-folded FairyGUI/global-manager
			// internals with unresolved delegate combine logic). Preserving a conservative stub to avoid wrong logic.
			if (_healthCom == null)
			{
				return;
			}
		}

		public float GetAttrValue(AttrEnum attrEnum)
		{
			// TODO: reconstruct — pseudocode is a large type-check + switch that reads members
			// (PlantEntity.CardEntity, buff/attr lists) not present on BaseBody, and every arm falls
			// through to a throw. Cannot map to real BaseBody members without inventing them.
			return 0f;
		}

		public void ShowAttr()
		{
			// TODO: reconstruct — pseudocode dispatches into a global AttrBox UI manager (FGUI.Entity.UI.AttrBoxEntity)
			// via unresolved singleton pointers; none of the touched members exist on BaseBody. Left as stub.
		}

		public abstract void ChangeMaxHealthAndShow(float value);

		public abstract void ChangeAttackAndShow(int value);

		public abstract void ChangeMagicAndShow(int value);

		public abstract void ChangeAttackSpeedAndShow(float ratio);

		public abstract bool Hit(float value, DamageTypeEntity damageType = null, BulletEntity sourceBullet = null);

		public abstract void HitEat(float value, ZombieEntity zombieEntity);

		public abstract void ChangeHealth(float value);

		public abstract void ChangeMaxHealth(float value);

		public abstract void Death();

		public abstract void DeathHandle();

		public abstract void Clear();

		public abstract void Remove();

		public abstract void OnTriggerBodyEnter(Collider2D col);

		public abstract void OnTriggerBodyExit(Collider2D col);

		public abstract void OnTriggerBodyStay(Collider2D col);

		public abstract void OnTriggerEatEnter(Collider2D col);

		public abstract void OnTriggerEatExit(Collider2D col);

		public abstract void OnTriggerEatStay(Collider2D col);

		public abstract void OnTriggerCustomEnter(Collider2D col, int index);

		public abstract void OnTriggerCustomExit(Collider2D col, int index);

		public abstract void OnTriggerCustomStay(Collider2D col, int index);

		public abstract Vector2 GetPosition();

		public abstract int GetRow();

		public abstract int GetColumn();

		public abstract bool IsNotPick0();

		public abstract bool IsNotPick();

		public abstract bool IsNotEat();

		protected abstract void UpdateHealthTextField();

		protected abstract void UpdateSortingOrder();

		public abstract void SetFlipX(bool isFlipX);

		protected BaseBody()
		{
			// TODO: list element type was a data pointer; currentLandList is List<LandEntity>.
			currentLandList = new List<LandEntity>();
			_lastDamageType = DamageTypeEntity.Common;
		}

		static BaseBody()
		{
			_nextOnlyId = 1L;
		}
	}
}
