namespace Common.Enum
{
	public enum BodyColliderType
	{
		Body = 0,
		Eat = 1,
		Custom = 99
	}
}
