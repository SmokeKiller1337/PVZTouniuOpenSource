namespace Common.Enum
{
	public enum AttrEnum
	{
		None = 0,
		Sun = 1,
		Cooldown = 2,
		PowerCooldown = 3,
		MaxHealth = 4,
		CurrentHealth = 5,
		Attack = 6,
		Magic = 7,
		AttackSpeed = 8,
		WalkSpeed = 9,
		Extra1 = 10,
		Extra2 = 11,
		Extra3 = 12
	}
}
