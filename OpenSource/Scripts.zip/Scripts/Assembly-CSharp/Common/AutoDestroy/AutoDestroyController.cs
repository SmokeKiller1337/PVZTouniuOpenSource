using System.Collections.Generic;
using UnityEngine;

namespace Common.AutoDestroy
{
	public class AutoDestroyController : MonoBehaviour
	{
		[Tooltip("是否使用对象池")]
		public bool isUsePool;

		[Tooltip("是否自动层级")]
		public bool isAutoLayer;

		[Tooltip("额外排序值")]
		public int addSortingOrder;

		[Tooltip("引用id")]
		public int autoId;

		[Tooltip("存活时间")]
		public float lifetime;

		[Tooltip("是粒子")]
		public bool isParticle;

		[Tooltip("是动画")]
		public bool isAnimation;

		private ParticleSystem _particleSystem;

		private List<ParticleSystemRenderer> _particleSystemRendererList;

		private Animator _animator;

		public void Reset()
		{
		}

		private void Awake()
		{
		}

		private void Start()
		{
		}

		private void Update()
		{
		}

		public void DestroySelf()
		{
		}

		protected virtual void BeforeDestroy()
		{
		}
	}
}
