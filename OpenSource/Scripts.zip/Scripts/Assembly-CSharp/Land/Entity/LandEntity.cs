using System.Collections.Generic;
using Building.Entity;
using Level.Enum;
using Plant.Entity;
using Plant.Enum;
using UnityEngine;

namespace Land.Entity
{
	public class LandEntity : MonoBehaviour
	{
		[Tooltip("行编号")]
		[Header("---基础")]
		public int rowId;

		[Tooltip("列编号")]
		public int columnId;

		[Tooltip("地皮类型")]
		public LandType type;

		[Header("---种植物")]
		[Tooltip("主植物")]
		public PlantEntity masterPlant;

		[Tooltip("外壳植物")]
		public PlantEntity shellPlant;

		[Tooltip("底座植物")]
		public PlantEntity basePlant;

		[Tooltip("浮空植物")]
		public PlantEntity floatPlant;

		[Header("---建筑物")]
		[Tooltip("建筑物")]
		public BuildingEntity masterBuilding;

		[Tooltip("地形集合")]
		[Header("---地形")]
		public List<TerrainEntity> terrainList;

		[HideInInspector]
		public Vector2 originalPosition;

		[HideInInspector]
		public Vector2 originalLocalPosition;

		private void Awake()
		{
			// 缓存出生时的世界坐标与本地坐标，供 Update 的漂浮/摆动动画使用
			originalPosition = transform.position;
			originalLocalPosition = transform.localPosition;
		}

		private void Update()
		{
			if (type != LandType.Water) // TODO: enum member name assumed; offset 0x28 compared to 1
			{
				return;
			}

			float waveFrequency = WaveManagerFrequency;   // TODO: (*(float*)(instance + 100))
			float waveAmplitude = WaveManagerAmplitude;   // TODO: (*(float*)(instance + 0x60))

			float t = (Time.time + columnId * WavePhasePerColumn) * WaveTimeScale;
			float offset = Mathf.Sin((t + t) * waveFrequency) * waveAmplitude;

			// 只改变本地坐标的 Y，X 保持原始本地 X
			transform.localPosition = new Vector3(originalLocalPosition.x, originalLocalPosition.y + offset, 0f);
		}

		public bool IsPlaceable(CardEntity cardEntity)
		{
			if (cardEntity == null)
			{
				return false;
			}
			return false;
		}

		public PlantEntity GetShovelPlant(float positionY = 0f)
		{
			// 根据 positionY 的正负决定优先返回哪一层植物（存在性用 Unity != null 判断）。
			// positionY >= 0: 优先浮空(float) > 主(master) > 外壳(shell) > 底座(base)
			// positionY <  0: 优先外壳(shell) > 主(master) > 浮空(float) > 底座(base)
			if (positionY >= 0f)
			{
				if (floatPlant != null)
				{
					return floatPlant;
				}
				if (masterPlant != null)
				{
					return masterPlant;
				}
				if (shellPlant != null)
				{
					return shellPlant;
				}
				if (basePlant != null)
				{
					return basePlant;
				}
				return null;
			}
			else
			{
				if (shellPlant != null)
				{
					return shellPlant;
				}
				if (masterPlant != null)
				{
					return masterPlant;
				}
				if (floatPlant != null)
				{
					return floatPlant;
				}
				if (basePlant != null)
				{
					return basePlant;
				}
				return null;
			}
		}

		public void ShovelHighlight(bool isHighlight = true, float positionY = 0f)
		{
			if (positionY >= 0f)
			{
				if (floatPlant != null)
				{
					floatPlant.Highlight(isHighlight);
					isHighlight = false;
				}
				if (masterPlant != null)
				{
					masterPlant.Highlight(isHighlight);
					isHighlight = false;
				}
				if (shellPlant != null)
				{
					shellPlant.Highlight(isHighlight);
					isHighlight = false;
				}
			}
			else
			{
				if (shellPlant != null)
				{
					shellPlant.Highlight(isHighlight);
					isHighlight = false;
				}
				if (masterPlant != null)
				{
					masterPlant.Highlight(isHighlight);
					isHighlight = false;
				}
				if (floatPlant != null)
				{
					floatPlant.Highlight(isHighlight);
					isHighlight = false;
				}
			}
			if (basePlant != null)
			{
				basePlant.Highlight(isHighlight);
			}
		}

		public void PowerHighlight(bool isHighlight = true)
		{
			// 只高亮主植物
			if (masterPlant != null)
			{
				masterPlant.Highlight(isHighlight);
			}
		}

		public void HammerHighlight(bool isHighlight = true)
		{
			if (masterBuilding != null && masterBuilding is PotEntity potEntity)
			{
				potEntity.Highlight(isHighlight);
			}
		}

		public bool IsEmptyPlant()
		{
			// 四层植物都为空时返回 true
			if (masterPlant != null)
			{
				return false;
			}
			if (floatPlant != null)
			{
				return false;
			}
			if (shellPlant != null)
			{
				return false;
			}
			if (basePlant != null)
			{
				return false;
			}
			return true;
		}

		public void ClearPlant(PlaceType placeType = PlaceType.All)
		{
			if (placeType == PlaceType.All || placeType == PlaceType.Master)
			{
				if (masterPlant != null)
				{
					masterPlant.Clear();
				}
				if (placeType != PlaceType.All)
				{
					return;
				}
			}

			if (placeType == PlaceType.All || placeType == PlaceType.Float)
			{
				if (floatPlant != null)
				{
					floatPlant.Clear();
				}
				if (placeType != PlaceType.All)
				{
					return;
				}
			}

			if (placeType == PlaceType.All || placeType == PlaceType.Shell)
			{
				if (shellPlant != null)
				{
					shellPlant.Clear();
				}
				if (placeType != PlaceType.All)
				{
					return;
				}
			}

			if (placeType == PlaceType.All || placeType == PlaceType.Base)
			{
				if (basePlant != null)
				{
					basePlant.Clear();
				}
			}
		}

		public void ClearNoFloatPlant()
		{
			// 清除除浮空植物外的所有植物（master / shell / base）
			if (masterPlant != null)
			{
				masterPlant.Clear();
			}
			if (shellPlant != null)
			{
				shellPlant.Clear();
			}
			if (basePlant != null)
			{
				basePlant.Clear();
			}
		}

		public void ClearBuilding()
		{
			if (masterBuilding != null)
			{
				masterBuilding.Clear();
			}
		}

		public void SetPlant(PlantEntity plantEntity)
		{
			if (plantEntity == null)
			{
				return;
			}

			CardEntity cardEntity = plantEntity.CardEntity;
			if (cardEntity == null)
			{
				return;
			}

			int placeType = (int)cardEntity.placeType; // CardEntity.placeType is a PlaceType enum; cast to int for the numeric switch
			switch (placeType)
			{
				case 0:
					masterPlant = plantEntity;
					break;
				case 1:
					shellPlant = plantEntity;
					break;
				case 2:
					basePlant = plantEntity;
					break;
				case 3:
					floatPlant = plantEntity;
					break;
			}

			// 回调植物：设置其所在地皮（PlantEntity 没有 SetLand，用公开的 CurrentLandEntity 属性）
			plantEntity.CurrentLandEntity = this;
		}

		public bool ContainPlaceTypePlant(PlaceType placeType)
		{
			if (placeType == PlaceType.All)
			{
				if (masterPlant != null)
				{
					return true;
				}
				if (floatPlant != null)
				{
					return true;
				}
				if (shellPlant != null)
				{
					return true;
				}
				return false;
			}

			PlantEntity plant;
			switch (placeType)
			{
				case PlaceType.Master:
					plant = masterPlant;
					break;
				case PlaceType.Shell:
					plant = shellPlant;
					break;
				case PlaceType.Base:
					plant = basePlant;
					break;
				case PlaceType.Float:
					plant = floatPlant;
					break;
				default:
					return false;
			}

			if (plant == null)
			{
				return false;
			}

			return plant != null;
		}

		public PlantEntity GetPlaceTypePlant(PlaceType placeType)
		{
			switch (placeType)
			{
				case PlaceType.Master:
					return masterPlant;
				case PlaceType.Shell:
					return shellPlant;
				case PlaceType.Base:
					return basePlant;
				case PlaceType.Float:
					return floatPlant;
				default:
					return null;
			}
		}

		public void ResetShowHealth()
		{
			if (masterPlant != null)
			{
				masterPlant.ResetShowHealth();
			}
			if (floatPlant != null)
			{
				floatPlant.ResetShowHealth();
			}
			if (shellPlant != null)
			{
				shellPlant.ResetShowHealth();
			}
			if (basePlant != null)
			{
				basePlant.ResetShowHealth();
			}
		}

		private const float WaveManagerFrequency = 1f;
		private const float WaveManagerAmplitude = 1f;
		private const float WavePhasePerColumn = 0f;
		private const float WaveTimeScale = 1f;
	}
}
