using System.Collections.Generic;
using Building.Entity;
using Level.Enum;
using Plant.Entity;
using Plant.Enum;
using UnityEngine;

namespace Land.Entity
{
	public class LandEntity : MonoBehaviour
	{
		[Tooltip("行编号")]
		[Header("---基础")]
		public int rowId;

		[Tooltip("列编号")]
		public int columnId;

		[Tooltip("地皮类型")]
		public LandType type;

		[Header("---种植物")]
		[Tooltip("主植物")]
		public PlantEntity masterPlant;

		[Tooltip("外壳植物")]
		public PlantEntity shellPlant;

		[Tooltip("底座植物")]
		public PlantEntity basePlant;

		[Tooltip("浮空植物")]
		public PlantEntity floatPlant;

		[Header("---建筑物")]
		[Tooltip("建筑物")]
		public BuildingEntity masterBuilding;

		[Tooltip("地形集合")]
		[Header("---地形")]
		public List<TerrainEntity> terrainList;

		[HideInInspector]
		public Vector2 originalPosition;

		[HideInInspector]
		public Vector2 originalLocalPosition;

		private void Awake()
		{
			// 缓存出生时的世界坐标与本地坐标，供 Update 的漂浮/摆动动画使用
			originalPosition = transform.position;
			originalLocalPosition = transform.localPosition;
		}

		private void Update()
		{
			// 仅当地皮类型为水面（type == 1）时才做水面漂浮摆动
			// 伪代码: if (*(int*)(param_1 + 0x28) != 1) return;
			if (type != LandType.Water) // TODO: enum member name assumed; offset 0x28 compared to 1
			{
				return;
			}

			// 通过全局关卡管理器读取水面波动参数
			// 伪代码里 _DAT_182e294b8 是关卡/波浪管理器单例，->0xb8 取其实例，
			// 实例 +0x64 / +0x60 为两个波动系数，无法从本类字段解析，用占位常量。
			// TODO: resolve global level/wave manager singleton and its wave parameters
			float waveFrequency = WaveManagerFrequency;   // TODO: (*(float*)(instance + 100))
			float waveAmplitude = WaveManagerAmplitude;   // TODO: (*(float*)(instance + 0x60))

			float t = (Time.time + columnId * WavePhasePerColumn) * WaveTimeScale; // TODO: _DAT_18252cb64 / _DAT_18252cb2c
			float offset = Mathf.Sin((t + t) * waveFrequency) * waveAmplitude;

			// 只改变本地坐标的 Y，X 保持原始本地 X
			transform.localPosition = new Vector3(originalLocalPosition.x, originalLocalPosition.y + offset, 0f);
		}

		public bool IsPlaceable(CardEntity cardEntity)
		{
			// 伪代码此方法逻辑非常晦涩：涉及多个全局单例（相机状态机、配置集合、
			// List<HashPair> 枚举遍历比较实例 id）以及对 cardEntity 的虚表调用
			// (**(code**)(*param_2 + 0x1a8))(...) 来做最终可放置判定。
			// 无法可靠还原被折叠(ICF)的真实调用与全局对象，保留桩实现以免产出错误逻辑。
			// 可确定的部分：if (cardEntity == null) return false; 其余判定委托给 cardEntity。
			if (cardEntity == null)
			{
				return false;
			}
			// TODO: reconstruct — 依赖多个无法解析的全局单例与虚表调用，最终应形如
			//   return cardEntity.SomePlaceCheck(this);
			return false;
		}

		public PlantEntity GetShovelPlant(float positionY = 0f)
		{
			// 根据 positionY 的正负决定优先返回哪一层植物（存在性用 Unity != null 判断）。
			// positionY >= 0: 优先浮空(float) > 主(master) > 外壳(shell) > 底座(base)
			// positionY <  0: 优先外壳(shell) > 主(master) > 浮空(float) > 底座(base)
			if (positionY >= 0f)
			{
				if (floatPlant != null)
				{
					return floatPlant;
				}
				if (masterPlant != null)
				{
					return masterPlant;
				}
				if (shellPlant != null)
				{
					return shellPlant;
				}
				if (basePlant != null)
				{
					return basePlant;
				}
				return null;
			}
			else
			{
				if (shellPlant != null)
				{
					return shellPlant;
				}
				if (masterPlant != null)
				{
					return masterPlant;
				}
				if (floatPlant != null)
				{
					return floatPlant;
				}
				if (basePlant != null)
				{
					return basePlant;
				}
				return null;
			}
		}

		public void ShovelHighlight(bool isHighlight = true, float positionY = 0f)
		{
			// 与 GetShovelPlant 相同的优先级顺序高亮各层植物；
			// 一旦对某个植物调用了 Highlight，就把后续的 isHighlight 传参改为 false
			// （伪代码里 param_2 被置 0），最后总是处理 basePlant。
			if (positionY >= 0f)
			{
				if (floatPlant != null)
				{
					floatPlant.Highlight(isHighlight);
					isHighlight = false;
				}
				if (masterPlant != null)
				{
					masterPlant.Highlight(isHighlight);
					isHighlight = false;
				}
				if (shellPlant != null)
				{
					shellPlant.Highlight(isHighlight);
					isHighlight = false;
				}
			}
			else
			{
				if (shellPlant != null)
				{
					shellPlant.Highlight(isHighlight);
					isHighlight = false;
				}
				if (masterPlant != null)
				{
					masterPlant.Highlight(isHighlight);
					isHighlight = false;
				}
				if (floatPlant != null)
				{
					floatPlant.Highlight(isHighlight);
					isHighlight = false;
				}
			}
			if (basePlant != null)
			{
				basePlant.Highlight(isHighlight);
			}
		}

		public void PowerHighlight(bool isHighlight = true)
		{
			// 只高亮主植物
			if (masterPlant != null)
			{
				masterPlant.Highlight(isHighlight);
			}
		}

		public void HammerHighlight(bool isHighlight = true)
		{
			// 建筑物存在且其运行时类型确实是 PotEntity 时才高亮
			// 伪代码里 lRam...182e44218 是 PotEntity 的类型信息，做了 is PotEntity 判断，
			// 然后调用 PotEntity.Highlight。
			if (masterBuilding != null && masterBuilding is PotEntity potEntity)
			{
				potEntity.Highlight(isHighlight);
			}
		}

		public bool IsEmptyPlant()
		{
			// 四层植物都为空时返回 true
			if (masterPlant != null)
			{
				return false;
			}
			if (floatPlant != null)
			{
				return false;
			}
			if (shellPlant != null)
			{
				return false;
			}
			if (basePlant != null)
			{
				return false;
			}
			return true;
		}

		public void ClearPlant(PlaceType placeType = PlaceType.All)
		{
			// placeType 决定清除哪一层植物。伪代码里对每个待清植物调用
			// 其虚表方法 (*plVar2 + 0x298)(plVar2, *(plVar2 + 0x2a0))，
			// 这是 PlantEntity 的销毁/移除方法，还原为 Clear()。
			// PlaceType 数值约定（据分支）: All=-1, Master=0, Shell=1, Base=2, Float=3
			// 伪代码结构: (placeType + 1U < 2) 即 placeType == -1(All) 或 0(Master) 时清 master，
			// 随后 All 会继续贯穿清 float/shell/base。
			if (placeType == PlaceType.All || placeType == PlaceType.Master)
			{
				if (masterPlant != null)
				{
					masterPlant.Clear(); // TODO: verify PlantEntity clear/destroy method name (vtable +0x298)
				}
				if (placeType != PlaceType.All)
				{
					return;
				}
			}

			if (placeType == PlaceType.All || placeType == PlaceType.Float)
			{
				if (floatPlant != null)
				{
					floatPlant.Clear(); // TODO: verify method name (vtable +0x298)
				}
				if (placeType != PlaceType.All)
				{
					return;
				}
			}

			if (placeType == PlaceType.All || placeType == PlaceType.Shell)
			{
				if (shellPlant != null)
				{
					shellPlant.Clear(); // TODO: verify method name (vtable +0x298)
				}
				if (placeType != PlaceType.All)
				{
					return;
				}
			}

			if (placeType == PlaceType.All || placeType == PlaceType.Base)
			{
				if (basePlant != null)
				{
					basePlant.Clear(); // TODO: verify method name (vtable +0x298)
				}
			}
		}

		public void ClearNoFloatPlant()
		{
			// 清除除浮空植物外的所有植物（master / shell / base）
			if (masterPlant != null)
			{
				masterPlant.Clear(); // TODO: verify method name (vtable +0x298)
			}
			if (shellPlant != null)
			{
				shellPlant.Clear(); // TODO: verify method name (vtable +0x298)
			}
			if (basePlant != null)
			{
				basePlant.Clear(); // TODO: verify method name (vtable +0x298)
			}
		}

		public void ClearBuilding()
		{
			// 清除建筑物，调用 BuildingEntity 的移除虚表方法 (*+0x1b8)
			if (masterBuilding != null)
			{
				masterBuilding.Clear(); // TODO: verify BuildingEntity clear/destroy method name (vtable +0x1b8)
			}
		}

		public void SetPlant(PlantEntity plantEntity)
		{
			// 根据植物卡牌的放置类型(CardEntity.placeType, 偏移 0x4c)把植物放到对应层，
			// 然后回调植物的 “被放置到地皮” 虚表方法 (*+0x188)(plant, this)。
			if (plantEntity == null)
			{
				return;
			}

			CardEntity cardEntity = plantEntity.CardEntity;
			if (cardEntity == null)
			{
				return;
			}

			int placeType = (int)cardEntity.placeType; // CardEntity.placeType is a PlaceType enum; cast to int for the numeric switch
			switch (placeType)
			{
				case 0:
					masterPlant = plantEntity;
					break;
				case 1:
					shellPlant = plantEntity;
					break;
				case 2:
					basePlant = plantEntity;
					break;
				case 3:
					floatPlant = plantEntity;
					break;
			}

			// 回调植物：设置其所在地皮（PlantEntity 没有 SetLand，用公开的 CurrentLandEntity 属性）
			plantEntity.CurrentLandEntity = this;
		}

		public bool ContainPlaceTypePlant(PlaceType placeType)
		{
			// placeType == All(-1): 只要 master/float/shell 任一存在即 true
			// 否则取对应层植物，判断其内部对象(+0x10)是否非空
			if (placeType == PlaceType.All)
			{
				if (masterPlant != null)
				{
					return true;
				}
				if (floatPlant != null)
				{
					return true;
				}
				if (shellPlant != null)
				{
					return true;
				}
				return false;
			}

			PlantEntity plant;
			switch (placeType)
			{
				case PlaceType.Master:
					plant = masterPlant;
					break;
				case PlaceType.Shell:
					plant = shellPlant;
					break;
				case PlaceType.Base:
					plant = basePlant;
					break;
				case PlaceType.Float:
					plant = floatPlant;
					break;
				default:
					return false;
			}

			if (plant == null)
			{
				return false;
			}

			// 伪代码: return op_Inequality(*(plant + 0x10), null)
			// plant + 0x10 是 PlantEntity 内部某个引用（例如 body / gameObject）。无法确定具体成员，
			// 稳妥地退回为植物本身非空判断。
			return plant != null; // TODO: original checks an inner reference at PlantEntity+0x10 (e.g. body != null)
		}

		public PlantEntity GetPlaceTypePlant(PlaceType placeType)
		{
			switch (placeType)
			{
				case PlaceType.Master:
					return masterPlant;
				case PlaceType.Shell:
					return shellPlant;
				case PlaceType.Base:
					return basePlant;
				case PlaceType.Float:
					return floatPlant;
				default:
					return null;
			}
		}

		public void ResetShowHealth()
		{
			// 对四层植物依次调用其 “重置血条显示” 虚表方法 (*+0x1e8)
			// 顺序: master -> float -> shell -> base
			if (masterPlant != null)
			{
				masterPlant.ResetShowHealth(); // TODO: verify method name (vtable +0x1e8)
			}
			if (floatPlant != null)
			{
				floatPlant.ResetShowHealth(); // TODO: verify method name (vtable +0x1e8)
			}
			if (shellPlant != null)
			{
				shellPlant.ResetShowHealth(); // TODO: verify method name (vtable +0x1e8)
			}
			if (basePlant != null)
			{
				basePlant.ResetShowHealth(); // TODO: verify method name (vtable +0x1e8)
			}
		}

		// ---- 占位常量：源自无法解析的全局波动参数 ----
		// TODO: 以下常量对应 Update() 里读取的全局波浪管理器参数 / DAT_ 全局常量，
		//       仅为可编译占位，实际数值需从关卡管理器还原。
		private const float WaveManagerFrequency = 1f;
		private const float WaveManagerAmplitude = 1f;
		private const float WavePhasePerColumn = 0f;
		private const float WaveTimeScale = 1f;
	}
}
