using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;
using Zombie.Entity;

namespace Land.Entity
{
	public class HomeLineEntity : MonoBehaviour
	{
		[CompilerGenerated]
		private sealed class _003CLoseGameCoroutine_003Ed__13 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public HomeLineEntity _003C_003E4__this;

			public ZombieEntity zombieEntity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CLoseGameCoroutine_003Ed__13(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("游戏结束预制体")]
		public GameObject gameOverPrefab;

		[Tooltip("游戏结束音效")]
		public AudioClip gameOverSound;

		[HideInInspector]
		public bool isTrigger;

		private GameObject _gameOverObj;

		private Rigidbody2D _rigidbody;

		public Rigidbody2D Rigidbody
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		private void Awake()
		{
		}

		private void Start()
		{
		}

		private void Update()
		{
		}

		private void OnTriggerEnter2D(Collider2D col)
		{
		}

		public void LoseGame(ZombieEntity zombieEntity)
		{
		}

		[IteratorStateMachine(typeof(_003CLoseGameCoroutine_003Ed__13))]
		private IEnumerator LoseGameCoroutine(ZombieEntity zombieEntity)
		{
			return null;
		}
	}
}
