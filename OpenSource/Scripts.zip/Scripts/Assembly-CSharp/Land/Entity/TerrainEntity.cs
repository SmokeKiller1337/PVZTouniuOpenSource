using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace Land.Entity
{
	public class TerrainEntity : MonoBehaviour
	{
		[Tooltip("编号")]
		public int id;

		[Tooltip("持续时间")]
		public float durationTime;

		private float _durationTimer;

		[Tooltip("是否禁止种植")]
		public bool isDisabledPlace;

		[HideInInspector]
		public List<LandEntity> landList;

		[HideInInspector]
		public Transform mainBodyTransform;

		private SortingGroup _sortingGroup;

		public float DurationTimer
		{
			get
			{
				return 0f;
			}
			set
			{
			}
		}

		public SortingGroup SortingGroup
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		private void Awake()
		{
		}

		private void Update()
		{
		}

		public void Clear()
		{
		}

		public virtual void OnTriggerLandEnter(LandEntity landEntity)
		{
		}

		public virtual void OnTriggerLandExit(LandEntity landEntity)
		{
		}
	}
}
