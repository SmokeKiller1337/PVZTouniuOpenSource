using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Entity;
using Level.Enum;
using Reanim2UnityAnim;
using UnityEngine;
using UnityEngine.Rendering;
using Zombie.Entity;

namespace Land.Entity
{
	public class LawnMowerEntity : MonoBehaviour
	{
		[CompilerGenerated]
		private sealed class _003CTriggerLawnCoroutine_003Ed__32 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public LawnMowerEntity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CTriggerLawnCoroutine_003Ed__32(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("推车类型")]
		public LandType type;

		[Tooltip("触发音效")]
		public AudioClip triggerSound;

		[HideInInspector]
		public int row;

		[HideInInspector]
		public bool isTrigger;

		[HideInInspector]
		public bool isForward;

		[HideInInspector]
		public LandEntity currentLand;

		[Tooltip("移动速度")]
		public float speed;

		[Tooltip("阴影")]
		public SpriteRenderer shadowSpriteRenderer;

		[Tooltip("主体")]
		public Transform mainBodyTransform;

		private Animator _animator;

		private Rigidbody2D _rigidbody;

		private SortingGroup _sortingGroup;

		private UniqueMaterialController _reanimSpriteEntity;

		private List<BaseBody> _targetBodyList;

		public Rigidbody2D Rigidbody
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		public SortingGroup SortingGroup
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		public UniqueMaterialController ReanimSpriteEntity
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		private void Awake()
		{
		}

		private void Start()
		{
		}

		private void Update()
		{
		}

		private void OnTriggerEnter2D(Collider2D col)
		{
		}

		private bool CheckTriggerLawn(ZombieEntity zombieEntity)
		{
			return false;
		}

		private void OnTriggerExit2D(Collider2D col)
		{
		}

		private void EnterLand(LandEntity landEntity)
		{
		}

		private void ExitLand(LandEntity landEntity)
		{
		}

		public void TriggerLawn()
		{
		}

		[IteratorStateMachine(typeof(_003CTriggerLawnCoroutine_003Ed__32))]
		private IEnumerator TriggerLawnCoroutine()
		{
			return null;
		}

		public void DestroySelf()
		{
		}

		public void OnPlantDoubleClick()
		{
		}
	}
}
