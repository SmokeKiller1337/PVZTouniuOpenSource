using UnityEngine;

namespace Land.Entity
{
	public class ZombieLineEntity : MonoBehaviour
	{
		private void Awake()
		{
		}

		private void Start()
		{
		}

		private void Update()
		{
		}

		private void OnTriggerExit2D(Collider2D col)
		{
		}
	}
}
