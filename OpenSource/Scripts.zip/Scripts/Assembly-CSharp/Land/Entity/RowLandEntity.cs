using System.Collections.Generic;
using Common.Collider;
using Level.Enum;
using UnityEngine;
using Zombie.Entity;

namespace Land.Entity
{
	public class RowLandEntity : MonoBehaviour
	{
		[Tooltip("行")]
		public int row;

		[Tooltip("草坪类型")]
		public LandType landType;

		[Tooltip("本行草坪集合")]
		public List<LandEntity> landList = new List<LandEntity>();

		[Tooltip("本行小推车")]
		public LawnMowerEntity lawnMowerEntity;

		[Tooltip("额外草坪")]
		public LandEntity extraLandEntity;

		// TODO: The following string literals could not be recovered from the
		// decompiled data pointers. They are used with landTransform.Find(...).
		// Values are plausible placeholders based on the level/land hierarchy naming.
		private const string RowNameFormat = "Row{0}"; // TODO: verify actual format string (String.Format arg is `row`)
		private const string ExtraLandName = "Extra"; // TODO: verify actual child object name for the extra land

		private void Awake()
		{
			// GetComponentInParent<BackgroundEntity>() supplies the column count and
			// the root land transform for this row's lands.
			BackgroundEntity background = GetComponentInParent<BackgroundEntity>();

			int columnNumber = background.columnNumber;
			Transform landTransform = background.landTransform;

			// Locate this row's transform under the land root, keyed by `row`.
			Transform rowTransform = landTransform.Find(string.Format(RowNameFormat, row));

			// Collect each column's LandEntity (columns are named "1".."columnNumber").
			for (int i = 1; i <= columnNumber; i++)
			{
				Transform landChild = rowTransform.Find(i.ToString());
				LandEntity landEntity = landChild.GetComponent<LandEntity>();
				landList.Add(landEntity);
			}

			// Resolve the extra land under this row (if present).
			Transform extraTransform = rowTransform.Find(ExtraLandName);
			if (extraTransform != null)
			{
				extraLandEntity = extraTransform.GetComponent<LandEntity>();

				// Grab the row's lawn mower and tell it which row it belongs to.
				lawnMowerEntity = rowTransform.GetComponentInChildren<LawnMowerEntity>();
				if (lawnMowerEntity != null)
				{
					// TODO: reconstruct - the decompiler writes `row` into LawnMowerEntity+0x30,
					// but LawnMowerEntity's fields are not available in the dump, so the exact
					// member name cannot be verified. Likely `lawnMowerEntity.row = row;`.
					// lawnMowerEntity.row = row;
				}
			}
		}

		private void OnTriggerEnter2D(Collider2D col)
		{
			ZombieBodyColliderEntity zombieCollider = col.gameObject.GetComponent<ZombieBodyColliderEntity>();
			if (zombieCollider != null)
			{
				// Remember this row on the zombie that just entered.
				zombieCollider.zombieEntity.currentRowLandEntity = this;
			}
		}
	}
}
