using System.Collections.Generic;
using UnityEngine;

namespace Land.Entity
{
	public class BackgroundEntity : MonoBehaviour
	{
		[Tooltip("编号")]
		public int id;

		[Tooltip("房间名")]
		public string roomTitle;

		[Tooltip("行数")]
		public int rowNumber = 5;

		[Tooltip("列数")]
		public int columnNumber = 9;

		[Tooltip("是白天")]
		public bool isDay;

		[Tooltip("行间距离")]
		public float rowDistance = 1.5f;

		[Tooltip("列间距离")]
		public float columnDistance = 1.425f;

		[Tooltip("背景坐标")]
		public Transform backgroundTransform;

		[Tooltip("地皮坐标")]
		public Transform landTransform;

		[Tooltip("卡牌坐标")]
		public Transform cardTransform;

		[Tooltip("嘉宾坐标")]
		public Transform guestTransform;

		[Tooltip("僵尸线坐标")]
		public Transform zombieLineTransform;

		[Tooltip("房子线坐标")]
		public Transform homeLineTransform;

		[Tooltip("背景图片渲染器")]
		public SpriteRenderer backgroundSpriteRenderer;

		[HideInInspector]
		public Dictionary<int, Dictionary<int, LandEntity>> landDic = new Dictionary<int, Dictionary<int, LandEntity>>();

		// NOTE: Awake and InitLandEntity share RVA 0x63CA70 (ICF folded byte-identical
		// bodies). Both decompile to the same land-dictionary build logic. Reconstructed
		// as Awake delegating to InitLandEntity, which is behaviorally identical (the init
		// runs once at startup) and matches idiomatic Unity usage.
		// TODO: verify whether Awake inlined the body directly vs. calling InitLandEntity.
		private void Awake()
		{
			InitLandEntity();
		}

		private void InitLandEntity()
		{
			if (landTransform != null)
			{
				LandEntity[] landEntities = landTransform.GetComponentsInChildren<LandEntity>();

				// Create one inner dictionary per row (row keys are 1-based).
				for (int i = 0; i < rowNumber; i++)
				{
					landDic.Add(i + 1, new Dictionary<int, LandEntity>());
				}

				// Bucket every LandEntity under its row, keyed by its column.
				for (int i = 0; i < landEntities.Length; i++)
				{
					LandEntity landEntity = landEntities[i];
					landDic[landEntity.rowId].Add(landEntity.columnId, landEntity);
				}
			}
		}
	}
}
