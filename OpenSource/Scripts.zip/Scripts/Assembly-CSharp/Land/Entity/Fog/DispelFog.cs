using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

namespace Land.Entity.Fog
{
	public class DispelFog : MonoBehaviour
	{
		[CompilerGenerated]
		private sealed class _003CTemporaryBoost_003Ed__55 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public DispelFog _003C_003E4__this;

			public float multiplier;

			public float duration;

			private Vector2 _003CoriginalSize_003E5__2;

			private float _003CoriginalIntensity_003E5__3;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CTemporaryBoost_003Ed__55(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Header("矩形驱散设置")]
		[SerializeField]
		public Vector2 baseDispelSize;

		[SerializeField]
		private float baseDispelIntensity;

		[SerializeField]
		private float edgeSmoothness;

		[SerializeField]
		private bool useRotation;

		[SerializeField]
		private float rotationAngle;

		[SerializeField]
		private bool isStatic;

		[Header("动态效果")]
		[SerializeField]
		private bool usePulsing;

		[SerializeField]
		private float pulseSpeed;

		[SerializeField]
		private float pulseAmount;

		[SerializeField]
		private bool pulseSize;

		[SerializeField]
		private bool pulseIntensity;

		[Header("可视化")]
		[SerializeField]
		private bool showGizmos;

		[SerializeField]
		private Color gizmoColor;

		[Header("防抖动设置")]
		[SerializeField]
		private bool enablePositionSmoothing;

		[SerializeField]
		private float positionSmoothingFactor;

		private Vector3 smoothedPosition;

		private Vector2 currentDispelSize;

		private float currentDispelIntensity;

		private float pulseTimer;

		private Vector3 lastPosition;

		private Vector2 lastSize;

		private float lastIntensity;

		private float lastRotationAngle;

		private Vector2 defaultBaseDispelSize;

		public Vector2 DefaultBaseDispelSize
		{
			get
			{
				return default(Vector2);
			}
			set
			{
			}
		}

		public Vector2 DispelSize => default(Vector2);

		public float DispelIntensity => 0f;

		public float EdgeSmoothness
		{
			get
			{
				return 0f;
			}
			set
			{
			}
		}

		public bool UseRotation => false;

		public float RotationAngle => 0f;

		public bool IsActive => false;

		public float BaseDispelIntensity
		{
			get
			{
				return 0f;
			}
			set
			{
			}
		}

		private void Awake()
		{
		}

		private void Start()
		{
		}

		private void InitDispelIntensity()
		{
		}

		private void SetDeathDispelFog()
		{
		}

		private void DeathDispelFog()
		{
		}

		private void InitializeDispel()
		{
		}

		private void Update()
		{
		}

		private void UpdatePulsingEffect()
		{
		}

		public bool IsInAnyFogRange()
		{
			return false;
		}

		private void NotifyFogManager()
		{
		}

		public void SetDispelParameters(Vector2 size, float intensity, float smoothness = -1f, float rotation = -1f)
		{
		}

		public void BoostDispel(float multiplier, float duration)
		{
		}

		[IteratorStateMachine(typeof(_003CTemporaryBoost_003Ed__55))]
		private IEnumerator TemporaryBoost(float multiplier, float duration)
		{
			return null;
		}

		private void OnEnable()
		{
		}

		private void OnDisable()
		{
		}

		private void OnDrawGizmos()
		{
		}

		private void OnValidate()
		{
		}

		public float GetSuccessfulDispelArea()
		{
			return 0f;
		}
	}
}
