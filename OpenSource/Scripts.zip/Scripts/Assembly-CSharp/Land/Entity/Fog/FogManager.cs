using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

namespace Land.Entity.Fog
{
	public class FogManager : MonoBehaviour
	{
		public class DispelData
		{
			public Vector3 worldPosition;

			public Vector2 dispelSize;

			public float intensity;

			public float edgeSmoothness;

			public DispelFog source;

			public bool useRotation;

			public float rotationAngle;
		}

		[CompilerGenerated]
		private sealed class _003CRemoveDispelSourceAfterTime_003Ed__34 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public float duration;

			public FogManager _003C_003E4__this;

			public DispelData data;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CRemoveDispelSourceAfterTime_003Ed__34(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Header("全局迷雾设置")]
		[SerializeField]
		private Texture noiseTexture;

		[SerializeField]
		private Color fogColor;

		[SerializeField]
		private float globalEdgeSmoothness;

		[Header("颜色脉动设置 (全局)")]
		[SerializeField]
		private bool globalPulsingEnabled;

		[SerializeField]
		private float globalPulseSpeed;

		[SerializeField]
		private float globalMinBrightness;

		[SerializeField]
		private bool randomizePerTile;

		[SerializeField]
		[Header("系统设置")]
		private float updateFrequency;

		[SerializeField]
		private int maxDispelSources;

		private List<FogTileController> fogTiles;

		private List<DispelData> activeDispelSources;

		private float updateTimer;

		private bool needsUpdate;

		public static FogManager Instance { get; private set; }

		public List<FogTileController> FogTiles => null;

		private void Awake()
		{
		}

		private void Start()
		{
		}

		private void InitializeFogTiles()
		{
		}

		private void Update()
		{
		}

		public void ApplyGlobalPulsingSettings()
		{
		}

		public void EnableGlobalPulsing(bool enabled)
		{
		}

		public void SetGlobalPulseSpeed(float speed)
		{
		}

		public void SetGlobalMinBrightness(float brightness)
		{
		}

		private void UpdateDispelSources()
		{
		}

		private void UpdateDispelData(DispelData data, DispelFog source)
		{
		}

		private void UpdateAllTiles()
		{
		}

		public bool IsDispelInFogRange(DispelFog dispel)
		{
			return false;
		}

		public void ForceUpdate()
		{
		}

		public void AddDispelSource(Vector3 position, Vector2 size, float intensity, float edgeSmoothness = 0.2f, float rotationAngle = 0f, float duration = 0f)
		{
		}

		[IteratorStateMachine(typeof(_003CRemoveDispelSourceAfterTime_003Ed__34))]
		private IEnumerator RemoveDispelSourceAfterTime(DispelData data, float duration)
		{
			return null;
		}

		public void RemoveDispelSource(DispelFog source)
		{
		}

		public void SetFogAlpha(float alpha)
		{
		}

		public void ResetAllDispel()
		{
		}

		private void OnValidate()
		{
		}

		private void OnDestroy()
		{
		}
	}
}
