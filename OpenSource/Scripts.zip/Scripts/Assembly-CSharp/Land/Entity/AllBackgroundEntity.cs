using UnityEngine;

namespace Land.Entity
{
	public class AllBackgroundEntity : MonoBehaviour
	{
		private void OnTriggerEnter2D(Collider2D col)
		{
		}
	}
}
