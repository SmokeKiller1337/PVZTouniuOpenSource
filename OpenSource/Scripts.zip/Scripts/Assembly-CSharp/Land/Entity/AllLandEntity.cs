using System.Collections.Generic;
using Common.Collider;
using UnityEngine;
using Zombie.Entity;

namespace Land.Entity
{
	public class AllLandEntity : MonoBehaviour
	{
		// The generated .ctor initializes this readonly dictionary; mirror it with an
		// inline initializer so rowlandDic is non-null before Awake runs.
		public readonly Dictionary<int, RowLandEntity> rowlandDic = new Dictionary<int, RowLandEntity>();

		private void Awake()
		{
			// GetComponentsInChildren<RowLandEntity>() returns an array; iterate it and
			// register each row by its `row` field into rowlandDic.
			RowLandEntity[] rowLands = GetComponentsInChildren<RowLandEntity>();
			if (rowLands == null)
			{
				return;
			}

			for (int i = 0; i < rowLands.Length; i++)
			{
				RowLandEntity rowLand = rowLands[i];
				if (rowLand == null || rowlandDic == null)
				{
					// Original bails out here (null element or uninitialized dictionary).
					return;
				}

				rowlandDic.Add(rowLand.row, rowLand);
			}
		}

		private void OnTriggerEnter2D(Collider2D col)
		{
			if (col == null)
			{
				return;
			}

			ZombieBodyColliderEntity colliderEntity = col.gameObject.GetComponent<ZombieBodyColliderEntity>();
			if (colliderEntity == null)
			{
				return;
			}

			ZombieEntity zombieEntity = colliderEntity.zombieEntity;
			if (zombieEntity == null || !zombieEntity.gameObject.activeSelf)
			{
				return;
			}

			// _isDeath (0x1B0) — a dead zombie is ignored.
			if (zombieEntity.IsDeath)
			{
				return;
			}

		}

		private void OnTriggerExit2D(Collider2D col)
		{
			if (col == null)
			{
				return;
			}

			ZombieBodyColliderEntity colliderEntity = col.gameObject.GetComponent<ZombieBodyColliderEntity>();
			if (colliderEntity == null)
			{
				return;
			}

			ZombieEntity zombieEntity = colliderEntity.zombieEntity;

			_ = zombieEntity;
		}
	}
}
