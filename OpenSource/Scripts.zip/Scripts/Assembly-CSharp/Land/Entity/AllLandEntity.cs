using System.Collections.Generic;
using Common.Collider;
using UnityEngine;
using Zombie.Entity;

namespace Land.Entity
{
	public class AllLandEntity : MonoBehaviour
	{
		// The generated .ctor initializes this readonly dictionary; mirror it with an
		// inline initializer so rowlandDic is non-null before Awake runs.
		public readonly Dictionary<int, RowLandEntity> rowlandDic = new Dictionary<int, RowLandEntity>();

		private void Awake()
		{
			// GetComponentsInChildren<RowLandEntity>() returns an array; iterate it and
			// register each row by its `row` field into rowlandDic.
			RowLandEntity[] rowLands = GetComponentsInChildren<RowLandEntity>();
			if (rowLands == null)
			{
				return;
			}

			for (int i = 0; i < rowLands.Length; i++)
			{
				RowLandEntity rowLand = rowLands[i];
				if (rowLand == null || rowlandDic == null)
				{
					// Original bails out here (null element or uninitialized dictionary).
					return;
				}

				rowlandDic.Add(rowLand.row, rowLand);
			}
		}

		private void OnTriggerEnter2D(Collider2D col)
		{
			if (col == null)
			{
				return;
			}

			ZombieBodyColliderEntity colliderEntity = col.gameObject.GetComponent<ZombieBodyColliderEntity>();
			if (colliderEntity == null)
			{
				return;
			}

			ZombieEntity zombieEntity = colliderEntity.zombieEntity;
			if (zombieEntity == null || !zombieEntity.gameObject.activeSelf)
			{
				return;
			}

			// _isDeath (0x1B0) — a dead zombie is ignored.
			if (zombieEntity.IsDeath)
			{
				return;
			}

			// TODO: reconstruct — the original then fetches a List<ZombieEntity> from a
			// static manager singleton (global _DAT_182e841b0, field at +0xB8 double
			// dereferenced) and, if the list does not already contain this zombie, adds
			// it. The owning manager/property chain cannot be resolved from this class's
			// stub/dump alone, so the tracking call is intentionally left unimplemented
			// rather than invent an external member. Intended behavior:
			//     var line = <ZombieLineManager>.Instance.<zombieList>;
			//     if (!line.Contains(zombieEntity)) line.Add(zombieEntity);
		}

		private void OnTriggerExit2D(Collider2D col)
		{
			if (col == null)
			{
				return;
			}

			ZombieBodyColliderEntity colliderEntity = col.gameObject.GetComponent<ZombieBodyColliderEntity>();
			if (colliderEntity == null)
			{
				return;
			}

			ZombieEntity zombieEntity = colliderEntity.zombieEntity;

			// TODO: reconstruct — the original fetches the same List<ZombieEntity> from a
			// static manager singleton (global _DAT_182e841b0, field at +0xB8 double
			// dereferenced). If the list contains this zombie it is removed (the pseudocode
			// shows the inlined List<T>.Remove: IndexOf + Array.Copy + count/version update).
			// The owning manager/property chain cannot be resolved from this class's
			// stub/dump alone, so the call is intentionally left unimplemented rather than
			// invent an external member. Intended behavior:
			//     var line = <ZombieLineManager>.Instance.<zombieList>;
			//     if (line.Contains(zombieEntity)) line.Remove(zombieEntity);
			_ = zombieEntity;
		}
	}
}
