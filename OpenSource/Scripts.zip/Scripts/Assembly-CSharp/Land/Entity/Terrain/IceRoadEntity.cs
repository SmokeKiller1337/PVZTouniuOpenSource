using UnityEngine;

namespace Land.Entity.Terrain
{
	public class IceRoadEntity : TerrainEntity
	{
		[Tooltip("身体物体")]
		public GameObject bodyObj;

		[Tooltip("行")]
		public int row;
	}
}
