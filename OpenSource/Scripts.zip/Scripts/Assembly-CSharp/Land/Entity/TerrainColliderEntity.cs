using UnityEngine;

namespace Land.Entity
{
	public class TerrainColliderEntity : MonoBehaviour
	{
		[HideInInspector]
		public TerrainEntity terrainEntity;

		private void Awake()
		{
		}

		private void OnTriggerEnter2D(Collider2D col)
		{
		}

		private void OnTriggerExit2D(Collider2D col)
		{
		}
	}
}
