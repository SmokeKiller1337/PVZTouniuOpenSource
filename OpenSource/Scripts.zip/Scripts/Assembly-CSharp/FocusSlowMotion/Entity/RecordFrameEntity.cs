using System;
using System.Collections.Generic;
using Building.Entity;
using Building.Enum;
using Common.Entity;
using Game.Entity;
using Land.Entity;
using NoSLoofah.BuffSystem;
using Plant.Entity;
using Touniu.Entity.Body;
using UnityEngine;
using Zombie.Entity;

namespace FocusSlowMotion.Entity
{
	[Serializable]
	public class RecordFrameEntity
	{
		[Serializable]
		public class RecordTouniuEntity
		{
			public int id;

			public Vector2 position;

			public bool isFlipX;

			public int currentWaveStartEventCount;

			public int currentWaveEndEventCount;

			public List<AttrLabelEntity> labelList;

			public List<RecordBuffEntity> buffList;

			public bool isSpecialPattern;

			public bool HasBuff(int buffId)
			{
				return false;
			}
		}

		[Serializable]
		public class RecordAssetsEntity
		{
			public int sunValue;

			public float diamondValue;

			public int hammerValue;

			public List<bool> hasLawnList;

			public float inGameTime;

			public float fogDistance;

			public Dictionary<string, object> ParamDic;
		}

		[Serializable]
		public class RecordCardSlotEntity
		{
			public List<RecordCardEntity> cardList;

			public List<int> conveyorCardIdList;

			public float conveyorSpeed;

			public RecordCardEntity extraCard;
		}

		[Serializable]
		public class RecordLandEntity
		{
			public int rowId;

			public int columnId;

			public RecordPlantEntity masterPlant;

			public RecordPlantEntity shellPlant;

			public RecordPlantEntity basePlant;

			public RecordPlantEntity floatPlant;

			public RecordBuildingEntity masterBuilding;

			public RecordLandEntity()
			{
			}

			public RecordLandEntity(LandEntity landEntity)
			{
			}
		}

		[Serializable]
		public class RecordCardEntity
		{
			public int id;

			public string title;

			public int sun;

			public float cooldownTime;

			public float cooldownTimer;

			public float powerCooldownTime;

			public float powerCooldownTimer;

			public int level;

			public PlantBaseAttr plantAttr;

			public List<int> hasStrengthenList;

			public RecordCardEntity()
			{
			}

			public RecordCardEntity(CardEntity cardEntity)
			{
			}
		}

		[Serializable]
		public class RecordPlantEntity
		{
			public int id;

			public string title;

			public float maxHealth;

			public float currentHealth;

			public int attack;

			public int magic;

			public float attackSpeed;

			public bool isSleeping;

			public bool isFlipX;

			public List<ValueEntity> extraAttrList;

			public List<AttrLabelEntity> labelList;

			public List<RecordBuffEntity> buffList;

			public List<float> floatValueList;

			public RecordPlantEntity()
			{
			}

			public RecordPlantEntity(PlantEntity plantEntity)
			{
			}

			public bool HasBuff(int buffId)
			{
				return false;
			}
		}

		[Serializable]
		public class RecordBuildingEntity
		{
			public int id;

			public PotType potType;

			public PotRewardEntity potRewardEntity;

			public RecordBuildingEntity()
			{
			}

			public RecordBuildingEntity(BuildingEntity buildingEntity)
			{
			}
		}

		[Serializable]
		public class RecordZombieEntity
		{
			public int id;

			public long onlyId;

			public float maxHealth;

			public float currentHealth;

			public float arm1MaxHealth;

			public float arm1CurrentHealth;

			public float arm2MaxHealth;

			public float arm2CurrentHealth;

			public float walkSpeedRatio;

			public int attack;

			public int magic;

			public float attackSpeed;

			public Vector2 position;

			public List<ValueEntity> extraAttrList;

			public List<AttrLabelEntity> labelList;

			public List<RecordBuffEntity> buffList;

			public RecordZombieEntity()
			{
			}

			public RecordZombieEntity(ZombieEntity zombieEntity)
			{
			}

			public bool HasBuff(int buffId)
			{
				return false;
			}
		}

		[Serializable]
		public class RecordBuffEntity
		{
			public int id;

			public float remainingTime;

			public List<ValueEntity> valueList;

			public RecordBuffEntity()
			{
			}

			public RecordBuffEntity(Buff buff)
			{
			}
		}

		public RecordAssetsEntity assetsEntity;

		public RecordCardSlotEntity cardSlotEntity;

		public List<RecordLandEntity> landList;

		public Dictionary<long, RecordZombieEntity> zombieDic;

		public RecordTouniuEntity touniuEntity;

		public void LoadFrame()
		{
		}

		private void BacktrackTouniu(TouniuBaseBody touniuBaseBody, RecordTouniuEntity recordTouniuEntity)
		{
		}

		private void BacktrackZombieDic(Dictionary<long, ZombieEntity> backgroundZombieDic, Dictionary<long, RecordZombieEntity> frameEntityZombieDic, bool endFrame = false)
		{
		}

		private void BacktrackLandPlant(LandEntity landEntity, RecordPlantEntity recordPlantEntity, int type, bool endFrame = false)
		{
		}

		private void BacktrackLandBuilding(LandEntity landEntity, RecordBuildingEntity recordBuildingEntity)
		{
		}

		public float BacktrackWave()
		{
			return 0f;
		}
	}
}
