using UnityEngine;

namespace FocusSlowMotion.Controller
{
	public class FocusRotationController : MonoBehaviour
	{
		public Material material;

		[SerializeField]
		private float rotationSpeed;

		[SerializeField]
		private float acceleration;

		private float targetAngle;

		private float currentAngle;

		private float lastUpdateTime;

		private float currentVelocity;

		private void Start()
		{
		}

		private void Update()
		{
		}

		public void SetRotationSpeed(float newSpeed)
		{
		}

		public void ToggleRotationDirection()
		{
		}

		public void ResetRotation()
		{
		}

		private bool IsUpdate()
		{
			return false;
		}
	}
}
