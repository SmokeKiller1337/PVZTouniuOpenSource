using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Bullet.Entity;
using DG.Tweening;
using FocusSlowMotion.Entity;
using Land.Entity;
using Touniu.Entity.Body;
using UnityEngine;
using Zombie.Entity;

namespace FocusSlowMotion.Controller
{
	public class FocusBackRecordController : MonoBehaviour
	{
		[CompilerGenerated]
		private sealed class _003CBacktrackOneFrameCoroutine_003Ed__18 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public FocusBackRecordController _003C_003E4__this;

			public RecordFrameEntity frameEntity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CBacktrackOneFrameCoroutine_003Ed__18(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("记录间隔")]
		public float recordIntervalTime;

		private float _recordTimer;

		[Tooltip("最大记录数")]
		public int recordMaxCount;

		[Tooltip("记录帧集合")]
		public List<RecordFrameEntity> recordFrameList;

		[Tooltip("回放每帧间隔")]
		public float backtrackIntervalTime;

		private float _backtrackTimer;

		private List<Tweener> _tweenerCoreList;

		private List<BulletEntity> _bulletList;

		private bool _isFallSun;

		private bool _isCooldownFlow;

		private bool _isPowerCooldownFlow;

		private bool _isDisableDamage;

		private int _currentWaveIndex;

		[NonSerialized]
		private RecordFrameEntity _currentFrameEntity;

		private void Start()
		{
		}

		private void Update()
		{
		}

		private void RecordCurrentFrame()
		{
		}

		private void BacktrackOneFrame()
		{
		}

		[IteratorStateMachine(typeof(_003CBacktrackOneFrameCoroutine_003Ed__18))]
		private IEnumerator BacktrackOneFrameCoroutine(RecordFrameEntity frameEntity)
		{
			return null;
		}

		private void BacktrackTouniu(TouniuBaseBody touniuBaseBody, RecordFrameEntity.RecordTouniuEntity recordTouniuEntity)
		{
		}

		private void BacktrackZombieDic(Dictionary<long, ZombieEntity> backgroundZombieDic, Dictionary<long, RecordFrameEntity.RecordZombieEntity> frameEntityZombieDic, bool endFrame = false)
		{
		}

		private void BacktrackLandPlant(LandEntity landEntity, RecordFrameEntity.RecordPlantEntity recordPlantEntity, int type, bool endFrame = false)
		{
		}

		private void BacktrackLandBuilding(LandEntity landEntity, RecordFrameEntity.RecordBuildingEntity recordBuildingEntity)
		{
		}

		private float BacktrackWave()
		{
			return 0f;
		}

		public void StartBacktrack()
		{
		}

		public void EndBacktrack()
		{
		}
	}
}
