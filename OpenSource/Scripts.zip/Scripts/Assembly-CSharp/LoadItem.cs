internal class LoadItem
{
	public string url;

	public LoadCompleteCallback onSuccess;

	public LoadErrorCallback onFail;
}
