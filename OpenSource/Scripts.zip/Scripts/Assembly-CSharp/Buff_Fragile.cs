using System;
using NoSLoofah.BuffSystem;
using UnityEngine;

[Serializable]
public class Buff_Fragile : Buff
{
	[SerializeField]
	private float hurtIncreaseRate;

	private Entity1 targetEntity;

	public override void OnBuffDestroy()
	{
	}

	public override void OnBuffModifyLayer(int change)
	{
		if (targetEntity != null)
		{
			targetEntity.ModifyDamageMultiplier((float)change * hurtIncreaseRate);
		}
	}

	public override void OnBuffRemove()
	{
	}

	public override void OnBuffStart()
	{
		targetEntity = Target.GetComponent<Entity1>();
	}

	public override void Reset()
	{
	}

	protected override void OnBuffTickEffect()
	{
	}
}
