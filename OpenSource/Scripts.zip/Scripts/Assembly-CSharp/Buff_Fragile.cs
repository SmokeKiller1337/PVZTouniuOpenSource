using System;
using NoSLoofah.BuffSystem;
using UnityEngine;

[Serializable]
public class Buff_Fragile : Buff
{
	[SerializeField]
	private float hurtIncreaseRate;

	private Entity1 targetEntity;

	public override void OnBuffDestroy()
	{
		// TODO: reconstruct
		// RVA 0x4079E0 is ICF-folded across Buff_Poison/Buff_Bleed/Buff_Fragile.OnBuffDestroy.
		// The body manipulates private base-class Buff bookkeeping fields (Layer, tmpLayer,
		// layerModified, mutilAddType, isEffective) plus a virtual dispatch, none of which
		// are accessible from this subclass. Cannot be faithfully reconstructed as clean C#.
	}

	public override void OnBuffModifyLayer(int change)
	{
		if (targetEntity != null)
		{
			targetEntity.ModifyDamageMultiplier((float)change * hurtIncreaseRate);
		}
	}

	public override void OnBuffRemove()
	{
		// TODO: reconstruct
		// RVA 0x407AF0: the decompiled body is entirely opaque static-init globals with a
		// swi(3) breakpoint and no recoverable member references. The real body could not be
		// recovered by the decompiler; reconstructing it would require fabricating members.
	}

	public override void OnBuffStart()
	{
		targetEntity = Target.GetComponent<Entity1>();
	}

	public override void Reset()
	{
	}

	protected override void OnBuffTickEffect()
	{
	}
}
