using TMPro;
using UnityEngine;

public class EntityStateWatcher : MonoBehaviour
{
	[SerializeField]
	private Entity1 entity1;

	[SerializeField]
	private TMP_Text text;

	private void Update()
	{
		if (entity1 == null || text == null)
		{
			return;
		}
		string value = "生命值: " + entity1.Health.ToString() + "/" + entity1.MaxHealth.ToString()
			+ "\n伤害倍率: " + entity1.DamageMultiplier.ToString() + "/" + entity1.StartDamageMultiplier.ToString();
		text.text = value;
	}
}
