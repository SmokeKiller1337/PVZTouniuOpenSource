using TMPro;
using UnityEngine;

public class EntityStateWatcher : MonoBehaviour
{
	[SerializeField]
	private Entity1 entity1;

	[SerializeField]
	private TMP_Text text;

	private void Update()
	{
		// Build a status string from the watched entity's current stats and
		// push it into the bound TMP_Text label. Concat order recovered from
		// pseudocode (8-part String.Concat): litA + Health + litB + MaxHealth
		//   + litC + DamageMultiplier + litB + StartDamageMultiplier.
		// Field-offset mapping (Entity1 dump): Health @0x28, MaxHealth @0x20,
		//   DamageMultiplier @0x2C, StartDamageMultiplier @0x24 -> public props.
		if (entity1 == null || text == null)
		{
			return;
		}
		string value = "生命值: " + entity1.Health.ToString() + "/" + entity1.MaxHealth.ToString()
			+ "\n伤害倍率: " + entity1.DamageMultiplier.ToString() + "/" + entity1.StartDamageMultiplier.ToString();
		text.text = value;
	}
}
