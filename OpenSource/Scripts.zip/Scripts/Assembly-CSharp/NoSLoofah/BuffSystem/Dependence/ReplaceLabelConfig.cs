namespace NoSLoofah.BuffSystem.Dependence
{
	public static class ReplaceLabelConfig
	{
		public const bool Allow = true;
	}
}
