using UnityEngine;

namespace NoSLoofah.BuffSystem.Dependence
{
	public class MonoSingleton<T> : MonoBehaviour where T : MonoSingleton<T>
	{
		protected static T instance;

		public static T GetInstance()
		{
			return null;
		}

		protected virtual void Awake()
		{
		}
	}
}
