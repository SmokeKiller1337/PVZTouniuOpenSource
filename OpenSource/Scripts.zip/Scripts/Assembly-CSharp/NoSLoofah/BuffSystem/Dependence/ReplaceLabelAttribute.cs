using System;
using UnityEngine;

namespace NoSLoofah.BuffSystem.Dependence
{
	[AttributeUsage(AttributeTargets.Field, AllowMultiple = false)]
	public class ReplaceLabelAttribute : PropertyAttribute
	{
		public string label;

		public ReplaceLabelAttribute(string label)
		{
		}
	}
}
