using System.Collections.Generic;
using UnityEngine;

namespace NoSLoofah.BuffSystem
{
	[CreateAssetMenu(fileName = "BFcollection", menuName = "BFcollection")]
	public class BuffCollection : ScriptableObject
	{
		[SerializeField]
		private int size;

		[HideInInspector]
		public List<Buff> buffList;

		public int Size => 0;

		public void Resize(int size)
		{
		}

		public void Resize()
		{
		}
	}
}
