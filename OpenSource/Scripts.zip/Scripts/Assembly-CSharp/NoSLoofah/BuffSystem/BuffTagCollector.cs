using UnityEngine;

namespace NoSLoofah.BuffSystem
{
	[CreateAssetMenu(fileName = "NewBuffTagCollector", menuName = "BuffTagCollector")]
	public class BuffTagCollector : ScriptableObject
	{
	}
}
