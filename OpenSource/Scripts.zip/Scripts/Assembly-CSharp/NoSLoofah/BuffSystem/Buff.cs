using System;
using System.Collections.Generic;
using Common.Entity;
using Game.Entity;
using Newtonsoft.Json;
using NoSLoofah.BuffSystem.Dependence;
using Touniu.Entity.Body;
using UnityEngine;

namespace NoSLoofah.BuffSystem
{
	[Serializable]
	public abstract class Buff : ScriptableObject, IBuff, IComparable<Buff>
	{
		[SerializeField]
		[ReplaceLabel("图标")]
		private Sprite icon;

		[SerializeField]
		[ReplaceLabel("名称（必填）")]
		private string buffName;

		[ReplaceLabel("描述")]
		[SerializeField]
		private string buffDesc;

		[SerializeField]
		[ReplaceLabel("重复添加方式")]
		private BuffMutilAddType mutilAddType;

		[SerializeField]
		[ReplaceLabel("计时结束时层-1/层全清空")]
		private bool removeOneLayerOnTimeUp;

		[ReplaceLabel("锁定时间的Buff编号")]
		[SerializeField]
		private List<int> lockTimerBuffIds;

		[ReplaceLabel("Tag")]
		[SerializeField]
		private BuffTag buffTag;

		[HideInInspector]
		[SerializeField]
		private int id;

		private int tmpLayer;

		private bool layerModified;

		private bool firstFrame;

		protected Rigidbody2D _rigidbody;

		protected BaseBody _baseBody;

		protected TouniuBaseBody _touniuBaseBody;

		protected SpriteRenderer _spriteRenderer;

		protected GameObject _particleObj;

		protected BuffHandler _buffHandler;

		private float timer;

		[ReplaceLabel("是永久的")]
		private bool isPermanent;

		[ReplaceLabel("Buff持续时间")]
		private float duration;

		[ReplaceLabel("值集合")]
		private List<ValueEntity> valueList;

		private bool isEffective;

		private float tickTimer;

		private float tickInterval;

		private bool runTickTimer;

		[JsonIgnore]
		public BuffHandler Target { get; private set; }

		[JsonIgnore]
		public GameObject Caster { get; private set; }

		[JsonIgnore]
		public int Layer { get; private set; }

		public bool RemoveOneLayerOnTimeUp => false;

		public List<int> LockTimerBuffIds => null;

		public BuffMutilAddType MutilAddType => default(BuffMutilAddType);

		public BuffTag BuffTag => default(BuffTag);

		public string BuffName => null;

		public string BuffDesc => null;

		public Sprite Icon => null;

		public int ID => 0;

		public BaseBody BaseBody
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		public TouniuBaseBody TouniuBaseBody
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		public Rigidbody2D Rigidbody
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		public SpriteRenderer SpriteRenderer
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		[JsonIgnore]
		public bool IsEffective => false;

		[JsonIgnore]
		public bool RunTickTimer => false;

		public float RemainingTime => 0f;

		public float Duration => 0f;

		public List<ValueEntity> ValueList => null;

		public float TickRemainingTime => 0f;

		public bool IsPermanent => false;

		public bool IsLockTimer => false;

		public static Buff CreateInstance(string buffName, int id)
		{
			return null;
		}

		public Buff Clone()
		{
			return null;
		}

		public virtual void OnBuffAwake()
		{
		}

		public abstract void OnBuffRemove();

		public virtual void OnBuffDestroy()
		{
		}

		public abstract void OnBuffStart();

		public abstract void OnBuffModifyLayer(int change);

		public abstract void Reset();

		public void InitBuff(float duration, List<ValueEntity> valueList)
		{
		}

		public void ChangeTimer(float value)
		{
		}

		public void ResetTimer()
		{
		}

		public void SetEffective(bool ef)
		{
		}

		protected virtual void OnBuffUpdateEffect()
		{
		}

		protected abstract void OnBuffTickEffect();

		public void StartBuffTickEffect(float interval)
		{
		}

		public void StopBuffTickEffect()
		{
		}

		public void OnBuffUpdate()
		{
		}

		public void Initialize(IBuffHandler target, GameObject caster)
		{
		}

		private void RealModifyLayer()
		{
		}

		public void ModifyLayer(int i)
		{
		}

		public override string ToString()
		{
			return null;
		}

		public override int GetHashCode()
		{
			return 0;
		}

		public override bool Equals(object other)
		{
			return false;
		}

		public int CompareTo(Buff other)
		{
			return 0;
		}

		public bool IsEmpty()
		{
			return false;
		}
	}
}
