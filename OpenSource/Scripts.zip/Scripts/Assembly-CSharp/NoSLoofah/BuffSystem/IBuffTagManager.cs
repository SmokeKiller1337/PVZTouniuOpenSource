namespace NoSLoofah.BuffSystem
{
	public interface IBuffTagManager
	{
		bool IsTagRemoveOther(BuffTag tag, BuffTag other);

		bool IsTagCanAddWhenHaveOther(BuffTag tag, BuffTag other);
	}
}
