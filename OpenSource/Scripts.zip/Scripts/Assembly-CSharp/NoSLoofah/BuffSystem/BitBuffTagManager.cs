using UnityEngine;

namespace NoSLoofah.BuffSystem
{
	public class BitBuffTagManager : BuffTagManager
	{
		[SerializeField]
		[HideInInspector]
		private BitBuffTagData tagData;

		public void SetData(BitBuffTagData data)
		{
		}

		private void Awake()
		{
		}

		public override bool IsTagRemoveOther(BuffTag tag, BuffTag other)
		{
			return false;
		}

		public override bool IsTagCanAddWhenHaveOther(BuffTag tag, BuffTag other)
		{
			return false;
		}
	}
}
