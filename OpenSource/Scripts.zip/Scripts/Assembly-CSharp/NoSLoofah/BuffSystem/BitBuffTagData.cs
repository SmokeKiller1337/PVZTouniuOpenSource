using System.Collections.Generic;
using UnityEngine;

namespace NoSLoofah.BuffSystem
{
	public class BitBuffTagData : BuffTagData
	{
		[Tooltip("这些tag的旧Buff会被挤掉")]
		[SerializeField]
		private List<int> removedTags;

		[SerializeField]
		[Tooltip("存在这些tag的Buff时新Buff无法被添加")]
		private List<int> blockTags;

		public int[] RemovedTags => null;

		public int[] BlockTags => null;

		public static int GetIndex(BuffTag tag)
		{
			return 0;
		}

		public void Initialize()
		{
		}
	}
}
