using UnityEngine;

namespace NoSLoofah.BuffSystem
{
	[SerializeField]
	public enum BuffMutilAddType
	{
		resetTime = 0,
		multipleLayer = 1,
		multipleLayerAndResetTime = 2,
		multipleCount = 3
	}
}
