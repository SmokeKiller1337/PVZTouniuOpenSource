using System;
using System.Collections.Generic;
using Game.Entity;
using UnityEngine;

namespace NoSLoofah.BuffSystem
{
	public interface IBuffHandler
	{
		Buff AddBuff(int buffId, GameObject caster, float duration = -1f, List<ValueEntity> valueList = null);

		void RemoveBuff(int buffId, bool removeAll = true);

		void InterruptBuff(int buffId, bool interuptAll = true);

		void RegisterOnAddBuff(Action act);

		void RemoveOnAddBuff(Action act);

		void RegisterOnRemoveBuff(Action act);

		void RemoveOnRemoveBuff(Action act);
	}
}
