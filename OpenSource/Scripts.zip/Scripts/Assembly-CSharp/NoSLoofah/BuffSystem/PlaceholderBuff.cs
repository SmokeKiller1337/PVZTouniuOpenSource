namespace NoSLoofah.BuffSystem
{
	public class PlaceholderBuff : Buff
	{
		public override void OnBuffDestroy()
		{
		}

		public override void OnBuffModifyLayer(int change)
		{
		}

		public override void OnBuffRemove()
		{
		}

		public override void OnBuffStart()
		{
		}

		public override void Reset()
		{
		}

		protected override void OnBuffTickEffect()
		{
		}
	}
}
