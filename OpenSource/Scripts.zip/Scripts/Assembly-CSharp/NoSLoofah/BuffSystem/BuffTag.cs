using System;

namespace NoSLoofah.BuffSystem
{
	[Flags]
	public enum BuffTag
	{
		none = 0,
		tag1 = 1,
		tag2 = 2,
		tag3 = 4,
		tag4 = 8,
		tag5 = 0x10,
		tag6 = 0x20,
		tag7 = 0x40,
		tag8 = 0x80,
		tag9 = 0x100,
		tag10 = 0x200,
		tag11 = 0x400,
		tag12 = 0x800,
		tag13 = 0x1000,
		tag14 = 0x2000,
		tag15 = 0x4000,
		tag16 = 0x8000,
		tag17 = 0x10000,
		tag18 = 0x20000,
		tag19 = 0x40000,
		tag20 = 0x80000,
		tag21 = 0x100000,
		tag22 = 0x200000,
		tag23 = 0x400000,
		tag24 = 0x800000,
		tag25 = 0x1000000,
		tag26 = 0x2000000,
		tag27 = 0x4000000,
		tag28 = 0x8000000,
		tag29 = 0x10000000,
		tag30 = 0x20000000,
		tag31 = 0x40000000
	}
}
