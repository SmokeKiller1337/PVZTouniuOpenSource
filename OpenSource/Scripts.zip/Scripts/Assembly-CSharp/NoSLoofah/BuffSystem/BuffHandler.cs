using System;
using System.Collections.Generic;
using Game.Entity;
using MyBuff.Entity;
using UnityEngine;

namespace NoSLoofah.BuffSystem
{
	public class BuffHandler : MonoBehaviour, IBuffHandler
	{
		private List<Buff> buffs;

		private Action onAddBuff;

		private Action onRemoveBuff;

		private List<BuffDefault> _materialBuffList;

		private BuffDefault _currentMaterialBuff;

		private bool updated;

		private Action forOnBuffDestroy;

		private Action forOnBuffStart;

		public List<Buff> GetBuffs => null;

		public void RegisterOnAddBuff(Action act)
		{
		}

		public void RemoveOnAddBuff(Action act)
		{
		}

		public void RegisterOnRemoveBuff(Action act)
		{
		}

		public void RemoveOnRemoveBuff(Action act)
		{
		}

		private Buff AddBuff(IBuff buff, GameObject caster, float duration = -1f, List<ValueEntity> valueList = null)
		{
			return null;
		}

		private void RemoveBuff(IBuff buff)
		{
		}

		private void InterruptBuff(IBuff buff)
		{
		}

		public void Reset()
		{
		}

		public Buff GetBuff(int buffId)
		{
			return null;
		}

		public bool HasBuff(int buffId)
		{
			return false;
		}

		public Buff AddBuff(int buffId, GameObject caster, float duration = -1f, List<ValueEntity> valueList = null)
		{
			return null;
		}

		public void ChangeBuffTimer(int buffId, float value)
		{
		}

		public void RemoveBuff(int buffId, bool removeAll = true)
		{
		}

		public void RemoveAllBuff()
		{
		}

		public void InterruptBuff(int buffId, bool removeAll = true)
		{
		}

		public void InterruptAllBuff()
		{
		}

		public void EnterBuffMaterial(BuffDefault buff)
		{
		}

		public void ExitBuffMaterial(BuffDefault buff)
		{
		}

		private void UpdateBuffMaterial(BuffDefault buff)
		{
		}

		private void Awake()
		{
		}

		private void Start()
		{
		}

		private void Update()
		{
		}

		private void LateUpdate()
		{
		}
	}
}
