using UnityEngine;

namespace NoSLoofah.BuffSystem
{
	[SerializeField]
	public interface IBuff
	{
		void OnBuffAwake();

		void OnBuffStart();

		void OnBuffRemove();

		void OnBuffDestroy();

		void OnBuffUpdate();

		void OnBuffModifyLayer(int change);

		void StartBuffTickEffect(float interval);

		void StopBuffTickEffect();

		void Reset();

		void ResetTimer();

		void Initialize(IBuffHandler target, GameObject caster);

		void ModifyLayer(int i);

		void SetEffective(bool ef);

		bool IsEmpty();
	}
}
