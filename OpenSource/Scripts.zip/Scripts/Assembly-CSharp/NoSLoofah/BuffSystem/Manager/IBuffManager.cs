namespace NoSLoofah.BuffSystem.Manager
{
	public interface IBuffManager
	{
		IBuff GetBuff(int id);

		void RegisterBuffTagManager(IBuffTagManager mgr);
	}
}
