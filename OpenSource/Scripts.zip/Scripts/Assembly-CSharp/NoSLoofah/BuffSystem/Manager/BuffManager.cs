using NoSLoofah.BuffSystem.Dependence;
using UnityEngine;

namespace NoSLoofah.BuffSystem.Manager
{
	public class BuffManager : MonoSingleton<BuffManager>, IBuffManager
	{
		[SerializeField]
		[HideInInspector]
		private BuffCollection collection;

		private IBuffTagManager tagManager;

		public bool IsWorking => false;

		public IBuffTagManager TagManager => null;

		public void SetData(BuffCollection buffCollection)
		{
		}

		protected override void Awake()
		{
		}

		public IBuff GetBuff(int id)
		{
			return null;
		}

		public void RegisterBuffTagManager(IBuffTagManager mgr)
		{
		}
	}
}
