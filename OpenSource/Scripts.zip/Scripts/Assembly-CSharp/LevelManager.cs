using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using FairyGUI;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelManager : MonoBehaviour
{
	[CompilerGenerated]
	private sealed class _003CDoLoad_003Ed__8 : IEnumerator<object>, IEnumerator, IDisposable
	{
		private int _003C_003E1__state;

		private object _003C_003E2__current;

		public LevelManager _003C_003E4__this;

		public string sceneName;

		private GProgressBar _003Cpb_003E5__2;

		private AsyncOperation _003Cop_003E5__3;

		private float _003CstartTime_003E5__4;

		object IEnumerator<object>.Current
		{
			[DebuggerHidden]
			get
			{
				return _003C_003E2__current;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return _003C_003E2__current;
			}
		}

		[DebuggerHidden]
		public _003CDoLoad_003Ed__8(int _003C_003E1__state)
		{
			this._003C_003E1__state = _003C_003E1__state;
		}

		[DebuggerHidden]
		void IDisposable.Dispose()
		{
		}

		private bool MoveNext()
		{
			LevelManager levelManager = this._003C_003E4__this;
			int num = this._003C_003E1__state;
			if (num == 0)
			{
				this._003C_003E1__state = -1;
				if (levelManager == null || GRoot.inst == null)
				{
					return false;
				}
				GRoot.inst.AddChild(levelManager._cutSceneView);
				if (levelManager._cutSceneView == null)
				{
					return false;
				}
				GObject child = levelManager._cutSceneView.GetChild("pb");
				if (child == null)
				{
					return false;
				}
				this._003Cpb_003E5__2 = child.asProgress;
				if (this._003Cpb_003E5__2 == null)
				{
					return false;
				}
				this._003Cpb_003E5__2.value = 0.0;
				this._003Cop_003E5__3 = SceneManager.LoadSceneAsync(this.sceneName);
				this._003CstartTime_003E5__4 = Time.time;
			}
			else
			{
				if (num != 1)
				{
					return false;
				}
				this._003C_003E1__state = -1;
			}
			if (this._003Cop_003E5__3 == null)
			{
				return false;
			}
			if (this._003Cop_003E5__3.isDone)
			{
				if (this._003Cpb_003E5__2 == null)
				{
					return false;
				}
				if (this._003Cpb_003E5__2.value == 100.0)
				{
					if (levelManager != null && GRoot.inst != null)
					{
						GRoot.inst.RemoveChild(levelManager._cutSceneView);
						if (GRoot.inst != null)
						{
							GRoot.inst.AddChild(levelManager._mainView);
							return false;
						}
					}
					return false;
				}
			}
			// TODO: reconstruct exact progress scaling constants (original used two float literals);
			// mapping (Time.time - startTime) into a clamped 0..100 progress value.
			int num2 = (int)((Time.time - this._003CstartTime_003E5__4) * 100f / 2f);
			if (num2 > 100)
			{
				num2 = 100;
			}
			if (this._003Cpb_003E5__2 != null)
			{
				this._003Cpb_003E5__2.value = num2;
				this._003C_003E2__current = null;
				this._003C_003E1__state = 1;
				return true;
			}
			return false;
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			return this.MoveNext();
		}

		[DebuggerHidden]
		void IEnumerator.Reset()
		{
			throw new NotSupportedException();
		}
	}

	private static LevelManager _instance;

	private GComponent _cutSceneView;

	private GComponent _mainView;

	public static LevelManager inst
	{
		get
		{
			if (_instance == null)
			{
				GameObject gameObject = new GameObject("LevelManager");
				UnityEngine.Object.DontDestroyOnLoad(gameObject);
				_instance = gameObject.AddComponent<LevelManager>();
			}
			return _instance;
		}
	}

	public void Init()
	{
		GObject gObject = UIPackage.CreateObject("Level", "Level");
		if (gObject != null)
		{
			_cutSceneView = gObject.asCom;
		}
	}

	public void LoadLevel(string levelName)
	{
		StartCoroutine(DoLoad(levelName));
		GRoot root = GRoot.inst;
		if (root != null)
		{
			root.AddChild(_cutSceneView);
		}
	}

	[IteratorStateMachine(typeof(_003CDoLoad_003Ed__8))]
	private IEnumerator DoLoad(string sceneName)
	{
		return new _003CDoLoad_003Ed__8(0)
		{
			_003C_003E4__this = this,
			sceneName = sceneName
		};
	}
}
