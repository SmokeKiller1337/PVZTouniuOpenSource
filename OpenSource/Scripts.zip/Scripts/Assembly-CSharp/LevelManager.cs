using System;
using System.Collections;
using System.Collections.Generic;
using FairyGUI;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelManager : MonoBehaviour
{
	private static LevelManager _instance;

	private GComponent _cutSceneView;

	private GComponent _mainView;

	public static LevelManager inst
	{
		get
		{
			if (_instance == null)
			{
				GameObject gameObject = new GameObject("LevelManager");
				UnityEngine.Object.DontDestroyOnLoad(gameObject);
				_instance = gameObject.AddComponent<LevelManager>();
			}
			return _instance;
		}
	}

	public void Init()
	{
		GObject gObject = UIPackage.CreateObject("Level", "Level");
		if (gObject != null)
		{
			_cutSceneView = gObject.asCom;
		}
	}

	public void LoadLevel(string levelName)
	{
		StartCoroutine(DoLoad(levelName));
		GRoot root = GRoot.inst;
		if (root != null)
		{
			root.AddChild(_cutSceneView);
		}
	}

	private IEnumerator DoLoad(string sceneName)
	{
		if (this == null || GRoot.inst == null)
		{
			yield break;
		}
		GRoot.inst.AddChild(_cutSceneView);
		if (_cutSceneView == null)
		{
			yield break;
		}
		GObject child = _cutSceneView.GetChild("pb");
		if (child == null)
		{
			yield break;
		}
		GProgressBar pb = child.asProgress;
		if (pb == null)
		{
			yield break;
		}
		pb.value = 0.0;
		AsyncOperation op = SceneManager.LoadSceneAsync(sceneName);
		float startTime = Time.time;
		// 进度条动画：等待场景异步加载完成，加载好后切换到主界面
		while (true)
		{
			if (op == null)
			{
				yield break;
			}
			if (op.isDone && pb == null)
			{
				yield break;
			}
			if (op.isDone && pb.value == 100.0)
			{
				if (this != null && GRoot.inst != null)
				{
					GRoot.inst.RemoveChild(_cutSceneView);
					if (GRoot.inst != null)
					{
						GRoot.inst.AddChild(_mainView);
					}
				}
				yield break;
			}
			int num = (int)((Time.time - startTime) * 100f / 2f);
			if (num > 100)
			{
				num = 100;
			}
			if (pb == null)
			{
				yield break;
			}
			pb.value = num;
			yield return null;
		}
	}
}
