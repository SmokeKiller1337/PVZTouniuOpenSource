using FairyGUI;

public delegate void LoadCompleteCallback(NTexture texture);
