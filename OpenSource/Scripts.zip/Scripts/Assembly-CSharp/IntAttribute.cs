public class IntAttribute
{
	public int Value { get; private set; }

	public int BaseValue { get; private set; }

	public int Addition0 { get; private set; }

	public int PctAddion0 { get; private set; }

	public int Addition1 { get; private set; }

	public int PctAddion1 { get; private set; }

	public IntAttribute(int baseValue = 0)
	{
		BaseValue = baseValue;
		Addition1 = 0;
		Addition0 = 0;
		Value = 0;
	}

	public void Reset()
	{
		Addition1 = 0;
		PctAddion1 = 0;
		Addition0 = 0;
		PctAddion0 = 0;
		Value = 0;
		BaseValue = 0;
	}

	public void SetBaseValue(int value)
	{
		BaseValue = value;
		UpdateValue();
	}

	public void ModifyValue(int value)
	{
		BaseValue += value;
		UpdateValue();
	}

	public void ModifyAddition0(int value)
	{
		Addition0 += value;
		UpdateValue();
	}

	public void ModifyAddition1(int value)
	{
		Addition1 += value;
		UpdateValue();
	}

	public void ModifyPctAddition0(int value)
	{
		PctAddion0 += value;
		UpdateValue();
	}

	public void ModifyPctAddition1(int value)
	{
		PctAddion1 += value;
		UpdateValue();
	}

	private void UpdateValue()
	{
		Value = (int)((((float)((Addition0 + BaseValue) * (PctAddion0 + 100)) / 100f + (float)Addition1) * (float)(PctAddion1 + 100)) / 100f);
	}
}
