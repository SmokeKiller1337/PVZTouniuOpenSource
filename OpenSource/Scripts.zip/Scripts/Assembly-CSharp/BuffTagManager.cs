using NoSLoofah.BuffSystem;
using UnityEngine;

public abstract class BuffTagManager : MonoBehaviour, IBuffTagManager
{
	public abstract bool IsTagRemoveOther(BuffTag tag, BuffTag other);

	public abstract bool IsTagCanAddWhenHaveOther(BuffTag tag, BuffTag other);

	protected virtual void Start()
	{
	}
}
