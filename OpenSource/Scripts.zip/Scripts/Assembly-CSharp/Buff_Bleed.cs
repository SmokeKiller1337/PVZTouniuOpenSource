using NoSLoofah.BuffSystem;
using UnityEngine;

public class Buff_Bleed : Buff
{
	[SerializeField]
	private int bleedDamage;

	[SerializeField]
	private float bleedTimeInterval;

	private Entity1 targetEntity;

	public override void OnBuffDestroy()
	{
		// TODO: reconstruct
		// RVA 0x4079E0 is ICF-folded onto Buff_Poison__OnBuffDestroy, whose body
		// references field offsets that do not match Buff_Bleed's layout. The real
		// body cannot be reliably recovered, so it is left as a stub.
	}

	public override void OnBuffModifyLayer(int change)
	{
	}

	public override void OnBuffRemove()
	{
	}

	public override void OnBuffStart()
	{
		targetEntity = Caster.GetComponent<Entity1>();
		StartBuffTickEffect(bleedTimeInterval);
	}

	public override void Reset()
	{
	}

	protected override void OnBuffTickEffect()
	{
		targetEntity.ModifyHealth(-(bleedDamage * Layer));
	}
}
