namespace Luban
{
	public readonly struct SegmentSaveState
	{
		public int ReaderIndex { get; }

		public int WriterIndex { get; }

		public SegmentSaveState(int readerIndex, int writerIndex)
		{
			ReaderIndex = 0;
			WriterIndex = 0;
		}
	}
}
