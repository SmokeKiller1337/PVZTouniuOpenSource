namespace Luban
{
	public enum EDeserializeError
	{
		OK = 0,
		NOT_ENOUGH = 1,
		EXCEED_SIZE = 2
	}
}
