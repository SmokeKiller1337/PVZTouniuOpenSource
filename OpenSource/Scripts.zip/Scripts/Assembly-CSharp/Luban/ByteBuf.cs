using System;
using System.Numerics;
using System.Runtime.CompilerServices;

namespace Luban
{
	public sealed class ByteBuf : ICloneable, IEquatable<ByteBuf>
	{
		private readonly Action<ByteBuf> _releaser;

		private const int MIN_CAPACITY = 16;

		public int ReaderIndex { get; set; }

		public int WriterIndex { get; set; }

		public int Capacity => 0;

		public int Size => 0;

		public bool Empty => false;

		public bool NotEmpty => false;

		public byte[] Bytes { get; private set; }

		public int Remaining => 0;

		public int NotCompactWritable => 0;

		public static Func<byte[], int, int, string> StringCacheFinder { get; set; }

		public ByteBuf()
		{
		}

		public ByteBuf(int capacity)
		{
		}

		public ByteBuf(byte[] bytes)
		{
		}

		public ByteBuf(byte[] bytes, int readIndex, int writeIndex)
		{
		}

		public ByteBuf(int capacity, Action<ByteBuf> releaser)
		{
		}

		public static ByteBuf Wrap(byte[] bytes)
		{
			return null;
		}

		public void Replace(byte[] bytes)
		{
		}

		public void Replace(byte[] bytes, int beginPos, int endPos)
		{
		}

		public void AddWriteIndex(int add)
		{
		}

		public void AddReadIndex(int add)
		{
		}

		public byte[] CopyData()
		{
			return null;
		}

		public void DiscardReadBytes()
		{
		}

		public void WriteBytesWithoutSize(byte[] bs)
		{
		}

		public void WriteBytesWithoutSize(byte[] bs, int offset, int len)
		{
		}

		public void Clear()
		{
		}

		private static int PropSize(int initSize, int needSize)
		{
			return 0;
		}

		private void EnsureWrite0(int size)
		{
		}

		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public void EnsureWrite(int size)
		{
		}

		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		private void EnsureRead(int size)
		{
		}

		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		private bool CanRead(int size)
		{
			return false;
		}

		public void Append(byte x)
		{
		}

		public void WriteBool(bool b)
		{
		}

		public bool ReadBool()
		{
			return false;
		}

		public void WriteByte(byte x)
		{
		}

		public byte ReadByte()
		{
			return 0;
		}

		public void WriteShort(short x)
		{
		}

		public short ReadShort()
		{
			return 0;
		}

		public short ReadFshort()
		{
			return 0;
		}

		public void WriteFshort(short x)
		{
		}

		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public void WriteInt(int x)
		{
		}

		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public int ReadInt()
		{
			return 0;
		}

		public void WriteUint(uint x)
		{
		}

		public uint ReadUint()
		{
			return 0u;
		}

		public void WriteUint_Unsafe(uint x)
		{
		}

		public uint ReadUint_Unsafe()
		{
			return 0u;
		}

		public int ReadFint()
		{
			return 0;
		}

		public void WriteFint(int x)
		{
		}

		public int ReadFint_Safe()
		{
			return 0;
		}

		public void WriteFint_Safe(int x)
		{
		}

		public void WriteLong(long x)
		{
		}

		public long ReadLong()
		{
			return 0L;
		}

		public void WriteNumberAsLong(double x)
		{
		}

		public double ReadLongAsNumber()
		{
			return 0.0;
		}

		private void WriteUlong(ulong x)
		{
		}

		public ulong ReadUlong()
		{
			return 0uL;
		}

		public void WriteFlong(long x)
		{
		}

		public long ReadFlong()
		{
			return 0L;
		}

		private unsafe static void Copy8(byte* dst, byte* src)
		{
		}

		private unsafe static void Copy4(byte* dst, byte* src)
		{
		}

		public void WriteFloat(float x)
		{
		}

		public float ReadFloat()
		{
			return 0f;
		}

		public void WriteDouble(double x)
		{
		}

		public double ReadDouble()
		{
			return 0.0;
		}

		public void WriteSize(int n)
		{
		}

		public int ReadSize()
		{
			return 0;
		}

		public void WriteSint(int x)
		{
		}

		public int ReadSint()
		{
			return 0;
		}

		public void WriteSlong(long x)
		{
		}

		public long ReadSlong()
		{
			return 0L;
		}

		public void WriteString(string x)
		{
		}

		public string ReadString()
		{
			return null;
		}

		public void WriteBytes(byte[] x)
		{
		}

		public byte[] ReadBytes()
		{
			return null;
		}

		public void WriteComplex(Complex x)
		{
		}

		public Complex ReadComplex()
		{
			return default(Complex);
		}

		public void WriteVector2(Vector2 x)
		{
		}

		public Vector2 ReadVector2()
		{
			return default(Vector2);
		}

		public void WriteVector3(Vector3 x)
		{
		}

		public Vector3 ReadVector3()
		{
			return default(Vector3);
		}

		public void WriteVector4(Vector4 x)
		{
		}

		public Vector4 ReadVector4()
		{
			return default(Vector4);
		}

		public void WriteQuaternion(Quaternion x)
		{
		}

		public Quaternion ReadQuaternion()
		{
			return default(Quaternion);
		}

		public void WriteMatrix4x4(Matrix4x4 x)
		{
		}

		public Matrix4x4 ReadMatrix4x4()
		{
			return default(Matrix4x4);
		}

		internal void SkipBytes()
		{
		}

		public void WriteByteBufWithSize(ByteBuf o)
		{
		}

		public void WriteByteBufWithoutSize(ByteBuf o)
		{
		}

		public bool TryReadByte(out byte x)
		{
			x = default(byte);
			return false;
		}

		public EDeserializeError TryDeserializeInplaceByteBuf(int maxSize, ByteBuf inplaceTempBody)
		{
			return default(EDeserializeError);
		}

		public void WriteRawTag(byte b1)
		{
		}

		public void WriteRawTag(byte b1, byte b2)
		{
		}

		public void WriteRawTag(byte b1, byte b2, byte b3)
		{
		}

		public void BeginWriteSegment(out int oldSize)
		{
			oldSize = default(int);
		}

		public void EndWriteSegment(int oldSize)
		{
		}

		public void ReadSegment(out int startIndex, out int segmentSize)
		{
			startIndex = default(int);
			segmentSize = default(int);
		}

		public void ReadSegment(ByteBuf buf)
		{
		}

		public void EnterSegment(out SegmentSaveState saveState)
		{
			saveState = default(SegmentSaveState);
		}

		public void LeaveSegment(SegmentSaveState saveState)
		{
		}

		public override string ToString()
		{
			return null;
		}

		public override bool Equals(object obj)
		{
			return false;
		}

		public bool Equals(ByteBuf other)
		{
			return false;
		}

		public object Clone()
		{
			return null;
		}

		public static ByteBuf FromString(string value)
		{
			return null;
		}

		public override int GetHashCode()
		{
			return 0;
		}

		public void Release()
		{
		}
	}
}
