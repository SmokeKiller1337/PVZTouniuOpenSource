using System;

namespace Luban
{
	public class SerializationException : Exception
	{
		public SerializationException()
		{
		}

		public SerializationException(string msg)
		{
		}

		public SerializationException(string message, Exception innerException)
		{
		}
	}
}
