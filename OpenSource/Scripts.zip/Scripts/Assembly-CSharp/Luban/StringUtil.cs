using System.Collections.Generic;
using System.Text;

namespace Luban
{
	public static class StringUtil
	{
		public static string ToStr(object o)
		{
			return null;
		}

		public static string ToStr(object o, StringBuilder sb)
		{
			return null;
		}

		public static string ArrayToString<T>(T[] arr)
		{
			return null;
		}

		public static string CollectionToString<T>(IEnumerable<T> arr)
		{
			return null;
		}

		public static string CollectionToString<TK, TV>(IDictionary<TK, TV> dic)
		{
			return null;
		}
	}
}
