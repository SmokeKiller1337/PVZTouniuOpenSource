namespace Plant.Enum
{
	public enum PlaceType
	{
		All = -1,
		Master = 0,
		Shell = 1,
		Base = 2,
		Float = 3,
		Zombie = 4
	}
}
