namespace Plant.Enum
{
	public enum SleepType
	{
		NoSleep = 0,
		DaySleep = 1,
		NightSleep = 2
	}
}
