namespace Plant.Enum
{
	public enum CardType
	{
		Normal = 0,
		Guest = 1,
		Special = 2,
		Zombie = 3
	}
}
