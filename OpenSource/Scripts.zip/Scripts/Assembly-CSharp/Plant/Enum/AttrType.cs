namespace Plant.Enum
{
	public enum AttrType
	{
		Sun = 1,
		CooldownTime = 2,
		Health = 11,
		Attack = 12,
		Magic = 13,
		AttackSpeed = 14,
		WalkSpeed = 15,
		CardExtra1 = 21,
		CardExtra2 = 22,
		CardExtra3 = 23,
		PlantExtra1 = 31,
		PlantExtra2 = 32,
		PlantExtra3 = 33
	}
}
