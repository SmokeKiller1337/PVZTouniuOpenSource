using System.Collections;
using Common.Collider;
using Common.Entity;
using Level.Manager;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	// Plant10Entity —— 豌豆射手（单发向前射击的基础植物）。
	// 从 GameAssembly.dll 反编译还原；协程已改写为惯用 yield 形式（编译器会自动生成状态机）。
	public class Plant10Entity : PlantEntity
	{
		// 动画参数/状态/标签名，均从 IL2CPP metadata 字符串表解出。
		private const string AttackAnimSpeedParam = "AttackSpeedRatio"; // Attack() 里 _animator.SetFloat 的参数
		private const string AttackWindupAnimName = "HeadShooting"; // AttackCoroutine 里 _animator.Play 的状态(图层1)
		private const string EyeBlinkAnimName = "EyeBlink"; // EyeBlink() 里 _animator.Play 的状态(图层0)
		private const string EyeBlinkTag = "Idle"; // EyeBlink() 判定的 animator 状态标签(两层)

		// 以下是二进制里的裸 float 全局常量，无法解出确切值，保留合理占位。
		private const float AttackSpeedFrameRate = 30f; // TODO: 攻速倍率 (_DAT_18252cf40)
		private const float AttackWindupFactor = 1f; // TODO: 协程等待倍率 (_DAT_18252cd08)
		private const float OnUsePower0Interval = 0.1f; // TODO: 连发间隔 (_DAT_18252ccfc)
		private const float DefaultAttackRange = 30f; // TODO: 射线射程回退值（原用管理器参照 transform）

		[Tooltip("子弹位置")]
		public Transform bulletPosition;

		[Tooltip("头部物体")]
		public GameObject headObj;

		public override void Reset()
		{
			// RVA 0x592570：与 PlantEntity.Reset() 完全一致，委托基类。
			base.Reset();
		}

		protected override void Update()
		{
			// RVA 0x592580：与 PlantEntity.Update() 一致（攻击节拍 + 眨眼 + 大招冷却）。
			// CheckAttack/Attack/EyeUpdate 走虚调用，基类节拍会回调本类的重写。
			base.Update();
		}

		public override void EyeBlink()
		{
			// RVA 0x592210：眼睛未闭合、且两层动画当前状态标签都是 "Idle" 时，播眨眼动画。
			if (partEntity == null || partEntity.isCloseEye)
			{
				return;
			}
			if (_animator == null)
			{
				return;
			}
			AnimatorStateInfo layer0 = _animator.GetCurrentAnimatorStateInfo(0);
			if (!layer0.IsTag(EyeBlinkTag))
			{
				return;
			}
			AnimatorStateInfo layer1 = _animator.GetCurrentAnimatorStateInfo(1);
			if (!layer1.IsTag(EyeBlinkTag))
			{
				return;
			}
			_animator.Play(EyeBlinkAnimName, 0);
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// RVA 0x381980：原本就是空实现。
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			// RVA 0x592360：
			//   index 0：attr.attack += (int)(defaultAttr.attack * value)
			//   index 1：attr.AttackSpeed = defaultAttr.attackSpeed * value + attr.attackSpeed
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				if (attr != null && defaultAttr != null)
				{
					attr.attack = (int)((float)defaultAttr.attack * entity.GetValue(this)) + attr.attack;
				}
			}
			else if (entity.index == 1)
			{
				if (attr != null && defaultAttr != null)
				{
					attr.AttackSpeed = defaultAttr.attackSpeed * entity.GetValue(this) + attr.attackSpeed;
				}
			}
		}

		protected override void Attack()
		{
			// RVA 0x592130：设置攻速动画参数，然后启动开火协程。
			if (attr == null || _animator == null)
			{
				return;
			}
			_animator.SetFloat(AttackAnimSpeedParam, attr.attackSpeed * AttackSpeedFrameRate);
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			// RVA 0x5920C0 / 0x59cc20：播头部射击动画(图层1) → 等一小段(攻击间隔的一部分) → 头部激活时从 bulletPosition 生成豌豆。
			if (_animator == null || attr == null)
			{
				yield break;
			}
			_animator.Play(AttackWindupAnimName, 1, 0f);
			yield return new WaitForSeconds(attr.attackIntervalTime * AttackWindupFactor);
			if (headObj != null && headObj.activeSelf && bulletPosition != null)
			{
				CreateBullet(0, bulletPosition.position);
			}
		}

		protected override bool CheckAttack()
		{
			// RVA 0x592200：向前方射线扫描 "Zombie" 层，命中活着的可攻击僵尸即返回 true。
			// 忠实于反编译结构：
			//   * 开火方向由 BaseBody.IsFlipX 决定（面朝左/右）；
			//   * 射线起点为本植物世界坐标；
			//   * 每个命中的碰撞体解析出 BodyColliderEntity -> BaseBody，
			//     该 body 需同时"可被吃"且"可选取"——即 IsNotEat() 与 IsNotPick0()
			//     （伪代码虚表槽 0x388 / 0x378）都为 false——才算有效目标。
			// 原始的精确方向分量与射程来自两个关卡管理器经 +0xb8 字段链，无法唯一解出；
			// 这里方向取水平朝向、射程取关卡边界（带固定回退值），结构等价。
			Vector2 origin = base.transform.position;
			bool flipX = IsFlipX;
			Vector2 direction = flipX ? Vector2.left : Vector2.right;

			float range = DefaultAttackRange;
			LevelAssetsManager assets = LevelAssetsManager.Instance;
			if (assets != null)
			{
				float edgeX = flipX ? assets.leftUpPosition.x : assets.rightDownPosition.x;
				range = Mathf.Abs(edgeX - origin.x);
			}

			int zombieMask = LayerMask.GetMask("Zombie");
			RaycastHit2D[] hits = Physics2D.RaycastAll(origin, direction, range, zombieMask);
			if (hits == null)
			{
				return false;
			}
			for (int i = 0; i < hits.Length; i++)
			{
				Collider2D collider = hits[i].collider;
				if (collider == null)
				{
					continue;
				}
				BodyColliderEntity bodyCollider = collider.GetComponent<BodyColliderEntity>();
				if (bodyCollider == null)
				{
					continue;
				}
				BaseBody body = bodyCollider.baseBody;
				if (body == null)
				{
					continue;
				}
				if (!body.IsNotEat() && !body.IsNotPick0())
				{
					return true;
				}
			}
			return false;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// RVA 0x592450 / 0x59e520：额外开火 entity.GetValue(this) 次，每次之间等 OnUsePower0Interval。
			if (entity == null)
			{
				yield break;
			}
			for (int i = 0; i < (int)entity.GetValue(this); i++)
			{
				yield return new WaitForSeconds(OnUsePower0Interval);
				StartCoroutine(AttackCoroutine());
			}
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			// RVA 0x5924E0 / 0x59fcd0：一次性增益——按 defaultAttr 加攻击力，并加一条属性标签。
			if (attr != null && defaultAttr != null && entity != null)
			{
				attr.attack = (int)((float)defaultAttr.attack * entity.GetValue(this)) + attr.attack;
				attr.AddLabel(entity.title, 1, entity.GetDesc(this));
			}
			yield break;
		}

		public override int GetHeadNumber()
		{
			// RVA 0x592330：头部物体激活时算 1 个头，否则 0。
			if (headObj == null)
			{
				return 0;
			}
			return headObj.activeSelf ? 1 : 0;
		}
	}
}
