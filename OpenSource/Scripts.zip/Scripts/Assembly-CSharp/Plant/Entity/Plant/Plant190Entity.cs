using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant190Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__10 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant190Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__10(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct — the attack state machine plays an attack animation, waits
				// attr.attackIntervalTime scaled by an unresolved global time factor, then (on resume)
				// spawns bullets from the three head muzzles with per-head directional velocity.
				// The bullet-spawn half relies on unresolved scene/level manager singletons and a bullet
				// velocity component whose fields could not be mapped to BulletEntity, so the whole body
				// is left as the default stub to avoid encoding wrong logic.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__12 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant190Entity _003C_003E4__this;

			public StrengthenEntity entity;

			private int _003Ci_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__12(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant190Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					// i = 0
					_003Ci_003E5__2 = 0;
				}
				else
				{
					if (num != 1)
					{
						return false;
					}
					_003C_003E1__state = -1;
					// fire one attack burst and advance the counter
					if (plant == null)
					{
						return false;
					}
					plant.StartCoroutine(plant.AttackCoroutine());
					_003Ci_003E5__2++;
				}
				// keep firing while the strengthen value (attack count) has not been reached
				if (entity == null)
				{
					return false;
				}
				if ((int)entity.GetValue(plant) <= _003Ci_003E5__2)
				{
					return false;
				}
				// TODO: OnUsePower0IntervalSeconds is an unresolved global (_DAT_18252ccfc) — the
				// per-shot delay used between the extra power-triggered attacks.
				_003C_003E2__current = new WaitForSeconds(OnUsePower0IntervalSeconds);
				_003C_003E1__state = 1;
				return true;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__13 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant190Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__13(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// Not an actual yielding coroutine: it applies an attack-power buff once, then ends.
				if (_003C_003E1__state != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				Plant190Entity plant = _003C_003E4__this;
				if (plant == null || plant.attr == null || plant.defaultAttr == null || entity == null)
				{
					return false;
				}
				// attr.attack += (int)(defaultAttr.attack * strengthenValue)
				plant.attr.attack = (int)((float)plant.defaultAttr.attack * entity.GetValue(plant)) + plant.attr.attack;
				// label the applied strengthen so the attr box can display it
				plant.attr.AddLabel(entity.title, 1, entity.GetDesc(plant));
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		// TODO: reconstruct — unresolved global (_DAT_18252ccfc) delay between power-0 extra attacks.
		private const float OnUsePower0IntervalSeconds = 0.1f;

		// TODO: reconstruct — the animator state name / tag literals below were data pointers in the
		// pseudocode and could not be recovered exactly. Placeholders keep EyeBlink compiling.
		private const string EyeBlinkAnimName = "EyeBlink";
		private const string EyeBlinkTag = "Blink";

		[Tooltip("上嘴")]
		public GameObject upHeadObj;

		[Tooltip("中嘴")]
		public GameObject middleHeadObj;

		[Tooltip("下嘴")]
		public GameObject downHeadObj;

		[Tooltip("子弹位置")]
		public Transform bulletPosition;

		public override void Reset()
		{
			// ICF-folded onto the base PlantEntity.Reset body (identical to the shared plant reset).
			base.Reset();
		}

		protected override void Update()
		{
			// ICF-folded onto the base PlantEntity.Update body (shared attack/eye/cooldown tick).
			base.Update();
		}

		public override void EyeBlink()
		{
			if (partEntity == null)
			{
				return;
			}
			// Don't blink while eyes are closed.
			if (partEntity.isCloseEye)
			{
				return;
			}
			if (_animator == null)
			{
				return;
			}
			// Only blink when both animator layers are sitting in a blink-tagged state.
			AnimatorStateInfo layer0 = _animator.GetCurrentAnimatorStateInfo(0);
			if (!layer0.IsTag(EyeBlinkTag))
			{
				return;
			}
			AnimatorStateInfo layer1 = _animator.GetCurrentAnimatorStateInfo(1);
			if (!layer1.IsTag(EyeBlinkTag))
			{
				return;
			}
			// TODO: EyeBlinkAnimName is an unresolved animator-state data pointer.
			_animator.Play(EyeBlinkAnimName, 0);
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// Base level-0 hook is empty for this plant.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				if (attr == null || defaultAttr == null)
				{
					return;
				}
				// attack += (int)(defaultAttr.attack * strengthenValue)
				attr.attack = (int)((float)defaultAttr.attack * entity.GetValue(this)) + attr.attack;
			}
			else if (entity.index == 1)
			{
				if (attr == null || defaultAttr == null)
				{
					return;
				}
				// AttackSpeed += defaultAttr.attackSpeed * strengthenValue
				attr.AttackSpeed = defaultAttr.attackSpeed * entity.GetValue(this) + attr.attackSpeed;
			}
		}

		protected override void Attack()
		{
			// Play the shared attack animation, then run the per-head firing coroutine.
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__10))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__10(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			// TODO: reconstruct — the original raycasts forward from each active head muzzle against
			// the zombie/bullet layers (using level/scene manager singletons for target position and
			// ray length) and returns true when any hit is a valid enemy. Those manager singletons and
			// their members could not be resolved to real project types, so this is left as a stub.
			return false;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__12))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__12(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__13))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__13(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		public override int GetHeadNumber()
		{
			// Count how many of the three mouths are currently active.
			if (upHeadObj == null || middleHeadObj == null || downHeadObj == null)
			{
				return 0;
			}
			int count = upHeadObj.activeSelf ? 1 : 0;
			if (middleHeadObj.activeSelf)
			{
				count++;
			}
			if (downHeadObj.activeSelf)
			{
				count++;
			}
			return count;
		}
	}
}
