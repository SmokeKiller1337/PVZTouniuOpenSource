using System;
using System.Collections;
using System.Collections.Generic;
using Common.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant190Entity : PlantEntity
	{
		private const float OnUsePower0IntervalSeconds = 0.1f;

		private const string EyeBlinkAnimName = "EyeBlink";
		private const string EyeBlinkTag = "Blink";

		[Tooltip("上嘴")]
		public GameObject upHeadObj;

		[Tooltip("中嘴")]
		public GameObject middleHeadObj;

		[Tooltip("下嘴")]
		public GameObject downHeadObj;

		[Tooltip("子弹位置")]
		public Transform bulletPosition;

		public override void Reset()
		{
			base.Reset();
		}

		protected override void Update()
		{
			base.Update();
		}

		public override void EyeBlink()
		{
			if (partEntity == null)
			{
				return;
			}
			// Don't blink while eyes are closed.
			if (partEntity.isCloseEye)
			{
				return;
			}
			if (_animator == null)
			{
				return;
			}
			// Only blink when both animator layers are sitting in a blink-tagged state.
			AnimatorStateInfo layer0 = _animator.GetCurrentAnimatorStateInfo(0);
			if (!layer0.IsTag(EyeBlinkTag))
			{
				return;
			}
			AnimatorStateInfo layer1 = _animator.GetCurrentAnimatorStateInfo(1);
			if (!layer1.IsTag(EyeBlinkTag))
			{
				return;
			}
			_animator.Play(EyeBlinkAnimName, 0);
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// Base level-0 hook is empty for this plant.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				if (attr == null || defaultAttr == null)
				{
					return;
				}
				// attack += (int)(defaultAttr.attack * strengthenValue)
				attr.attack = (int)((float)defaultAttr.attack * entity.GetValue(this)) + attr.attack;
			}
			else if (entity.index == 1)
			{
				if (attr == null || defaultAttr == null)
				{
					return;
				}
				// AttackSpeed += defaultAttr.attackSpeed * strengthenValue
				attr.AttackSpeed = defaultAttr.attackSpeed * entity.GetValue(this) + attr.attackSpeed;
			}
		}

		protected override void Attack()
		{
			// Play the shared attack animation, then run the per-head firing coroutine.
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			// 各嘴依次开火的动画钩子（当前为空实现）
			yield break;
		}

		protected override bool CheckAttack()
		{
			return false;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 依据强化数值，每隔固定间隔连续触发多次攻击
			int i = 0;
			while (true)
			{
				if (entity == null)
				{
					yield break;
				}
				if ((int)entity.GetValue(this) <= i)
				{
					yield break;
				}
				yield return new WaitForSeconds(OnUsePower0IntervalSeconds);
				if (this == null)
				{
					yield break;
				}
				StartCoroutine(AttackCoroutine());
				i++;
			}
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			// 一次性按强化数值提升攻击力，并登记强化标签
			if (this == null || attr == null || defaultAttr == null || entity == null)
			{
				yield break;
			}
			attr.attack = (int)((float)defaultAttr.attack * entity.GetValue(this)) + attr.attack;
			attr.AddLabel(entity.title, 1, entity.GetDesc(this));
		}

		public override int GetHeadNumber()
		{
			// Count how many of the three mouths are currently active.
			if (upHeadObj == null || middleHeadObj == null || downHeadObj == null)
			{
				return 0;
			}
			int count = upHeadObj.activeSelf ? 1 : 0;
			if (middleHeadObj.activeSelf)
			{
				count++;
			}
			if (downHeadObj.activeSelf)
			{
				count++;
			}
			return count;
		}
	}
}
