using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Level.Manager;
using Reward.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant1001Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__8 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant1001Entity _003C_003E4__this;

			public StrengthenEntity entity;

			private int _003Ci_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__8(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant1001Entity plant = _003C_003E4__this;
				switch (num)
				{
				default:
					return false;
				case 0:
					_003C_003E1__state = -1;
					if (plant == null)
					{
						return false;
					}
					// TODO: reconstruct — before the first wait the original faded the head
					// sprite renderers via material DOFloat (unresolved shader property id and
					// target value were data pointers in the pseudocode). Cosmetic tween dropped.
					// yield return new WaitForSeconds(FADE_IN_DURATION);
					_003C_003E2__current = new WaitForSeconds(PowerFadeInDuration);
					_003C_003E1__state = 1;
					return true;
				case 1:
					_003C_003E1__state = -1;
					// Begin the produce loop: i = 0.
					_003Ci_003E5__2 = 0;
					break;
				case 2:
					_003C_003E1__state = -1;
					// Advance the produce loop: i++.
					_003Ci_003E5__2++;
					break;
				case 3:
					_003C_003E1__state = -1;
					return false;
				}
				// Loop body shared by the initial (state 1) and subsequent (state 2) entries.
				if (plant == null || entity == null || plant.attr == null)
				{
					return false;
				}
				if (_003Ci_003E5__2 < (int)entity.GetValue(plant, 0))
				{
					// Produce one sun at the plant's position and stamp its value.
					plant.ProduceOneSun();
					_003C_003E2__current = new WaitForSeconds(PowerSunInterval);
					_003C_003E1__state = 2;
					return true;
				}
				// Loop finished: fade the head sprites back (cosmetic, dropped) and wait once.
				// TODO: reconstruct — trailing head-sprite fade-back material DOFloat dropped
				// (unresolved shader property id / target value).
				_003C_003E2__current = new WaitForSeconds(PowerFadeOutDuration);
				_003C_003E1__state = 3;
				return true;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__9 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant1001Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__9(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant1001Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				// Boost max health to min(currentMax + strengthen bonus, strengthen cap).
				if (plant != null && plant.attr != null && entity != null)
				{
					float boosted = entity.GetValue(plant, 0) + plant.attr.maxHealth;
					float cap = entity.GetValue(plant, 1);
					if (cap <= boosted)
					{
						boosted = cap;
					}
					plant.attr.maxHealth = (int)boosted;
					// TODO: reconstruct — the original then invoked a virtual health-refresh
					// slot on the plant with the new max value. The exact target method could
					// not be resolved from the vtable offset, so the refresh call is dropped.
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CProduceSun_003Ed__7 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant1001Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CProduceSun_003Ed__7(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant1001Entity plant = _003C_003E4__this;
				switch (num)
				{
				default:
					return false;
				case 0:
					_003C_003E1__state = -1;
					if (plant == null)
					{
						return false;
					}
					// TODO: reconstruct — head-sprite fade-in via material DOFloat dropped
					// (unresolved shader property id / target value data pointers).
					_003C_003E2__current = new WaitForSeconds(ProduceFadeInDuration);
					_003C_003E1__state = 1;
					return true;
				case 1:
					_003C_003E1__state = -1;
					if (plant == null)
					{
						return false;
					}
					// Notify listeners, then spawn the sun.
					if (plant.OnProduceSun != null)
					{
						plant.OnProduceSun();
					}
					plant.ProduceOneSun();
					// TODO: reconstruct — the original then played a DOTween pop/move
					// sequence on the spawned sun and faded the head sprites back before
					// this final wait. Those cosmetic tweens use unresolved offset/shader
					// globals and are dropped.
					_003C_003E2__current = new WaitForSeconds(ProduceMoveDuration);
					_003C_003E1__state = 2;
					return true;
				case 2:
					_003C_003E1__state = -1;
					return false;
				}
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		// TODO: unresolved coroutine timing constants (stored as float globals in the
		// pseudocode; their literal values could not be recovered).
		private const float ProduceFadeInDuration = 0f; // TODO: reconstruct constant
		private const float ProduceMoveDuration = 0f; // TODO: reconstruct constant
		private const float PowerFadeInDuration = 0f; // TODO: reconstruct constant
		private const float PowerFadeOutDuration = 0f; // TODO: reconstruct constant
		private const float PowerSunInterval = 0f; // TODO: reconstruct constant

		// TODO: unresolved multiplier applied to the produce-interval on Reset (float
		// global _UNK_18252cf78 in the pseudocode).
		private const float ProduceIntervalStartRatio = 0f; // TODO: reconstruct constant

		// The reward value handed to CreateSun (0x19 = 25 in the pseudocode).
		private const int ProduceSunValue = 25;

		[Tooltip("头贴图渲染器集合")]
		public List<SpriteRenderer> headSpriteRendererList;

		private float _intervalTimer;

		public Action OnProduceSun;

		public override void Reset()
		{
			base.Reset();
			// _intervalTimer starts partway through the first produce cycle, seeded from
			// the plant's produce interval (attr value 0) times a fixed ratio.
			if (attr != null)
			{
				_intervalTimer = attr.GetValue(this, 0) * ProduceIntervalStartRatio;
			}
		}

		protected override void Update()
		{
			base.Update();
			_intervalTimer += Time.deltaTime;
			// Once the accumulated timer reaches the produce interval, start a produce cycle.
			if (attr != null && attr.GetValue(this, 0) <= _intervalTimer)
			{
				_intervalTimer = 0f;
				StartCoroutine(ProduceSun());
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// Reduce the produce-interval base value by a fraction of its default,
				// scaled by this strengthen's value.
				if (attr != null && attr.valueList != null && attr.valueList.Count > 0 &&
					defaultAttr != null && defaultAttr.valueList != null && defaultAttr.valueList.Count > 0)
				{
					attr.valueList[0].baseValue -= entity.GetValue(this, 0) * defaultAttr.valueList[0].baseValue;
				}
			}
			else if (entity.index == 1)
			{
				// Register an extra effect that fires each time a sun is produced.
				OnProduceSun += delegate
				{
					// TODO: reconstruct — the original handler read entity.GetValue(this, 0)
					// and invoked a virtual slot on this plant with it. The exact target
					// method could not be resolved from the vtable offset, so the effect
					// body is left unimplemented to avoid inventing a member.
					float _ = (entity != null) ? entity.GetValue(this, 0) : 0f;
				};
			}
		}

		[IteratorStateMachine(typeof(_003CProduceSun_003Ed__7))]
		private IEnumerator ProduceSun()
		{
			return new _003CProduceSun_003Ed__7(0)
			{
				_003C_003E4__this = this
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__8))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__8(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__9))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__9(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		// Spawns one sun at this plant's position and stamps its value from the plant's
		// magic-value attribute. Shared by the ProduceSun and OnUsePower0 coroutines.
		private void ProduceOneSun()
		{
			if (attr == null)
			{
				return;
			}
			RewardManager rewardManager = RewardManager.Instance;
			if (rewardManager == null)
			{
				return;
			}
			Transform t = transform;
			if (t == null)
			{
				return;
			}
			SunEntity sun = rewardManager.CreateSun(t.position, ProduceSunValue, 1f, true);
			if (sun != null)
			{
				sun.value = attr.GetValueInt(this, 1);
			}
			// TODO: reconstruct — the original then played a DOTween pop/scatter move
			// sequence on the spawned sun (using unresolved random-range / offset globals).
			// That cosmetic tween is dropped here.
		}
	}
}
