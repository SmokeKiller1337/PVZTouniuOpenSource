using System;
using System.Collections;
using System.Collections.Generic;
using Level.Manager;
using Reward.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant1001Entity : PlantEntity
	{
		private const float ProduceFadeInDuration = 0f;
		private const float ProduceMoveDuration = 0f;
		private const float PowerFadeInDuration = 0f;
		private const float PowerFadeOutDuration = 0f;
		private const float PowerSunInterval = 0f;

		private const float ProduceIntervalStartRatio = 0f;

		private const int ProduceSunValue = 25;

		[Tooltip("头贴图渲染器集合")]
		public List<SpriteRenderer> headSpriteRendererList;

		private float _intervalTimer;

		public Action OnProduceSun;

		public override void Reset()
		{
			base.Reset();
			// _intervalTimer starts partway through the first produce cycle, seeded from
			// the plant's produce interval (attr value 0) times a fixed ratio.
			if (attr != null)
			{
				_intervalTimer = attr.GetValue(this, 0) * ProduceIntervalStartRatio;
			}
		}

		protected override void Update()
		{
			base.Update();
			_intervalTimer += Time.deltaTime;
			// Once the accumulated timer reaches the produce interval, start a produce cycle.
			if (attr != null && attr.GetValue(this, 0) <= _intervalTimer)
			{
				_intervalTimer = 0f;
				StartCoroutine(ProduceSun());
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// Reduce the produce-interval base value by a fraction of its default,
				// scaled by this strengthen's value.
				if (attr != null && attr.valueList != null && attr.valueList.Count > 0 &&
					defaultAttr != null && defaultAttr.valueList != null && defaultAttr.valueList.Count > 0)
				{
					attr.valueList[0].baseValue -= entity.GetValue(this, 0) * defaultAttr.valueList[0].baseValue;
				}
			}
			else if (entity.index == 1)
			{
				// Register an extra effect that fires each time a sun is produced.
				OnProduceSun += delegate
				{
					float _ = (entity != null) ? entity.GetValue(this, 0) : 0f;
				};
			}
		}

		// 生产一颗阳光：淡入等待后通知监听者并生成阳光，再等待移动时间。
		private IEnumerator ProduceSun()
		{
			if (this == null)
			{
				yield break;
			}
			yield return new WaitForSeconds(ProduceFadeInDuration);
			if (this == null)
			{
				yield break;
			}
			if (OnProduceSun != null)
			{
				OnProduceSun();
			}
			ProduceOneSun();
			yield return new WaitForSeconds(ProduceMoveDuration);
		}

		// 技能0：淡入后按强化数值连续生产多颗阳光，最后淡出。
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			if (this == null)
			{
				yield break;
			}
			yield return new WaitForSeconds(PowerFadeInDuration);
			for (int i = 0; ; i++)
			{
				if (this == null || entity == null || attr == null)
				{
					yield break;
				}
				if (i < (int)entity.GetValue(this, 0))
				{
					ProduceOneSun();
					yield return new WaitForSeconds(PowerSunInterval);
				}
				else
				{
					yield return new WaitForSeconds(PowerFadeOutDuration);
					yield break;
				}
			}
		}

		// 技能1：把最大生命值提升强化数值，但不超过强化上限。
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			if (this != null && attr != null && entity != null)
			{
				float boosted = entity.GetValue(this, 0) + attr.maxHealth;
				float cap = entity.GetValue(this, 1);
				if (cap <= boosted)
				{
					boosted = cap;
				}
				attr.maxHealth = (int)boosted;
			}
			yield break;
		}

		// Spawns one sun at this plant's position and stamps its value from the plant's
		// magic-value attribute. Shared by the ProduceSun and OnUsePower0 coroutines.
		private void ProduceOneSun()
		{
			if (attr == null)
			{
				return;
			}
			RewardManager rewardManager = RewardManager.Instance;
			if (rewardManager == null)
			{
				return;
			}
			Transform t = transform;
			if (t == null)
			{
				return;
			}
			SunEntity sun = rewardManager.CreateSun(t.position, ProduceSunValue, 1f, true);
			if (sun != null)
			{
				sun.value = attr.GetValueInt(this, 1);
			}
		}
	}
}
