using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Bullet.Entity;
using Bullet.Util;
using Game.Entity;
using Game.Util;
using Level.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant40Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__18 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant40Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__18(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant40Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (plant == null || plant.attr == null)
					{
						return false;
					}
					// Become invincible for the duration of the power.
					plant.attr.isInvincible = true;
					// yield return new WaitForSeconds(PowerDelay);
					_003C_003E2__current = new WaitForSeconds(PowerDelay);
					_003C_003E1__state = 1;
					return true;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (entity == null || plant == null)
				{
					return false;
				}
				// AOE damage value comes from the level-3 strengthen entity.
				float damage = entity.GetValue(plant, 0);
				Vector2 position = plant.transform.position;
				// Spawn the explosion visual on the plant's own position.
				GameUtils.CreateEffect(plant.explosionEffect, position, Quaternion.identity);
				position = plant.transform.position;
				// TODO: the target layer name is a data pointer in the pseudocode and could
				// not be recovered; ExplosionLayerName is a placeholder.
				int layerMask = LayerMask.GetMask(ExplosionLayerName);
				DamageUtils.Explosion(position, ExplosionRadius, damage, layerMask);
				// Suicide after the blast.
				plant.Death();
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__19 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public StrengthenEntity entity;

			public Plant40Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__19(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant40Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (entity == null)
				{
					return false;
				}
				// Permanent max-health boost derived from the strengthen value...
				float value = entity.GetValue(plant, 0);
				plant.ChangeMaxHealth(value);
				if (plant.attr != null)
				{
					// ...then top the plant up to its (new) maximum health...
					plant.ChangeHealth(plant.attr.maxHealth);
					// ...and record the perk as an attribute label.
					string desc = entity.GetDesc(plant);
					plant.attr.AddLabel(entity.title, 1, desc);
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("坚果渲染器")]
		public SpriteRenderer bodySpriteRenderer;

		[Tooltip("坚果贴图集合")]
		public List<Sprite> bodySpriteList;

		[Tooltip("被吃效果")]
		public EffectEntity eatEffect;

		[Tooltip("爆炸效果")]
		public EffectEntity explosionEffect;

		private float _hitTimer;

		private StrengthenEntity _addHealthEntity;

		private bool _isAddHealth;

		private float _addHealthIntervalTimer;

		private bool _isDeathCooldown;

		// TODO: the following constants are data pointers / unresolved globals in the
		// pseudocode and could not be recovered to their literal values.
		private const float PowerDelay = 0f; // TODO: reconstruct WaitForSeconds constant
		private const float ExplosionRadius = 1f; // TODO: reconstruct explosion radius constant
		private const string ExplosionLayerName = "Zombie"; // TODO: reconstruct layer name literal
		private const float HitFreezeTime = 0.6f; // 0x3F19999A
		private const float NormalAnimatorSpeed = 1f;
		private const float HealthRatioHighThreshold = 0.66f; // TODO: reconstruct threshold constant
		private const float HealthRatioLowThreshold = 0.33f; // TODO: reconstruct threshold constant
		private const float InstantKillBuffDuration = -1f; // TODO: reconstruct buff duration constant
		private const int FreezeBuffId = 2; // TODO: confirm buff id
		private const int InstantKillBuffId = 4; // TODO: confirm buff id

		public override void Reset()
		{
			base.Reset();
			UpdateBodySprite();
		}

		protected override void Update()
		{
			base.Update();
			// Periodic self-heal driven by a strengthen entity (interval at index 0,
			// heal ratio of max health at index 1).
			if (_isAddHealth)
			{
				_addHealthIntervalTimer += Time.deltaTime;
				if (_addHealthEntity == null)
				{
					return;
				}
				float interval = _addHealthEntity.GetValue(this, 0);
				if (interval <= _addHealthIntervalTimer)
				{
					_addHealthIntervalTimer = 0f;
					if (attr == null)
					{
						return;
					}
					float maxHealth = attr.maxHealth;
					float ratio = _addHealthEntity.GetValue(this, 1);
					ChangeHealth(ratio * maxHealth);
				}
			}
			// Hit-freeze timer: while it runs the animator is stopped; when it elapses
			// restore the normal animator speed unless a freeze / instant-kill buff is active.
			if (_hitTimer > 0f)
			{
				_hitTimer -= Time.deltaTime;
				if (_hitTimer <= 0f)
				{
					if (_buffHandler == null)
					{
						return;
					}
					if (!_buffHandler.HasBuff(FreezeBuffId) && !_buffHandler.HasBuff(InstantKillBuffId))
					{
						if (_animator == null)
						{
							return;
						}
						_animator.speed = NormalAnimatorSpeed;
					}
				}
			}
		}

		private void UpdateBodySprite()
		{
			// Swap the body sprite based on the current health ratio (three damage stages).
			if (bodySpriteRenderer == null)
			{
				return;
			}
			if (attr == null)
			{
				return;
			}
			float ratio = attr.currentHealth / attr.maxHealth;
			int index;
			if (ratio > HealthRatioHighThreshold)
			{
				index = 0;
			}
			else if (ratio > HealthRatioLowThreshold)
			{
				index = 1;
			}
			else
			{
				index = 2;
			}
			bodySpriteRenderer.sprite = bodySpriteList[index];
		}

		public override bool Hit(float value, DamageTypeEntity damageType = null, BulletEntity sourceBullet = null)
		{
			if (value > 0f)
			{
				// Freeze the plant briefly and pop the "被吃" (eaten) effect.
				_hitTimer = HitFreezeTime;
				if (_animator == null)
				{
					return false;
				}
				_animator.speed = 0f;
				Vector2 position = transform.position;
				GameUtils.CreateEffect(eatEffect, position, Quaternion.identity);
			}
			if (damageType == null)
			{
				damageType = DamageTypeEntity.Common;
			}
			if (attr == null)
			{
				return false;
			}
			// Invincible plants take no damage.
			if (attr.isInvincible)
			{
				return false;
			}
			if (damageType == null)
			{
				return false;
			}
			if ((int)damageType.damageType == 2)
			{
				// Explosion-type damage: immune via buff list or the isNotPick2 flag.
				if (immuneBuffIdList == null)
				{
					return false;
				}
				if (immuneBuffIdList.Contains(InstantKillBuffId))
				{
					return false;
				}
				if (attr.isNotPick2)
				{
					return false;
				}
			}
			// TODO: reconstruct - the pseudocode also gated this on a global "damage disabled"
			// flag read from GameManager.Instance.LevelEntity, a type/member that does not
			// exist in the project; that guard is dropped here.
			if (value <= 0f)
			{
				return false;
			}
			if ((int)damageType.deathType == 1 && value >= attr.currentHealth)
			{
				// Lethal instant-death: apply the instant-kill buff instead of raw damage.
				if (_buffHandler != null)
				{
					_buffHandler.AddBuff(InstantKillBuffId, null, InstantKillBuffDuration);
					return true;
				}
				return false;
			}
			ChangeHealth(0f - value);
			Flicker();
			return true;
		}

		public override void EyeBlink()
		{
			// Suppress blinking while the hit-freeze timer is running.
			if (_hitTimer > 0f)
			{
				return;
			}
			if (partEntity == null)
			{
				return;
			}
			// Don't blink while the eyes are closed.
			if (partEntity.isCloseEye)
			{
				return;
			}
			if (_animator == null)
			{
				return;
			}
			AnimatorStateInfo state = _animator.GetCurrentAnimatorStateInfo(0);
			// Only blink when the current state carries the blink tag.
			if (state.IsTag(BlinkTag))
			{
				_animator.Play(EyeBlinkAnimName);
			}
		}

		// TODO: the blink tag / animation name are data pointers in the pseudocode.
		private const string BlinkTag = "Blink"; // TODO: reconstruct animator tag literal
		private const string EyeBlinkAnimName = "EyeBlink"; // TODO: reconstruct animation state literal

		public override void ChangeHealth(float value)
		{
			base.ChangeHealth(value);
			UpdateBodySprite();
		}

		public override void Death()
		{
			base.Death();
			// A level-2 perk (index 1) refunds part of the card's recharge on a normal death.
			if (LastDamageType == null)
			{
				return;
			}
			if ((int)LastDamageType.deathType == 2 || !_isDeathCooldown || !IsHasCardSlot)
			{
				return;
			}
			StrengthenEntity strengthen = GetStrengthenEntity(2, 1);
			CardEntity card = CardEntity;
			if (card == null || card.attr == null)
			{
				return;
			}
			CardBaseAttr cardAttr = card.attr;
			float cooldownTimer = cardAttr.cooldownTimer;
			CardEntity card2 = CardEntity;
			if (card2 == null || card2.attr == null || strengthen == null)
			{
				return;
			}
			float cooldownTime = card2.attr.cooldownTime;
			float ratio = strengthen.GetValue(this, 0);
			cardAttr.cooldownTimer = cooldownTimer - ratio * cooldownTime;
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// Base virtual is a no-op; this override was ICF-folded onto an empty body.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				if (defaultAttr == null)
				{
					return;
				}
				// Index 0: increase max health by a ratio of the default max health.
				float baseMaxHealth = defaultAttr.maxHealth;
				float ratio = entity.GetValue(this, 0);
				ChangeMaxHealth(ratio * baseMaxHealth);
			}
			else if (entity.index == 1)
			{
				// Index 1: enable the on-death recharge refund handled in Death().
				_isDeathCooldown = true;
			}
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__18))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			_003COnUsePower0_003Ed__18 result = new _003COnUsePower0_003Ed__18(0);
			result._003C_003E4__this = this;
			result.entity = entity;
			return result;
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__19))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			_003COnUsePower1_003Ed__19 result = new _003COnUsePower1_003Ed__19(0);
			result._003C_003E4__this = this;
			result.entity = entity;
			return result;
		}
	}
}
