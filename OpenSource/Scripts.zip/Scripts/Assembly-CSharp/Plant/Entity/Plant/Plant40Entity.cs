using System;
using System.Collections;
using System.Collections.Generic;
using Bullet.Entity;
using Bullet.Util;
using Game.Entity;
using Game.Util;
using Level.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant40Entity : PlantEntity
	{
		[Tooltip("坚果渲染器")]
		public SpriteRenderer bodySpriteRenderer;

		[Tooltip("坚果贴图集合")]
		public List<Sprite> bodySpriteList;

		[Tooltip("被吃效果")]
		public EffectEntity eatEffect;

		[Tooltip("爆炸效果")]
		public EffectEntity explosionEffect;

		private float _hitTimer;

		private StrengthenEntity _addHealthEntity;

		private bool _isAddHealth;

		private float _addHealthIntervalTimer;

		private bool _isDeathCooldown;

		private const float PowerDelay = 0f;
		private const float ExplosionRadius = 1f;
		private const string ExplosionLayerName = "Zombie";
		private const float HitFreezeTime = 0.6f; // 0x3F19999A
		private const float NormalAnimatorSpeed = 1f;
		private const float HealthRatioHighThreshold = 0.66f;
		private const float HealthRatioLowThreshold = 0.33f;
		private const float InstantKillBuffDuration = -1f;
		private const int FreezeBuffId = 2; // TODO: confirm buff id
		private const int InstantKillBuffId = 4; // TODO: confirm buff id

		public override void Reset()
		{
			base.Reset();
			UpdateBodySprite();
		}

		protected override void Update()
		{
			base.Update();
			// Periodic self-heal driven by a strengthen entity (interval at index 0,
			// heal ratio of max health at index 1).
			if (_isAddHealth)
			{
				_addHealthIntervalTimer += Time.deltaTime;
				if (_addHealthEntity == null)
				{
					return;
				}
				float interval = _addHealthEntity.GetValue(this, 0);
				if (interval <= _addHealthIntervalTimer)
				{
					_addHealthIntervalTimer = 0f;
					if (attr == null)
					{
						return;
					}
					float maxHealth = attr.maxHealth;
					float ratio = _addHealthEntity.GetValue(this, 1);
					ChangeHealth(ratio * maxHealth);
				}
			}
			// Hit-freeze timer: while it runs the animator is stopped; when it elapses
			// restore the normal animator speed unless a freeze / instant-kill buff is active.
			if (_hitTimer > 0f)
			{
				_hitTimer -= Time.deltaTime;
				if (_hitTimer <= 0f)
				{
					if (_buffHandler == null)
					{
						return;
					}
					if (!_buffHandler.HasBuff(FreezeBuffId) && !_buffHandler.HasBuff(InstantKillBuffId))
					{
						if (_animator == null)
						{
							return;
						}
						_animator.speed = NormalAnimatorSpeed;
					}
				}
			}
		}

		private void UpdateBodySprite()
		{
			// Swap the body sprite based on the current health ratio (three damage stages).
			if (bodySpriteRenderer == null)
			{
				return;
			}
			if (attr == null)
			{
				return;
			}
			float ratio = attr.currentHealth / attr.maxHealth;
			int index;
			if (ratio > HealthRatioHighThreshold)
			{
				index = 0;
			}
			else if (ratio > HealthRatioLowThreshold)
			{
				index = 1;
			}
			else
			{
				index = 2;
			}
			bodySpriteRenderer.sprite = bodySpriteList[index];
		}

		public override bool Hit(float value, DamageTypeEntity damageType = null, BulletEntity sourceBullet = null)
		{
			if (value > 0f)
			{
				// Freeze the plant briefly and pop the "被吃" (eaten) effect.
				_hitTimer = HitFreezeTime;
				if (_animator == null)
				{
					return false;
				}
				_animator.speed = 0f;
				Vector2 position = transform.position;
				GameUtils.CreateEffect(eatEffect, position, Quaternion.identity);
			}
			if (damageType == null)
			{
				damageType = DamageTypeEntity.Common;
			}
			if (attr == null)
			{
				return false;
			}
			// Invincible plants take no damage.
			if (attr.isInvincible)
			{
				return false;
			}
			if (damageType == null)
			{
				return false;
			}
			if ((int)damageType.damageType == 2)
			{
				// Explosion-type damage: immune via buff list or the isNotPick2 flag.
				if (immuneBuffIdList == null)
				{
					return false;
				}
				if (immuneBuffIdList.Contains(InstantKillBuffId))
				{
					return false;
				}
				if (attr.isNotPick2)
				{
					return false;
				}
			}
			if (value <= 0f)
			{
				return false;
			}
			if ((int)damageType.deathType == 1 && value >= attr.currentHealth)
			{
				// Lethal instant-death: apply the instant-kill buff instead of raw damage.
				if (_buffHandler != null)
				{
					_buffHandler.AddBuff(InstantKillBuffId, null, InstantKillBuffDuration);
					return true;
				}
				return false;
			}
			ChangeHealth(0f - value);
			Flicker();
			return true;
		}

		public override void EyeBlink()
		{
			// Suppress blinking while the hit-freeze timer is running.
			if (_hitTimer > 0f)
			{
				return;
			}
			if (partEntity == null)
			{
				return;
			}
			// Don't blink while the eyes are closed.
			if (partEntity.isCloseEye)
			{
				return;
			}
			if (_animator == null)
			{
				return;
			}
			AnimatorStateInfo state = _animator.GetCurrentAnimatorStateInfo(0);
			// Only blink when the current state carries the blink tag.
			if (state.IsTag(BlinkTag))
			{
				_animator.Play(EyeBlinkAnimName);
			}
		}

		private const string BlinkTag = "Blink";
		private const string EyeBlinkAnimName = "EyeBlink";

		public override void ChangeHealth(float value)
		{
			base.ChangeHealth(value);
			UpdateBodySprite();
		}

		public override void Death()
		{
			base.Death();
			// A level-2 perk (index 1) refunds part of the card's recharge on a normal death.
			if (LastDamageType == null)
			{
				return;
			}
			if ((int)LastDamageType.deathType == 2 || !_isDeathCooldown || !IsHasCardSlot)
			{
				return;
			}
			StrengthenEntity strengthen = GetStrengthenEntity(2, 1);
			CardEntity card = CardEntity;
			if (card == null || card.attr == null)
			{
				return;
			}
			CardBaseAttr cardAttr = card.attr;
			float cooldownTimer = cardAttr.cooldownTimer;
			CardEntity card2 = CardEntity;
			if (card2 == null || card2.attr == null || strengthen == null)
			{
				return;
			}
			float cooldownTime = card2.attr.cooldownTime;
			float ratio = strengthen.GetValue(this, 0);
			cardAttr.cooldownTimer = cooldownTimer - ratio * cooldownTime;
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				if (defaultAttr == null)
				{
					return;
				}
				// Index 0: increase max health by a ratio of the default max health.
				float baseMaxHealth = defaultAttr.maxHealth;
				float ratio = entity.GetValue(this, 0);
				ChangeMaxHealth(ratio * baseMaxHealth);
			}
			else if (entity.index == 1)
			{
				// Index 1: enable the on-death recharge refund handled in Death().
				_isDeathCooldown = true;
			}
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			if (this == null || attr == null)
			{
				yield break;
			}
			// 技能持续期间进入无敌状态
			attr.isInvincible = true;
			yield return new WaitForSeconds(PowerDelay);
			if (entity == null || this == null)
			{
				yield break;
			}
			// 爆炸伤害数值取自三级强化实体
			float damage = entity.GetValue(this, 0);
			Vector2 position = transform.position;
			// 在自身位置生成爆炸特效
			GameUtils.CreateEffect(explosionEffect, position, Quaternion.identity);
			position = transform.position;
			int layerMask = LayerMask.GetMask(ExplosionLayerName);
			DamageUtils.Explosion(position, ExplosionRadius, damage, layerMask);
			// 爆炸后自爆
			Death();
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			if (entity == null)
			{
				yield break;
			}
			// 永久提升最大生命值
			float value = entity.GetValue(this, 0);
			ChangeMaxHealth(value);
			if (attr != null)
			{
				// 将生命补满至新的上限
				ChangeHealth(attr.maxHealth);
				// 以属性标签记录该增益
				string desc = entity.GetDesc(this);
				attr.AddLabel(entity.title, 1, desc);
			}
		}
	}
}
