using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Entity;
using Game.Entity;
using Game.Util;
using Level.Entity;
using Level.Util;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant150Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__11 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant150Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__11(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant150Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null || plant.attr == null)
				{
					return false;
				}
				Transform t = plant.transform;
				if (t == null)
				{
					return false;
				}
				// Spawn the attack / explosion visual at the plant's world position.
				GameUtils.CreateEffect(plant.effectEntity, t.position, Quaternion.identity);
				// TODO: reconstruct — when _currentPowerEntity is active (index 0/1) the
				//       original triggered a Particle.Entity.ScreenFlash2D.Flash(color,
				//       duration, maxAlpha). The ScreenFlash2D instance is resolved through
				//       an unresolved global manager singleton, so the screen-flash branch
				//       (and its per-index colour constants) is dropped here.
				List<ZombieEntity> zombieList = LevelUtils.GetLandZombieList();
				if (zombieList != null)
				{
					foreach (ZombieEntity zombie in zombieList)
					{
						if (zombie == null)
						{
							return false;
						}
						// TODO: reconstruct — the original gated each zombie on a CompareTag
						//       against an unresolved tag literal and on a zombie bool field
						//       (offset 0x1b0) whose member name could not be recovered. Both
						//       guards are dropped so every land zombie is affected.
						if (zombie.BuffHandler != null)
						{
							if (zombie.BuffHandler.HasBuff(3))
							{
								zombie.BuffHandler.RemoveBuff(3, true);
							}
							if (plant.buff5ValueList != null && plant.buff5ValueList.Count > 0)
							{
								plant.buff5ValueList[0].baseValue = plant.attr.GetValue(plant, 1);
							}
							GameObject caster = plant.gameObject;
							// Slow buff (id 5) carries the slow-value list; duration = value[0].
							zombie.BuffHandler.AddBuff(5, caster, plant.attr.GetValue(plant, 0), plant.buff5ValueList);
							// Secondary buff (id 6), duration = value[2].
							zombie.BuffHandler.AddBuff(6, caster, plant.attr.GetValue(plant, 2));
						}
						// The explosion damage type is prepared (deathType cleared) and applied
						// to the zombie via a virtual slot in the original.
						DamageTypeEntity explosion = DamageTypeEntity.Explosion;
						explosion.deathType = (Level.Enum.DeathType)0;
						// TODO: reconstruct — the killing blow was dispatched through an
						//       unresolved zombie virtual slot (vtable 0x238) with the explosion
						//       damage type and an unknown damage value; not emitted here.
					}
				}
				// Notify listeners of the explosion with the affected land-zombie list.
				if (plant.OnExplosionAction != null)
				{
					plant.OnExplosionAction(zombieList);
				}
				// TODO: reconstruct — a trailing virtual call (vtable 0x278) on the plant
				//       could not be resolved to a named method and is omitted.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CChangeSleepStateCoroutine_003Ed__7 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant150Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CChangeSleepStateCoroutine_003Ed__7(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant150Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (plant == null)
					{
						return false;
					}
					// TODO: reconstruct — the original yielded the base coroutine here
					//       (yield return base.ChangeSleepStateCoroutine()), which is a
					//       non-virtual base call that cannot be expressed from this
					//       compiler-generated nested class. Approximated by waiting one
					//       frame (yield return null), matching the base coroutine's own
					//       initial one-frame delay; its subsequent sleep/awake animation
					//       switch is therefore not driven from here.
					_003C_003E2__current = null;
					_003C_003E1__state = 1;
					return true;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null || plant.partEntity == null)
				{
					return false;
				}
				if (!plant.partEntity.isSleeping)
				{
					if (plant.attr != null)
					{
						plant.attr.isInvincible = true;
					}
					// TODO: reconstruct — the original scheduled DOVirtual.DelayedCall(1f, ...)
					//       targeting a virtual method (vtable 0x430) on the plant, likely to
					//       clear the invincibility set above. The delegate target could not be
					//       resolved to a named method, so the delayed call is not emitted.
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__13 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant150Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__13(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant150Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (plant != null && plant.attr != null && plant.attr.valueList != null && plant.attr.valueList.Count > 2)
					{
						ValueEntity value = plant.attr.valueList[2];
						if (value != null && entity != null)
						{
							value.baseValue += entity.GetValue(plant, 0);
							plant._currentPowerEntity = entity;
						}
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__14 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant150Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__14(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant150Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (plant != null && plant.attr != null && entity != null)
					{
						plant.attr.attack += (int)entity.GetValue(plant, 0);
						plant._currentPowerEntity = entity;
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("特效")]
		public EffectEntity effectEntity;

		[Tooltip("减速Buff值集合")]
		public List<ValueEntity> buff5ValueList;

		private StrengthenEntity _currentPowerEntity;

		public Action<List<ZombieEntity>> OnExplosionAction;

		public override void Reset()
		{
			base.Reset();
			_currentPowerEntity = null;
			if (partEntity == null)
			{
				return;
			}
			if (!partEntity.isSleeping)
			{
				// TODO: reconstruct — the original scheduled DOVirtual.DelayedCall(1f, ...)
				//       targeting a virtual method (vtable 0x430) on this plant. The delegate
				//       target could not be resolved to a named method, so it is not emitted.
				if (IsHasCardSlot)
				{
					CardEntity card = CardEntity;
					if (card != null && card.IsAvailablePower())
					{
						UsePower();
					}
				}
			}
		}

		protected override void Start()
		{
			base.Start();
			if (partEntity == null)
			{
				return;
			}
			// Awake plants start invincible until their sleep coroutine says otherwise.
			if (!partEntity.isSleeping)
			{
				attr.isInvincible = true;
			}
		}

		protected override void Update()
		{
			base.Update();
			if (partEntity == null)
			{
				return;
			}
			// Only tick attack / eye / cooldown logic while awake.
			if (partEntity.isSleeping)
			{
				return;
			}
			PlantBaseAttr a = attr;
			if (a.attackIntervalTime > 0f)
			{
				a.attackIntervalTimer += Time.deltaTime;
				if (a.attackIntervalTimer >= a.attackIntervalTime)
				{
					a.attackIntervalTimer = 0f;
					if (CheckAttack())
					{
						Attack();
					}
				}
			}
			EyeUpdate();
			if (isHasSpecialSkill && specialCooldownTimer > 0f)
			{
				specialCooldownTimer -= Time.deltaTime;
			}
		}

		[IteratorStateMachine(typeof(_003CChangeSleepStateCoroutine_003Ed__7))]
		protected override IEnumerator ChangeSleepStateCoroutine()
		{
			return new _003CChangeSleepStateCoroutine_003Ed__7(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// Genuinely empty in the binary (ICF-folded onto the shared empty-body stub).
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			int idx;
			if (entity.index == 0)
			{
				idx = 1;
			}
			else if (entity.index == 1)
			{
				idx = 0;
			}
			else
			{
				return;
			}
			float baseVal = attr.valueList[idx].baseValue;
			ValueEntity defValue = defaultAttr.valueList[idx];
			if (defValue != null)
			{
				attr.valueList[idx].baseValue = entity.GetValue(this, 0) * defValue.baseValue + baseVal;
			}
		}

		protected override void Attack()
		{
			if (attr == null || _animator == null)
			{
				return;
			}
			// Drive the attack animation speed from the plant's attack speed.
			// TODO: reconstruct — the Animator float-parameter name and the multiplier
			//       constant were data pointers in the pseudocode; placeholders used below.
			_animator.SetFloat(AttackSpeedAnimParam, attr.attackSpeed * AttackSpeedAnimMultiplier);
			IEnumerator routine = AttackCoroutine();
			if (routine != null && base.isActiveAndEnabled)
			{
				StartCoroutine(routine);
			}
		}

		// TODO: unresolved Animator float-parameter name / speed multiplier (data pointers).
		private const string AttackSpeedAnimParam = "AttackSpeed"; // TODO: reconstruct literal
		private const float AttackSpeedAnimMultiplier = 1f; // TODO: reconstruct constant

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__11))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__11(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			// ICF-folded onto a constant-false body in the binary.
			return false;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__13))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__13(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__14))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__14(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
