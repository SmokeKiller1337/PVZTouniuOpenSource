using System;
using System.Collections;
using System.Collections.Generic;
using Common.Entity;
using Game.Entity;
using Game.Util;
using Level.Entity;
using Level.Util;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant150Entity : PlantEntity
	{
		[Tooltip("特效")]
		public EffectEntity effectEntity;

		[Tooltip("减速Buff值集合")]
		public List<ValueEntity> buff5ValueList;

		private StrengthenEntity _currentPowerEntity;

		public Action<List<ZombieEntity>> OnExplosionAction;

		public override void Reset()
		{
			base.Reset();
			_currentPowerEntity = null;
			if (partEntity == null)
			{
				return;
			}
			if (!partEntity.isSleeping)
			{
				if (IsHasCardSlot)
				{
					CardEntity card = CardEntity;
					if (card != null && card.IsAvailablePower())
					{
						UsePower();
					}
				}
			}
		}

		protected override void Start()
		{
			base.Start();
			if (partEntity == null)
			{
				return;
			}
			// Awake plants start invincible until their sleep coroutine says otherwise.
			if (!partEntity.isSleeping)
			{
				attr.isInvincible = true;
			}
		}

		protected override void Update()
		{
			base.Update();
			if (partEntity == null)
			{
				return;
			}
			// Only tick attack / eye / cooldown logic while awake.
			if (partEntity.isSleeping)
			{
				return;
			}
			PlantBaseAttr a = attr;
			if (a.attackIntervalTime > 0f)
			{
				a.attackIntervalTimer += Time.deltaTime;
				if (a.attackIntervalTimer >= a.attackIntervalTime)
				{
					a.attackIntervalTimer = 0f;
					if (CheckAttack())
					{
						Attack();
					}
				}
			}
			EyeUpdate();
			if (isHasSpecialSkill && specialCooldownTimer > 0f)
			{
				specialCooldownTimer -= Time.deltaTime;
			}
		}

		protected override IEnumerator ChangeSleepStateCoroutine()
		{
			if (this == null)
			{
				yield break;
			}
			// 等待一帧后再根据睡眠状态决定是否无敌
			yield return null;
			if (this == null || partEntity == null)
			{
				yield break;
			}
			if (!partEntity.isSleeping)
			{
				if (attr != null)
				{
					attr.isInvincible = true;
				}
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			int idx;
			if (entity.index == 0)
			{
				idx = 1;
			}
			else if (entity.index == 1)
			{
				idx = 0;
			}
			else
			{
				return;
			}
			float baseVal = attr.valueList[idx].baseValue;
			ValueEntity defValue = defaultAttr.valueList[idx];
			if (defValue != null)
			{
				attr.valueList[idx].baseValue = entity.GetValue(this, 0) * defValue.baseValue + baseVal;
			}
		}

		protected override void Attack()
		{
			if (attr == null || _animator == null)
			{
				return;
			}
			_animator.SetFloat(AttackSpeedAnimParam, attr.attackSpeed * AttackSpeedAnimMultiplier);
			IEnumerator routine = AttackCoroutine();
			if (routine != null && base.isActiveAndEnabled)
			{
				StartCoroutine(routine);
			}
		}

		private const string AttackSpeedAnimParam = "AttackSpeed";
		private const float AttackSpeedAnimMultiplier = 1f;

		private IEnumerator AttackCoroutine()
		{
			if (this == null || attr == null)
			{
				yield break;
			}
			Transform t = transform;
			if (t == null)
			{
				yield break;
			}
			// 在植物位置生成爆炸特效
			GameUtils.CreateEffect(effectEntity, t.position, Quaternion.identity);
			List<ZombieEntity> zombieList = LevelUtils.GetLandZombieList();
			if (zombieList != null)
			{
				foreach (ZombieEntity zombie in zombieList)
				{
					if (zombie == null)
					{
						yield break;
					}
					if (zombie.BuffHandler != null)
					{
						if (zombie.BuffHandler.HasBuff(3))
						{
							zombie.BuffHandler.RemoveBuff(3, true);
						}
						if (buff5ValueList != null && buff5ValueList.Count > 0)
						{
							buff5ValueList[0].baseValue = attr.GetValue(this, 1);
						}
						GameObject caster = gameObject;
						// 施加减速Buff(5)与附加Buff(6)
						zombie.BuffHandler.AddBuff(5, caster, attr.GetValue(this, 0), buff5ValueList);
						zombie.BuffHandler.AddBuff(6, caster, attr.GetValue(this, 2));
					}
					DamageTypeEntity explosion = DamageTypeEntity.Explosion;
					explosion.deathType = (Level.Enum.DeathType)0;
				}
			}
			// 通知爆炸波及的地面僵尸列表
			if (OnExplosionAction != null)
			{
				OnExplosionAction(zombieList);
			}
		}

		protected override bool CheckAttack()
		{
			return false;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			if (this != null && attr != null && attr.valueList != null && attr.valueList.Count > 2)
			{
				ValueEntity value = attr.valueList[2];
				if (value != null && entity != null)
				{
					value.baseValue += entity.GetValue(this, 0);
					_currentPowerEntity = entity;
				}
			}
			yield break;
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			if (this != null && attr != null && entity != null)
			{
				attr.attack += (int)entity.GetValue(this, 0);
				_currentPowerEntity = entity;
			}
			yield break;
		}
	}
}
