using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Land.Entity;
using Land.Entity.Fog;
using Level.Manager;
using Level.Util;
using Plant.Enum;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant265Entity : PlantEntity
	{
		[Tooltip("驱散迷雾实体")]
		public DispelFog dispelFog;

		[Tooltip("驱散特效物体")]
		public GameObject dispelFogEffectObj;

		[Tooltip("种植音效")]
		public AudioClip startSound;

		private float _addBuffTimer;

		private float _intervalTimer;

		public override void Reset()
		{
			base.Reset();
		}

		protected override void Start()
		{
			base.Start();
		}

		protected override void Update()
		{
			base.Update();
			// 累计计时超过 1 秒后，为周围植物刷新免疫爆炸的 buff 并重置计时

			_addBuffTimer += Time.deltaTime;
			if (_addBuffTimer > 1f)
			{
				_addBuffTimer = 0f;
				AddImmuneExplosionBuff();
			}
			_intervalTimer += Time.deltaTime;
			if (attr == null)
			{
				return;
			}
			if (attr.GetValue(this, 1) <= _intervalTimer)
			{
				_intervalTimer = 0f;
				StartCoroutine(ProduceSun());
			}
		}

		public override void Death()
		{
			base.Death();
			// On death, drop the explosion-immunity buff (buff id 4) from every plant in
			// the surrounding 3x3 grid (including diagonals) that this plant had granted it
			// to. Neighbours are all land plants whose land row/column are within 1 of ours.
			List<PlantEntity> neighbours = LevelUtils
				.GetLandPlantList(-1, -1, PlaceType.All)
				.Where(delegate(PlantEntity plantEntity)
				{
					if (plantEntity == this)
					{
						return false;
					}
					if (plantEntity == null || plantEntity.CurrentLandEntity == null)
					{
						return false;
					}
					LandEntity self = CurrentLandEntity;
					LandEntity other = plantEntity.CurrentLandEntity;
					if (self == null)
					{
						return false;
					}
					return Mathf.Abs(self.rowId - other.rowId) < 2
						&& Mathf.Abs(self.columnId - other.columnId) < 2;
				})
				.ToList();
			foreach (PlantEntity neighbour in neighbours)
			{
				if (neighbour.immuneBuffIdList != null && neighbour.immuneBuffIdList.Contains(4))
				{
					neighbour.immuneBuffIdList.Remove(4);
				}
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// Strengthen 0: increase the plant's primary tunable value and push the new
				// ratio into the dispel-fog visual.
				float value = entity.GetValue(this);
				if (attr != null && attr.valueList != null && attr.valueList.Count > 0)
				{
					attr.valueList[0].baseValue += value;
					UpdateDispelFog(attr.valueList[0].baseValue);
				}
			}
			else if (entity.index == 1)
			{
			}
		}

		private IEnumerator ProduceSun()
		{
			yield break;
		}

		private void AddImmuneExplosionBuff()
		{
			// Grant the explosion-immunity buff (buff id 4) to every plant in the
			// surrounding 3x3 grid (including diagonals) that does not already have it.
			List<PlantEntity> neighbours = LevelUtils
				.GetLandPlantList(-1, -1, PlaceType.All)
				.Where(delegate(PlantEntity plantEntity)
				{
					if (plantEntity == this)
					{
						return false;
					}
					if (plantEntity == null || plantEntity.CurrentLandEntity == null)
					{
						return false;
					}
					LandEntity self = CurrentLandEntity;
					LandEntity other = plantEntity.CurrentLandEntity;
					if (self == null)
					{
						return false;
					}
					return Mathf.Abs(self.rowId - other.rowId) < 2
						&& Mathf.Abs(self.columnId - other.columnId) < 2;
				})
				.ToList();
			foreach (PlantEntity neighbour in neighbours)
			{
				if (neighbour.immuneBuffIdList != null && !neighbour.immuneBuffIdList.Contains(4))
				{
					neighbour.immuneBuffIdList.Add(4);
				}
			}
		}

		public void UpdateDispelFog(float ratio, float duration = 1f)
		{
		}

		protected override void Attack()
		{
		}

		protected override bool CheckAttack()
		{
			return false;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			yield break;
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			// 三级强化：提升主数值并刷新驱散迷雾表现
			if (entity != null)
			{
				float value = entity.GetValue(this);
				if (attr != null && attr.valueList != null && attr.valueList.Count > 0)
				{
					attr.valueList[0].baseValue += value;
					UpdateDispelFog(attr.valueList[0].baseValue);
				}
			}
			yield break;
		}
	}
}
