using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using Land.Entity;
using Land.Entity.Fog;
using Level.Manager;
using Level.Util;
using Plant.Enum;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant265Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__16 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant265Entity _003C_003E4__this;

			public StrengthenEntity entity;

			private int _003Ci_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__16(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct — the pseudocode state machine drives a material glow
				// tween (DG.Tweening ShortcutExtensions.DOFloat over the plant's renderer
				// materials on an unresolved shader property) interleaved with a
				// RewardManager.Instance.CreateSun loop gated by entity.GetValue(this).
				// The renderer/material collection and the tweened shader property are data
				// pointers that cannot be mapped to real, accessible members, and the
				// per-step WaitForSeconds durations are unresolved globals, so the body is
				// left as a stub rather than fabricating members.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__17 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public StrengthenEntity entity;

			public Plant265Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__17(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant265Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				// entity.GetValue(this): the level-3 power's value for this plant.
				if (entity != null)
				{
					float value = entity.GetValue(plant);
					// attr.valueList[0].baseValue += value, then push the new ratio into the
					// dispel-fog visual. attr is the PlantEntity base field; valueList[0] is
					// the plant's primary tunable value.
					if (plant != null && plant.attr != null && plant.attr.valueList != null
						&& plant.attr.valueList.Count > 0)
					{
						plant.attr.valueList[0].baseValue += value;
						plant.UpdateDispelFog(plant.attr.valueList[0].baseValue);
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CProduceSun_003Ed__11 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant265Entity _003C_003E4__this;

			private float _003Cscale_003E5__2;

			private int _003CsunValue_003E5__3;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CProduceSun_003Ed__11(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct — the pseudocode derives a sun value and scale from
				// DispelFog.GetSuccessfulDispelArea(), plays a material glow tween over the
				// plant's renderer materials (DOFloat on an unresolved shader property), then
				// spawns suns via RewardManager.Instance.CreateSun with per-step
				// WaitForSeconds delays. The renderer/material collection, the tweened shader
				// property and the delay durations are unresolved data pointers / globals, so
				// the multi-state body is left as a stub rather than fabricating members.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("驱散迷雾实体")]
		public DispelFog dispelFog;

		[Tooltip("驱散特效物体")]
		public GameObject dispelFogEffectObj;

		[Tooltip("种植音效")]
		public AudioClip startSound;

		private float _addBuffTimer;

		private float _intervalTimer;

		public override void Reset()
		{
			// ICF-folded onto the base PlantEntity.Reset body; this override adds no
			// plant-specific reset logic beyond the base behavior.
			base.Reset();
		}

		protected override void Start()
		{
			// TODO: reconstruct — after base.Start() the pseudocode activates the
			// dispelFog GameObject and dispelFogEffectObj, plays startSound through
			// AudioManager, then DOTween-lerps the fog's dispel size to
			// baseDispelSize * attr.valueList[0].baseValue. The tween drives a private
			// DispelFog field via DOGetter/DOSetter closures whose target member is not
			// safely resolvable from the dump, so the visual setup is left stubbed rather
			// than manipulating members that may not be accessible.
			base.Start();
		}

		protected override void Update()
		{
			base.Update();
			// _addBuffTimer (0x138): once it exceeds a 1s interval, refresh the
			// explosion-immunity buff on neighbouring plants and reset the timer.
			_addBuffTimer += Time.deltaTime;
			if (_addBuffTimer > 1f)
			{
				_addBuffTimer = 0f;
				AddImmuneExplosionBuff();
			}
			// _intervalTimer (0x13c): drives sun production on the interval defined by
			// attr.attackIntervalTime (attr.GetValue(this, 1) in the pseudocode maps to
			// the plant's produce interval). Once reached, kick off the ProduceSun
			// coroutine and reset the timer.
			_intervalTimer += Time.deltaTime;
			if (attr == null)
			{
				return;
			}
			if (attr.GetValue(this, 1) <= _intervalTimer)
			{
				_intervalTimer = 0f;
				StartCoroutine(ProduceSun());
			}
		}

		public override void Death()
		{
			base.Death();
			// On death, drop the explosion-immunity buff (buff id 4) from every plant in
			// the surrounding 3x3 grid (including diagonals) that this plant had granted it
			// to. Neighbours are all land plants whose land row/column are within 1 of ours.
			List<PlantEntity> neighbours = LevelUtils
				.GetLandPlantList(-1, -1, PlaceType.All)
				.Where(delegate(PlantEntity plantEntity)
				{
					if (plantEntity == this)
					{
						return false;
					}
					if (plantEntity == null || plantEntity.CurrentLandEntity == null)
					{
						return false;
					}
					LandEntity self = CurrentLandEntity;
					LandEntity other = plantEntity.CurrentLandEntity;
					if (self == null)
					{
						return false;
					}
					return Mathf.Abs(self.rowId - other.rowId) < 2
						&& Mathf.Abs(self.columnId - other.columnId) < 2;
				})
				.ToList();
			foreach (PlantEntity neighbour in neighbours)
			{
				if (neighbour.immuneBuffIdList != null && neighbour.immuneBuffIdList.Contains(4))
				{
					neighbour.immuneBuffIdList.Remove(4);
				}
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// ICF-folded onto an empty body; this level-0 hook applies no extra effect.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// Strengthen 0: increase the plant's primary tunable value and push the new
				// ratio into the dispel-fog visual.
				float value = entity.GetValue(this);
				if (attr != null && attr.valueList != null && attr.valueList.Count > 0)
				{
					attr.valueList[0].baseValue += value;
					UpdateDispelFog(attr.valueList[0].baseValue);
				}
			}
			else if (entity.index == 1)
			{
				// TODO: reconstruct — strengthen 1 multiplies defaultAttr.maxHealth by
				// entity.GetValue(this) and feeds the product into a virtual slot (0x268)
				// that could not be mapped to a concrete, verified method on this type, so
				// the effect is left unapplied rather than invoking an unidentified member.
			}
		}

		[IteratorStateMachine(typeof(_003CProduceSun_003Ed__11))]
		private IEnumerator ProduceSun()
		{
			return new _003CProduceSun_003Ed__11(0)
			{
				_003C_003E4__this = this
			};
		}

		private void AddImmuneExplosionBuff()
		{
			// Grant the explosion-immunity buff (buff id 4) to every plant in the
			// surrounding 3x3 grid (including diagonals) that does not already have it.
			List<PlantEntity> neighbours = LevelUtils
				.GetLandPlantList(-1, -1, PlaceType.All)
				.Where(delegate(PlantEntity plantEntity)
				{
					if (plantEntity == this)
					{
						return false;
					}
					if (plantEntity == null || plantEntity.CurrentLandEntity == null)
					{
						return false;
					}
					LandEntity self = CurrentLandEntity;
					LandEntity other = plantEntity.CurrentLandEntity;
					if (self == null)
					{
						return false;
					}
					return Mathf.Abs(self.rowId - other.rowId) < 2
						&& Mathf.Abs(self.columnId - other.columnId) < 2;
				})
				.ToList();
			foreach (PlantEntity neighbour in neighbours)
			{
				if (neighbour.immuneBuffIdList != null && !neighbour.immuneBuffIdList.Contains(4))
				{
					neighbour.immuneBuffIdList.Add(4);
				}
			}
		}

		public void UpdateDispelFog(float ratio, float duration = 1f)
		{
			// TODO: reconstruct — the pseudocode DOTween-lerps the DispelFog's dispel size
			// to baseDispelSize * ratio over `duration` by driving a private DispelFog field
			// through DOGetter/DOSetter closures. The target member is not safely resolvable
			// to an accessible DispelFog property, so this is left stubbed rather than
			// manipulating members that may not exist / be accessible.
		}

		protected override void Attack()
		{
			// TODO: reconstruct — the pseudocode reads attr and a field at 0x78 then invokes
			// an indirect global delegate (jump table not recovered) with a value derived
			// from attr. The delegate target cannot be identified from the dump, so this is
			// left stubbed rather than fabricating a call.
		}

		protected override bool CheckAttack()
		{
			// ICF-folded onto a body that returns false; this fog plant does not gate on a
			// projectile-style attack check.
			return false;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__16))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__16(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__17))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__17(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
