using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Audio.Manager;
using Bullet.Entity;
using Bullet.Util;
using Common.Entity;
using DG.Tweening;
using Game.Entity;
using Game.Util;
using Level.Entity;
using Level.Enum;
using Level.Manager;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant35Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CExplosionCoroutine_003Ed__15 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant35Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CExplosionCoroutine_003Ed__15(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// State machine runs its whole body in state 0 and finishes immediately
				// (no yields in the pseudocode); MoveNext always returns false.
				Plant35Entity plant = _003C_003E4__this;
				if (_003C_003E1__state != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null)
				{
					return false;
				}
				// Guard: only explode once (_isExplosion @0x13C).
				if (plant._isExplosion)
				{
					return false;
				}
				plant._isExplosion = true;
				// attr @0xE0
				if (plant.attr == null)
				{
					return false;
				}
				// Explosion damage/value pulled from the plant's value list (index 0).
				float damage = plant.attr.GetValue(plant, 0);
				// effectScale = damage * <scale const> (_UNK_18252ce24, unresolved global).
				float effectScale = damage * ExplosionEffectScale;
				Transform t = plant.transform;
				if (t == null)
				{
					return false;
				}
				Vector2 pos = t.position;
				// explosionEffect @0x128
				GameUtils.CreateEffect(plant.explosionEffect, pos, Quaternion.identity, effectScale);
				Vector2 pos2 = plant.transform.position;
				// Damage plants first (returns the affected bodies), then zombies/others.
				// TODO: the pseudocode passes a single resolved float (damage) for these
				// calls; the radius argument is an unresolved constant, placeholdered below.
				List<BaseBody> affected = DamageUtils.ExplosionPlant(pos2, ExplosionRadius, damage, plant);
				Vector2 pos3 = plant.transform.position;
				DamageUtils.Explosion(pos3, ExplosionRadius, damage);
				// OnExplosionAfter @0x140
				if (plant.OnExplosionAfter != null)
				{
					plant.OnExplosionAfter(affected);
				}
				// Remove this plant after it detonates.
				plant.Clear();
				return false;
			}

			// TODO: unresolved explosion constants (data-pointer / global floats in the
			// pseudocode). Effect scale multiplier and blast radius could not be recovered.
			private const float ExplosionEffectScale = 1f; // TODO: reconstruct constant
			private const float ExplosionRadius = 1f; // TODO: reconstruct constant

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__16 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__16(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// Empty coroutine: the pseudocode only clears the state flag and finishes.
				if (_003C_003E1__state == 0)
				{
					_003C_003E1__state = -1;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__17 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__17(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// Empty coroutine: the pseudocode only clears the state flag and finishes.
				if (_003C_003E1__state == 0)
				{
					_003C_003E1__state = -1;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("种植时音效")]
		public AudioClip startSound;

		[Tooltip("爆炸效果")]
		public EffectEntity explosionEffect;

		[Tooltip("叠加攻击时间")]
		public float addAttackTime;

		private float _addAttackTimer;

		[Tooltip("叠加攻击值")]
		public float addAttackRatio;

		private bool _isExplosion;

		public Action<List<BaseBody>> OnExplosionAfter;

		public override void Reset()
		{
			base.Reset();
			// _isExplosion @0x13C
			_isExplosion = false;
		}

		protected override void Start()
		{
			// The override reproduces the base behaviour (subscribe to the card's level-up
			// event and refresh the land health display). The compiler-generated handler /
			// animation targets in the pseudocode are data pointers that resolve to the same
			// work PlantEntity.Start already performs, so delegate to base.
			base.Start();
		}

		protected override void Update()
		{
			base.Update();
			// _addAttackTimer @0x134, addAttackTime @0x130
			_addAttackTimer += Time.deltaTime;
			if (addAttackTime <= _addAttackTimer)
			{
				_addAttackTimer = 0f;
				// Periodically boost current attack by a ratio of the default attack.
				// attr @0xE0, defaultAttr @0xE8, PlantBaseAttr.attack @0x20, addAttackRatio @0x138
				attr.attack += (int)((float)defaultAttr.attack * addAttackRatio);
			}
		}

		public override bool Hit(float value, DamageTypeEntity damageType = null, BulletEntity sourceBullet = null)
		{
			bool result = base.Hit(value, damageType, sourceBullet);
			// attr @0xE0, PlantBaseAttr.currentHealth @0x14
			if (attr.currentHealth <= 0f)
			{
				StartCoroutine(ExplosionCoroutine());
			}
			return result;
		}

		public override void Death()
		{
			base.Death();
			// _lastDamageType @0xB0, DamageTypeEntity.deathType @0x14 (DeathType.Clear == 2)
			if (_lastDamageType != null && _lastDamageType.deathType == DeathType.Clear)
			{
				// attr @0xE0, PlantBaseAttr.attack @0x20
				if (attr != null)
				{
					int attack = attr.attack;
					RewardManager rewardManager = RewardManager.Instance;
					if (rewardManager != null)
					{
						rewardManager.CreateSun(transform.position, attack / 10, 1f, true);
					}
				}
			}
		}

		public void Explosion()
		{
			// _isExplosion @0x13C
			if (_isExplosion)
			{
				return;
			}
			AudioManager audioManager = AudioManager.Instance;
			if (audioManager == null)
			{
				return;
			}
			// startSound @0x120
			audioManager.PlayOneShot(startSound);
			// _animator @0x78
			if (_animator != null)
			{
				// TODO: the explosion animation state name is a data pointer in the
				// pseudocode and could not be resolved to its literal string.
				_animator.Play(ExplosionAnimName);
				// After a short delay, run the explosion coroutine (see <Explosion>b__12_0).
				DOVirtual.DelayedCall(ExplosionDelay, _003CExplosion_003Eb__12_0);
			}
		}

		// TODO: unresolved explosion animation-state name / delay constant (data pointers).
		private const string ExplosionAnimName = "Explosion"; // TODO: reconstruct literal
		private const float ExplosionDelay = 1f; // TODO: reconstruct constant

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
		}

		[IteratorStateMachine(typeof(_003CExplosionCoroutine_003Ed__15))]
		private IEnumerator ExplosionCoroutine()
		{
			return new _003CExplosionCoroutine_003Ed__15(0)
			{
				_003C_003E4__this = this
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__16))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__16(0);
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__17))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__17(0);
		}

		public override int GetHeadNumber()
		{
			return 2;
		}

		[CompilerGenerated]
		private void _003CExplosion_003Eb__12_0()
		{
			// Delayed callback scheduled from Explosion(): kick off the explosion coroutine.
			StartCoroutine(ExplosionCoroutine());
		}
	}
}
