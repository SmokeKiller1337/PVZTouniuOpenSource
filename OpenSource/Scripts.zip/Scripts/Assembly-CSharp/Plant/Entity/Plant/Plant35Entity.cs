using System;
using System.Collections;
using System.Collections.Generic;
using Audio.Manager;
using Bullet.Entity;
using Bullet.Util;
using Common.Entity;
using DG.Tweening;
using Game.Entity;
using Game.Util;
using Level.Entity;
using Level.Enum;
using Level.Manager;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant35Entity : PlantEntity
	{
		[Tooltip("种植时音效")]
		public AudioClip startSound;

		[Tooltip("爆炸效果")]
		public EffectEntity explosionEffect;

		[Tooltip("叠加攻击时间")]
		public float addAttackTime;

		private float _addAttackTimer;

		[Tooltip("叠加攻击值")]
		public float addAttackRatio;

		private bool _isExplosion;

		public Action<List<BaseBody>> OnExplosionAfter;

		public override void Reset()
		{
			base.Reset();
			_isExplosion = false;
		}

		protected override void Start()
		{
			base.Start();
		}

		protected override void Update()
		{
			base.Update();
			_addAttackTimer += Time.deltaTime;
			if (addAttackTime <= _addAttackTimer)
			{
				_addAttackTimer = 0f;
				attr.attack += (int)((float)defaultAttr.attack * addAttackRatio);
			}
		}

		public override bool Hit(float value, DamageTypeEntity damageType = null, BulletEntity sourceBullet = null)
		{
			bool result = base.Hit(value, damageType, sourceBullet);
			if (attr.currentHealth <= 0f)
			{
				StartCoroutine(ExplosionCoroutine());
			}
			return result;
		}

		public override void Death()
		{
			base.Death();
			if (_lastDamageType != null && _lastDamageType.deathType == DeathType.Clear)
			{
				if (attr != null)
				{
					int attack = attr.attack;
					RewardManager rewardManager = RewardManager.Instance;
					if (rewardManager != null)
					{
						rewardManager.CreateSun(transform.position, attack / 10, 1f, true);
					}
				}
			}
		}

		public void Explosion()
		{
			if (_isExplosion)
			{
				return;
			}
			AudioManager audioManager = AudioManager.Instance;
			if (audioManager == null)
			{
				return;
			}
			audioManager.PlayOneShot(startSound);
			if (_animator != null)
			{
				_animator.Play(ExplosionAnimName);
				// 播放爆炸动画后延迟触发爆炸协程
				DOVirtual.DelayedCall(ExplosionDelay, delegate
				{
					StartCoroutine(ExplosionCoroutine());
				});
			}
		}

		private const string ExplosionAnimName = "Explosion";
		private const float ExplosionDelay = 1f;

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
		}

		private IEnumerator ExplosionCoroutine()
		{
			if (this == null)
			{
				yield break;
			}
			if (_isExplosion)
			{
				yield break;
			}
			_isExplosion = true;
			if (attr == null)
			{
				yield break;
			}
			// 爆炸伤害取自植物数值列表索引 0
			float damage = attr.GetValue(this, 0);
			float effectScale = damage * ExplosionEffectScale;
			Transform t = transform;
			if (t == null)
			{
				yield break;
			}
			Vector2 pos = t.position;
			GameUtils.CreateEffect(explosionEffect, pos, Quaternion.identity, effectScale);
			Vector2 pos2 = transform.position;
			List<BaseBody> affected = DamageUtils.ExplosionPlant(pos2, ExplosionRadius, damage, this);
			Vector2 pos3 = transform.position;
			DamageUtils.Explosion(pos3, ExplosionRadius, damage);
			if (OnExplosionAfter != null)
			{
				OnExplosionAfter(affected);
			}
			// 引爆后移除该植物
			Clear();
		}

		private const float ExplosionEffectScale = 1f;
		private const float ExplosionRadius = 1f;

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			yield break;
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			yield break;
		}

		public override int GetHeadNumber()
		{
			return 2;
		}
	}
}
