using System.Collections;
using System.Collections.Generic;
using Common.Entity;
using Game.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant110Entity : PlantEntity
	{
		private const string AttackAnimName = "Attack";

		private const string AttackSpeedParamName = "AttackSpeed";

		private const float AttackWaitFactor = 1f;

		private const float AttackSpeedAnimFactor = 30f;

		[Tooltip("子弹位置")]
		public Transform bulletPosition;

		public override void Reset()
		{
			base.Reset();
		}

		protected override void Update()
		{
			base.Update();
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// empty body (matches the base virtual no-op).
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// Level-up branch 0: additive attack bonus scaled by the strengthen value.
				if (attr != null && defaultAttr != null)
				{
					int currentAttack = attr.attack;
					int baseAttack = defaultAttr.attack;
					float scale = entity.GetValue(this, 0);
					attr.attack = (int)((float)baseAttack * scale) + currentAttack;
				}
			}
			else if (entity.index == 1)
			{
				if (attr != null && defaultAttr != null)
				{
					float ratio = entity.GetValue(this, 0);
					attr.AttackSpeed = ratio * defaultAttr.attackSpeed + attr.attackSpeed;
				}
			}
		}

		protected override void Attack()
		{
			if (attr == null || _animator == null)
			{
				return;
			}
			// Drive the attack animator parameter from the current attack speed, then
			// run the shoot coroutine.
			_animator.SetFloat(AttackSpeedParamName, attr.attackSpeed * AttackSpeedAnimFactor);
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			if (this != null && _animator != null)
			{
				_animator.Play(AttackAnimName);
				if (attr != null)
				{
					// 播放攻击动画后等待攻击间隔
					yield return new WaitForSeconds(attr.attackIntervalTime * AttackWaitFactor);
					if (this != null && bulletPosition != null)
					{
						// 从枪口位置发射子弹
						CreateBullet(0, bulletPosition.position);
					}
				}
			}
		}

		protected override bool CheckAttack()
		{
			return false;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			List<ValueEntity> valueList = new List<ValueEntity>();
			if (this != null)
			{
				// 攻速加成随强化值缩放，作为限时 buff 施加
				float scale = entity.GetValue(this, 0);
				if (defaultAttr != null)
				{
					float baseAttackSpeed = defaultAttr.attackSpeed;
					float duration = entity.GetValue(this, 1);
					ValueEntity value = new ValueEntity();
					value.baseValue = baseAttackSpeed * scale;
					valueList.Add(value);
					if (_buffHandler != null)
					{
						_buffHandler.AddBuff(10, null, duration, valueList);
					}
				}
			}
			yield break;
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			if (this != null && attr != null)
			{
				PlantBaseAttr a = attr;
				float currentAttackSpeed = a.attackSpeed;
				if (defaultAttr != null)
				{
					float baseAttackSpeed = defaultAttr.attackSpeed;
					if (entity != null)
					{
						float ratio = entity.GetValue(this, 0);
						a.AttackSpeed = ratio * baseAttackSpeed + currentAttackSpeed;
						// 以强化条目的标题记录这次属性修改
						attr.AddLabel(entity.title, 1, entity.GetDesc(this));
					}
				}
			}
			yield break;
		}
	}
}
