using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Entity;
using Game.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant110Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__6 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant110Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__6(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant110Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (plant != null && plant._animator != null)
					{
						// TODO: reconstruct — the attack animation state name is an
						// unresolved data pointer in the pseudocode.
						plant._animator.Play(AttackAnimName);
						if (plant.attr != null)
						{
							// yield return new WaitForSeconds(attr.attackIntervalTime * factor)
							_003C_003E2__current = new WaitForSeconds(plant.attr.attackIntervalTime * AttackWaitFactor);
							_003C_003E1__state = 1;
							return true;
						}
					}
					return false;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant != null && plant.bulletPosition != null)
				{
					// Fire a bullet from the muzzle transform.
					plant.CreateBullet(0, plant.bulletPosition.position);
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__8 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public StrengthenEntity entity;

			public Plant110Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__8(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant110Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				List<ValueEntity> valueList = new List<ValueEntity>();
				if (plant != null)
				{
					// Base attack-speed value scaled by the strengthen value.
					float scale = entity.GetValue(plant, 0);
					if (plant.defaultAttr != null)
					{
						float baseAttackSpeed = plant.defaultAttr.attackSpeed;
						float duration = entity.GetValue(plant, 1);
						ValueEntity value = new ValueEntity();
						value.baseValue = baseAttackSpeed * scale;
						valueList.Add(value);
						if (plant._buffHandler != null)
						{
							// TODO: buff id (10) taken from the pseudocode.
							plant._buffHandler.AddBuff(10, null, duration, valueList);
						}
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__9 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant110Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__9(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant110Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant != null && plant.attr != null)
				{
					PlantBaseAttr a = plant.attr;
					float currentAttackSpeed = a.attackSpeed;
					if (plant.defaultAttr != null)
					{
						float baseAttackSpeed = plant.defaultAttr.attackSpeed;
						if (entity != null)
						{
							float ratio = entity.GetValue(plant, 0);
							a.AttackSpeed = ratio * baseAttackSpeed + currentAttackSpeed;
							// Record the change as a labelled attribute modifier.
							plant.attr.AddLabel(entity.title, 1, entity.GetDesc(plant));
						}
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		// TODO: reconstruct — the attack animation state name and the two timing
		// factors below are unresolved data/global pointers in the pseudocode.
		private const string AttackAnimName = "Attack"; // TODO: reconstruct literal

		private const string AttackSpeedParamName = "AttackSpeed"; // TODO: reconstruct animator parameter name

		private const float AttackWaitFactor = 1f; // TODO: reconstruct constant (_DAT_18252cd08)

		private const float AttackSpeedAnimFactor = 30f; // TODO: reconstruct constant (_DAT_18252cf40)

		[Tooltip("子弹位置")]
		public Transform bulletPosition;

		public override void Reset()
		{
			// RVA 0x592570 is ICF-folded onto the base PlantEntity.Reset body; this
			// override reproduces the same behaviour by delegating to it.
			base.Reset();
		}

		protected override void Update()
		{
			// RVA 0x592580 is ICF-folded onto the base PlantEntity.Update body; this
			// override reproduces the same behaviour by delegating to it.
			base.Update();
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// RVA 0x381980: empty body (matches the base virtual no-op).
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// Level-up branch 0: additive attack bonus scaled by the strengthen value.
				if (attr != null && defaultAttr != null)
				{
					int currentAttack = attr.attack;
					int baseAttack = defaultAttr.attack;
					float scale = entity.GetValue(this, 0);
					attr.attack = (int)((float)baseAttack * scale) + currentAttack;
				}
			}
			else if (entity.index == 1)
			{
				// Level-up branch 1: attack-speed bonus. The exact set argument was lost
				// by the void-typed decompilation; reconstructed from the analogous
				// OnUsePower1 formula (ratio * defaultAttr.attackSpeed + attr.attackSpeed).
				if (attr != null && defaultAttr != null)
				{
					float ratio = entity.GetValue(this, 0);
					attr.AttackSpeed = ratio * defaultAttr.attackSpeed + attr.attackSpeed;
				}
			}
		}

		protected override void Attack()
		{
			if (attr == null || _animator == null)
			{
				return;
			}
			// Drive the attack animator parameter from the current attack speed, then
			// run the shoot coroutine.
			_animator.SetFloat(AttackSpeedParamName, attr.attackSpeed * AttackSpeedAnimFactor);
			StartCoroutine(AttackCoroutine());
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__6))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__6(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			// TODO: reconstruct — the pseudocode performs a Physics2D.RaycastAll toward
			// the level's zombie/home house transforms (resolved through an unverified
			// manager singleton chain _DAT_182e2bc20 -> ... -> transform) and inspects
			// each hit body via virtual slots that could not be mapped to concrete
			// members. Those manager members do not exist / cannot be verified in the
			// project, so this front-zombie detection is left stubbed.
			return false;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__8))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__8(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__9))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__9(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
