using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Audio.Manager;
using Level.Manager;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant100Entity : PlantEntity
	{
		// ---------------------------------------------------------------------
		// Reconstruction notes for the compiler-generated iterator classes below:
		//   * Only their MoveNext bodies are reconstructed (per task scope). The
		//     ctor / Dispose / Reset / Current getters are left exactly as the
		//     authoritative skeleton produced them. In particular the two Current
		//     getters return null in the skeleton, so at runtime every yielded
		//     value is observed as null (i.e. "wait one frame"); the WaitForSeconds
		//     objects are still constructed for fidelity but the skeleton getter
		//     collapses them to null-yields. This is a skeleton-imposed limitation,
		//     not a reconstruction choice.
		//   * The empty ctor means _003C_003E1__state keeps its default value 0,
		//     which is the correct initial state, so the outer factory methods just
		//     use an object initializer to set _003C_003E4__this / entity.
		// ---------------------------------------------------------------------

		[CompilerGenerated]
		private sealed class _003CChangeSleepStateCoroutine_003Ed__15 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant100Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CChangeSleepStateCoroutine_003Ed__15(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant100Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					// The original state machine yielded base.ChangeSleepStateCoroutine()
					// here (via the compiler-generated <>n__0 helper, which is not part of
					// this class' authoritative skeleton). That helper cannot be referenced
					// without inventing a member, so the nested wait is simplified to a
					// single frame yield before the animation switch below.
					_003C_003E2__current = null;
					_003C_003E1__state = 1;
					return true;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant != null && plant.partEntity != null)
				{
					if (!plant.partEntity.isSleeping)
					{
						if (plant._animator != null)
						{
							plant._animator.Play(AwakeAnimName);
						}
					}
					else if (plant._animator != null)
					{
						plant._animator.Play(SleepAnimName);
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__19 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant100Entity _003C_003E4__this;

			public StrengthenEntity entity;

			private int _003Ci_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__19(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant100Entity plant = _003C_003E4__this;
				switch (num)
				{
				default:
					return false;
				case 0:
					_003C_003E1__state = -1;
					if (plant == null)
					{
						return false;
					}
					// Original: fade the head sprites' shader property via DOTween when the
					// plant is not highlighted. The shader property id, target value and tween
					// duration are unresolved data pointers, so the tween itself is left as a
					// TODO rather than fabricated. The renderer enumeration is preserved.
					if (!plant._isHighlight && plant.headSpriteRendererList != null)
					{
						foreach (SpriteRenderer spriteRenderer in plant.headSpriteRendererList)
						{
							if (spriteRenderer != null)
							{
								// TODO: reconstruct DOTween DOFloat(spriteRenderer.material, target,
								// propertyId, duration) - property id / target / duration were
								// unrecoverable globals in the pseudocode.
							}
						}
					}
					_003C_003E2__current = new WaitForSeconds(ProduceIntervalSeconds);
					_003C_003E1__state = 1;
					return true;
				case 1:
					_003C_003E1__state = -1;
					_003Ci_003E5__2 = 0;
					break;
				case 2:
					_003C_003E1__state = -1;
					_003Ci_003E5__2++;
					break;
				case 3:
					_003C_003E1__state = -1;
					return false;
				}
				if (entity == null || plant == null)
				{
					return false;
				}
				int count = (int)entity.GetValue(plant, 0);
				if (count <= _003Ci_003E5__2)
				{
					// Final pass: play the closing head-sprite tween and wait once more.
					if (!plant._isHighlight && plant.headSpriteRendererList != null)
					{
						foreach (SpriteRenderer spriteRenderer in plant.headSpriteRendererList)
						{
							if (spriteRenderer != null)
							{
								// TODO: reconstruct closing DOTween DOFloat (unresolved args).
							}
						}
					}
					_003C_003E2__current = new WaitForSeconds(ProduceIntervalSeconds);
					_003C_003E1__state = 3;
					return true;
				}
				if (plant.OnProduceSun != null)
				{
					plant.OnProduceSun();
				}
				if (plant.attr != null)
				{
					int sunValue = plant.attr.GetValueInt(plant, 1);
					float scale = (plant._isBig ? BigSunScale : SmallSunScale);
					if (RewardManager.Instance != null)
					{
						RewardManager.Instance.CreateSun(plant.transform.position, sunValue, scale, true);
					}
					_003C_003E2__current = new WaitForSeconds(SunSpawnDelaySeconds);
					_003C_003E1__state = 2;
					return true;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__20 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant100Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__20(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// This iterator body contains no yields; the whole effect runs on the
				// first MoveNext and then completes.
				if (_003C_003E1__state != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				Plant100Entity plant = _003C_003E4__this;
				if (plant != null && entity != null && plant.attr != null)
				{
					// Only apply the strengthen once (guarded by the label having been added).
					if (!plant.attr.HasLabel(entity.title))
					{
						if (plant.attr.valueList != null && plant.defaultAttr != null && plant.defaultAttr.valueList != null)
						{
							plant.attr.valueList[0].baseValue -= entity.GetValue(plant, 0) * plant.defaultAttr.valueList[0].baseValue;
						}
						plant.attr.AddLabel(entity.title, 0, entity.GetDesc(plant));
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CProduceSun_003Ed__18 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant100Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CProduceSun_003Ed__18(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant100Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (plant == null)
					{
						return false;
					}
					// Opening head-sprite tween (unresolved DOTween args -> TODO).
					if (!plant._isHighlight && plant.headSpriteRendererList != null)
					{
						foreach (SpriteRenderer spriteRenderer in plant.headSpriteRendererList)
						{
							if (spriteRenderer != null)
							{
								// TODO: reconstruct DOTween DOFloat (unresolved property/target/duration).
							}
						}
					}
					_003C_003E2__current = new WaitForSeconds(ProduceIntervalSeconds);
					_003C_003E1__state = 1;
					return true;
				}
				if (num != 1)
				{
					if (num == 2)
					{
						_003C_003E1__state = -1;
					}
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null)
				{
					return false;
				}
				if (plant.OnProduceSun != null)
				{
					plant.OnProduceSun();
				}
				if (plant.attr != null)
				{
					int sunValue = plant.attr.GetValueInt(plant, 1);
					float scale = (plant._isBig ? BigSunScale : SmallSunScale);
					if (RewardManager.Instance != null)
					{
						RewardManager.Instance.CreateSun(plant.transform.position, sunValue, scale, true);
					}
					// Closing head-sprite tween (unresolved DOTween args -> TODO).
					if (!plant._isHighlight && plant.headSpriteRendererList != null)
					{
						foreach (SpriteRenderer spriteRenderer in plant.headSpriteRendererList)
						{
							if (spriteRenderer != null)
							{
								// TODO: reconstruct closing DOTween DOFloat (unresolved args).
							}
						}
					}
					_003C_003E2__current = new WaitForSeconds(SunSpawnDelaySeconds);
					_003C_003E1__state = 2;
					return true;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		// TODO: the following constants are unresolved data-pointer globals in the
		// pseudocode (float thresholds / durations / animator state names). They are
		// given conservative placeholder values so the class compiles and behaves
		// sensibly; replace with the real values when known.
		private const string AwakeAnimName = "Awake"; // TODO: reconstruct animator state literal
		private const string SleepAnimName = "Sleep"; // TODO: reconstruct animator state literal
		private const string GrowAnimName = "Grow"; // TODO: reconstruct animator state literal
		private const string DecreaseAnimName = "Decrease"; // TODO: reconstruct animator state literal
		private const float ProduceIntervalSeconds = 0f; // TODO: reconstruct wait duration
		private const float SunSpawnDelaySeconds = 0f; // TODO: reconstruct wait duration
		private const float SmallSunScale = 1f; // TODO: reconstruct sun scale (small plant)
		private const float BigSunScale = 1f; // TODO: reconstruct sun scale (big plant)
		private const float ResetIntervalFactor = 1f; // TODO: reconstruct _UNK_18252cf78 multiplier
		private const float BigValueDelta = 1f; // TODO: reconstruct _DAT_18252cb30 value-list delta

		[Tooltip("头贴图渲染器集合")]
		public List<SpriteRenderer> headSpriteRendererList;

		[Tooltip("生长音效")]
		public AudioClip growSound;

		[Tooltip("缩小音效")]
		public AudioClip decreaseSound;

		private float _intervalTimer;

		private bool _isBig;

		private float _bigTimer;

		public Action OnProduceSun;

		public bool IsBig
		{
			get
			{
				return _isBig;
			}
			set
			{
				_isBig = value;
			}
		}

		public override void Reset()
		{
			base.Reset();
			if (attr != null)
			{
				// _intervalTimer starts scaled off the plant's base value (produce interval).
				_intervalTimer = attr.GetValue(this, 0) * ResetIntervalFactor;
				_isBig = false;
			}
		}

		protected override void Start()
		{
			base.Start();
			if (attr == null || attr.floatValueList == null)
			{
				return;
			}
			if (attr.floatValueList.Count != 0)
			{
				// Restore persisted timers from the float value list.
				_intervalTimer = attr.floatValueList[0];
				_bigTimer = attr.floatValueList[1];
				if (_bigTimer < attr.GetValue(this, 2))
				{
					return;
				}
				// Already past the "grow" threshold on load -> shrink the grow value entry.
				if (attr.valueList != null)
				{
					attr.valueList[1].baseValue -= BigValueDelta;
				}
			}
			else
			{
				// Initialise the persisted-timer slots.
				attr.floatValueList.Add(0f);
				attr.floatValueList.Add(0f);
			}
		}

		protected override void Update()
		{
			base.Update();
			if (attr == null || attr.floatValueList == null)
			{
				return;
			}
			// Persist the live timers back into the float value list.
			attr.floatValueList[0] = _intervalTimer;
			attr.floatValueList[1] = _bigTimer;
			if (partEntity == null || partEntity.isSleeping)
			{
				return;
			}
			_intervalTimer += Time.deltaTime;
			if (_intervalTimer >= attr.GetValue(this, 0))
			{
				_intervalTimer = 0f;
				StartCoroutine(ProduceSun());
			}
			if (!_isBig)
			{
				_bigTimer += Time.deltaTime;
				if (_bigTimer >= attr.GetValue(this, 2))
				{
					EnterBig();
				}
			}
		}

		public void EnterBig()
		{
			if (_isBig)
			{
				return;
			}
			_isBig = true;
			if (AudioManager.Instance != null)
			{
				AudioManager.Instance.PlayOneShot(growSound);
			}
			if (attr != null && attr.valueList != null)
			{
				attr.valueList[1].baseValue += BigValueDelta;
			}
			if (_animator != null)
			{
				_animator.Play(GrowAnimName);
			}
		}

		public void EnterDecrease()
		{
			if (!_isBig)
			{
				return;
			}
			_bigTimer = 0f;
			_isBig = false;
			if (AudioManager.Instance != null)
			{
				AudioManager.Instance.PlayOneShot(decreaseSound);
			}
			if (attr != null && attr.valueList != null)
			{
				attr.valueList[1].baseValue -= BigValueDelta;
			}
			if (_animator != null)
			{
				_animator.Play(DecreaseAnimName);
			}
		}

		[IteratorStateMachine(typeof(_003CChangeSleepStateCoroutine_003Ed__15))]
		protected override IEnumerator ChangeSleepStateCoroutine()
		{
			return new _003CChangeSleepStateCoroutine_003Ed__15(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// ICF-folded onto the shared empty stub (RVA 0x381980); no body.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				if (attr != null && attr.valueList != null && defaultAttr != null && defaultAttr.valueList != null)
				{
					attr.valueList[2].baseValue -= entity.GetValue(this, 0) * defaultAttr.valueList[2].baseValue;
				}
			}
			else if (entity.index == 1)
			{
				if (attr != null && attr.valueList != null)
				{
					attr.valueList[1].baseValue += entity.GetValue(this, 0);
				}
			}
		}

		[IteratorStateMachine(typeof(_003CProduceSun_003Ed__18))]
		private IEnumerator ProduceSun()
		{
			return new _003CProduceSun_003Ed__18(0)
			{
				_003C_003E4__this = this
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__19))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__19(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__20))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__20(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
