using System;
using System.Collections;
using System.Collections.Generic;
using Audio.Manager;
using Level.Manager;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant100Entity : PlantEntity
	{

		private const string AwakeAnimName = "Awake";
		private const string SleepAnimName = "Sleep";
		private const string GrowAnimName = "Grow";
		private const string DecreaseAnimName = "Decrease";
		private const float ProduceIntervalSeconds = 0f;
		private const float SunSpawnDelaySeconds = 0f;
		private const float SmallSunScale = 1f;
		private const float BigSunScale = 1f;
		private const float ResetIntervalFactor = 1f;
		private const float BigValueDelta = 1f;

		[Tooltip("头贴图渲染器集合")]
		public List<SpriteRenderer> headSpriteRendererList;

		[Tooltip("生长音效")]
		public AudioClip growSound;

		[Tooltip("缩小音效")]
		public AudioClip decreaseSound;

		private float _intervalTimer;

		private bool _isBig;

		private float _bigTimer;

		public Action OnProduceSun;

		public bool IsBig
		{
			get
			{
				return _isBig;
			}
			set
			{
				_isBig = value;
			}
		}

		public override void Reset()
		{
			base.Reset();
			if (attr != null)
			{
				// _intervalTimer starts scaled off the plant's base value (produce interval).
				_intervalTimer = attr.GetValue(this, 0) * ResetIntervalFactor;
				_isBig = false;
			}
		}

		protected override void Start()
		{
			base.Start();
			if (attr == null || attr.floatValueList == null)
			{
				return;
			}
			if (attr.floatValueList.Count != 0)
			{
				// Restore persisted timers from the float value list.
				_intervalTimer = attr.floatValueList[0];
				_bigTimer = attr.floatValueList[1];
				if (_bigTimer < attr.GetValue(this, 2))
				{
					return;
				}
				// Already past the "grow" threshold on load -> shrink the grow value entry.
				if (attr.valueList != null)
				{
					attr.valueList[1].baseValue -= BigValueDelta;
				}
			}
			else
			{
				// Initialise the persisted-timer slots.
				attr.floatValueList.Add(0f);
				attr.floatValueList.Add(0f);
			}
		}

		protected override void Update()
		{
			base.Update();
			if (attr == null || attr.floatValueList == null)
			{
				return;
			}
			// Persist the live timers back into the float value list.
			attr.floatValueList[0] = _intervalTimer;
			attr.floatValueList[1] = _bigTimer;
			if (partEntity == null || partEntity.isSleeping)
			{
				return;
			}
			_intervalTimer += Time.deltaTime;
			if (_intervalTimer >= attr.GetValue(this, 0))
			{
				_intervalTimer = 0f;
				StartCoroutine(ProduceSun());
			}
			if (!_isBig)
			{
				_bigTimer += Time.deltaTime;
				if (_bigTimer >= attr.GetValue(this, 2))
				{
					EnterBig();
				}
			}
		}

		public void EnterBig()
		{
			if (_isBig)
			{
				return;
			}
			_isBig = true;
			if (AudioManager.Instance != null)
			{
				AudioManager.Instance.PlayOneShot(growSound);
			}
			if (attr != null && attr.valueList != null)
			{
				attr.valueList[1].baseValue += BigValueDelta;
			}
			if (_animator != null)
			{
				_animator.Play(GrowAnimName);
			}
		}

		public void EnterDecrease()
		{
			if (!_isBig)
			{
				return;
			}
			_bigTimer = 0f;
			_isBig = false;
			if (AudioManager.Instance != null)
			{
				AudioManager.Instance.PlayOneShot(decreaseSound);
			}
			if (attr != null && attr.valueList != null)
			{
				attr.valueList[1].baseValue -= BigValueDelta;
			}
			if (_animator != null)
			{
				_animator.Play(DecreaseAnimName);
			}
		}

		protected override IEnumerator ChangeSleepStateCoroutine()
		{
			// 等待一帧后根据休眠状态切换动画
			yield return null;
			if (this != null && partEntity != null)
			{
				if (!partEntity.isSleeping)
				{
					if (_animator != null)
					{
						_animator.Play(AwakeAnimName);
					}
				}
				else if (_animator != null)
				{
					_animator.Play(SleepAnimName);
				}
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				if (attr != null && attr.valueList != null && defaultAttr != null && defaultAttr.valueList != null)
				{
					attr.valueList[2].baseValue -= entity.GetValue(this, 0) * defaultAttr.valueList[2].baseValue;
				}
			}
			else if (entity.index == 1)
			{
				if (attr != null && attr.valueList != null)
				{
					attr.valueList[1].baseValue += entity.GetValue(this, 0);
				}
			}
		}

		private IEnumerator ProduceSun()
		{
			if (this == null)
			{
				yield break;
			}
			// 头部贴图开合表现
			if (!_isHighlight && headSpriteRendererList != null)
			{
				foreach (SpriteRenderer spriteRenderer in headSpriteRendererList)
				{
					if (spriteRenderer != null)
					{
					}
				}
			}
			yield return new WaitForSeconds(ProduceIntervalSeconds);
			if (this == null)
			{
				yield break;
			}
			if (OnProduceSun != null)
			{
				OnProduceSun();
			}
			if (attr != null)
			{
				int sunValue = attr.GetValueInt(this, 1);
				float scale = (_isBig ? BigSunScale : SmallSunScale);
				if (RewardManager.Instance != null)
				{
					RewardManager.Instance.CreateSun(transform.position, sunValue, scale, true);
				}
				// 头部贴图闭合表现
				if (!_isHighlight && headSpriteRendererList != null)
				{
					foreach (SpriteRenderer spriteRenderer in headSpriteRendererList)
					{
						if (spriteRenderer != null)
						{
						}
					}
				}
				yield return new WaitForSeconds(SunSpawnDelaySeconds);
			}
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			if (this == null)
			{
				yield break;
			}
			// 头部贴图开合表现
			if (!_isHighlight && headSpriteRendererList != null)
			{
				foreach (SpriteRenderer spriteRenderer in headSpriteRendererList)
				{
					if (spriteRenderer != null)
					{
					}
				}
			}
			yield return new WaitForSeconds(ProduceIntervalSeconds);
			// 按强化值决定额外产出阳光的次数
			for (int i = 0; ; i++)
			{
				if (entity == null || this == null)
				{
					yield break;
				}
				int count = (int)entity.GetValue(this, 0);
				if (count <= i)
				{
					// 收尾：播放闭合表现并再等待一次
					if (!_isHighlight && headSpriteRendererList != null)
					{
						foreach (SpriteRenderer spriteRenderer in headSpriteRendererList)
						{
							if (spriteRenderer != null)
							{
							}
						}
					}
					yield return new WaitForSeconds(ProduceIntervalSeconds);
					yield break;
				}
				if (OnProduceSun != null)
				{
					OnProduceSun();
				}
				if (attr != null)
				{
					int sunValue = attr.GetValueInt(this, 1);
					float scale = (_isBig ? BigSunScale : SmallSunScale);
					if (RewardManager.Instance != null)
					{
						RewardManager.Instance.CreateSun(transform.position, sunValue, scale, true);
					}
					yield return new WaitForSeconds(SunSpawnDelaySeconds);
				}
				else
				{
					yield break;
				}
			}
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			if (this != null && entity != null && attr != null)
			{
				// 仅应用一次强化，避免重复叠加标签
				if (!attr.HasLabel(entity.title))
				{
					if (attr.valueList != null && defaultAttr != null && defaultAttr.valueList != null)
					{
						attr.valueList[0].baseValue -= entity.GetValue(this, 0) * defaultAttr.valueList[0].baseValue;
					}
					attr.AddLabel(entity.title, 0, entity.GetDesc(this));
				}
			}
			yield break;
		}
	}
}
