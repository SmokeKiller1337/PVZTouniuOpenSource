using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Bullet.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant290Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CLeftAttackCoroutine_003Ed__11 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant290Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CLeftAttackCoroutine_003Ed__11(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant290Entity plant = _003C_003E4__this;
				switch (num)
				{
				default:
					return false;
				case 0:
				{
					_003C_003E1__state = -1;
					if (plant == null || plant.Animator == null)
					{
						return false;
					}
					// TODO: left-attack animator state name is a data pointer in the pseudocode.
					plant.Animator.Play(LeftAttackAnimName, 2);
					if (plant.attr == null)
					{
						return false;
					}
					// wait attackIntervalTime * <windup ratio> (unresolved global constant)
					_003C_003E2__current = new WaitForSeconds(plant.attr.attackIntervalTime * AttackWindupRatio);
					_003C_003E1__state = 1;
					return true;
				}
				case 1:
				{
					_003C_003E1__state = -1;
					// Fire the first left bullet if the left head is currently active.
					if (plant != null && plant.leftHeadRendererList != null)
					{
						SpriteRenderer head = plant.leftHeadRendererList[0];
						if (head != null && head.gameObject != null && head.gameObject.activeSelf)
						{
							plant.SpawnLeftBullet();
						}
					}
					if (plant == null || plant.attr == null)
					{
						return false;
					}
					// wait attackIntervalTime * <fire ratio> (unresolved global constant)
					_003C_003E2__current = new WaitForSeconds(plant.attr.attackIntervalTime * AttackFireRatio);
					_003C_003E1__state = 2;
					return true;
				}
				case 2:
					_003C_003E1__state = -1;
					// Fire the second left bullet if the left head is still active.
					if (plant != null && plant.leftHeadRendererList != null)
					{
						SpriteRenderer head2 = plant.leftHeadRendererList[0];
						if (head2 != null && head2.gameObject != null && head2.gameObject.activeSelf)
						{
							plant.SpawnLeftBullet();
						}
					}
					return false;
				}
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__15 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant290Entity _003C_003E4__this;

			public StrengthenEntity entity;

			private int _003Ci_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__15(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant290Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					_003Ci_003E5__2 = 0;
				}
				else
				{
					if (num != 1)
					{
						return false;
					}
					_003C_003E1__state = -1;
					// Trigger both sides once per burst step.
					plant.StartCoroutine(plant.LeftAttackCoroutine());
					plant.StartCoroutine(plant.RightAttackCoroutine());
					_003Ci_003E5__2++;
				}
				if (entity == null)
				{
					return false;
				}
				// Repeat GetValue() times, waiting between each burst.
				if ((int)entity.GetValue(plant, 0) <= _003Ci_003E5__2)
				{
					return false;
				}
				// TODO: burst interval is an unresolved global constant in the pseudocode.
				_003C_003E2__current = new WaitForSeconds(UsePower0BurstInterval);
				_003C_003E1__state = 1;
				return true;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__16 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant290Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__16(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				if (_003C_003E1__state != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				Plant290Entity plant = _003C_003E4__this;
				// One-shot power: permanently buffs attack by a fraction of the default attack
				// and records a descriptive label. No yield points.
				if (plant != null && plant.attr != null && plant.defaultAttr != null && entity != null)
				{
					plant.attr.attack = (int)((float)plant.defaultAttr.attack * entity.GetValue(plant, 0)) + plant.attr.attack;
					plant.attr.AddLabel(entity.title, 1, entity.GetDesc(plant));
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CRightAttackCoroutine_003Ed__12 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant290Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CRightAttackCoroutine_003Ed__12(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant290Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (plant == null || plant.Animator == null)
					{
						return false;
					}
					// TODO: right-attack animator state name is a data pointer in the pseudocode.
					plant.Animator.Play(RightAttackAnimName, 1);
					if (plant.attr == null)
					{
						return false;
					}
					_003C_003E2__current = new WaitForSeconds(plant.attr.attackIntervalTime * AttackWindupRatio);
					_003C_003E1__state = 1;
					return true;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				// Fire the right bullet if the right head is currently active.
				if (plant != null && plant.rightHeadRendererList != null)
				{
					SpriteRenderer head = plant.rightHeadRendererList[0];
					if (head != null && head.gameObject != null && head.gameObject.activeSelf && plant.rightBulletPosition != null)
					{
						plant.CreateBullet(0, plant.rightBulletPosition.position);
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("子弹位置")]
		public Transform rightBulletPosition;

		public Transform leftBulletPosition;

		[Tooltip("头部物体")]
		public List<SpriteRenderer> rightHeadRendererList;

		public List<SpriteRenderer> leftHeadRendererList;

		private bool _isLeftAttack;

		private bool _isRightAttack;

		// TODO: the following constants are data pointers / global floats in the pseudocode
		// that could not be resolved to their literal values. Replace with the real values
		// when known. They gate animation state selection and burst timing only.
		private const string LeftAttackAnimName = "LeftAttack"; // TODO: reconstruct literal
		private const string RightAttackAnimName = "RightAttack"; // TODO: reconstruct literal
		private const float AttackWindupRatio = 1f; // TODO: reconstruct constant (_DAT_18252cd08)
		private const float AttackFireRatio = 1f; // TODO: reconstruct constant (_DAT_18252cb80)
		private const float UsePower0BurstInterval = 0f; // TODO: reconstruct constant (_DAT_18252ccfc)
		private const float FrontZombieCheckDistance = -1f; // TODO: reconstruct constant (_DAT_18252cb70)

		public override void Reset()
		{
			// ICF-folded onto PlantEntity.Reset in the dump (no Plant290-specific fields are
			// touched); the override simply re-runs the base reset.
			base.Reset();
		}

		protected override void Update()
		{
			// ICF-folded onto PlantEntity.Update in the dump (identical attack/eye/cooldown
			// tick logic, no Plant290-specific fields); forwards to the base update.
			base.Update();
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// Empty in the dump (folded onto a no-op body).
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// Additive attack bonus scaled off the default attack.
				if (attr != null && defaultAttr != null)
				{
					attr.attack = (int)((float)defaultAttr.attack * entity.GetValue(this, 0)) + attr.attack;
				}
			}
			else if (entity.index == 1)
			{
				// Attack-speed replacement.
				if (attr != null)
				{
					attr.AttackSpeed = entity.GetValue(this, 0);
				}
			}
		}

		protected override void Attack()
		{
			base.Attack();
			if (_isLeftAttack)
			{
				StartCoroutine(LeftAttackCoroutine());
			}
			if (_isRightAttack)
			{
				StartCoroutine(RightAttackCoroutine());
			}
		}

		[IteratorStateMachine(typeof(_003CLeftAttackCoroutine_003Ed__11))]
		private IEnumerator LeftAttackCoroutine()
		{
			return new _003CLeftAttackCoroutine_003Ed__11(0)
			{
				_003C_003E4__this = this
			};
		}

		[IteratorStateMachine(typeof(_003CRightAttackCoroutine_003Ed__12))]
		private IEnumerator RightAttackCoroutine()
		{
			return new _003CRightAttackCoroutine_003Ed__12(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			_isLeftAttack = CheckIsBackZombie();
			_isRightAttack = CheckIsFrontZombie(FrontZombieCheckDistance);
			if (_isLeftAttack)
			{
				return true;
			}
			return _isRightAttack;
		}

		protected bool CheckIsBackZombie()
		{
			// TODO: reconstruct - the pseudocode performs a Physics2D.RaycastAll behind the
			// plant using ray parameters read from global level-manager singletons
			// (_DAT_182e706b8 muzzle-offset config and _DAT_182e2bc20 -> home-house / zombie
			// grid) that do not correspond to any type/member present in the project. Because
			// the ray origin, direction and length cannot be resolved without inventing those
			// members, this is left as a conservative stub.
			return false;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__15))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__15(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__16))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__16(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		public override int GetHeadNumber()
		{
			if (leftHeadRendererList == null)
			{
				return 0;
			}
			SpriteRenderer leftHead = leftHeadRendererList[0];
			if (leftHead == null || leftHead.gameObject == null)
			{
				return 0;
			}
			int count = (leftHead.gameObject.activeSelf ? 1 : 0);
			if (rightHeadRendererList == null)
			{
				return count;
			}
			SpriteRenderer rightHead = rightHeadRendererList[0];
			if (rightHead == null || rightHead.gameObject == null)
			{
				return count;
			}
			if (rightHead.gameObject.activeSelf)
			{
				count++;
			}
			return count;
		}

		private void SpawnLeftBullet()
		{
			// Spawn a bullet at the left muzzle, then nudge it by a flip-dependent offset read
			// from an unresolved global muzzle-offset config in the pseudocode.
			if (leftBulletPosition == null)
			{
				return;
			}
			BulletEntity bullet = CreateBullet(0, leftBulletPosition.position);
			if (bullet == null || bullet.transform == null)
			{
				return;
			}
			// TODO: the additional muzzle offset (flipped vs un-flipped) is read from the same
			// unresolved global config as PlantEntity.CreateBullet; applied as zero here.
			Vector3 pos = bullet.transform.position;
			Vector2 offset = (IsFlipX ? LeftMuzzleOffsetFlipped : LeftMuzzleOffset);
			bullet.transform.position = new Vector3(pos.x + offset.x, pos.y + offset.y, pos.z);
		}

		// TODO: unresolved flip-dependent muzzle offsets for the left cannon.
		private static readonly Vector2 LeftMuzzleOffset = Vector2.zero; // TODO: reconstruct offset
		private static readonly Vector2 LeftMuzzleOffsetFlipped = Vector2.zero; // TODO: reconstruct offset
	}
}
