using System.Collections;
using System.Collections.Generic;
using Bullet.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant290Entity : PlantEntity
	{
		[Tooltip("子弹位置")]
		public Transform rightBulletPosition;

		public Transform leftBulletPosition;

		[Tooltip("头部物体")]
		public List<SpriteRenderer> rightHeadRendererList;

		public List<SpriteRenderer> leftHeadRendererList;

		private bool _isLeftAttack;

		private bool _isRightAttack;

		private const string LeftAttackAnimName = "LeftAttack";
		private const string RightAttackAnimName = "RightAttack";
		private const float AttackWindupRatio = 1f;
		private const float AttackFireRatio = 1f;
		private const float UsePower0BurstInterval = 0f;
		private const float FrontZombieCheckDistance = -1f;

		public override void Reset()
		{
			base.Reset();
		}

		protected override void Update()
		{
			base.Update();
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// Additive attack bonus scaled off the default attack.
				if (attr != null && defaultAttr != null)
				{
					attr.attack = (int)((float)defaultAttr.attack * entity.GetValue(this, 0)) + attr.attack;
				}
			}
			else if (entity.index == 1)
			{
				// Attack-speed replacement.
				if (attr != null)
				{
					attr.AttackSpeed = entity.GetValue(this, 0);
				}
			}
		}

		protected override void Attack()
		{
			base.Attack();
			if (_isLeftAttack)
			{
				StartCoroutine(LeftAttackCoroutine());
			}
			if (_isRightAttack)
			{
				StartCoroutine(RightAttackCoroutine());
			}
		}

		private IEnumerator LeftAttackCoroutine()
		{
			if (Animator == null)
			{
				yield break;
			}
			// 播放左侧攻击动画后蓄力等待
			Animator.Play(LeftAttackAnimName, 2);
			if (attr == null)
			{
				yield break;
			}
			yield return new WaitForSeconds(attr.attackIntervalTime * AttackWindupRatio);
			// 左头激活时发射第一发子弹
			if (leftHeadRendererList != null)
			{
				SpriteRenderer head = leftHeadRendererList[0];
				if (head != null && head.gameObject != null && head.gameObject.activeSelf)
				{
					SpawnLeftBullet();
				}
			}
			if (attr == null)
			{
				yield break;
			}
			yield return new WaitForSeconds(attr.attackIntervalTime * AttackFireRatio);
			// 左头仍激活时发射第二发子弹
			if (leftHeadRendererList != null)
			{
				SpriteRenderer head2 = leftHeadRendererList[0];
				if (head2 != null && head2.gameObject != null && head2.gameObject.activeSelf)
				{
					SpawnLeftBullet();
				}
			}
		}

		private IEnumerator RightAttackCoroutine()
		{
			if (Animator == null)
			{
				yield break;
			}
			// 播放右侧攻击动画后蓄力等待
			Animator.Play(RightAttackAnimName, 1);
			if (attr == null)
			{
				yield break;
			}
			yield return new WaitForSeconds(attr.attackIntervalTime * AttackWindupRatio);
			// 右头激活时发射右侧子弹
			if (rightHeadRendererList != null)
			{
				SpriteRenderer head = rightHeadRendererList[0];
				if (head != null && head.gameObject != null && head.gameObject.activeSelf && rightBulletPosition != null)
				{
					CreateBullet(0, rightBulletPosition.position);
				}
			}
		}

		protected override bool CheckAttack()
		{
			_isLeftAttack = CheckIsBackZombie();
			_isRightAttack = CheckIsFrontZombie(FrontZombieCheckDistance);
			if (_isLeftAttack)
			{
				return true;
			}
			return _isRightAttack;
		}

		protected bool CheckIsBackZombie()
		{
			return false;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 按强化数值重复触发左右两侧攻击，每次之间等待固定间隔
			for (int i = 0; entity != null && (int)entity.GetValue(this, 0) > i; i++)
			{
				yield return new WaitForSeconds(UsePower0BurstInterval);
				StartCoroutine(LeftAttackCoroutine());
				StartCoroutine(RightAttackCoroutine());
			}
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			// 一次性强化：按默认攻击的比例永久提升攻击力并记录标签
			if (attr != null && defaultAttr != null && entity != null)
			{
				attr.attack = (int)((float)defaultAttr.attack * entity.GetValue(this, 0)) + attr.attack;
				attr.AddLabel(entity.title, 1, entity.GetDesc(this));
			}
			yield break;
		}

		public override int GetHeadNumber()
		{
			if (leftHeadRendererList == null)
			{
				return 0;
			}
			SpriteRenderer leftHead = leftHeadRendererList[0];
			if (leftHead == null || leftHead.gameObject == null)
			{
				return 0;
			}
			int count = (leftHead.gameObject.activeSelf ? 1 : 0);
			if (rightHeadRendererList == null)
			{
				return count;
			}
			SpriteRenderer rightHead = rightHeadRendererList[0];
			if (rightHead == null || rightHead.gameObject == null)
			{
				return count;
			}
			if (rightHead.gameObject.activeSelf)
			{
				count++;
			}
			return count;
		}

		private void SpawnLeftBullet()
		{
			if (leftBulletPosition == null)
			{
				return;
			}
			BulletEntity bullet = CreateBullet(0, leftBulletPosition.position);
			if (bullet == null || bullet.transform == null)
			{
				return;
			}
			// TODO: the additional muzzle offset (flipped vs un-flipped) is read from the same
			// unresolved global config as PlantEntity.CreateBullet; applied as zero here.
			Vector3 pos = bullet.transform.position;
			Vector2 offset = (IsFlipX ? LeftMuzzleOffsetFlipped : LeftMuzzleOffset);
			bullet.transform.position = new Vector3(pos.x + offset.x, pos.y + offset.y, pos.z);
		}

		// TODO: unresolved flip-dependent muzzle offsets for the left cannon.
		private static readonly Vector2 LeftMuzzleOffset = Vector2.zero;
		private static readonly Vector2 LeftMuzzleOffsetFlipped = Vector2.zero;
	}
}
