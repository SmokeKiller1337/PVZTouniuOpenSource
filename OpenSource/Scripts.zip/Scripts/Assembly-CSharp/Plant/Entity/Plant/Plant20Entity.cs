using System;
using System.Collections;
using System.Collections.Generic;
using Common.Entity;
using Game.Entity;
using Level.Manager;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant20Entity : PlantEntity
	{
		private const float ProduceSunWaitTime = 0.2f;
		private const float UsePowerWaitTime = 0.2f;
		private const float ProduceWaitTime = 0.2f;

		private const float IntervalTimerFactor = 1f;

		[Tooltip("头贴图渲染器集合")]
		public List<SpriteRenderer> headSpriteRendererList;

		private float _intervalTimer;

		public Action OnProduceSun;

		public override void Reset()
		{
			base.Reset();
			_intervalTimer = attr.GetValue(this, 0) * IntervalTimerFactor;
		}

		protected override void Update()
		{
			base.Update();
			if (partEntity == null)
			{
				return;
			}
			// 处于睡眠状态时不累积产出计时
			if (partEntity.isSleeping)
			{
				return;
			}
			_intervalTimer += Time.deltaTime;
			// 计时器达到产出间隔后触发一次产阳光
			if (attr.GetValue(this, 0) <= _intervalTimer)
			{
				_intervalTimer = 0f;
				StartCoroutine(ProduceSun());
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// 强化 0：按强化值乘以默认基础值减少阳光值
				if (attr != null && attr.valueList != null)
				{
					ValueEntity value = attr.valueList[0];
					if (defaultAttr != null && defaultAttr.valueList != null)
					{
						ValueEntity defaultValue = defaultAttr.valueList[0];
						value.baseValue -= entity.GetValue(this, 0) * defaultValue.baseValue;
					}
				}
			}
			else if (entity.index == 1)
			{
				// 强化 1：把强化值加到第二项阳光值上
				if (attr != null && attr.valueList != null)
				{
					ValueEntity value = attr.valueList[1];
					value.baseValue = entity.GetValue(this, 0) + value.baseValue;
				}
			}
		}

		private IEnumerator ProduceSun()
		{
			yield return new WaitForSeconds(ProduceSunWaitTime);
			if (OnProduceSun != null)
			{
				OnProduceSun();
			}
			if (attr != null)
			{
				int value = attr.GetValueInt(this, 1);
				if (headSpriteRendererList[0].gameObject.activeSelf)
				{
					RewardManager.Instance.CreateSun(transform.position, value, 1f, true);
				}
				yield return new WaitForSeconds(ProduceSunWaitTime);
			}
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			yield return new WaitForSeconds(UsePowerWaitTime);
			// 依据强化数量循环产出对应份数的阳光
			int i = 0;
			while (entity != null)
			{
				int count = (int)entity.GetValue(this, 0);
				if (count <= i)
				{
					yield return new WaitForSeconds(UsePowerWaitTime);
					yield break;
				}
				if (OnProduceSun != null)
				{
					OnProduceSun();
				}
				if (attr != null)
				{
					int value = attr.GetValueInt(this, 1);
					if (headSpriteRendererList[0].gameObject.activeSelf)
					{
						RewardManager.Instance.CreateSun(transform.position, value, 1f, true);
					}
				}
				yield return new WaitForSeconds(ProduceWaitTime);
				i++;
			}
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			// 强化 1：永久提升第二项阳光值并登记强化说明标签
			if (attr != null && attr.valueList != null)
			{
				ValueEntity value = attr.valueList[1];
				if (value != null && entity != null)
				{
					value.baseValue = entity.GetValue(this, 0) + value.baseValue;
					if (attr != null)
					{
						attr.AddLabel(entity.title, 1, entity.GetDesc(this));
					}
				}
			}
			yield break;
		}

		public override int GetHeadNumber()
		{
			// 头数量取决于第一个头部精灵的 GameObject 是否处于激活状态
			if (headSpriteRendererList != null)
			{
				SpriteRenderer head = headSpriteRendererList[0];
				if (head != null)
				{
					GameObject go = head.gameObject;
					if (go != null)
					{
						return go.activeSelf ? 1 : 0;
					}
				}
			}
			return 0;
		}
	}
}
