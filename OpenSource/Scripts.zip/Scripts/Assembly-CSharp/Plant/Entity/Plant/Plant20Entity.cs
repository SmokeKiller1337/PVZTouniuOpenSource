using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Entity;
using Game.Entity;
using Level.Manager;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant20Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__8 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant20Entity _003C_003E4__this;

			public StrengthenEntity entity;

			private int _003Ci_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__8(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant20Entity plant = _003C_003E4__this;
				switch (num)
				{
				case 0:
					_003C_003E1__state = -1;
					// TODO: reconstruct — a shader dissolve tween on headSpriteRendererList
					// (Renderer.material.DOFloat(target, shaderProperty, duration)) ran here.
					// The shader property name and float constants are unresolved data
					// pointers in the pseudocode, so the tween is dropped.
					// yield return new WaitForSeconds(UsePowerWaitTime);
					_003C_003E2__current = new WaitForSeconds(UsePowerWaitTime);
					_003C_003E1__state = 1;
					return true;
				case 1:
					_003C_003E1__state = -1;
					_003Ci_003E5__2 = 0;
					break;
				case 2:
					_003C_003E1__state = -1;
					_003Ci_003E5__2++;
					break;
				case 3:
					_003C_003E1__state = -1;
					return false;
				default:
					return false;
				}
				// loop body: produce one sun per iteration until the strengthen value is reached
				if (entity != null)
				{
					int count = (int)entity.GetValue(plant, 0);
					if (count <= _003Ci_003E5__2)
					{
						// TODO: reconstruct — trailing shader dissolve tween dropped (see case 0).
						// yield return new WaitForSeconds(UsePowerWaitTime);
						_003C_003E2__current = new WaitForSeconds(UsePowerWaitTime);
						_003C_003E1__state = 3;
						return true;
					}
					if (plant.OnProduceSun != null)
					{
						plant.OnProduceSun();
					}
					if (plant.attr != null)
					{
						int value = plant.attr.GetValueInt(plant, 1);
						if (plant.headSpriteRendererList[0].gameObject.activeSelf)
						{
							RewardManager.Instance.CreateSun(plant.transform.position, value, 1f, true);
						}
					}
					// yield return new WaitForSeconds(ProduceWaitTime);
					_003C_003E2__current = new WaitForSeconds(ProduceWaitTime);
					_003C_003E1__state = 2;
					return true;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__9 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant20Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__9(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant20Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				// Power 1: permanently boost the second sun-value and register a label
				// describing the strengthen on the plant's attribute.
				if (plant != null && plant.attr != null && plant.attr.valueList != null)
				{
					ValueEntity value = plant.attr.valueList[1];
					if (value != null && entity != null)
					{
						value.baseValue = entity.GetValue(plant, 0) + value.baseValue;
						PlantBaseAttr attr = plant.attr;
						if (attr != null)
						{
							attr.AddLabel(entity.title, 1, entity.GetDesc(plant));
						}
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CProduceSun_003Ed__7 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant20Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CProduceSun_003Ed__7(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant20Entity plant = _003C_003E4__this;
				switch (num)
				{
				case 0:
					_003C_003E1__state = -1;
					// TODO: reconstruct — a shader dissolve tween on headSpriteRendererList
					// (Renderer.material.DOFloat(target, shaderProperty, duration)) ran here.
					// The shader property name and float constants are unresolved data
					// pointers in the pseudocode, so the tween is dropped.
					// yield return new WaitForSeconds(ProduceSunWaitTime);
					_003C_003E2__current = new WaitForSeconds(ProduceSunWaitTime);
					_003C_003E1__state = 1;
					return true;
				case 1:
					_003C_003E1__state = -1;
					if (plant != null)
					{
						if (plant.OnProduceSun != null)
						{
							plant.OnProduceSun();
						}
						if (plant.attr != null)
						{
							int value = plant.attr.GetValueInt(plant, 1);
							if (plant.headSpriteRendererList[0].gameObject.activeSelf)
							{
								RewardManager.Instance.CreateSun(plant.transform.position, value, 1f, true);
							}
							// TODO: reconstruct — trailing shader dissolve tween dropped (see case 0).
							// yield return new WaitForSeconds(ProduceSunWaitTime);
							_003C_003E2__current = new WaitForSeconds(ProduceSunWaitTime);
							_003C_003E1__state = 2;
							return true;
						}
					}
					return false;
				case 2:
					_003C_003E1__state = -1;
					return false;
				default:
					return false;
				}
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		// TODO: unresolved WaitForSeconds durations (float constants stored as globals in
		// the pseudocode). Placeholder values chosen so the coroutines compile and run.
		private const float ProduceSunWaitTime = 0.2f; // TODO: reconstruct constant
		private const float UsePowerWaitTime = 0.2f; // TODO: reconstruct constant
		private const float ProduceWaitTime = 0.2f; // TODO: reconstruct constant

		// TODO: unresolved multiplier applied to the produce-sun interval in Reset()
		// (global constant _UNK_18252cf78 in the pseudocode).
		private const float IntervalTimerFactor = 1f; // TODO: reconstruct constant

		[Tooltip("头贴图渲染器集合")]
		public List<SpriteRenderer> headSpriteRendererList;

		private float _intervalTimer;

		public Action OnProduceSun;

		public override void Reset()
		{
			base.Reset();
			// _intervalTimer (0x128) = attr.GetValue(this, 0) * IntervalTimerFactor
			_intervalTimer = attr.GetValue(this, 0) * IntervalTimerFactor;
		}

		protected override void Update()
		{
			base.Update();
			if (partEntity == null)
			{
				return;
			}
			// only accumulate the produce timer while the plant is awake
			if (partEntity.isSleeping)
			{
				return;
			}
			_intervalTimer += Time.deltaTime;
			// once the accumulated timer reaches the produce interval, kick off ProduceSun
			if (attr.GetValue(this, 0) <= _intervalTimer)
			{
				_intervalTimer = 0f;
				StartCoroutine(ProduceSun());
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// index 0: reduce the sun value by strengthenValue * defaultAttr's base value
				if (attr != null && attr.valueList != null)
				{
					ValueEntity value = attr.valueList[0];
					if (defaultAttr != null && defaultAttr.valueList != null)
					{
						ValueEntity defaultValue = defaultAttr.valueList[0];
						value.baseValue -= entity.GetValue(this, 0) * defaultValue.baseValue;
					}
				}
			}
			else if (entity.index == 1)
			{
				// index 1: add the strengthen value to the second sun-value entry
				if (attr != null && attr.valueList != null)
				{
					ValueEntity value = attr.valueList[1];
					value.baseValue = entity.GetValue(this, 0) + value.baseValue;
				}
			}
		}

		[IteratorStateMachine(typeof(_003CProduceSun_003Ed__7))]
		private IEnumerator ProduceSun()
		{
			return new _003CProduceSun_003Ed__7(0)
			{
				_003C_003E4__this = this
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__8))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__8(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__9))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__9(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		public override int GetHeadNumber()
		{
			// number of visible heads == whether the first head sprite's GameObject is active
			if (headSpriteRendererList != null)
			{
				SpriteRenderer head = headSpriteRendererList[0];
				if (head != null)
				{
					GameObject go = head.gameObject;
					if (go != null)
					{
						return go.activeSelf ? 1 : 0;
					}
				}
			}
			return 0;
		}
	}
}
