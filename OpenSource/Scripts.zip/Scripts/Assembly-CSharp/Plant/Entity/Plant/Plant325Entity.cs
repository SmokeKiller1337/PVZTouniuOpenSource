using System;
using System.Collections;
using System.Collections.Generic;
using Common.Entity;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using Strengthen.Entity;
using Touniu.Entity.Body;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant325Entity : PlantEntity
	{
		private const string BiteAnimName = "Bite";
		private const string SwallowEndAnimName = "Idle";
		private const float SwallowEndDelay = 0f;
		private const float MaxAttackSpeedCap = 10f;
		private const int Power0BuffId = 10;

		[Tooltip("金属渲染器")]
		public SpriteRenderer metalSpriteRenderer;

		[Tooltip("吸取音效")]
		public AudioClip biteSound;

		private bool _isBiting;

		private float _biteTimer;

		private bool _isEndBiting;

		private bool _isPower0;

		private Coroutine _swallowEndCoroutine;

		private TweenerCore<Vector3, Vector3, VectorOptions> _metalMoveTween;

		public Action OnBiteAction;

		public override void Reset()
		{
			base.Reset();
		}

		protected override void Update()
		{
			base.Update();
			// Only tick the bite timer while a bite is in progress and not yet ending.
			if (_isEndBiting || !_isBiting)
			{
				return;
			}
			_biteTimer += Time.deltaTime;
			if (attr == null)
			{
				return;
			}
			// attr value index 1 is the maximum bite/hold duration.
			float maxTime = attr.GetValue(this, 1);
			if (maxTime <= _biteTimer)
			{
				SwallowEnd();
			}
			if (_isPower0)
			{
				SwallowEnd();
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			// entity.index selects which attr value this upgrade modifies.
			if (entity.index == 0)
			{
				if (attr == null || attr.valueList == null || defaultAttr == null || defaultAttr.valueList == null)
				{
					return;
				}
				Game.Entity.ValueEntity target = attr.valueList[0];
				Game.Entity.ValueEntity defaultValue = defaultAttr.valueList[0];
				if (target == null || defaultValue == null)
				{
					return;
				}
				// baseValue += strengthenValue * defaultBaseValue
				float scale = entity.GetValue(this, 0);
				target.baseValue = scale * defaultValue.baseValue + target.baseValue;
			}
			else if (entity.index == 1)
			{
				if (attr == null || attr.valueList == null || defaultAttr == null || defaultAttr.valueList == null)
				{
					return;
				}
				Game.Entity.ValueEntity target = attr.valueList[1];
				Game.Entity.ValueEntity defaultValue = defaultAttr.valueList[1];
				if (target == null || defaultValue == null)
				{
					return;
				}
				// baseValue -= strengthenValue * defaultBaseValue
				float scale = entity.GetValue(this, 0);
				target.baseValue = target.baseValue - scale * defaultValue.baseValue;
			}
		}

		protected override void Attack()
		{
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			// 播放咬取动画并触发咬取攻击
			if (_animator != null)
			{
				_animator.CrossFade(BiteAnimName, defaultTransitionDuration);
				BiteAttack();
			}
			yield break;
		}

		public void BiteAttack()
		{
		}

		public void SwallowEnd()
		{
			// Only start the swallow-end coroutine once.
			if (_swallowEndCoroutine == null)
			{
				_swallowEndCoroutine = StartCoroutine(SwallowEndCoroutine());
			}
		}

		private IEnumerator SwallowEndCoroutine()
		{
			yield return new WaitForSeconds(SwallowEndDelay);
			// 播放吞咽结束动画并复位咬取状态
			if (_animator != null)
			{
				_animator.CrossFade(SwallowEndAnimName, defaultTransitionDuration);
				if (metalSpriteRenderer != null)
				{
					metalSpriteRenderer.sprite = null;
					_isBiting = false;
					_isEndBiting = false;
					_swallowEndCoroutine = null;
				}
			}
		}

		protected override bool CheckAttack()
		{
			// Can only start a new attack when not already biting and a valid target exists.
			if (!_isBiting)
			{
				TouniuBaseBody target = GetNearestTargetZombie();
				if (target != null)
				{
					return true;
				}
			}
			return false;
		}

		private TouniuBaseBody GetNearestTargetZombie()
		{
			return null;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 咬取过程中，用当前攻速属性刷新咬取计时上限
			if (_isBiting)
			{
				if (attr == null)
				{
					yield break;
				}
				_biteTimer = attr.GetValue(this, 1);
			}
			if (entity == null)
			{
				yield break;
			}
			// 强化值决定技能效果的持续时间
			float duration = entity.GetValue(this, 0);
			_isPower0 = true;
			if (attr == null)
			{
				yield break;
			}
			// 攻速超过上限的部分作为临时增益的数值
			float overflow = 0f;
			if (attr.attackSpeed <= MaxAttackSpeedCap && MaxAttackSpeedCap != attr.attackSpeed)
			{
				overflow = MaxAttackSpeedCap - attr.attackSpeed;
			}
			List<Game.Entity.ValueEntity> valueList = new List<Game.Entity.ValueEntity>();
			Game.Entity.ValueEntity value = new Game.Entity.ValueEntity();
			value.baseValue = overflow;
			valueList.Add(value);
			if (_buffHandler == null)
			{
				yield break;
			}
			_buffHandler.AddBuff(Power0BuffId, null, duration, valueList);
			yield return new WaitForSeconds(duration);
			// 增益时间结束
			_isPower0 = false;
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			if (attr == null || defaultAttr == null)
			{
				yield break;
			}
			if (entity == null)
			{
				yield break;
			}
			// 按默认攻速的一定比例提升当前攻速
			float ratio = entity.GetValue(this, 0);
			attr.AttackSpeed = ratio * defaultAttr.attackSpeed + attr.attackSpeed;
			// 为属性添加用于界面显示的标签
			string title = entity.title;
			string desc = entity.GetDesc(this);
			if (attr != null)
			{
				attr.AddLabel(title, 1, desc);
			}
		}
	}
}
