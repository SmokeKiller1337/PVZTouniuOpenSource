using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Entity;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using Strengthen.Entity;
using Touniu.Entity.Body;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant325Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__14 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant325Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__14(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant325Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant != null && plant._animator != null)
				{
					// CrossFade into the bite animation using the attack-speed derived transition
					// duration, then perform the actual bite/target grab.
					// TODO: reconstruct literal — the CrossFade state name is a data pointer.
					plant._animator.CrossFade(BiteAnimName, plant.defaultTransitionDuration);
					plant.BiteAttack();
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__20 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant325Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__20(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant325Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					if (num == 1)
					{
						_003C_003E1__state = -1;
						if (plant == null)
						{
							return false;
						}
						// power window ended
						plant._isPower0 = false;
					}
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null)
				{
					return false;
				}
				// While biting, refresh the bite timer bound from the current attr value.
				if (plant._isBiting)
				{
					if (plant.attr == null)
					{
						return false;
					}
					plant._biteTimer = plant.attr.GetValue(plant, 1);
				}
				if (entity == null)
				{
					return false;
				}
				// Duration of the power's effect, driven by the strengthen value.
				float duration = entity.GetValue(plant, 0);
				plant._isPower0 = true;
				PlantBaseAttr attr = plant.attr;
				if (attr == null)
				{
					return false;
				}
				// Amount by which the attack speed exceeds the configured cap; used as the
				// magnitude of the temporary buff value.
				float overflow = 0f;
				if (attr.attackSpeed <= MaxAttackSpeedCap && MaxAttackSpeedCap != attr.attackSpeed)
				{
					overflow = MaxAttackSpeedCap - attr.attackSpeed;
				}
				List<Game.Entity.ValueEntity> valueList = new List<Game.Entity.ValueEntity>();
				Game.Entity.ValueEntity value = new Game.Entity.ValueEntity();
				value.baseValue = overflow;
				valueList.Add(value);
				if (plant._buffHandler == null)
				{
					return false;
				}
				// TODO: reconstruct — buff id (10) taken from the pseudocode literal.
				plant._buffHandler.AddBuff(Power0BuffId, null, duration, valueList);
				_003C_003E2__current = new WaitForSeconds(duration);
				_003C_003E1__state = 1;
				return true;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__21 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant325Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__21(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant325Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null)
				{
					return false;
				}
				PlantBaseAttr attr = plant.attr;
				if (attr == null || plant.defaultAttr == null)
				{
					return false;
				}
				if (entity == null)
				{
					return false;
				}
				// Increase attack speed by a strengthen-scaled fraction of the default speed.
				float ratio = entity.GetValue(plant, 0);
				attr.AttackSpeed = ratio * plant.defaultAttr.attackSpeed + attr.attackSpeed;
				// Add a descriptive label to the (refreshed) attr for the UI.
				PlantBaseAttr labelAttr = plant.attr;
				string title = entity.title;
				string desc = entity.GetDesc(plant);
				if (labelAttr != null)
				{
					labelAttr.AddLabel(title, 1, desc);
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CSwallowEndCoroutine_003Ed__17 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant325Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CSwallowEndCoroutine_003Ed__17(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant325Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					if (num != 1)
					{
						return false;
					}
					_003C_003E1__state = -1;
					if (plant != null && plant._animator != null)
					{
						// Return to the idle animation and clear the metal / bite visuals.
						// TODO: reconstruct literal — the CrossFade state name is a data pointer.
						plant._animator.CrossFade(SwallowEndAnimName, plant.defaultTransitionDuration);
						if (plant.metalSpriteRenderer != null)
						{
							plant.metalSpriteRenderer.sprite = null;
							plant._isBiting = false;
							plant._isEndBiting = false;
							plant._swallowEndCoroutine = null;
						}
					}
					return false;
				}
				_003C_003E1__state = -1;
				// TODO: reconstruct constant — the swallow-end delay is a global data pointer.
				_003C_003E2__current = new WaitForSeconds(SwallowEndDelay);
				_003C_003E1__state = 1;
				return true;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		// TODO: unresolved animation state names / timing constants that appear as data
		// pointers or globals in the pseudocode. Replace with the real literals when known.
		private const string BiteAnimName = "Bite"; // TODO: reconstruct literal
		private const string SwallowEndAnimName = "Idle"; // TODO: reconstruct literal
		private const float SwallowEndDelay = 0f; // TODO: reconstruct constant
		// Attack-speed cap used to compute the power-0 buff magnitude (pseudocode global).
		private const float MaxAttackSpeedCap = 10f; // TODO: reconstruct constant
		// Buff id applied by the power-0 window (pseudocode literal 10).
		private const int Power0BuffId = 10; // TODO: reconstruct constant

		[Tooltip("金属渲染器")]
		public SpriteRenderer metalSpriteRenderer;

		[Tooltip("吸取音效")]
		public AudioClip biteSound;

		private bool _isBiting;

		private float _biteTimer;

		private bool _isEndBiting;

		private bool _isPower0;

		private Coroutine _swallowEndCoroutine;

		private TweenerCore<Vector3, Vector3, VectorOptions> _metalMoveTween;

		public Action OnBiteAction;

		public override void Reset()
		{
			// The pseudocode body is ICF-folded onto the identical base PlantEntity.Reset
			// implementation (title / defaultAttr / priority / partEntity setup / attr
			// rebuild). Delegating to the base preserves that behavior faithfully.
			base.Reset();
		}

		protected override void Update()
		{
			base.Update();
			// Only tick the bite timer while a bite is in progress and not yet ending.
			if (_isEndBiting || !_isBiting)
			{
				return;
			}
			_biteTimer += Time.deltaTime;
			if (attr == null)
			{
				return;
			}
			// attr value index 1 is the maximum bite/hold duration.
			float maxTime = attr.GetValue(this, 1);
			if (maxTime <= _biteTimer)
			{
				SwallowEnd();
			}
			if (_isPower0)
			{
				SwallowEnd();
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// ICF-folded onto a trivial return; no per-level behavior for level 0.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			// entity.index selects which attr value this upgrade modifies.
			if (entity.index == 0)
			{
				if (attr == null || attr.valueList == null || defaultAttr == null || defaultAttr.valueList == null)
				{
					return;
				}
				Game.Entity.ValueEntity target = attr.valueList[0];
				Game.Entity.ValueEntity defaultValue = defaultAttr.valueList[0];
				if (target == null || defaultValue == null)
				{
					return;
				}
				// baseValue += strengthenValue * defaultBaseValue
				float scale = entity.GetValue(this, 0);
				target.baseValue = scale * defaultValue.baseValue + target.baseValue;
			}
			else if (entity.index == 1)
			{
				if (attr == null || attr.valueList == null || defaultAttr == null || defaultAttr.valueList == null)
				{
					return;
				}
				Game.Entity.ValueEntity target = attr.valueList[1];
				Game.Entity.ValueEntity defaultValue = defaultAttr.valueList[1];
				if (target == null || defaultValue == null)
				{
					return;
				}
				// baseValue -= strengthenValue * defaultBaseValue
				float scale = entity.GetValue(this, 0);
				target.baseValue = target.baseValue - scale * defaultValue.baseValue;
			}
		}

		protected override void Attack()
		{
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__14))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__14(0)
			{
				_003C_003E4__this = this
			};
		}

		public void BiteAttack()
		{
			// TODO: reconstruct - the pseudocode plays the bite sound via
			// AudioManager.Instance.PlayOneShot, resolves the nearest target zombie's body,
			// snaps the metal renderer transform to it, copies its sprite/material, tweens the
			// metal piece via DG.Tweening DOLocalMove using a config-global target position,
			// removes the zombie's helmet and fires OnBiteAction. Several of those inputs are
			// unresolved data pointers (shader property id, material-slot handling, the target
			// world offset config, the target-flag field at +0x158) that cannot be mapped to
			// verified members, so the body is left stubbed rather than referencing invented
			// members.
		}

		public void SwallowEnd()
		{
			// Only start the swallow-end coroutine once.
			if (_swallowEndCoroutine == null)
			{
				_swallowEndCoroutine = StartCoroutine(SwallowEndCoroutine());
			}
		}

		[IteratorStateMachine(typeof(_003CSwallowEndCoroutine_003Ed__17))]
		private IEnumerator SwallowEndCoroutine()
		{
			return new _003CSwallowEndCoroutine_003Ed__17(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			// Can only start a new attack when not already biting and a valid target exists.
			if (!_isBiting)
			{
				TouniuBaseBody target = GetNearestTargetZombie();
				if (target != null)
				{
					return true;
				}
			}
			return false;
		}

		private TouniuBaseBody GetNearestTargetZombie()
		{
			// TODO: reconstruct - the pseudocode reads an attack radius from attr, builds a
			// LayerMask from an unresolved layer-name data pointer, runs Physics2D.OverlapCircleAll
			// around a computed origin, and returns the first hit whose body carries a target flag
			// (bool at offset +0x158). The layer-mask name, the origin helper (virtual slot 0x348)
			// and the target-flag field are unresolved data pointers / unverifiable members, so this
			// is left stubbed rather than referencing invented members.
			return null;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__20))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__20(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__21))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__21(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
