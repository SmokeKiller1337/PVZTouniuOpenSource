using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Bullet.Entity;
using Common.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant15Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__11 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant15Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__11(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant15Entity plant = _003C_003E4__this;
				switch (num)
				{
				default:
					return false;
				case 0:
					_003C_003E1__state = -1;
					// Play the attack animation, then wait one attack interval before firing.
					if (plant != null && plant._animator != null)
					{
						// TODO: attack animation state name is a data pointer in the pseudocode.
						plant._animator.Play(AttackAnimName);
						if (plant.attr != null)
						{
							// WaitForSeconds(attr.attackIntervalTime * AnimTimeScale)
							_003C_003E2__current = new WaitForSeconds(plant.attr.attackIntervalTime * AnimTimeScale);
							_003C_003E1__state = 1;
							return true;
						}
					}
					return false;
				case 1:
					_003C_003E1__state = -1;
					if (plant == null || plant.bulletPosition == null)
					{
						return false;
					}
					// Fire a bullet from the muzzle transform.
					Vector2 spawnPos = plant.bulletPosition.position;
					BulletEntity bullet = plant.CreateBullet(0, spawnPos);
					// TODO: reconstruct - when touniuLevel3 is set the pseudocode fetched a
					// component off the freshly-created bullet and toggled a bool at +0x30 on
					// it. The component type and field are unresolved data pointers, so that
					// per-bullet mutation is dropped here (bullet is still spawned).
					if (plant.touniuLevel3 && bullet == null)
					{
						return false;
					}
					// Ramp the attack speed up by a fixed step, clamped by PlantBaseAttr.AttackSpeed.
					if (plant.attr == null)
					{
						return false;
					}
					if (plant.attr.attackSpeed < MaxAttackSpeedClamp)
					{
						plant.attr.AttackSpeed = plant.attr.attackSpeed + AttackSpeedRampStep;
					}
					return false;
				}
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__13 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant15Entity _003C_003E4__this;

			public StrengthenEntity entity;

			private int _003Ci_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__13(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant15Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					_003Ci_003E5__2 = 0;
				}
				else
				{
					if (num != 1)
					{
						return false;
					}
					_003C_003E1__state = -1;
					if (plant == null)
					{
						return false;
					}
					plant.StartCoroutine(plant.AttackCoroutine());
					_003Ci_003E5__2++;
				}
				if (entity == null)
				{
					return false;
				}
				if ((int)entity.GetValue(plant) <= _003Ci_003E5__2)
				{
					return false;
				}
				// Wait one shot interval, then loop back to fire another AttackCoroutine.
				_003C_003E2__current = new WaitForSeconds(ShotInterval);
				_003C_003E1__state = 1;
				return true;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__14 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant15Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__14(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				if (_003C_003E1__state != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				Plant15Entity plant = _003C_003E4__this;
				// One-shot power: raise the plant's attack by a multiple of its base attack.
				if (plant != null && plant.attr != null && plant.defaultAttr != null && entity != null)
				{
					plant.attr.attack += (int)((float)plant.defaultAttr.attack * entity.GetValue(plant));
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		public int touniuLevel;

		public bool touniuLevel1;

		private float touniuLevel1Timer;

		public bool touniuLevel2;

		public bool touniuLevel3;

		[Tooltip("子弹位置")]
		public Transform bulletPosition;

		// TODO: unresolved global constants used by the reconstructed method bodies. The
		// values below are placeholders (the originals are data pointers in the pseudocode).
		private const string AttackAnimName = "Attack"; // TODO: reconstruct literal
		private const float AnimTimeScale = 1f; // TODO: reconstruct constant (_DAT_18252cb80)
		private const float AttackSpeedRampStep = 0f; // TODO: reconstruct constant (_UNK_18252d11c)
		private const float MaxAttackSpeedClamp = 10f; // _DAT_18252cb30 (PlantBaseAttr max attack speed)
		private const float ShotInterval = 0f; // TODO: reconstruct constant (_DAT_18252ccfc)
		private const float AttackSpeedFrameRate = 30f; // TODO: reconstruct constant (_DAT_18252cf40)
		private const float TouniuLevel1Interval = 0f; // TODO: reconstruct constant (_DAT_18252cb94)
		private const float HeadNumberThreshold = 0f; // TODO: reconstruct constant (_UNK_18252cf24)

		public override void Reset()
		{
			// The pseudocode body is ICF-folded onto the full PlantEntity.Reset logic, i.e.
			// this override re-runs the exact base reset. Delegate to the base implementation.
			base.Reset();
		}

		protected override void Update()
		{
			base.Update();
			// touniuLevel1: periodically bump the plant's attack while the buff is active.
			if (!touniuLevel1)
			{
				return;
			}
			touniuLevel1Timer += Time.deltaTime;
			if (touniuLevel1Timer > TouniuLevel1Interval)
			{
				touniuLevel1Timer = 0f;
				if (attr != null)
				{
					attr.attack++;
				}
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index != 0)
			{
				if (entity.index == 1 && attr != null)
				{
					// Level-2 branch 1: raise attack speed.
					attr.AttackSpeed = attr.AttackSpeed + entity.GetValue(this);
				}
				return;
			}
			// Level-2 branch 0: boost the first bullet's trigger count and reduce base attack.
			if (bulletList == null || bulletList.Count < 1)
			{
				return;
			}
			BulletAttr bulletAttr = bulletList[0];
			if (bulletAttr == null)
			{
				return;
			}
			bulletAttr.triggerCount += entity.GetValue(this);
			if (attr != null && defaultAttr != null)
			{
				attr.attack -= (int)((float)defaultAttr.attack * entity.GetValue(this, 1));
			}
		}

		protected override void Attack()
		{
			if (attr == null || _animator == null)
			{
				return;
			}
			// Drive the attack animation speed from the plant's attack speed, then run the
			// firing coroutine.
			_animator.speed = attr.attackSpeed * AttackSpeedFrameRate;
			// TODO: reconstruct - the pseudocode gated StartCoroutine on a cached delegate
			// (an "is playing" check via a private base member that is not accessible here);
			// that gate is dropped and the coroutine is always started.
			StartCoroutine(AttackCoroutine());
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__11))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__11(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			// touniuLevel3 short-circuits the front-zombie check and always allows attacking.
			if (touniuLevel3)
			{
				return true;
			}
			// TODO: reconstruct - the remaining body performed a Physics2D.RaycastAll in front
			// of the plant against the zombie layer, using several unresolved global config
			// singletons (muzzle offsets, ray length, layer name, level manager) that do not
			// map to known project members. It cannot be reconstructed faithfully, so the
			// non-touniuLevel3 path is left as a conservative stub.
			return false;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__13))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__13(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__14))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__14(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		public override int GetHeadNumber()
		{
			// One head while the plant's attack speed is at/above the threshold, else zero.
			if (attr != null)
			{
				return (attr.attackSpeed >= HeadNumberThreshold) ? 1 : 0;
			}
			return 0;
		}
	}
}
