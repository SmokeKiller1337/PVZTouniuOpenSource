using System;
using System.Collections;
using System.Collections.Generic;
using Bullet.Entity;
using Common.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant15Entity : PlantEntity
	{
		public int touniuLevel;

		public bool touniuLevel1;

		private float touniuLevel1Timer;

		public bool touniuLevel2;

		public bool touniuLevel3;

		[Tooltip("子弹位置")]
		public Transform bulletPosition;

		private const string AttackAnimName = "Attack";
		private const float AnimTimeScale = 1f;
		private const float AttackSpeedRampStep = 0f;
		private const float MaxAttackSpeedClamp = 10f;
		private const float ShotInterval = 0f;
		private const float AttackSpeedFrameRate = 30f;
		private const float TouniuLevel1Interval = 0f;
		private const float HeadNumberThreshold = 0f;

		public override void Reset()
		{
			base.Reset();
		}

		protected override void Update()
		{
			base.Update();
			// touniuLevel1: periodically bump the plant's attack while the buff is active.
			if (!touniuLevel1)
			{
				return;
			}
			touniuLevel1Timer += Time.deltaTime;
			if (touniuLevel1Timer > TouniuLevel1Interval)
			{
				touniuLevel1Timer = 0f;
				if (attr != null)
				{
					attr.attack++;
				}
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index != 0)
			{
				if (entity.index == 1 && attr != null)
				{
					// Level-2 branch 1: raise attack speed.
					attr.AttackSpeed = attr.AttackSpeed + entity.GetValue(this);
				}
				return;
			}
			// Level-2 branch 0: boost the first bullet's trigger count and reduce base attack.
			if (bulletList == null || bulletList.Count < 1)
			{
				return;
			}
			BulletAttr bulletAttr = bulletList[0];
			if (bulletAttr == null)
			{
				return;
			}
			bulletAttr.triggerCount += entity.GetValue(this);
			if (attr != null && defaultAttr != null)
			{
				attr.attack -= (int)((float)defaultAttr.attack * entity.GetValue(this, 1));
			}
		}

		protected override void Attack()
		{
			if (attr == null || _animator == null)
			{
				return;
			}
			// Drive the attack animation speed from the plant's attack speed, then run the
			// firing coroutine.
			_animator.speed = attr.attackSpeed * AttackSpeedFrameRate;
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			// 播放攻击动画，等待一个攻击间隔后开火。
			if (_animator != null)
			{
				_animator.Play(AttackAnimName);
				if (attr != null)
				{
					yield return new WaitForSeconds(attr.attackIntervalTime * AnimTimeScale);
					if (bulletPosition == null)
					{
						yield break;
					}
					// 从枪口位置发射子弹。
					Vector2 spawnPos = bulletPosition.position;
					BulletEntity bullet = CreateBullet(0, spawnPos);
					if (touniuLevel3 && bullet == null)
					{
						yield break;
					}
					if (attr == null)
					{
						yield break;
					}
					// 逐步提升攻击速度，受上限约束。
					if (attr.attackSpeed < MaxAttackSpeedClamp)
					{
						attr.AttackSpeed = attr.attackSpeed + AttackSpeedRampStep;
					}
				}
			}
		}

		protected override bool CheckAttack()
		{
			// touniuLevel3 short-circuits the front-zombie check and always allows attacking.
			if (touniuLevel3)
			{
				return true;
			}
			return false;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 按强化数值决定连发次数，每次间隔 ShotInterval 触发一次攻击协程。
			int i = 0;
			while (entity != null && (int)entity.GetValue(this) > i)
			{
				yield return new WaitForSeconds(ShotInterval);
				StartCoroutine(AttackCoroutine());
				i++;
			}
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			// 一次性强化：按基础攻击的倍数提升当前攻击力。
			if (attr != null && defaultAttr != null && entity != null)
			{
				attr.attack += (int)((float)defaultAttr.attack * entity.GetValue(this));
			}
			yield break;
		}

		public override int GetHeadNumber()
		{
			// One head while the plant's attack speed is at/above the threshold, else zero.
			if (attr != null)
			{
				return (attr.attackSpeed >= HeadNumberThreshold) ? 1 : 0;
			}
			return 0;
		}
	}
}
