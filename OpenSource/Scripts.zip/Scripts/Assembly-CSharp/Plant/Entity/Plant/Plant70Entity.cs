using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Entity;
using Game.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant70Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__10 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant70Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__10(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct — state 0 cross-fades the plant animator into the "bite"
				// state (Animator.CrossFade(<state>, defaultTransitionDuration)). The target
				// animator-state name is a data pointer in the pseudocode that cannot be
				// resolved to its literal, so the animation trigger is dropped and the
				// coroutine completes immediately.
				int num = _003C_003E1__state;
				if (num == 0)
				{
					_003C_003E1__state = -1;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__14 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant70Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__14(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant70Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					if (num != 1)
					{
						return false;
					}
					_003C_003E1__state = -1;
					if (plant == null)
					{
						return false;
					}
					// _isPower0 (0x131) cleared once the buff duration elapses.
					plant._isPower0 = false;
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null)
				{
					return false;
				}
				// While mid-bite, refresh the bite timer target from attr value #1.
				if (plant._isBiting)
				{
					if (plant.attr == null)
					{
						return false;
					}
					plant._biteTimer = plant.attr.GetValue(plant, 1);
				}
				if (entity == null)
				{
					return false;
				}
				// Buff duration is the strengthen value #0.
				float duration = entity.GetValue(plant, 0);
				PlantBaseAttr attr = plant.attr;
				plant._isPower0 = true;
				if (attr == null)
				{
					return false;
				}
				// Compute the attack-speed boost so the plant is capped at the max speed.
				// TODO: reconstruct — the cap (10f below) is an unresolved global constant
				// (_DAT_18252cb88); it matches PlantBaseAttr's internal MaxAttackSpeed.
				float boost = 0f;
				if (attr.attackSpeed <= MaxAttackSpeedCap && MaxAttackSpeedCap != attr.attackSpeed)
				{
					boost = MaxAttackSpeedCap - attr.attackSpeed;
				}
				List<ValueEntity> valueList = new List<ValueEntity>();
				ValueEntity value = new ValueEntity();
				value.baseValue = boost;
				valueList.Add(value);
				if (plant._buffHandler == null)
				{
					return false;
				}
				// Apply the attack-speed buff (id 10) for the computed duration.
				plant._buffHandler.AddBuff(10, null, duration, valueList);
				_003C_003E2__current = new WaitForSeconds(duration);
				_003C_003E1__state = 1;
				return true;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__15 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant70Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__15(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant70Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null)
				{
					return false;
				}
				PlantBaseAttr attr = plant.attr;
				if (attr == null)
				{
					return false;
				}
				PlantBaseAttr defaultAttr = plant.defaultAttr;
				if (defaultAttr == null)
				{
					return false;
				}
				if (entity == null)
				{
					return false;
				}
				// Permanently raise the attack speed by a strengthen-scaled amount of the
				// plant's default attack speed, then record a label describing the boost.
				attr.AttackSpeed = entity.GetValue(plant, 0) * defaultAttr.attackSpeed + attr.attackSpeed;
				attr.AddLabel(entity.title, 1, entity.GetDesc(plant));
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("咬击音效")]
		public AudioClip biteSound;

		private bool _isBiting;

		private float _biteTimer;

		private bool _isEndBiting;

		private bool _isPower0;

		// TODO: reconstruct — attack-speed cap used by OnUsePower0; unresolved global
		// constant (_DAT_18252cb88). Matches PlantBaseAttr's internal MaxAttackSpeed (10f).
		private const float MaxAttackSpeedCap = 10f;

		public override void Reset()
		{
			// ICF-folded onto the generic PlantEntity.Reset body (card lookup, attr
			// construction, place-type / sleep setup). The override adds nothing beyond
			// the base implementation.
			base.Reset();
		}

		protected override void Update()
		{
			base.Update();
			// Only tick the bite windup while mid-bite and before the end has fired.
			if (_isEndBiting || !_isBiting)
			{
				return;
			}
			_biteTimer += Time.deltaTime;
			if (attr == null)
			{
				return;
			}
			// When the bite windup reaches the attr value #1 threshold, mark the bite as
			// ended.
			// TODO: reconstruct — the original also cross-faded the animator into the
			// swallow/end state here; the target animator-state name is a data pointer in
			// the pseudocode that cannot be resolved to a literal, so the trigger is
			// dropped.
			if (attr.GetValue(this, 1) <= _biteTimer)
			{
				_isEndBiting = true;
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			// index 0: increase attr value #0 by a strengthen-scaled amount of the default.
			if (entity.index == 0)
			{
				if (attr == null || attr.valueList == null)
				{
					return;
				}
				ValueEntity current = attr.valueList[0];
				if (current == null)
				{
					return;
				}
				if (defaultAttr == null || defaultAttr.valueList == null)
				{
					return;
				}
				ValueEntity def = defaultAttr.valueList[0];
				if (def == null)
				{
					return;
				}
				current.baseValue = entity.GetValue(this, 0) * def.baseValue + current.baseValue;
			}
			// index 1: decrease attr value #1 by a strengthen-scaled amount of the default.
			else if (entity.index == 1)
			{
				if (attr == null || attr.valueList == null)
				{
					return;
				}
				ValueEntity current = attr.valueList[1];
				if (current == null)
				{
					return;
				}
				if (defaultAttr == null || defaultAttr.valueList == null)
				{
					return;
				}
				ValueEntity def = defaultAttr.valueList[1];
				if (def == null)
				{
					return;
				}
				current.baseValue -= entity.GetValue(this, 0) * def.baseValue;
			}
		}

		protected override void Attack()
		{
			// Kick off the bite attack coroutine.
			StartCoroutine(AttackCoroutine());
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__10))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__10(0)
			{
				_003C_003E4__this = this
			};
		}

		public void BiteAttack()
		{
			// TODO: reconstruct — the original raycasts forward from a screen/scene manager
			// singleton to find zombies in bite range and applies damage via a zombie
			// virtual-slot call, gated on zombie state ids and buff flags. It depends on
			// several unresolved global config pointers (muzzle offsets, layer masks,
			// camera positions) and animator-state name pointers that cannot be recovered,
			// so the method is left as a no-op stub rather than inventing members.
		}

		public void SwallowEnd()
		{
			// Clear the bite state flags at the end of a swallow.
			// TODO: reconstruct — the original also cross-faded the animator back to the
			// idle/attack state; that animator-state name is a data pointer in the
			// pseudocode and cannot be resolved to a literal, so the trigger is dropped.
			_isBiting = false;
			_isEndBiting = false;
		}

		protected override bool CheckAttack()
		{
			// TODO: reconstruct — the original raycasts forward (using scene-manager
			// singleton positions, unresolved muzzle-offset/layer-mask config globals) to
			// detect an eatable zombie within range and returns whether one was hit. It
			// depends on global data pointers that cannot be recovered, so the method is
			// left as a stub returning false rather than inventing members.
			return false;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__14))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__14(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__15))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__15(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
