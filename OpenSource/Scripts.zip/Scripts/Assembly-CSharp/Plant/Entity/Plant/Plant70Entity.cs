using System.Collections;
using System.Collections.Generic;
using Common.Entity;
using Game.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant70Entity : PlantEntity
	{
		[Tooltip("咬击音效")]
		public AudioClip biteSound;

		private bool _isBiting;

		private float _biteTimer;

		private bool _isEndBiting;

		private bool _isPower0;

		private const float MaxAttackSpeedCap = 10f;

		public override void Reset()
		{
			base.Reset();
		}

		protected override void Update()
		{
			base.Update();
			// 仅在咬击途中且未触发结束时推进咬击计时
			if (_isEndBiting || !_isBiting)
			{
				return;
			}
			_biteTimer += Time.deltaTime;
			if (attr == null)
			{
				return;
			}
			if (attr.GetValue(this, 1) <= _biteTimer)
			{
				_isEndBiting = true;
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			// index 0：按强化系数乘默认值提升属性值 #0
			if (entity.index == 0)
			{
				if (attr == null || attr.valueList == null)
				{
					return;
				}
				ValueEntity current = attr.valueList[0];
				if (current == null)
				{
					return;
				}
				if (defaultAttr == null || defaultAttr.valueList == null)
				{
					return;
				}
				ValueEntity def = defaultAttr.valueList[0];
				if (def == null)
				{
					return;
				}
				current.baseValue = entity.GetValue(this, 0) * def.baseValue + current.baseValue;
			}
			// index 1：按强化系数乘默认值降低属性值 #1
			else if (entity.index == 1)
			{
				if (attr == null || attr.valueList == null)
				{
					return;
				}
				ValueEntity current = attr.valueList[1];
				if (current == null)
				{
					return;
				}
				if (defaultAttr == null || defaultAttr.valueList == null)
				{
					return;
				}
				ValueEntity def = defaultAttr.valueList[1];
				if (def == null)
				{
					return;
				}
				current.baseValue -= entity.GetValue(this, 0) * def.baseValue;
			}
		}

		protected override void Attack()
		{
			// 启动咬击攻击协程
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			yield break;
		}

		public void BiteAttack()
		{
		}

		public void SwallowEnd()
		{
			_isBiting = false;
			_isEndBiting = false;
		}

		protected override bool CheckAttack()
		{
			return false;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			if (this == null)
			{
				yield break;
			}
			// 咬击途中时，从属性值 #1 刷新咬击计时目标
			if (_isBiting)
			{
				if (attr == null)
				{
					yield break;
				}
				_biteTimer = attr.GetValue(this, 1);
			}
			if (entity == null)
			{
				yield break;
			}
			// 增益持续时间取强化值 #0
			float duration = entity.GetValue(this, 0);
			PlantBaseAttr baseAttr = attr;
			_isPower0 = true;
			if (baseAttr == null)
			{
				yield break;
			}
			float boost = 0f;
			if (baseAttr.attackSpeed <= MaxAttackSpeedCap && MaxAttackSpeedCap != baseAttr.attackSpeed)
			{
				boost = MaxAttackSpeedCap - baseAttr.attackSpeed;
			}
			List<ValueEntity> valueList = new List<ValueEntity>();
			ValueEntity value = new ValueEntity();
			value.baseValue = boost;
			valueList.Add(value);
			if (_buffHandler == null)
			{
				yield break;
			}
			// 施加攻速增益（id 10），持续计算出的时长
			_buffHandler.AddBuff(10, null, duration, valueList);
			yield return new WaitForSeconds(duration);
			if (this == null)
			{
				yield break;
			}
			// 增益时间结束后清除 _isPower0
			_isPower0 = false;
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			if (this == null)
			{
				yield break;
			}
			PlantBaseAttr baseAttr = attr;
			if (baseAttr == null)
			{
				yield break;
			}
			PlantBaseAttr baseDefaultAttr = defaultAttr;
			if (baseDefaultAttr == null)
			{
				yield break;
			}
			if (entity == null)
			{
				yield break;
			}
			// 永久提升攻速：按强化系数乘默认攻速后叠加，并记录说明标签
			baseAttr.AttackSpeed = entity.GetValue(this, 0) * baseDefaultAttr.attackSpeed + baseAttr.attackSpeed;
			baseAttr.AddLabel(entity.title, 1, entity.GetDesc(this));
		}
	}
}
