using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Audio.Manager;
using Bullet.Entity;
using Bullet.Part.Common;
using Common.Entity;
using Land.Entity;
using Level.Util;
using Touniu.Entity.Say.Fixed.Area4.Level4;
using UnityEngine;
using Zombie.Entity;
using Zombie.Entity.Data;

namespace Plant.Entity.Plant
{
	public class Plant275Entity : Plant270Entity
	{
		private float _checkWindTimer;

		private float _riseCheckTimer;

		private const float CheckInterval = 1f;
		private const float GroundFireDelayScale = 1f;
		private const float HighFireDelayScale = 1f;
		private const float RiseTransitionTime = 0f;
		private const float WindAttackSpeed1 = 0f;
		private const float WindAttackSpeed2 = 0f;
		private const float WindAttackSpeed3 = 0f;
		private const float WindSpeedEpsilon = 0.001f;

		private const string GroundAttackAnimName = "Attack";
		private const string RiseAttackAnimName = "AttackRise";
		private const string RiseUpAnimName = "RiseUp";
		private const string RiseDownAnimName = "RiseDown";

		protected override void Update()
		{
			base.Update();
			// While not mid-transition, periodically re-evaluate whether we should rise/fall.
			if (!IsRising)
			{
				_riseCheckTimer += Time.deltaTime;
				if (_riseCheckTimer > CheckInterval)
				{
					_riseCheckTimer = 0f;
					StartCoroutine(CheckRise());
				}
			}
			// Periodically sample the level's wind controller and set attack speed accordingly.
			_checkWindTimer += Time.deltaTime;
			if (_checkWindTimer > CheckInterval)
			{
				_checkWindTimer = 0f;
				Level44WindController windController = UnityEngine.Object.FindObjectOfType<Level44WindController>();
				if (windController != null)
				{
					int windLevel = windController.windLevel;
					float targetAttackSpeed = WindAttackSpeed1;
					if (windLevel != 1)
					{
						targetAttackSpeed = WindAttackSpeed2;
						if (windLevel != 2)
						{
							targetAttackSpeed = 0f;
							if (windLevel == 3)
							{
								targetAttackSpeed = WindAttackSpeed3;
							}
						}
					}
					if (attr != null)
					{
						if (Mathf.Abs(attr.attackSpeed - targetAttackSpeed) <= WindSpeedEpsilon)
						{
							return;
						}
						attr.AttackSpeed = targetAttackSpeed;
					}
				}
			}
		}

		protected override IEnumerator CheckRise()
		{
			if (this == null)
			{
				yield break;
			}
			IsRising = true;
			if (IsHasBalloonRow() && !isRise)
			{
				// 出现气球行且当前在地面：升空。
				AudioManager audioManager = AudioManager.Instance;
				if (audioManager != null)
				{
					audioManager.PlayOneShot(growSound);
					isRise = true;
					if (_animator != null)
					{
						_animator.Play(RiseUpAnimName);
						yield return new WaitForSeconds(RiseTransitionTime);
						if (this != null)
						{
							IsRising = false;
						}
						yield break;
					}
				}
				if (this != null)
				{
					IsRising = false;
				}
				yield break;
			}
			if (IsHasBalloonRow())
			{
				if (this != null)
				{
					IsRising = false;
				}
				yield break;
			}
			if (isRise)
			{
				// 升空状态下气球行消失：落回地面。
				AudioManager audioManager2 = AudioManager.Instance;
				if (audioManager2 != null)
				{
					audioManager2.PlayOneShot(decreaseSound);
					isRise = false;
					if (_animator != null)
					{
						_animator.Play(RiseDownAnimName);
						yield return new WaitForSeconds(RiseTransitionTime);
						if (this != null)
						{
							IsRising = false;
						}
						yield break;
					}
				}
				if (this != null)
				{
					IsRising = false;
				}
				yield break;
			}
			IsRising = false;
		}

		protected override IEnumerator AttackCoroutine()
		{
			if (this == null)
			{
				yield break;
			}
			// 升空过渡中不开火。
			if (IsRising)
			{
				yield break;
			}
			if (!isRise)
			{
				// 地面射击：播放普通攻击动画，按地面开火延迟等待攻击间隔。
				if (_animator != null)
				{
					_animator.Play(GroundAttackAnimName);
					if (attr != null)
					{
						yield return new WaitForSeconds(attr.attackIntervalTime * GroundFireDelayScale);
						// 从 bulletPosition 发射地面子弹并设为追踪。
						if (this == null || bulletPosition == null)
						{
							yield break;
						}
						BulletEntity groundBullet = CreateBullet(0, bulletPosition.position);
						if (groundBullet == null)
						{
							yield break;
						}
						MovePart groundMove = groundBullet.GetComponent<MovePart>();
						if (groundMove != null)
						{
							groundMove.isTrack = true;
						}
					}
				}
			}
			else
			{
				// 升空射击：播放升空攻击动画，按高空开火延迟等待攻击间隔。
				if (_animator != null)
				{
					_animator.Play(RiseAttackAnimName);
					if (attr != null)
					{
						yield return new WaitForSeconds(attr.attackIntervalTime * HighFireDelayScale);
						// 从 bulletPosition1 发射高空子弹并设为追踪。
						if (this == null || bulletPosition1 == null)
						{
							yield break;
						}
						BulletEntity highBullet = CreateBullet(1, bulletPosition1.position);
						if (highBullet == null)
						{
							yield break;
						}
						MovePart highMove = highBullet.GetComponent<MovePart>();
						if (highMove != null)
						{
							highMove.isTrack = true;
						}
					}
				}
			}
		}

		protected override bool CheckAttack()
		{
			List<ZombieEntity> enemyZombies = LevelUtils.GetLandEnemyZombieList();
			if (enemyZombies == null)
			{
				return false;
			}
			if (enemyZombies.Count < 1)
			{
				// No enemy zombies on the lawn: only keep attacking if we are risen and a
				// balloon row still exists (to keep popping balloons).
				if (!IsHasBalloonRow() || !isRise)
				{
					return false;
				}
			}
			return true;
		}

		private bool IsHasBalloonRow(int row = -1)
		{
			// A balloon row exists when any Zombie160Entity currently carrying a balloon is
			// present (optionally restricted to the given row).
			List<ZombieEntity> zombies = LevelUtils.GetLandZombieList();
			if (zombies == null)
			{
				return false;
			}
			return zombies.Where(delegate(ZombieEntity zombie)
			{
				if (row != -1)
				{
					LandEntity land = zombie.CurrentLandEntity;
					if (land != null && row != land.rowId)
					{
						return false;
					}
				}
				Zombie160Entity balloonZombie = zombie as Zombie160Entity;
				return balloonZombie != null && balloonZombie.isHasBalloon;
			}).ToList().Count > 0;
		}
	}
}
