using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using Audio.Manager;
using Bullet.Entity;
using Bullet.Part.Common;
using Common.Entity;
using Land.Entity;
using Level.Util;
using Touniu.Entity.Say.Fixed.Area4.Level4;
using UnityEngine;
using Zombie.Entity;
using Zombie.Entity.Data;

namespace Plant.Entity.Plant
{
	public class Plant275Entity : Plant270Entity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__3 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant275Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__3(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant275Entity plant = _003C_003E4__this;
				switch (num)
				{
				default:
					return false;
				case 0:
					_003C_003E1__state = -1;
					if (plant == null)
					{
						return false;
					}
					// IsRising guard: if the plant is currently rising, skip the shot.
					if (plant.IsRising)
					{
						return false;
					}
					if (!plant.isRise)
					{
						// Ground shot: play the normal attack animation and wait for the
						// per-attack interval scaled by the ground-fire delay constant.
						if (plant._animator != null)
						{
							plant._animator.Play(GroundAttackAnimName);
							if (plant.attr != null)
							{
								_003C_003E2__current = new WaitForSeconds(plant.attr.attackIntervalTime * GroundFireDelayScale);
								_003C_003E1__state = 2;
								return true;
							}
						}
					}
					else
					{
						// Risen (balloon) shot: play the risen attack animation and wait for
						// the per-attack interval scaled by the high-fire delay constant.
						if (plant._animator != null)
						{
							plant._animator.Play(RiseAttackAnimName);
							if (plant.attr != null)
							{
								_003C_003E2__current = new WaitForSeconds(plant.attr.attackIntervalTime * HighFireDelayScale);
								_003C_003E1__state = 1;
								return true;
							}
						}
					}
					return false;
				case 1:
				{
					// Fire the high bullet from bulletPosition1 and make it a tracking bullet.
					_003C_003E1__state = -1;
					if (plant == null || plant.bulletPosition1 == null)
					{
						return false;
					}
					BulletEntity highBullet = plant.CreateBullet(1, plant.bulletPosition1.position);
					if (highBullet == null)
					{
						return false;
					}
					MovePart highMove = highBullet.GetComponent<MovePart>();
					if (highMove != null)
					{
						highMove.isTrack = true;
					}
					return false;
				}
				case 2:
				{
					// Fire the ground bullet from bulletPosition and make it a tracking bullet.
					_003C_003E1__state = -1;
					if (plant == null || plant.bulletPosition == null)
					{
						return false;
					}
					BulletEntity groundBullet = plant.CreateBullet(0, plant.bulletPosition.position);
					if (groundBullet == null)
					{
						return false;
					}
					MovePart groundMove = groundBullet.GetComponent<MovePart>();
					if (groundMove != null)
					{
						groundMove.isTrack = true;
					}
					return false;
				}
				}
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CCheckRise_003Ed__2 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant275Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CCheckRise_003Ed__2(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant275Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					if (num != 1 && num != 2)
					{
						return false;
					}
					_003C_003E1__state = -1;
					if (plant != null)
					{
						plant.IsRising = false;
					}
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null)
				{
					return false;
				}
				plant.IsRising = true;
				if (plant.IsHasBalloonRow() && !plant.isRise)
				{
					// A balloon row appeared while grounded: rise up.
					AudioManager audioManager = AudioManager.Instance;
					if (audioManager != null)
					{
						audioManager.PlayOneShot(plant.growSound);
						plant.isRise = true;
						if (plant._animator != null)
						{
							plant._animator.Play(RiseUpAnimName);
							_003C_003E2__current = new WaitForSeconds(RiseTransitionTime);
							_003C_003E1__state = 1;
							return true;
						}
					}
					if (plant != null)
					{
						plant.IsRising = false;
					}
					return false;
				}
				if (plant.IsHasBalloonRow())
				{
					if (plant != null)
					{
						plant.IsRising = false;
					}
					return false;
				}
				if (plant.isRise)
				{
					// No balloon row remains while risen: come back down.
					AudioManager audioManager2 = AudioManager.Instance;
					if (audioManager2 != null)
					{
						audioManager2.PlayOneShot(plant.decreaseSound);
						plant.isRise = false;
						if (plant._animator != null)
						{
							plant._animator.Play(RiseDownAnimName);
							_003C_003E2__current = new WaitForSeconds(RiseTransitionTime);
							_003C_003E1__state = 2;
							return true;
						}
					}
					if (plant != null)
					{
						plant.IsRising = false;
					}
					return false;
				}
				plant.IsRising = false;
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		private float _checkWindTimer;

		// The base rise throttle timer (Plant270Entity._riseTimer @0x144) is private to the
		// base type and exposes no accessor, so the derived Update() cannot touch it. A local
		// throttle field is used here instead to preserve the once-per-interval CheckRise call.
		private float _riseCheckTimer;

		// TODO: unresolved timer / animation-state / fire-delay constants below. In the
		// pseudocode these are global data pointers (_DAT_* / uRam*) that could not be
		// resolved to their literal values or Animator state names. Replace with the real
		// values when known; they are placed here so the reconstructed method bodies compile.
		private const float CheckInterval = 1f; // TODO: reconstruct constant (_DAT_18252cb64)
		private const float GroundFireDelayScale = 1f; // TODO: reconstruct constant (_DAT_18252cd00)
		private const float HighFireDelayScale = 1f; // TODO: reconstruct constant (_DAT_18252cd08)
		private const float RiseTransitionTime = 0f; // TODO: reconstruct constant (_DAT_18252cb24)
		private const float WindAttackSpeed1 = 0f; // TODO: reconstruct constant (_DAT_18252cd0c)
		private const float WindAttackSpeed2 = 0f; // TODO: reconstruct constant (_DAT_18252ce84)
		private const float WindAttackSpeed3 = 0f; // TODO: reconstruct constant (_DAT_18252cb8c)
		private const float WindSpeedEpsilon = 0.001f; // TODO: reconstruct constant (_DAT_18252cb78)

		private const string GroundAttackAnimName = "Attack"; // TODO: reconstruct literal
		private const string RiseAttackAnimName = "AttackRise"; // TODO: reconstruct literal
		private const string RiseUpAnimName = "RiseUp"; // TODO: reconstruct literal
		private const string RiseDownAnimName = "RiseDown"; // TODO: reconstruct literal

		protected override void Update()
		{
			base.Update();
			// While not mid-transition, periodically re-evaluate whether we should rise/fall.
			if (!IsRising)
			{
				_riseCheckTimer += Time.deltaTime;
				if (_riseCheckTimer > CheckInterval)
				{
					_riseCheckTimer = 0f;
					StartCoroutine(CheckRise());
				}
			}
			// Periodically sample the level's wind controller and set attack speed accordingly.
			_checkWindTimer += Time.deltaTime;
			if (_checkWindTimer > CheckInterval)
			{
				_checkWindTimer = 0f;
				Level44WindController windController = UnityEngine.Object.FindObjectOfType<Level44WindController>();
				if (windController != null)
				{
					int windLevel = windController.windLevel;
					float targetAttackSpeed = WindAttackSpeed1;
					if (windLevel != 1)
					{
						targetAttackSpeed = WindAttackSpeed2;
						if (windLevel != 2)
						{
							targetAttackSpeed = 0f;
							if (windLevel == 3)
							{
								targetAttackSpeed = WindAttackSpeed3;
							}
						}
					}
					if (attr != null)
					{
						if (Mathf.Abs(attr.attackSpeed - targetAttackSpeed) <= WindSpeedEpsilon)
						{
							return;
						}
						attr.AttackSpeed = targetAttackSpeed;
					}
				}
			}
		}

		[IteratorStateMachine(typeof(_003CCheckRise_003Ed__2))]
		protected override IEnumerator CheckRise()
		{
			return new _003CCheckRise_003Ed__2(0)
			{
				_003C_003E4__this = this
			};
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__3))]
		protected override IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__3(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			List<ZombieEntity> enemyZombies = LevelUtils.GetLandEnemyZombieList();
			if (enemyZombies == null)
			{
				return false;
			}
			if (enemyZombies.Count < 1)
			{
				// No enemy zombies on the lawn: only keep attacking if we are risen and a
				// balloon row still exists (to keep popping balloons).
				if (!IsHasBalloonRow() || !isRise)
				{
					return false;
				}
			}
			return true;
		}

		private bool IsHasBalloonRow(int row = -1)
		{
			// A balloon row exists when any Zombie160Entity currently carrying a balloon is
			// present (optionally restricted to the given row).
			List<ZombieEntity> zombies = LevelUtils.GetLandZombieList();
			if (zombies == null)
			{
				return false;
			}
			return zombies.Where(delegate(ZombieEntity zombie)
			{
				if (row != -1)
				{
					LandEntity land = zombie.CurrentLandEntity;
					if (land != null && row != land.rowId)
					{
						return false;
					}
				}
				Zombie160Entity balloonZombie = zombie as Zombie160Entity;
				return balloonZombie != null && balloonZombie.isHasBalloon;
			}).ToList().Count > 0;
		}
	}
}
