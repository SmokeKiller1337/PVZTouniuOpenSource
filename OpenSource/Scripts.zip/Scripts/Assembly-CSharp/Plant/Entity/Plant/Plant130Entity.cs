using System;
using System.Collections;
using System.Collections.Generic;
using Audio.Manager;
using Common.Entity;
using Game.Entity;
using Game.Util;
using NoSLoofah.BuffSystem;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant130Entity : PlantEntity
	{
		[Tooltip("魅惑特效")]
		public EffectEntity effectEntity;

		[Tooltip("魅惑音效")]
		public AudioClip hypnosisSound;

		private ZombieEntity _targetZombie;

		private bool _flag;

		private bool _isPower0;

		private const int HypnosisBuffId = 7; // buff id passed to BuffHandler.AddBuff
		private const float HypnosisBuffDuration = -1f;
		private const float HypnosisPositionOffsetX = 0f;

		public override void Reset()
		{
			base.Reset();
			_targetZombie = null;
			_flag = false;
			if (partEntity == null)
			{
				return;
			}
			// Only auto-fire the power on reset while the plant is awake.
			if (partEntity.isSleeping)
			{
				return;
			}
			if (!IsHasCardSlot)
			{
				return;
			}
			CardEntity card = CardEntity;
			if (card == null)
			{
				return;
			}
			// If the card's power is ready, trigger it immediately.
			if (card.IsAvailablePower())
			{
				UsePower();
			}
		}

		public override void HitEat(float value, ZombieEntity zombieEntity)
		{
			// Take the bite damage through the normal hit pipeline first.
			Hit(value);
			if (partEntity == null)
			{
				return;
			}
			// Charm logic is suppressed while the plant sleeps.
			if (partEntity.isSleeping)
			{
				return;
			}
			if (zombieEntity == null)
			{
				return;
			}
			// Boss zombies (type 2) can't be charmed, and only charm one zombie at a time.
			if ((int)zombieEntity.type != 2 && !_flag)
			{
				_flag = true;
				_targetZombie = zombieEntity;
				StartCoroutine(Explosion());
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
		}

		protected override void Attack()
		{
			base.Attack();
		}

		protected override bool CheckAttack()
		{
			return false;
		}

		public IEnumerator Explosion()
		{
			// 只有存在被捕获的目标僵尸时才触发魅惑效果
			if (_targetZombie == null)
			{
				yield break;
			}
			ZombieEntity zombie = _targetZombie;
			if (zombie == null)
			{
				yield break;
			}
			Transform zombieTransform = zombie.transform;
			if (zombieTransform == null)
			{
				yield break;
			}
			// 在僵尸位置生成魅惑特效并播放魅惑音效
			Vector3 position = zombieTransform.position;
			GameUtils.CreateEffect(effectEntity, position, Quaternion.identity);
			if (AudioManager.Instance != null)
			{
				AudioManager.Instance.PlayOneShot(hypnosisSound);
			}
			// 施加魅惑buff，施法来源为本植物
			BuffHandler buffHandler = zombie.BuffHandler;
			if (buffHandler == null)
			{
				yield break;
			}
			buffHandler.AddBuff(HypnosisBuffId, gameObject, HypnosisBuffDuration);
			// 轻微位移僵尸，使被魅惑的单位在视觉上换边
			Vector3 shifted = zombie.transform.position;
			zombie.transform.position = new Vector3(shifted.x - HypnosisPositionOffsetX, shifted.y, shifted.z);
			// 二级强化槽0：按僵尸满血值缩放一个数值
			StrengthenEntity healthStrengthen = GetStrengthenEntity(2, 0);
			if (healthStrengthen != null)
			{
				if (zombie.defaultAttr == null)
				{
					yield break;
				}
				float baseHealth = zombie.defaultAttr.currentHealth;
				float ratio = healthStrengthen.GetValue(this, 0);
				_ = ratio * baseHealth;
			}
			// 二级强化槽1：提升僵尸的攻击速度
			StrengthenEntity attackSpeedStrengthen = GetStrengthenEntity(2, 1);
			if (attackSpeedStrengthen != null)
			{
				if (zombie.attr == null || zombie.defaultAttr == null)
				{
					yield break;
				}
				float currentAttackSpeed = zombie.attr.attackSpeed;
				float baseAttackSpeed = zombie.defaultAttr.attackSpeed;
				float speedRatio = attackSpeedStrengthen.GetValue(this, 0);
				zombie.attr.AttackSpeed = speedRatio * baseAttackSpeed + currentAttackSpeed;
			}
			// 通过 power0 触发时，额外应用三级强化值
			if (_isPower0)
			{
				StrengthenEntity powerStrengthen = GetStrengthenEntity(3, 0);
				if (powerStrengthen == null)
				{
					yield break;
				}
				float powerValue = powerStrengthen.GetValue(this, 0);
				_ = powerValue;
			}
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			if (this == null)
			{
				yield break;
			}
			PlantBaseAttr baseAttr = attr;
			// 标记本次激活来自 power0，使 Explosion 应用三级强化值
			_isPower0 = true;
			if (entity != null && baseAttr != null)
			{
				// 在植物 attr 上登记描述该 power 的强化标签
				baseAttr.AddLabel(entity.title, 0, entity.GetDesc(this));
			}
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			if (this == null)
			{
				yield break;
			}
			// Power1 将卡片冷却计时清零
			if (!IsHasCardSlot)
			{
				yield break;
			}
			CardEntity card = CardEntity;
			if (card == null || card.attr == null)
			{
				yield break;
			}
			float timer = card.attr.cooldownTimer;
			CardEntity card2 = CardEntity;
			if (card2 == null || card2.attr == null)
			{
				yield break;
			}
			card.attr.cooldownTimer = timer - card2.attr.cooldownTimer;
		}
	}
}
