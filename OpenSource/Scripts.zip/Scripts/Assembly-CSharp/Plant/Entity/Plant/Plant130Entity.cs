using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Audio.Manager;
using Common.Entity;
using Game.Entity;
using Game.Util;
using NoSLoofah.BuffSystem;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant130Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CExplosion_003Ed__11 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant130Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CExplosion_003Ed__11(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant130Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				// The explosion/charm effect only fires when there is a captured target zombie.
				if (plant._targetZombie == null)
				{
					return false;
				}
				ZombieEntity zombie = plant._targetZombie;
				if (zombie == null)
				{
					return false;
				}
				Transform zombieTransform = zombie.transform;
				if (zombieTransform == null)
				{
					return false;
				}
				// Spawn the charm effect and play the charm sound at the zombie's position.
				Vector3 position = zombieTransform.position;
				GameUtils.CreateEffect(plant.effectEntity, position, Quaternion.identity);
				if (AudioManager.Instance != null)
				{
					AudioManager.Instance.PlayOneShot(plant.hypnosisSound);
				}
				// Apply the charm buff, casting from this plant's game object.
				BuffHandler buffHandler = zombie.BuffHandler;
				if (buffHandler == null)
				{
					return false;
				}
				buffHandler.AddBuff(HypnosisBuffId, plant.gameObject, HypnosisBuffDuration);
				// Nudge the zombie slightly so the charmed unit visibly shifts side.
				Vector3 shifted = zombie.transform.position;
				zombie.transform.position = new Vector3(shifted.x - HypnosisPositionOffsetX, shifted.y, shifted.z);
				// Level-2 strengthen slot 0: scale a value by the zombie's full health.
				StrengthenEntity healthStrengthen = plant.GetStrengthenEntity(2, 0);
				if (healthStrengthen != null)
				{
					if (zombie.defaultAttr == null)
					{
						return false;
					}
					float baseHealth = zombie.defaultAttr.currentHealth;
					float ratio = healthStrengthen.GetValue(plant, 0);
					// TODO: reconstruct - the decompile then invoked a ZombieEntity virtual
					// (vtable offset 0x268) with (ratio * baseHealth). That method's member
					// name is not exposed by the skeleton, so the application is dropped.
					_ = ratio * baseHealth;
				}
				// Level-2 strengthen slot 1: boost the zombie's attack speed.
				StrengthenEntity attackSpeedStrengthen = plant.GetStrengthenEntity(2, 1);
				if (attackSpeedStrengthen != null)
				{
					if (zombie.attr == null || zombie.defaultAttr == null)
					{
						return false;
					}
					float currentAttackSpeed = zombie.attr.attackSpeed;
					float baseAttackSpeed = zombie.defaultAttr.attackSpeed;
					float speedRatio = attackSpeedStrengthen.GetValue(plant, 0);
					zombie.attr.AttackSpeed = speedRatio * baseAttackSpeed + currentAttackSpeed;
				}
				// When triggered via power 0, also apply the level-3 strengthen value.
				if (plant._isPower0)
				{
					StrengthenEntity powerStrengthen = plant.GetStrengthenEntity(3, 0);
					if (powerStrengthen == null)
					{
						return false;
					}
					float powerValue = powerStrengthen.GetValue(plant, 0);
					// TODO: reconstruct - same unresolved ZombieEntity virtual (offset 0x268)
					// applied with the level-3 value; dropped for lack of a member name.
					_ = powerValue;
				}
				// TODO: reconstruct - the decompile finished by invoking a PlantEntity virtual
				// (vtable offset 0x278) on this instance; that slot could not be resolved to a
				// named method, so the final call is omitted.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__12 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant130Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__12(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant130Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null)
				{
					return false;
				}
				PlantBaseAttr attr = plant.attr;
				// Mark that this activation came through power 0 so Explosion applies the
				// level-3 strengthen value.
				plant._isPower0 = true;
				if (entity != null && attr != null)
				{
					// Register the strengthen label describing this power on the plant's attr.
					attr.AddLabel(entity.title, 0, entity.GetDesc(plant));
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__13 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant130Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__13(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant130Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null)
				{
					return false;
				}
				// Power 1 zeroes out the card's cooldown timer (x -= x).
				if (!plant.IsHasCardSlot)
				{
					return false;
				}
				CardEntity card = plant.CardEntity;
				if (card == null || card.attr == null)
				{
					return false;
				}
				float timer = card.attr.cooldownTimer;
				CardEntity card2 = plant.CardEntity;
				if (card2 == null || card2.attr == null)
				{
					return false;
				}
				card.attr.cooldownTimer = timer - card2.attr.cooldownTimer;
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("魅惑特效")]
		public EffectEntity effectEntity;

		[Tooltip("魅惑音效")]
		public AudioClip hypnosisSound;

		private ZombieEntity _targetZombie;

		private bool _flag;

		private bool _isPower0;

		// TODO: unresolved constants used by the Explosion charm effect. These appear only as
		// data-pointer globals in the pseudocode (buff id 7, buff duration _DAT_18252cb70,
		// horizontal nudge _DAT_18252cd10) and could not be resolved to literals.
		private const int HypnosisBuffId = 7; // buff id passed to BuffHandler.AddBuff
		private const float HypnosisBuffDuration = -1f; // TODO: reconstruct constant
		private const float HypnosisPositionOffsetX = 0f; // TODO: reconstruct constant

		public override void Reset()
		{
			base.Reset();
			_targetZombie = null;
			_flag = false;
			if (partEntity == null)
			{
				return;
			}
			// Only auto-fire the power on reset while the plant is awake.
			if (partEntity.isSleeping)
			{
				return;
			}
			if (!IsHasCardSlot)
			{
				return;
			}
			CardEntity card = CardEntity;
			if (card == null)
			{
				return;
			}
			// If the card's power is ready, trigger it immediately.
			if (card.IsAvailablePower())
			{
				UsePower();
			}
		}

		public override void HitEat(float value, ZombieEntity zombieEntity)
		{
			// Take the bite damage through the normal hit pipeline first.
			Hit(value);
			if (partEntity == null)
			{
				return;
			}
			// Charm logic is suppressed while the plant sleeps.
			if (partEntity.isSleeping)
			{
				return;
			}
			if (zombieEntity == null)
			{
				return;
			}
			// Boss zombies (type 2) can't be charmed, and only charm one zombie at a time.
			if ((int)zombieEntity.type != 2 && !_flag)
			{
				_flag = true;
				_targetZombie = zombieEntity;
				StartCoroutine(Explosion());
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
		}

		protected override void Attack()
		{
			// ICF-folded onto PlantEntity.Attack (identical RVA 0x593370); mirror the base body.
			base.Attack();
		}

		protected override bool CheckAttack()
		{
			return false;
		}

		[IteratorStateMachine(typeof(_003CExplosion_003Ed__11))]
		public IEnumerator Explosion()
		{
			return new _003CExplosion_003Ed__11(0)
			{
				_003C_003E4__this = this
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__12))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__12(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__13))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__13(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
