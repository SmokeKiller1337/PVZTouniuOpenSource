using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Audio.Manager;
using Common.Entity;
using Game.Entity;
using Game.Util;
using Level.Manager;
using Strengthen.Entity;
using UnityEngine;

// NOTE: Reconstructed from the authoritative stub.cs skeleton + Ghidra pseudocode + dump.cs offsets.
// The namespace / usings / class + base / fields / method signatures / nested iterator classes are
// taken verbatim from the authoritative inputs and must not change.
//
// Field offset map (from dump.cs), relative to the object:
//   0x120 startSound          0x128 explosionEffect      0x130 explosionEffect1
//   0x138 _isSun              0x140 OnExplosionAfter      0x148 _currentPowerEntity
// Inherited (PlantEntity / BaseBody): 0xE0 attr, 0xE8 defaultAttr, 0x80 _rigidbody.
//
// Several methods in the original binary reference global manager singletons whose types/members do
// not exist in the restored project (an impulse/camera manager _DAT_182e52250, a "level entity"
// holder _DAT_182e2bc20 exposing non-existent zombieHouse/homeHouse transforms, a terrain manager
// _DAT_182e294b8, and a raycast-direction config holder _DAT_182e706b8). Logic that depends on those
// cannot be reconstructed faithfully and is left stubbed with // TODO, mirroring how the base
// PlantEntity reconstruction handled the same singletons. Only members verified against the project
// are used in reconstructed bodies.

namespace Plant.Entity.Plant
{
	public class Plant210Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__12 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant210Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__12(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant210Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null || plant.attr == null)
				{
					return false;
				}
				// Pick the explosion effect: the normal one, or the "big" one when the power
				// was triggered with strengthen slot 0.
				EffectEntity effect = plant.explosionEffect;
				if (plant._currentPowerEntity != null)
				{
					if (plant._currentPowerEntity.index == 0)
					{
						// TODO: reconstruct - the original also fired a camera impulse via an
						// unresolved impulse/camera manager singleton (_DAT_182e52250) whose type
						// and members do not exist in the project; that shake is dropped here.
						effect = plant.explosionEffect1;
					}
					// else if (index == 1): the original nudged the current card-slot's cooldown
					// bar height by the plant card's slot height. That touches CardEntity slot
					// internals (offset 0x70 -> 0x18) not present in the project and is dropped.
				}
				// Spawn the explosion effect at the plant's position.
				if (plant.transform != null)
				{
					GameUtils.CreateEffect(effect, plant.transform.position, Quaternion.identity);
				}
				// Gather the bodies caught in the blast and clear their entangle/root buffs.
				List<BaseBody> bodyList = plant.GetExplosionBodyList();
				if (bodyList != null)
				{
					foreach (BaseBody body in bodyList)
					{
						if (body == null)
						{
							continue;
						}
						if (body.BuffHandler != null)
						{
							// Buff ids 5 and 6 taken from the pseudocode (RemoveBuff(id, all)).
							body.BuffHandler.RemoveBuff(5);
							body.BuffHandler.RemoveBuff(6);
						}
						// TODO: reconstruct - the original then applied Explosion (or Clear) damage
						// to each body through a virtual slot (0x238) whose exact single-argument
						// target and damage payload could not be resolved from the dump. The kill
						// step is dropped to avoid inventing damage semantics.
					}
					// Notify listeners with the affected bodies.
					if (plant.OnExplosionAfter != null)
					{
						plant.OnExplosionAfter(bodyList);
					}
					plant._currentPowerEntity = null;
					// TODO: reconstruct - the original then cleared the terrain tiles under the
					// blast via an unresolved terrain manager singleton (_DAT_182e294b8) and
					// TerrainEntity.Clear over a component lookup; those members do not exist in
					// the project, so the terrain clear is dropped here.
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__16 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant210Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__16(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant210Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null)
				{
					return false;
				}
				// Remember which strengthen option triggered the power so AttackCoroutine can
				// pick the matching explosion behaviour.
				plant._currentPowerEntity = entity;
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__17 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant210Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__17(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant210Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null)
				{
					return false;
				}
				// Same as OnUsePower0: record the triggering strengthen entity.
				plant._currentPowerEntity = entity;
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("种植时音效")]
		public AudioClip startSound;

		[Tooltip("爆炸效果")]
		public EffectEntity explosionEffect;

		[Tooltip("大招爆炸效果")]
		public EffectEntity explosionEffect1;

		private bool _isSun;

		public Action<List<BaseBody>> OnExplosionAfter;

		private StrengthenEntity _currentPowerEntity;

		public override void Reset()
		{
			base.Reset();
			// TODO: reconstruct - the original scheduled a one-frame-delayed callback via
			// DG.Tweening DOVirtual.DelayedCall wrapping a compiler-generated lambda that is
			// absent from the authoritative skeleton; that delayed call is dropped here.
			if (AudioManager.Instance != null)
			{
				AudioManager.Instance.PlayOneShot(startSound);
			}
			// If this plant already sits in a card slot and its power is off cooldown, fire it.
			if (IsHasCardSlot)
			{
				CardEntity card = CardEntity;
				if (card == null)
				{
					return;
				}
				if (card.IsAvailablePower())
				{
					UsePower();
				}
			}
		}

		protected override void Start()
		{
			base.Start();
			if (attr == null)
			{
				return;
			}
			// This plant is planted invincible.
			attr.isInvincible = true;
			// Only sun-producing variants pay out on plant.
			if (!_isSun)
			{
				return;
			}
			StrengthenEntity strengthen = GetStrengthenEntity(2, 1);
			if (strengthen == null || _rigidbody == null || RewardManager.Instance == null)
			{
				return;
			}
			int sunValue = (int)strengthen.GetValue(this);
			RewardManager.Instance.CreateSun(_rigidbody.position, sunValue);
		}

		public override void Death()
		{
			// The pseudocode invokes a leading virtual (death handler) then detaches from the
			// land and destroys the GameObject - the same shape as the base PlantEntity.Death.
			DeathHandle();
			ClearLand();
			UnityEngine.Object.Destroy(base.gameObject);
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// ICF-folded onto the shared empty method (RVA 0x3D9020): no level-0 adjustment.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index != 0)
			{
				// Strengthen slot 1: mark this plant as a sun producer.
				if (entity.index == 1)
				{
					_isSun = true;
				}
				return;
			}
			// Strengthen slot 0: add (defaultAttr.attack * value) onto the current attack.
			if (attr == null || defaultAttr == null)
			{
				return;
			}
			int currentAttack = attr.attack;
			int baseAttack = defaultAttr.attack;
			float value = entity.GetValue(this);
			attr.attack = (int)((float)baseAttack * value) + currentAttack;
		}

		protected override void Attack()
		{
			// Play the shared attack animation (base), then run the explosion coroutine.
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__12))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__12(0)
			{
				_003C_003E4__this = this
			};
		}

		public List<BaseBody> GetExplosionBodyList()
		{
			// TODO: reconstruct - the original built the hit list from a set of Physics2D.RaycastAll
			// sweeps whose ray directions/offsets come from an unresolved config holder
			// (_DAT_182e706b8) and whose ray lengths are derived from the level's zombie/home house
			// transforms via a "level entity" singleton (_DAT_182e2bc20). Neither the config holder's
			// members nor the LevelEntity type / its house transforms exist in the restored project,
			// so the sweep cannot be reconstructed faithfully. Returns an empty list so callers stay
			// well-defined instead of fabricating layer/direction data.
			return new List<BaseBody>();
		}

		private HashSet<RaycastHit2D> GetDirectionBodyList(Vector2 direction, float distance)
		{
			// TODO: reconstruct - like GetExplosionBodyList, this performs Physics2D.RaycastAll sweeps
			// whose layer mask comes from unresolved string-data-pointer globals and whose spread
			// offsets come from the unresolved config holder (_DAT_182e706b8). Those inputs cannot be
			// recovered, so the raycast set cannot be reproduced. Returns an empty set.
			return new HashSet<RaycastHit2D>();
		}

		protected override bool CheckAttack()
		{
			// ICF-folded onto a "return false" stub (RVA 0x387B60): this plant never auto-attacks;
			// its explosion is driven by the power path instead.
			return false;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__16))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__16(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__17))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__17(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
