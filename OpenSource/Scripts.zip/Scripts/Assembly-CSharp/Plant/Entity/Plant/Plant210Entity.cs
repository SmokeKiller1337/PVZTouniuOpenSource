using System;
using System.Collections;
using System.Collections.Generic;
using Audio.Manager;
using Common.Entity;
using Game.Entity;
using Game.Util;
using Level.Manager;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant210Entity : PlantEntity
	{
		[Tooltip("种植时音效")]
		public AudioClip startSound;

		[Tooltip("爆炸效果")]
		public EffectEntity explosionEffect;

		[Tooltip("大招爆炸效果")]
		public EffectEntity explosionEffect1;

		private bool _isSun;

		public Action<List<BaseBody>> OnExplosionAfter;

		private StrengthenEntity _currentPowerEntity;

		public override void Reset()
		{
			base.Reset();
			if (AudioManager.Instance != null)
			{
				AudioManager.Instance.PlayOneShot(startSound);
			}
			// If this plant already sits in a card slot and its power is off cooldown, fire it.
			if (IsHasCardSlot)
			{
				CardEntity card = CardEntity;
				if (card == null)
				{
					return;
				}
				if (card.IsAvailablePower())
				{
					UsePower();
				}
			}
		}

		protected override void Start()
		{
			base.Start();
			if (attr == null)
			{
				return;
			}
			// This plant is planted invincible.
			attr.isInvincible = true;
			// Only sun-producing variants pay out on plant.
			if (!_isSun)
			{
				return;
			}
			StrengthenEntity strengthen = GetStrengthenEntity(2, 1);
			if (strengthen == null || _rigidbody == null || RewardManager.Instance == null)
			{
				return;
			}
			int sunValue = (int)strengthen.GetValue(this);
			RewardManager.Instance.CreateSun(_rigidbody.position, sunValue);
		}

		public override void Death()
		{
			DeathHandle();
			ClearLand();
			UnityEngine.Object.Destroy(base.gameObject);
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index != 0)
			{
				// Strengthen slot 1: mark this plant as a sun producer.
				if (entity.index == 1)
				{
					_isSun = true;
				}
				return;
			}
			// Strengthen slot 0: add (defaultAttr.attack * value) onto the current attack.
			if (attr == null || defaultAttr == null)
			{
				return;
			}
			int currentAttack = attr.attack;
			int baseAttack = defaultAttr.attack;
			float value = entity.GetValue(this);
			attr.attack = (int)((float)baseAttack * value) + currentAttack;
		}

		protected override void Attack()
		{
			// Play the shared attack animation (base), then run the explosion coroutine.
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			if (this == null || attr == null)
			{
				yield break;
			}
			// 选择爆炸特效：普通特效，或 0 号强化槽触发大招时的大爆炸特效。
			EffectEntity effect = explosionEffect;
			if (_currentPowerEntity != null && _currentPowerEntity.index == 0)
			{
				effect = explosionEffect1;
			}
			// 在植物位置生成爆炸特效。
			if (transform != null)
			{
				GameUtils.CreateEffect(effect, transform.position, Quaternion.identity);
			}
			// 收集被波及的实体，清除它们的缠绕/定身增益并通知监听者。
			List<BaseBody> bodyList = GetExplosionBodyList();
			if (bodyList != null)
			{
				foreach (BaseBody body in bodyList)
				{
					if (body == null)
					{
						continue;
					}
					if (body.BuffHandler != null)
					{
						body.BuffHandler.RemoveBuff(5);
						body.BuffHandler.RemoveBuff(6);
					}
				}
				if (OnExplosionAfter != null)
				{
					OnExplosionAfter(bodyList);
				}
				_currentPowerEntity = null;
			}
		}

		public List<BaseBody> GetExplosionBodyList()
		{
			return new List<BaseBody>();
		}

		private HashSet<RaycastHit2D> GetDirectionBodyList(Vector2 direction, float distance)
		{
			return new HashSet<RaycastHit2D>();
		}

		protected override bool CheckAttack()
		{
			return false;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			if (this == null)
			{
				yield break;
			}
			// 记录触发大招的强化项，供 AttackCoroutine 选择对应的爆炸表现。
			_currentPowerEntity = entity;
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			if (this == null)
			{
				yield break;
			}
			// 与 OnUsePower0 相同：记录触发的强化项。
			_currentPowerEntity = entity;
		}
	}
}
