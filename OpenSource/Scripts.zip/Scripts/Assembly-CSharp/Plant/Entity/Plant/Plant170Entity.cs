using System.Collections;
using Common.Entity;
using Level.Manager;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant170Entity : PlantEntity
	{
		private bool _isSun;

		private const float PowerFadeInDuration = 0f;
		private const float SunSpawnInterval = 0f;
		private const float PowerFadeOutDuration = 0f;

		public override void Reset()
		{
			base.Reset();
			if (!IsHasCardSlot)
			{
				return;
			}
			if (CardEntity.IsAvailablePower())
			{
				UsePower();
			}
		}

		protected override void Start()
		{
			base.Start();
			if (!_isSun)
			{
				return;
			}
			StrengthenEntity strengthenEntity = GetStrengthenEntity(2, 1);
			RewardManager reward = RewardManager.Instance;
			if (_rigidbody != null && strengthenEntity != null && reward != null)
			{
				reward.CreateSun(_rigidbody.position, (int)strengthenEntity.GetValue(this, 0), 1f, true);
			}
		}

		protected override void Update()
		{
			base.Update();
			if (partEntity == null)
			{
				return;
			}
			if (partEntity.isSleeping)
			{
				return;
			}
			PlantBaseAttr plantBaseAttr = attr;
			if (plantBaseAttr.attackIntervalTime > 0f)
			{
				plantBaseAttr.attackIntervalTimer += Time.deltaTime;
				if (plantBaseAttr.attackIntervalTimer >= plantBaseAttr.attackIntervalTime)
				{
					plantBaseAttr.attackIntervalTimer = 0f;
					if (CheckAttack())
					{
						Attack();
					}
				}
			}
			EyeUpdate();
			if (isHasSpecialSkill && specialCooldownTimer > 0f)
			{
				specialCooldownTimer -= Time.deltaTime;
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// 按等级2的倍率放大默认最大生命值
				ChangeMaxHealth(defaultAttr.maxHealth * entity.GetValue(this, 0));
			}
			else if (entity.index == 1)
			{
				_isSun = true;
			}
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			if (this == null)
			{
				yield break;
			}
			// 先等待能量淡入时间
			yield return new WaitForSeconds(PowerFadeInDuration);
			// 按强化数值逐个产出阳光，每个之间等待间隔
			for (int i = 0; ; i++)
			{
				if (entity == null)
				{
					yield break;
				}
				if (i < (int)entity.GetValue(this, 0))
				{
					if (this == null || transform == null)
					{
						yield break;
					}
					RewardManager reward = RewardManager.Instance;
					if (reward == null)
					{
						yield break;
					}
					reward.CreateSun(transform.position, 25, 1f, true);
					yield return new WaitForSeconds(SunSpawnInterval);
				}
				else
				{
					// 产出完毕后等待能量淡出时间
					if (this != null)
					{
						yield return new WaitForSeconds(PowerFadeOutDuration);
					}
					yield break;
				}
			}
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			if (entity != null)
			{
				// 永久提升最大生命值并回满，同时挂上强化标签
				ChangeMaxHealth(entity.GetValue(this, 0));
				if (attr != null)
				{
					ChangeHealth(attr.maxHealth);
					attr.AddLabel(entity.title, 1, entity.GetDesc(this));
				}
			}
			yield break;
		}

		public override int GetHeadNumber()
		{
			return 0;
		}
	}
}
