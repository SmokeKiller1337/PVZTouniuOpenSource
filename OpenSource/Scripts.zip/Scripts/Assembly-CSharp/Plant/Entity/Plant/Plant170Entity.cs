using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Entity;
using Level.Manager;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant170Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__6 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant170Entity _003C_003E4__this;

			public StrengthenEntity entity;

			private int _003Ci_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__6(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant170Entity plant = _003C_003E4__this;
				switch (num)
				{
				default:
					return false;
				case 0:
					_003C_003E1__state = -1;
					if (plant != null)
					{
						// TODO: reconstruct - the pseudocode first faded this plant's renderer
						// materials in via a DOTween DOFloat sweep over a shader property. The
						// shader property name and target value are unresolved data globals, so
						// the visual sweep is dropped here and only the timing wait is kept.
						_003C_003E2__current = new WaitForSeconds(PowerFadeInDuration);
						_003C_003E1__state = 1;
						return true;
					}
					return false;
				case 1:
					_003C_003E1__state = -1;
					_003Ci_003E5__2 = 0;
					break;
				case 2:
					_003C_003E1__state = -1;
					_003Ci_003E5__2++;
					break;
				}
				if (entity != null)
				{
					if (_003Ci_003E5__2 < (int)entity.GetValue(plant, 0))
					{
						if (plant != null && plant.transform != null)
						{
							RewardManager reward = RewardManager.Instance;
							if (reward != null)
							{
								// Spawn one sun per produced unit, then wait before the next.
								reward.CreateSun(plant.transform.position, 25, 1f, true);
								_003C_003E2__current = new WaitForSeconds(SunSpawnInterval);
								_003C_003E1__state = 2;
								return true;
							}
						}
					}
					else if (plant != null)
					{
						// TODO: reconstruct - the pseudocode then faded the renderer materials
						// back out via the same DOTween DOFloat sweep (unresolved shader globals);
						// dropped, only the trailing timing wait is kept.
						_003C_003E2__current = new WaitForSeconds(PowerFadeOutDuration);
						_003C_003E1__state = 3;
						return true;
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__7 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public StrengthenEntity entity;

			public Plant170Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__7(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant170Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (entity != null)
				{
					// Permanently raise max health by the strengthen value, then top the
					// plant back off to full and tag it with the strengthen's label.
					plant.ChangeMaxHealth(entity.GetValue(plant, 0));
					if (plant.attr != null)
					{
						plant.ChangeHealth(plant.attr.maxHealth);
						plant.attr.AddLabel(entity.title, 1, entity.GetDesc(plant));
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		private bool _isSun;

		// TODO: unresolved coroutine wait durations (WaitForSeconds args are data-pointer
		// float globals in the pseudocode). Replace with the real timings when known.
		private const float PowerFadeInDuration = 0f; // TODO: reconstruct constant
		private const float SunSpawnInterval = 0f; // TODO: reconstruct constant
		private const float PowerFadeOutDuration = 0f; // TODO: reconstruct constant

		public override void Reset()
		{
			base.Reset();
			if (!IsHasCardSlot)
			{
				return;
			}
			if (CardEntity.IsAvailablePower())
			{
				UsePower();
			}
		}

		protected override void Start()
		{
			base.Start();
			if (!_isSun)
			{
				return;
			}
			StrengthenEntity strengthenEntity = GetStrengthenEntity(2, 1);
			RewardManager reward = RewardManager.Instance;
			if (_rigidbody != null && strengthenEntity != null && reward != null)
			{
				reward.CreateSun(_rigidbody.position, (int)strengthenEntity.GetValue(this, 0), 1f, true);
			}
		}

		protected override void Update()
		{
			base.Update();
			if (partEntity == null)
			{
				return;
			}
			if (partEntity.isSleeping)
			{
				return;
			}
			PlantBaseAttr plantBaseAttr = attr;
			if (plantBaseAttr.attackIntervalTime > 0f)
			{
				plantBaseAttr.attackIntervalTimer += Time.deltaTime;
				if (plantBaseAttr.attackIntervalTimer >= plantBaseAttr.attackIntervalTime)
				{
					plantBaseAttr.attackIntervalTimer = 0f;
					if (CheckAttack())
					{
						Attack();
					}
				}
			}
			EyeUpdate();
			if (isHasSpecialSkill && specialCooldownTimer > 0f)
			{
				specialCooldownTimer -= Time.deltaTime;
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// Original body is empty (folded onto an empty stub in the pseudocode).
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// Scale max health by the level-2 multiplier applied to the default max health.
				ChangeMaxHealth(defaultAttr.maxHealth * entity.GetValue(this, 0));
			}
			else if (entity.index == 1)
			{
				_isSun = true;
			}
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__6))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			_003COnUsePower0_003Ed__6 result = new _003COnUsePower0_003Ed__6(0);
			result._003C_003E4__this = this;
			result.entity = entity;
			return result;
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__7))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			_003COnUsePower1_003Ed__7 result = new _003COnUsePower1_003Ed__7(0);
			result._003C_003E4__this = this;
			result.entity = entity;
			return result;
		}

		public override int GetHeadNumber()
		{
			return 0;
		}
	}
}
