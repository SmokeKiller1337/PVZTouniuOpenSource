using System;
using System.Collections;
using System.Collections.Generic;
using Bullet.Entity;
using Bullet.Util;
using Common.Collider;
using Game.Entity;
using Game.Util;
using Level.Entity;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant240Entity : PlantEntity
	{
		[Tooltip("坚果渲染器")]
		public SpriteRenderer bodySpriteRenderer;

		[Tooltip("坚果贴图集合")]
		public List<Sprite> bodySpriteList;

		[Tooltip("被吃效果")]
		public EffectEntity eatEffect;

		[Tooltip("爆炸效果")]
		public EffectEntity explosionEffect;

		private float _hitTimer;

		private StrengthenEntity _addHealthEntity;

		private bool _isAddHealth;

		private float _addHealthIntervalTimer;

		private bool _isDeathCooldown;

		private float _breakJumpTimer;

		// TODO: unresolved float globals used when a body sprite is chosen from the
		// bodySpriteList by remaining-health ratio (0x18252cf78 / 0x18252cf28).
		private const float BodySpriteHealthRatioHigh = 0.66f;
		private const float BodySpriteHealthRatioLow = 0.33f;

		// TODO: hit-stun duration written to _hitTimer when struck (float bits 0x3F19999A = 0.6f).
		private const float HitStunTime = 0.6f;

		// TODO: unresolved globals for the OnUsePower0 blast.
		private const float PowerWindUpDelay = 0f;
		private const float ExplosionRadius = 0f;
		private const string ExplosionLayerName = "Zombie";

		private const string EyeBlinkAnimName = "EyeBlink";
		private const string BlinkTag = "Blink";

		private const string ZombieTag = "Zombie";

		public override void Reset()
		{
			base.Reset();
			UpdateBodySprite();
		}

		protected override void Update()
		{
			base.Update();
			// Periodic self-heal while the add-health strengthen is active.
			if (_isAddHealth)
			{
				_addHealthIntervalTimer += Time.deltaTime;
				if (_addHealthEntity == null)
				{
					return;
				}
				float interval = _addHealthEntity.GetValue(this, 0);
				if (interval <= _addHealthIntervalTimer)
				{
					_addHealthIntervalTimer = 0f;
					if (attr == null)
					{
						return;
					}
					float maxHealth = attr.maxHealth;
					if (_addHealthEntity == null)
					{
						return;
					}
					float ratio = _addHealthEntity.GetValue(this, 1);
					ChangeHealth(ratio * maxHealth);
				}
			}
			// Count down the hit-stun; once it lapses, restore the animator speed unless
			// the plant is currently frozen (buff 2) or being instantly killed (buff 4).
			if (_hitTimer > 0f)
			{
				_hitTimer -= Time.deltaTime;
				if (_hitTimer <= 0f)
				{
					if (_buffHandler == null)
					{
						return;
					}
					if (!_buffHandler.HasBuff(2))
					{
						if (_buffHandler == null)
						{
							return;
						}
						if (!_buffHandler.HasBuff(4))
						{
							if (_animator == null)
							{
								return;
							}
							_animator.speed = 1f;
						}
					}
				}
			}
		}

		private void UpdateBodySprite()
		{
			if (bodySpriteRenderer == null)
			{
				return;
			}
			if (attr == null)
			{
				return;
			}
			float ratio = attr.currentHealth / attr.maxHealth;
			int index;
			if (ratio > BodySpriteHealthRatioHigh)
			{
				index = 0;
			}
			else if (ratio > BodySpriteHealthRatioLow)
			{
				index = 1;
			}
			else
			{
				index = 2;
			}
			if (bodySpriteList == null)
			{
				return;
			}
			Sprite sprite = bodySpriteList[index];
			bodySpriteRenderer.sprite = sprite;
		}

		public override void OnTriggerCustomEnter(Collider2D col, int index)
		{
			base.OnTriggerCustomEnter(col, index);
			if (col == null)
			{
				return;
			}
			GameObject gameObject = col.gameObject;
			if (gameObject == null)
			{
				return;
			}
			if (!gameObject.CompareTag(ZombieTag))
			{
				return;
			}
			ZombieBodyColliderEntity colliderEntity = gameObject.GetComponent<ZombieBodyColliderEntity>();
			if (colliderEntity == null)
			{
				return;
			}
			BreakJump(colliderEntity.zombieEntity, true);
		}

		public override void OnTriggerCustomExit(Collider2D col, int index)
		{
			base.OnTriggerCustomExit(col, index);
			if (col == null)
			{
				return;
			}
			GameObject gameObject = col.gameObject;
			if (gameObject == null)
			{
				return;
			}
			if (!gameObject.CompareTag(ZombieTag))
			{
				return;
			}
			ZombieBodyColliderEntity colliderEntity = gameObject.GetComponent<ZombieBodyColliderEntity>();
			if (colliderEntity == null)
			{
				return;
			}
			BreakJump(colliderEntity.zombieEntity, false);
		}

		private void BreakJump(ZombieEntity zombieEntity, bool isBreak = true)
		{
		}

		public override bool Hit(float value, DamageTypeEntity damageType = null, BulletEntity sourceBullet = null)
		{
			// A positive hit briefly freezes the plant's animation and spawns the eaten effect.
			if (value > 0f)
			{
				_hitTimer = HitStunTime;
				if (_animator == null)
				{
					return false;
				}
				_animator.speed = 0f;
				Transform t = transform;
				if (t == null)
				{
					return false;
				}
				GameUtils.CreateEffect(eatEffect, t.position, Quaternion.identity);
			}
			if (damageType == null)
			{
				damageType = DamageTypeEntity.Common;
			}
			if (attr == null)
			{
				return false;
			}
			if (attr.isInvincible)
			{
				return false;
			}
			if (damageType == null)
			{
				return false;
			}
			// Instant-kill damage type (2) can be immune-listed or blocked by isNotPick2.
			if ((int)damageType.damageType == 2)
			{
				if (immuneBuffIdList == null)
				{
					return false;
				}
				if (immuneBuffIdList.Contains(4))
				{
					return false;
				}
				if (attr == null)
				{
					return false;
				}
				if (attr.isNotPick2)
				{
					return false;
				}
			}
			if (value <= 0f)
			{
				return false;
			}
			// deathType 1 with lethal damage applies the instant-kill buff instead of damage.
			if ((int)damageType.deathType == 1 && value >= attr.currentHealth)
			{
				if (_buffHandler != null)
				{
					// TODO: instant-kill buff duration is an unresolved float global.
					_buffHandler.AddBuff(4, null, InstantKillBuffDuration);
					return true;
				}
			}
			else
			{
				ChangeHealth(-value);
				Flicker();
				return true;
			}
			return false;
		}

		// TODO: unresolved instant-kill buff duration constant.
		private const float InstantKillBuffDuration = 0f;

		public override void EyeBlink()
		{
			// Suppress blinking while the plant is in hit-stun.
			if (_hitTimer > 0f)
			{
				return;
			}
			if (partEntity == null)
			{
				return;
			}
			if (partEntity.isCloseEye)
			{
				return;
			}
			if (_animator == null)
			{
				return;
			}
			AnimatorStateInfo state = _animator.GetCurrentAnimatorStateInfo(0);
			if (state.IsTag(BlinkTag))
			{
				_animator.Play(EyeBlinkAnimName);
			}
		}

		public override void ChangeHealth(float value)
		{
			base.ChangeHealth(value);
			UpdateBodySprite();
		}

		public override void Death()
		{
			base.Death();
			// When the death-cooldown strengthen is active and the plant owns a card slot,
			// reduce the card's cooldown timer by the strengthen value times its cooldown.
			if (!_isDeathCooldown || !IsHasCardSlot)
			{
				return;
			}
			StrengthenEntity entity = GetStrengthenEntity(2, 1);
			CardEntity card = CardEntity;
			if (card == null || card.attr == null)
			{
				return;
			}
			float cooldownTimer = card.attr.cooldownTimer;
			CardEntity card2 = CardEntity;
			if (card2 == null || card2.attr == null)
			{
				return;
			}
			float cooldownTime = card2.attr.cooldownTime;
			if (entity == null)
			{
				return;
			}
			float value = entity.GetValue(this, 0);
			card.attr.cooldownTimer = cooldownTimer - value * cooldownTime;
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// Scale max health by the level-2 multiplier applied to the default max health.
				if (defaultAttr == null)
				{
					return;
				}
				float baseMaxHealth = defaultAttr.maxHealth;
				float value = entity.GetValue(this, 0);
				ChangeMaxHealth(value * baseMaxHealth);
			}
			else if (entity.index == 1)
			{
				// Enable the reduce-card-cooldown-on-death strengthen (consumed in Death()).
				_isDeathCooldown = true;
			}
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 蓄力期间令坚果进入无敌状态，随后等待一段时间再引爆。
			if (attr == null)
			{
				yield break;
			}
			attr.isInvincible = true;
			yield return new WaitForSeconds(PowerWindUpDelay);
			if (entity == null)
			{
				yield break;
			}
			// 爆炸伤害由强化数值决定。
			float damage = entity.GetValue(this, 0);
			Transform t = transform;
			if (t == null)
			{
				yield break;
			}
			// 在坚果所在位置生成爆炸特效。
			GameUtils.CreateEffect(explosionEffect, t.position, Quaternion.identity);
			// 对周围范围内的僵尸造成爆炸伤害。
			Vector2 blastPos = transform.position;
			int layerMask = LayerMask.GetMask(ExplosionLayerName);
			DamageUtils.Explosion(blastPos, ExplosionRadius, damage, layerMask);
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			if (entity == null)
			{
				yield break;
			}
			// 按强化数值提升最大生命并回满，同时挂上强化标签。
			float value = entity.GetValue(this, 0);
			ChangeMaxHealth(value);
			if (attr != null)
			{
				ChangeHealth(attr.maxHealth);
				attr.AddLabel(entity.title, 1, entity.GetDesc(this));
			}
		}
	}
}
