using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Bullet.Entity;
using Bullet.Util;
using Common.Collider;
using Game.Entity;
using Game.Util;
using Level.Entity;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant240Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__22 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant240Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__22(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant240Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					// Make the plant invincible during the wind-up, then wait a beat.
					if (plant == null || plant.attr == null)
					{
						return false;
					}
					plant.attr.isInvincible = true;
					// TODO: wind-up duration is an unresolved float global in the pseudocode.
					_003C_003E2__current = new WaitForSeconds(PowerWindUpDelay);
					_003C_003E1__state = 1;
					return true;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (entity == null)
				{
					return false;
				}
				// Damage dealt by the blast is derived from the strengthen value.
				float damage = entity.GetValue(plant, 0);
				// Spawn the explosion visual at the plant's position.
				Transform t = plant.transform;
				if (t == null)
				{
					return false;
				}
				GameUtils.CreateEffect(plant.explosionEffect, t.position, Quaternion.identity);
				// Apply explosion damage in a radius around the plant.
				Vector2 blastPos = plant.transform.position;
				// TODO: layer name is an unresolved data pointer in the pseudocode.
				int layerMask = LayerMask.GetMask(ExplosionLayerName);
				DamageUtils.Explosion(blastPos, ExplosionRadius, damage, layerMask);
				// TODO: reconstruct - the pseudocode then made a trailing virtual call on the
				// plant (vtable slot 0x278). That slot could not be resolved to a member, so
				// the call is dropped rather than guessing (matches sibling reconstructions).
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__23 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public StrengthenEntity entity;

			public Plant240Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__23(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// Permanently raises max health, heals to full, and records a strengthen
				// label. The pseudocode never yields, so this completes on the first pump.
				int num = _003C_003E1__state;
				Plant240Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (entity == null)
				{
					return false;
				}
				float value = entity.GetValue(plant, 0);
				plant.ChangeMaxHealth(value);
				if (plant.attr != null)
				{
					plant.ChangeHealth(plant.attr.maxHealth);
					plant.attr.AddLabel(entity.title, 1, entity.GetDesc(plant));
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("坚果渲染器")]
		public SpriteRenderer bodySpriteRenderer;

		[Tooltip("坚果贴图集合")]
		public List<Sprite> bodySpriteList;

		[Tooltip("被吃效果")]
		public EffectEntity eatEffect;

		[Tooltip("爆炸效果")]
		public EffectEntity explosionEffect;

		private float _hitTimer;

		private StrengthenEntity _addHealthEntity;

		private bool _isAddHealth;

		private float _addHealthIntervalTimer;

		private bool _isDeathCooldown;

		private float _breakJumpTimer;

		// TODO: unresolved float globals used when a body sprite is chosen from the
		// bodySpriteList by remaining-health ratio (0x18252cf78 / 0x18252cf28).
		private const float BodySpriteHealthRatioHigh = 0.66f; // TODO: reconstruct constant
		private const float BodySpriteHealthRatioLow = 0.33f; // TODO: reconstruct constant

		// TODO: hit-stun duration written to _hitTimer when struck (float bits 0x3F19999A = 0.6f).
		private const float HitStunTime = 0.6f;

		// TODO: unresolved globals for the OnUsePower0 blast.
		private const float PowerWindUpDelay = 0f; // TODO: reconstruct constant (WaitForSeconds)
		private const float ExplosionRadius = 0f; // TODO: reconstruct constant (blast radius)
		private const string ExplosionLayerName = "Zombie"; // TODO: reconstruct layer name literal

		// TODO: unresolved eye-blink animator state / tag literals (data pointers).
		private const string EyeBlinkAnimName = "EyeBlink"; // TODO: reconstruct literal
		private const string BlinkTag = "Blink"; // TODO: reconstruct animator tag literal

		// TODO: collider tag compared before resolving the owning zombie (data pointer).
		private const string ZombieTag = "Zombie"; // TODO: reconstruct literal

		public override void Reset()
		{
			base.Reset();
			UpdateBodySprite();
		}

		protected override void Update()
		{
			base.Update();
			// Periodic self-heal while the add-health strengthen is active.
			if (_isAddHealth)
			{
				_addHealthIntervalTimer += Time.deltaTime;
				if (_addHealthEntity == null)
				{
					return;
				}
				float interval = _addHealthEntity.GetValue(this, 0);
				if (interval <= _addHealthIntervalTimer)
				{
					_addHealthIntervalTimer = 0f;
					if (attr == null)
					{
						return;
					}
					float maxHealth = attr.maxHealth;
					if (_addHealthEntity == null)
					{
						return;
					}
					float ratio = _addHealthEntity.GetValue(this, 1);
					ChangeHealth(ratio * maxHealth);
				}
			}
			// Count down the hit-stun; once it lapses, restore the animator speed unless
			// the plant is currently frozen (buff 2) or being instantly killed (buff 4).
			if (_hitTimer > 0f)
			{
				_hitTimer -= Time.deltaTime;
				if (_hitTimer <= 0f)
				{
					if (_buffHandler == null)
					{
						return;
					}
					if (!_buffHandler.HasBuff(2))
					{
						if (_buffHandler == null)
						{
							return;
						}
						if (!_buffHandler.HasBuff(4))
						{
							if (_animator == null)
							{
								return;
							}
							_animator.speed = 1f;
						}
					}
				}
			}
		}

		private void UpdateBodySprite()
		{
			if (bodySpriteRenderer == null)
			{
				return;
			}
			if (attr == null)
			{
				return;
			}
			float ratio = attr.currentHealth / attr.maxHealth;
			int index;
			if (ratio > BodySpriteHealthRatioHigh)
			{
				index = 0;
			}
			else if (ratio > BodySpriteHealthRatioLow)
			{
				index = 1;
			}
			else
			{
				index = 2;
			}
			if (bodySpriteList == null)
			{
				return;
			}
			Sprite sprite = bodySpriteList[index];
			bodySpriteRenderer.sprite = sprite;
		}

		public override void OnTriggerCustomEnter(Collider2D col, int index)
		{
			base.OnTriggerCustomEnter(col, index);
			if (col == null)
			{
				return;
			}
			GameObject gameObject = col.gameObject;
			if (gameObject == null)
			{
				return;
			}
			if (!gameObject.CompareTag(ZombieTag))
			{
				return;
			}
			ZombieBodyColliderEntity colliderEntity = gameObject.GetComponent<ZombieBodyColliderEntity>();
			if (colliderEntity == null)
			{
				return;
			}
			BreakJump(colliderEntity.zombieEntity, true);
		}

		public override void OnTriggerCustomExit(Collider2D col, int index)
		{
			base.OnTriggerCustomExit(col, index);
			if (col == null)
			{
				return;
			}
			GameObject gameObject = col.gameObject;
			if (gameObject == null)
			{
				return;
			}
			if (!gameObject.CompareTag(ZombieTag))
			{
				return;
			}
			ZombieBodyColliderEntity colliderEntity = gameObject.GetComponent<ZombieBodyColliderEntity>();
			if (colliderEntity == null)
			{
				return;
			}
			BreakJump(colliderEntity.zombieEntity, false);
		}

		private void BreakJump(ZombieEntity zombieEntity, bool isBreak = true)
		{
			// TODO: reconstruct — the pseudocode does runtime type-checks against several
			// specific zombie subtypes (comparing the type-id byte at zombie+0x130 against
			// unresolved type descriptors) and then rewrites internal fields on the zombie's
			// arm entities (arm1Entity/arm2Entity list element [1], field +0x20) and makes a
			// trailing virtual call (vtable 0x588). None of those arm-internal offsets map to
			// verifiable ZombieArmEntity members, and the type descriptors are data pointers,
			// so a faithful body cannot be produced without inventing members. Left as a stub.
		}

		public override bool Hit(float value, DamageTypeEntity damageType = null, BulletEntity sourceBullet = null)
		{
			// A positive hit briefly freezes the plant's animation and spawns the eaten effect.
			if (value > 0f)
			{
				_hitTimer = HitStunTime;
				if (_animator == null)
				{
					return false;
				}
				_animator.speed = 0f;
				Transform t = transform;
				if (t == null)
				{
					return false;
				}
				GameUtils.CreateEffect(eatEffect, t.position, Quaternion.identity);
			}
			if (damageType == null)
			{
				damageType = DamageTypeEntity.Common;
			}
			if (attr == null)
			{
				return false;
			}
			if (attr.isInvincible)
			{
				return false;
			}
			if (damageType == null)
			{
				return false;
			}
			// Instant-kill damage type (2) can be immune-listed or blocked by isNotPick2.
			if ((int)damageType.damageType == 2)
			{
				if (immuneBuffIdList == null)
				{
					return false;
				}
				if (immuneBuffIdList.Contains(4))
				{
					return false;
				}
				if (attr == null)
				{
					return false;
				}
				if (attr.isNotPick2)
				{
					return false;
				}
			}
			// TODO: reconstruct - the pseudocode also gated here on a global "damage disabled"
			// flag read from GameManager.Instance.LevelEntity, a type/member that does not exist
			// in the project; that guard is dropped. The non-positive-damage guard is preserved.
			if (value <= 0f)
			{
				return false;
			}
			// deathType 1 with lethal damage applies the instant-kill buff instead of damage.
			if ((int)damageType.deathType == 1 && value >= attr.currentHealth)
			{
				if (_buffHandler != null)
				{
					// TODO: instant-kill buff duration is an unresolved float global.
					_buffHandler.AddBuff(4, null, InstantKillBuffDuration);
					return true;
				}
			}
			else
			{
				ChangeHealth(-value);
				Flicker();
				return true;
			}
			return false;
		}

		// TODO: unresolved instant-kill buff duration constant.
		private const float InstantKillBuffDuration = 0f; // TODO: reconstruct constant

		public override void EyeBlink()
		{
			// Suppress blinking while the plant is in hit-stun.
			if (_hitTimer > 0f)
			{
				return;
			}
			if (partEntity == null)
			{
				return;
			}
			if (partEntity.isCloseEye)
			{
				return;
			}
			if (_animator == null)
			{
				return;
			}
			AnimatorStateInfo state = _animator.GetCurrentAnimatorStateInfo(0);
			if (state.IsTag(BlinkTag))
			{
				_animator.Play(EyeBlinkAnimName);
			}
		}

		public override void ChangeHealth(float value)
		{
			base.ChangeHealth(value);
			UpdateBodySprite();
		}

		public override void Death()
		{
			base.Death();
			// When the death-cooldown strengthen is active and the plant owns a card slot,
			// reduce the card's cooldown timer by the strengthen value times its cooldown.
			if (!_isDeathCooldown || !IsHasCardSlot)
			{
				return;
			}
			StrengthenEntity entity = GetStrengthenEntity(2, 1);
			CardEntity card = CardEntity;
			if (card == null || card.attr == null)
			{
				return;
			}
			float cooldownTimer = card.attr.cooldownTimer;
			CardEntity card2 = CardEntity;
			if (card2 == null || card2.attr == null)
			{
				return;
			}
			float cooldownTime = card2.attr.cooldownTime;
			if (entity == null)
			{
				return;
			}
			float value = entity.GetValue(this, 0);
			card.attr.cooldownTimer = cooldownTimer - value * cooldownTime;
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// ICF-folded onto the shared empty method (RVA 0x3D9020); no body.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// Scale max health by the level-2 multiplier applied to the default max health.
				if (defaultAttr == null)
				{
					return;
				}
				float baseMaxHealth = defaultAttr.maxHealth;
				float value = entity.GetValue(this, 0);
				ChangeMaxHealth(value * baseMaxHealth);
			}
			else if (entity.index == 1)
			{
				// Enable the reduce-card-cooldown-on-death strengthen (consumed in Death()).
				_isDeathCooldown = true;
			}
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__22))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__22(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__23))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__23(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
