using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant140Entity : PlantEntity
	{
		// TODO: The following name/constant fields are data pointers in the pseudocode
		// (Animator state names, animator float-parameter names, overlap radius, wait
		// multipliers, layer names) that could not be resolved to their literal values.
		// Replace with the real values when known.
		private const string AttackAnimName = "Attack"; // TODO: reconstruct literal
		private const string EnterFlinchAnimName = "EnterFlinch"; // TODO: reconstruct literal
		private const string ExitFlinchAnimName = "ExitFlinch"; // TODO: reconstruct literal
		private const string FlinchSleepAnimName = "FlinchSleep"; // TODO: reconstruct literal
		private const string FlinchAwakeAnimName = "FlinchAwake"; // TODO: reconstruct literal
		private const string AttackSpeedParam = "attackSpeed"; // TODO: reconstruct animator float-parameter name
		private const string FlinchLayerName = "Zombie"; // TODO: reconstruct layer name literal
		private const float AttackSpeedAnimMultiplier = 1f; // TODO: reconstruct constant (_DAT_18252cf40)
		private const float AttackWaitMultiplier = 1f; // TODO: reconstruct constant (_DAT_18252cd08)
		private const float FlinchExitBaseDuration = 1f; // TODO: reconstruct constant (_DAT_18252cb64)
		private const float PowerAttackInterval = 0.1f; // TODO: reconstruct constant (_DAT_18252ccfc)
		private const float FlinchOverlapRadius = 1f; // TODO: reconstruct constant (_UNK_18252cd2c)

		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__18 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant140Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__18(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant140Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (plant != null && plant._animator != null)
					{
						// Play the attack animation, then wait one attack interval before firing.
						plant._animator.Play(AttackAnimName);
						if (plant.attr != null)
						{
							_003C_003E2__current = new WaitForSeconds(plant.attr.attackIntervalTime * AttackWaitMultiplier);
							_003C_003E1__state = 1;
							return true;
						}
					}
					return false;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant != null && plant.bulletPosition != null)
				{
					// Spawn the projectile at the configured muzzle transform.
					plant.CreateBullet(0, plant.bulletPosition.position);
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CChangeSleepStateCoroutine_003Ed__14 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant140Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CChangeSleepStateCoroutine_003Ed__14(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant140Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (plant != null)
					{
						// TODO: the original yielded the compiler-generated base-call wrapper
						// (<>n__0 => base.ChangeSleepStateCoroutine()), which is absent from the
						// authoritative skeleton and cannot be referenced. Yield one frame in
						// its place so the two-phase structure (base sleep swap, then flinch
						// animation overlay) is preserved.
						_003C_003E2__current = null;
						_003C_003E1__state = 1;
						return true;
					}
					return false;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null || !plant._isFlinch)
				{
					return false;
				}
				if (plant.partEntity != null && plant._animator != null)
				{
					// While flinching, overlay the flinch variant of the sleep / awake state.
					if (!plant.partEntity.isSleeping)
					{
						plant._animator.Play(FlinchAwakeAnimName);
					}
					else
					{
						plant._animator.Play(FlinchSleepAnimName);
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CCheckFlinch_003Ed__10 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant140Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CCheckFlinch_003Ed__10(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant140Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null || plant._flinchZombieList == null)
				{
					return false;
				}
				// Rebuild the list of zombies inside the flinch radius each tick.
				plant._flinchZombieList.Clear();
				Vector2 center = plant.transform.position;
				int mask = LayerMask.GetMask(FlinchLayerName);
				Collider2D[] hits = Physics2D.OverlapCircleAll(center, FlinchOverlapRadius, mask);
				if (hits != null)
				{
					for (int i = 0; i < hits.Length; i++)
					{
						Collider2D col = hits[i];
						if (col == null)
						{
							continue;
						}
						ZombieEntity zombie = col.gameObject.GetComponent<ZombieEntity>();
						if (zombie != null && plant._flinchZombieList != null)
						{
							plant._flinchZombieList.Add(zombie);
						}
					}
					if (plant._flinchZombieList != null)
					{
						// Enter/exit the flinch pose depending on whether any zombie is close,
						// bounded by the strengthen counter and the power-active flag.
						if (plant._strengthen31Number < 3 && !plant._strengthen30Flag && plant._flinchZombieList.Count > 0)
						{
							plant.StartCoroutine(plant.EnterFlinch());
						}
						else
						{
							plant.StartCoroutine(plant.ExitFlinch());
						}
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CEnterFlinch_003Ed__12 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant140Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEnterFlinch_003Ed__12(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant140Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null)
				{
					return false;
				}
				if (!plant._isFlinch)
				{
					plant._isFlinch = true;
					if (plant._animator != null)
					{
						plant._animator.Play(EnterFlinchAnimName);
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CExitFlinch_003Ed__13 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant140Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CExitFlinch_003Ed__13(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant140Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (plant == null || !plant._isFlinch)
					{
						return false;
					}
					if (plant._animator != null)
					{
						// Scale the exit wait by the current animator speed so the recovery
						// lines up with the animation's playback rate.
						float duration = FlinchExitBaseDuration;
						float speed = plant._animator.speed;
						if (speed > 0f)
						{
							duration = FlinchExitBaseDuration / speed;
						}
						plant._animator.Play(ExitFlinchAnimName);
						_003C_003E2__current = new WaitForSeconds(duration);
						_003C_003E1__state = 1;
						return true;
					}
					return false;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant != null)
				{
					plant._isFlinch = false;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__20 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant140Entity _003C_003E4__this;

			public StrengthenEntity entity;

			private int _003Ci_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__20(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant140Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (plant == null)
					{
						return false;
					}
					// Mark the power as active so CheckFlinch won't enter the flinch pose.
					plant._strengthen30Flag = true;
					// Wait until any current flinch has cleared before starting the barrage.
					if (plant._isFlinch)
					{
						_003C_003E2__current = null;
						_003C_003E1__state = 1;
						return true;
					}
					_003Ci_003E5__2 = 0;
				}
				else if (num == 1)
				{
					_003C_003E1__state = -1;
					if (plant == null)
					{
						return false;
					}
					if (plant._isFlinch)
					{
						_003C_003E2__current = null;
						_003C_003E1__state = 1;
						return true;
					}
					_003Ci_003E5__2 = 0;
				}
				else
				{
					if (num != 2)
					{
						return false;
					}
					_003C_003E1__state = -1;
					if (plant == null)
					{
						return false;
					}
					plant.StartCoroutine(plant.AttackCoroutine());
					_003Ci_003E5__2++;
				}
				if (entity != null)
				{
					// Fire a total of GetValue() volleys, one every PowerAttackInterval seconds.
					if (_003Ci_003E5__2 < (int)entity.GetValue(plant))
					{
						_003C_003E2__current = new WaitForSeconds(PowerAttackInterval);
						_003C_003E1__state = 2;
						return true;
					}
					plant._strengthen30Flag = false;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__21 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant140Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__21(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant140Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null || plant.attr == null || plant.defaultAttr == null || entity == null)
				{
					return false;
				}
				// Add the strengthen value onto the current attack speed and register the
				// matching attribute label, then bump the applied-strengthen counter.
				float value = entity.GetValue(plant);
				plant.attr.AttackSpeed = value * plant.defaultAttr.attackSpeed + plant.attr.attackSpeed;
				plant.attr.AddLabel(entity.title, 1, entity.GetDesc(plant));
				plant._strengthen31Number++;
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("子弹位置")]
		public Transform bulletPosition;

		[Tooltip("是否检查畏缩")]
		public bool isCheckFlinch;

		private bool _isFlinch;

		private float _flinchTime;

		private float _flinchTimer;

		private List<ZombieEntity> _flinchZombieList;

		private bool _strengthen30Flag;

		private int _strengthen31Number;

		public override void Reset()
		{
			base.Reset();
			_isFlinch = false;
		}

		protected override void Update()
		{
			base.Update();
			if (partEntity == null)
			{
				return;
			}
			// Only run the flinch scan while awake and when flinch checking is enabled.
			if (!partEntity.isSleeping && isCheckFlinch)
			{
				_flinchTimer += Time.deltaTime;
				if (_flinchTimer >= _flinchTime)
				{
					_flinchTimer = 0f;
					StartCoroutine(CheckFlinch());
				}
			}
		}

		[IteratorStateMachine(typeof(_003CCheckFlinch_003Ed__10))]
		private IEnumerator CheckFlinch()
		{
			return new _003CCheckFlinch_003Ed__10(0)
			{
				_003C_003E4__this = this
			};
		}

		public void IsFlinch(bool flag)
		{
			if (flag)
			{
				StartCoroutine(EnterFlinch());
			}
			else
			{
				StartCoroutine(ExitFlinch());
			}
		}

		[IteratorStateMachine(typeof(_003CEnterFlinch_003Ed__12))]
		private IEnumerator EnterFlinch()
		{
			return new _003CEnterFlinch_003Ed__12(0)
			{
				_003C_003E4__this = this
			};
		}

		[IteratorStateMachine(typeof(_003CExitFlinch_003Ed__13))]
		private IEnumerator ExitFlinch()
		{
			return new _003CExitFlinch_003Ed__13(0)
			{
				_003C_003E4__this = this
			};
		}

		[IteratorStateMachine(typeof(_003CChangeSleepStateCoroutine_003Ed__14))]
		protected override IEnumerator ChangeSleepStateCoroutine()
		{
			return new _003CChangeSleepStateCoroutine_003Ed__14(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// Folded onto an empty body in the pseudocode: no per-level-0 adjustment.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// Strengthen slot 0: add (defaultAttr.attack * value) to the current attack.
				if (attr != null && defaultAttr != null)
				{
					float value = entity.GetValue(this);
					attr.attack = (int)((float)defaultAttr.attack * value) + attr.attack;
				}
			}
			else if (entity.index == 1)
			{
				// Strengthen slot 1: add (defaultAttr.attackSpeed * value) to the attack speed.
				if (attr != null && defaultAttr != null)
				{
					float value = entity.GetValue(this);
					attr.AttackSpeed = defaultAttr.attackSpeed * value + attr.attackSpeed;
				}
			}
		}

		protected override void Attack()
		{
			if (attr == null || _animator == null)
			{
				return;
			}
			// Drive the animator's attack-speed parameter, then run the fire coroutine.
			_animator.SetFloat(AttackSpeedParam, attr.attackSpeed * AttackSpeedAnimMultiplier);
			StartCoroutine(AttackCoroutine());
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__18))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__18(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			// TODO: reconstruct - beyond the "no attack while flinching" guard, the original
			// raycast-based front-zombie detection is driven by two unnamed global manager
			// singletons (config holder _DAT_182e706b8 and target holder _DAT_182e2bc20) plus
			// vtable calls on an offset-resolved entity type. None of those members exist in
			// the provided skeleton, so the detection cannot be reconstructed and this is
			// left as a conservative stub. The recoverable flinch guard is preserved.
			if (_isFlinch)
			{
				return false;
			}
			return false;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__20))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__20(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__21))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__21(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
