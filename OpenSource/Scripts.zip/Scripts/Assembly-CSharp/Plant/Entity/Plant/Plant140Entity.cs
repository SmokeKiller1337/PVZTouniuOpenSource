using System.Collections;
using System.Collections.Generic;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant140Entity : PlantEntity
	{
		private const string AttackAnimName = "Attack";
		private const string EnterFlinchAnimName = "EnterFlinch";
		private const string ExitFlinchAnimName = "ExitFlinch";
		private const string FlinchSleepAnimName = "FlinchSleep";
		private const string FlinchAwakeAnimName = "FlinchAwake";
		private const string AttackSpeedParam = "attackSpeed";
		private const string FlinchLayerName = "Zombie";
		private const float AttackSpeedAnimMultiplier = 1f;
		private const float AttackWaitMultiplier = 1f;
		private const float FlinchExitBaseDuration = 1f;
		private const float PowerAttackInterval = 0.1f;
		private const float FlinchOverlapRadius = 1f;

		[Tooltip("子弹位置")]
		public Transform bulletPosition;

		[Tooltip("是否检查畏缩")]
		public bool isCheckFlinch;

		private bool _isFlinch;

		private float _flinchTime;

		private float _flinchTimer;

		private List<ZombieEntity> _flinchZombieList;

		private bool _strengthen30Flag;

		private int _strengthen31Number;

		public override void Reset()
		{
			base.Reset();
			_isFlinch = false;
		}

		protected override void Update()
		{
			base.Update();
			if (partEntity == null)
			{
				return;
			}
			// 醒着且开启畏缩检测时才进行范围扫描
			if (!partEntity.isSleeping && isCheckFlinch)
			{
				_flinchTimer += Time.deltaTime;
				if (_flinchTimer >= _flinchTime)
				{
					_flinchTimer = 0f;
					StartCoroutine(CheckFlinch());
				}
			}
		}

		private IEnumerator CheckFlinch()
		{
			if (_flinchZombieList == null)
			{
				yield break;
			}
			// 每次重建畏缩半径内的僵尸列表
			_flinchZombieList.Clear();
			Vector2 center = transform.position;
			int mask = LayerMask.GetMask(FlinchLayerName);
			Collider2D[] hits = Physics2D.OverlapCircleAll(center, FlinchOverlapRadius, mask);
			if (hits != null)
			{
				for (int i = 0; i < hits.Length; i++)
				{
					Collider2D col = hits[i];
					if (col == null)
					{
						continue;
					}
					ZombieEntity zombie = col.gameObject.GetComponent<ZombieEntity>();
					if (zombie != null && _flinchZombieList != null)
					{
						_flinchZombieList.Add(zombie);
					}
				}
				if (_flinchZombieList != null)
				{
					// 根据附近是否有僵尸进入/退出畏缩，受强化计数与技能激活标志限制
					if (_strengthen31Number < 3 && !_strengthen30Flag && _flinchZombieList.Count > 0)
					{
						StartCoroutine(EnterFlinch());
					}
					else
					{
						StartCoroutine(ExitFlinch());
					}
				}
			}
		}

		public void IsFlinch(bool flag)
		{
			if (flag)
			{
				StartCoroutine(EnterFlinch());
			}
			else
			{
				StartCoroutine(ExitFlinch());
			}
		}

		private IEnumerator EnterFlinch()
		{
			if (!_isFlinch)
			{
				_isFlinch = true;
				if (_animator != null)
				{
					_animator.Play(EnterFlinchAnimName);
				}
			}
			yield break;
		}

		private IEnumerator ExitFlinch()
		{
			if (!_isFlinch)
			{
				yield break;
			}
			if (_animator != null)
			{
				// 退出等待时长按动画播放速度缩放，使恢复与动画节奏对齐
				float duration = FlinchExitBaseDuration;
				float speed = _animator.speed;
				if (speed > 0f)
				{
					duration = FlinchExitBaseDuration / speed;
				}
				_animator.Play(ExitFlinchAnimName);
				yield return new WaitForSeconds(duration);
				_isFlinch = false;
			}
		}

		protected override IEnumerator ChangeSleepStateCoroutine()
		{
			yield return null;
			if (!_isFlinch)
			{
				yield break;
			}
			if (partEntity != null && _animator != null)
			{
				// 畏缩状态下叠加睡眠/苏醒的畏缩变体动画
				if (!partEntity.isSleeping)
				{
					_animator.Play(FlinchAwakeAnimName);
				}
				else
				{
					_animator.Play(FlinchSleepAnimName);
				}
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// 强化槽 0：在当前攻击力上追加 defaultAttr.attack * value
				if (attr != null && defaultAttr != null)
				{
					float value = entity.GetValue(this);
					attr.attack = (int)((float)defaultAttr.attack * value) + attr.attack;
				}
			}
			else if (entity.index == 1)
			{
				// 强化槽 1：在攻击速度上追加 defaultAttr.attackSpeed * value
				if (attr != null && defaultAttr != null)
				{
					float value = entity.GetValue(this);
					attr.AttackSpeed = defaultAttr.attackSpeed * value + attr.attackSpeed;
				}
			}
		}

		protected override void Attack()
		{
			if (attr == null || _animator == null)
			{
				return;
			}
			// 设置动画攻速参数后启动开火协程
			_animator.SetFloat(AttackSpeedParam, attr.attackSpeed * AttackSpeedAnimMultiplier);
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			if (_animator != null)
			{
				// 播放攻击动画，等待一个攻击间隔后再发射
				_animator.Play(AttackAnimName);
				if (attr != null)
				{
					yield return new WaitForSeconds(attr.attackIntervalTime * AttackWaitMultiplier);
					if (bulletPosition != null)
					{
						// 在配置的枪口位置生成子弹
						CreateBullet(0, bulletPosition.position);
					}
				}
			}
		}

		protected override bool CheckAttack()
		{
			if (_isFlinch)
			{
				return false;
			}
			return false;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 标记技能激活，避免 CheckFlinch 进入畏缩姿态
			_strengthen30Flag = true;
			// 等待当前畏缩结束后再开始连射
			while (_isFlinch)
			{
				yield return null;
			}
			// 共发射 GetValue() 轮，每 PowerAttackInterval 秒一次
			for (int i = 0; entity != null && i < (int)entity.GetValue(this); i++)
			{
				yield return new WaitForSeconds(PowerAttackInterval);
				StartCoroutine(AttackCoroutine());
			}
			if (entity != null)
			{
				_strengthen30Flag = false;
			}
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			if (attr == null || defaultAttr == null || entity == null)
			{
				yield break;
			}
			// 将强化值叠加到当前攻速，登记对应属性标签，并累加已应用强化计数
			float value = entity.GetValue(this);
			attr.AttackSpeed = value * defaultAttr.attackSpeed + attr.attackSpeed;
			attr.AddLabel(entity.title, 1, entity.GetDesc(this));
			_strengthen31Number++;
		}
	}
}
