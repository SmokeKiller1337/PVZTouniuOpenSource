using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Game.Entity;
using Game.Util;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant50Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CExplosion_003Ed__30 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant50Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CExplosion_003Ed__30(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant50Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (plant == null || plant._isExplosion)
					{
						return false;
					}
					// _isExplosion (0x147) / _isRise (0x144) bookkeeping and attr flag at 0x1c.
					if (plant.attr != null)
					{
						plant.attr.isInvincible = true;
					}
					plant._isExplosion = true;
					plant._isRise = false;

					// TODO: reconstruct - the original body here fired a Cinemachine impulse
					// (via an unresolved global impulse-source singleton), spawned the
					// explosionEffect at the plant position, ran an AoE damage pass through
					// DamageUtils.Explosion using a layer mask built from an unresolvable
					// layer-name string literal, applied the resulting damage to each hit body,
					// and optionally produced sun via RewardManager.Instance.CreateSun. Those
					// paths depend on data-pointer string literals / a manager member that
					// cannot be recovered from the dump, so the visual + damage pass is dropped
					// and only the coroutine's frame-yield structure and the state bookkeeping
					// below are reconstructed faithfully.

					// _extraExplosionCount (0x26 -> 0x130) drives repeat explosions.
					if (plant._extraExplosionCount >= 1)
					{
						plant._extraExplosionCount--;
						StrengthenEntity se = plant.GetStrengthenEntity(3, 1);
						if (se != null && plant.attr != null)
						{
							plant.attr.ReduceLabel(se.title, 1);
							plant._isRise = true;
						}
					}

					// Prune any dead / null targets that were collected while rising.
					if (plant._targetList != null)
					{
						plant._targetList = plant._targetList.FindAll((ZombieEntity z) => z != null);
					}

					// yield return null; (wait one frame before finishing)
					_003C_003E2__current = null;
					_003C_003E1__state = 1;
					return true;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant != null)
				{
					plant._isExplosion = false;
					plant._explosionCoroutine = null;
					if (plant.attr != null)
					{
						plant.attr.isInvincible = false;
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__33 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant50Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__33(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant50Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (plant == null || plant.attr == null)
					{
						return false;
					}
					// attr flag at 0x18 raised while the power runs.
					plant.attr.isInvincible = true;
					// _isPreparation (0x134): if still preparing, kick off the preparation-end
					// coroutine and pause one interval before continuing.
					if (plant._isPreparation)
					{
						plant.StartCoroutine(plant.PreparationEnd());
						_003C_003E2__current = new WaitForSeconds(1f);
						_003C_003E1__state = 1;
						return true;
					}
				}
				else
				{
					if (num != 1)
					{
						return false;
					}
					_003C_003E1__state = -1;
					if (plant == null)
					{
						return false;
					}
				}
				// _isBigExplosion (0x146) enabled, then trigger a fresh Explosion coroutine.
				plant._isBigExplosion = true;
				plant.StartCoroutine(plant.Explosion());
				if (plant.attr != null)
				{
					plant.attr.isInvincible = false;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__34 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public StrengthenEntity entity;

			public Plant50Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__34(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				if (_003C_003E1__state != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				Plant50Entity plant = _003C_003E4__this;
				if (entity != null && plant != null)
				{
					int add = (int)entity.GetValue(plant, 0);
					// _extraExplosionCount (0x130) is boosted by the strengthen value.
					plant._extraExplosionCount += add;
					if (plant.attr != null)
					{
						string desc = entity.GetDesc(plant);
						plant.attr.AddLabel(entity.title, add, desc);
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CPreparationEnd_003Ed__29 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant50Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CPreparationEnd_003Ed__29(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant50Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (plant == null)
					{
						return false;
					}
					// _isPreparation (0x134) cleared: the plant has finished preparing.
					plant._isPreparation = false;
					if (plant._animator != null)
					{
						// TODO: reconstruct - the rise animation state name is a data pointer
						// in the pseudocode and could not be resolved to its literal string.
						// plant._animator.Play(<RiseAnimName>);

						// Spawn the "rise from soil" effect at the plant position.
						GameUtils.CreateEffect(plant.riseEffect, plant.transform.position, Quaternion.identity);
						_003C_003E2__current = new WaitForSeconds(1f);
						_003C_003E1__state = 1;
						return true;
					}
				}
				else
				{
					if (num != 1)
					{
						return false;
					}
					_003C_003E1__state = -1;
					if (plant != null)
					{
						// _isRise (0x144) set, attr flag at 0x19 lowered once risen.
						plant._isRise = true;
						if (plant.attr != null)
						{
							plant.attr.isNotEat = false;
						}
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("出土效果")]
		public EffectEntity riseEffect;

		[Tooltip("爆炸效果")]
		public EffectEntity explosionEffect;

		private int _extraExplosionCount;

		private bool _isPreparation;

		private float _preparationTime;

		private float _preparationTimer;

		private float _checkDistanceTimer;

		private bool _isRise;

		private bool _isSun;

		private bool _isBigExplosion;

		private bool _isExplosion;

		private List<ZombieEntity> _targetList;

		private Coroutine _explosionCoroutine;

		public bool IsPreparation
		{
			get
			{
				return _isPreparation;
			}
			set
			{
				_isPreparation = value;
			}
		}

		public float PreparationTime
		{
			get
			{
				return _preparationTime;
			}
			set
			{
				_preparationTime = value;
			}
		}

		public float PreparationTimer
		{
			get
			{
				return _preparationTimer;
			}
			set
			{
				_preparationTimer = value;
			}
		}

		public override void Reset()
		{
			base.Reset();
			if (attr == null)
			{
				return;
			}
			// _preparationTime (0x138) seeded from the base attribute value.
			_preparationTime = attr.GetValue(this, 0);
			_preparationTimer = 0f;
			_isPreparation = true;
			_isRise = false;
			if (_targetList != null)
			{
				int count = _targetList.Count;
				_targetList.Clear();
				// (the original also cleared the list's version counter; List.Clear covers it)
				_ = count;
				if (_animator != null)
				{
					// TODO: reconstruct - the idle/prepare animation state name is a data
					// pointer in the pseudocode and could not be resolved to its literal.
					// _animator.Play(<PrepareAnimName>);
					_checkDistanceTimer = 0f;
					_isSun = false;
					_isBigExplosion = false;
					_extraExplosionCount = 0;
					_isExplosion = false;
					_explosionCoroutine = null;
				}
			}
		}

		protected override void Update()
		{
			base.Update();
			// _isPreparation (0x134): advance the preparation timer and finish once elapsed.
			if (_isPreparation)
			{
				_preparationTimer += Time.deltaTime;
				if (_preparationTimer >= _preparationTime)
				{
					StartCoroutine(PreparationEnd());
				}
			}
			// _isRise (0x144): once risen, tick the distance check and drive explosions.
			if (!_isRise)
			{
				return;
			}
			_checkDistanceTimer += Time.deltaTime;
			if (_checkDistanceTimer > 1f)
			{
				_checkDistanceTimer = 0f;
				CheckDistance();
			}
			if (_targetList == null)
			{
				return;
			}
			// Count live targets; if any are present, kick off (once) the explosion coroutine.
			int liveTargets = 0;
			foreach (ZombieEntity target in _targetList)
			{
				if (target != null)
				{
					liveTargets++;
				}
			}
			if (liveTargets >= 1 && _explosionCoroutine == null)
			{
				_explosionCoroutine = StartCoroutine(Explosion());
			}
		}

		private void CheckDistanceUpdate()
		{
			// _checkDistanceTimer (0x140): accumulate deltaTime, run the check once per interval.
			_checkDistanceTimer += Time.deltaTime;
			if (_checkDistanceTimer > 1f)
			{
				_checkDistanceTimer = 0f;
				CheckDistance();
			}
		}

		private void CheckDistance()
		{
			// TODO: reconstruct - this method performed two OverlapCircle scans
			// (GameUtils.OverlapCircleAll) against a layer mask built from an unresolvable
			// layer-name string literal, then played one of three animator states chosen by
			// unresolved data-pointer state names depending on how close a zombie was. Both
			// the layer name and the animator state names are data pointers that cannot be
			// recovered from the dump, so the body is left stubbed rather than fabricated.
		}

		public override void HitEat(float value, ZombieEntity zombieEntity)
		{
			base.HitEat(value, zombieEntity);
			// Only react to being eaten once risen (_isRise at 0x144).
			if (!_isRise)
			{
				return;
			}
			if (zombieEntity == null)
			{
				return;
			}
			if (_targetList == null)
			{
				return;
			}
			// Track the biting zombie, then ensure the explosion coroutine is running.
			if (!_targetList.Contains(zombieEntity))
			{
				_targetList.Add(zombieEntity);
			}
			if (_explosionCoroutine == null)
			{
				_explosionCoroutine = StartCoroutine(Explosion());
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// ICF-folded onto an empty body in the dump; no level-0 behaviour.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			// entity.index (0x10): index 1 flips the "produce sun" flag; index 0 rescales
			// the preparation time from the base attributes.
			if (entity.index != 0)
			{
				if (entity.index == 1)
				{
					_isSun = true;
				}
				return;
			}
			// TODO: reconstruct - the index-0 branch rescaled attr.valueList[0] by
			// (defaultAttr.GetValue * entity.GetValue) and refreshed _preparationTime.
			// The target value member is accessed purely by raw offset (attr.valueList[0]
			// at +0x20) and cannot be mapped to a named member with certainty, so the
			// rescale is dropped and only _preparationTime is refreshed from attr.
			if (attr != null)
			{
				_preparationTime = attr.GetValue(this, 0);
			}
		}

		[IteratorStateMachine(typeof(_003CPreparationEnd_003Ed__29))]
		public IEnumerator PreparationEnd()
		{
			return new _003CPreparationEnd_003Ed__29(0)
			{
				_003C_003E4__this = this
			};
		}

		[IteratorStateMachine(typeof(_003CExplosion_003Ed__30))]
		public IEnumerator Explosion()
		{
			return new _003CExplosion_003Ed__30(0)
			{
				_003C_003E4__this = this
			};
		}

		public override void OnTriggerCustomEnter(Collider2D col, int index)
		{
			base.OnTriggerCustomEnter(col, index);
			// TODO: reconstruct - the original resolved a zombie-body component off the
			// collider's GameObject (GetComponent of an unresolved component type), compared
			// its tag against an unresolvable tag literal, then read the owning ZombieEntity
			// from that component (raw offset +0x30) and added it to _targetList. The
			// component type and the member at +0x30 are data pointers that cannot be
			// recovered from the dump, so the collection is left stubbed.
		}

		public override void OnTriggerCustomExit(Collider2D col, int index)
		{
			base.OnTriggerCustomExit(col, index);
			// TODO: reconstruct - mirrors OnTriggerCustomEnter: it resolved the same
			// unresolved zombie-body component, read the owning ZombieEntity (raw offset
			// +0x30) and removed it from _targetList. The component type / member cannot be
			// recovered from the dump, so the removal is left stubbed.
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__33))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__33(0)
			{
				_003C_003E4__this = this
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__34))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__34(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
