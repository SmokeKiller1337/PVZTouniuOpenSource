using System;
using System.Collections;
using System.Collections.Generic;
using Game.Entity;
using Game.Util;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant50Entity : PlantEntity
	{
		[Tooltip("出土效果")]
		public EffectEntity riseEffect;

		[Tooltip("爆炸效果")]
		public EffectEntity explosionEffect;

		private int _extraExplosionCount;

		private bool _isPreparation;

		private float _preparationTime;

		private float _preparationTimer;

		private float _checkDistanceTimer;

		private bool _isRise;

		private bool _isSun;

		private bool _isBigExplosion;

		private bool _isExplosion;

		private List<ZombieEntity> _targetList;

		private Coroutine _explosionCoroutine;

		public bool IsPreparation
		{
			get
			{
				return _isPreparation;
			}
			set
			{
				_isPreparation = value;
			}
		}

		public float PreparationTime
		{
			get
			{
				return _preparationTime;
			}
			set
			{
				_preparationTime = value;
			}
		}

		public float PreparationTimer
		{
			get
			{
				return _preparationTimer;
			}
			set
			{
				_preparationTimer = value;
			}
		}

		public override void Reset()
		{
			base.Reset();
			if (attr == null)
			{
				return;
			}
			// 从基础属性读取准备时间，并进入准备状态
			_preparationTime = attr.GetValue(this, 0);
			_preparationTimer = 0f;
			_isPreparation = true;
			_isRise = false;
			if (_targetList != null)
			{
				int count = _targetList.Count;
				_targetList.Clear();
				_ = count;
				if (_animator != null)
				{
					_checkDistanceTimer = 0f;
					_isSun = false;
					_isBigExplosion = false;
					_extraExplosionCount = 0;
					_isExplosion = false;
					_explosionCoroutine = null;
				}
			}
		}

		protected override void Update()
		{
			base.Update();
			// 准备阶段：累计计时，到点后结束准备
			if (_isPreparation)
			{
				_preparationTimer += Time.deltaTime;
				if (_preparationTimer >= _preparationTime)
				{
					StartCoroutine(PreparationEnd());
				}
			}
			// 出土后才进行距离检测并驱动爆炸
			if (!_isRise)
			{
				return;
			}
			_checkDistanceTimer += Time.deltaTime;
			if (_checkDistanceTimer > 1f)
			{
				_checkDistanceTimer = 0f;
				CheckDistance();
			}
			if (_targetList == null)
			{
				return;
			}
			// 统计存活目标，若有目标且爆炸协程未运行则启动
			int liveTargets = 0;
			foreach (ZombieEntity target in _targetList)
			{
				if (target != null)
				{
					liveTargets++;
				}
			}
			if (liveTargets >= 1 && _explosionCoroutine == null)
			{
				_explosionCoroutine = StartCoroutine(Explosion());
			}
		}

		private void CheckDistanceUpdate()
		{
			// 每隔一秒执行一次距离检测
			_checkDistanceTimer += Time.deltaTime;
			if (_checkDistanceTimer > 1f)
			{
				_checkDistanceTimer = 0f;
				CheckDistance();
			}
		}

		private void CheckDistance()
		{
		}

		public override void HitEat(float value, ZombieEntity zombieEntity)
		{
			base.HitEat(value, zombieEntity);
			// 只有出土后才响应被啃咬
			if (!_isRise)
			{
				return;
			}
			if (zombieEntity == null)
			{
				return;
			}
			if (_targetList == null)
			{
				return;
			}
			// 记录啃咬的僵尸，并确保爆炸协程在运行
			if (!_targetList.Contains(zombieEntity))
			{
				_targetList.Add(zombieEntity);
			}
			if (_explosionCoroutine == null)
			{
				_explosionCoroutine = StartCoroutine(Explosion());
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			// index 为 1 时开启产阳光，为 0 时按基础属性重算准备时间
			if (entity.index != 0)
			{
				if (entity.index == 1)
				{
					_isSun = true;
				}
				return;
			}
			if (attr != null)
			{
				_preparationTime = attr.GetValue(this, 0);
			}
		}

		public IEnumerator PreparationEnd()
		{
			if (this == null)
			{
				yield break;
			}
			// 结束准备状态
			_isPreparation = false;
			if (_animator != null)
			{
				// 在植物位置生成出土特效
				GameUtils.CreateEffect(riseEffect, transform.position, Quaternion.identity);
				yield return new WaitForSeconds(1f);
				if (this != null)
				{
					// 出土完成，重新允许被啃咬
					_isRise = true;
					if (attr != null)
					{
						attr.isNotEat = false;
					}
				}
			}
		}

		public IEnumerator Explosion()
		{
			if (this == null || _isExplosion)
			{
				yield break;
			}
			if (attr != null)
			{
				attr.isInvincible = true;
			}
			_isExplosion = true;
			_isRise = false;
			// 额外爆炸次数驱动重复爆炸
			if (_extraExplosionCount >= 1)
			{
				_extraExplosionCount--;
				StrengthenEntity se = GetStrengthenEntity(3, 1);
				if (se != null && attr != null)
				{
					attr.ReduceLabel(se.title, 1);
					_isRise = true;
				}
			}
			// 清理出土期间收集到的空目标
			if (_targetList != null)
			{
				_targetList = _targetList.FindAll((ZombieEntity z) => z != null);
			}
			// 等待一帧再结束
			yield return null;
			if (this != null)
			{
				_isExplosion = false;
				_explosionCoroutine = null;
				if (attr != null)
				{
					attr.isInvincible = false;
				}
			}
		}

		public override void OnTriggerCustomEnter(Collider2D col, int index)
		{
			base.OnTriggerCustomEnter(col, index);
		}

		public override void OnTriggerCustomExit(Collider2D col, int index)
		{
			base.OnTriggerCustomExit(col, index);
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			if (this == null || attr == null)
			{
				yield break;
			}
			attr.isInvincible = true;
			// 若仍在准备中，先触发准备结束并等待一段时间
			if (_isPreparation)
			{
				StartCoroutine(PreparationEnd());
				yield return new WaitForSeconds(1f);
				if (this == null)
				{
					yield break;
				}
			}
			// 开启大爆炸并触发一次爆炸协程
			_isBigExplosion = true;
			StartCoroutine(Explosion());
			if (attr != null)
			{
				attr.isInvincible = false;
			}
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			if (entity != null && this != null)
			{
				int add = (int)entity.GetValue(this, 0);
				// 强化值提升额外爆炸次数
				_extraExplosionCount += add;
				if (attr != null)
				{
					string desc = entity.GetDesc(this);
					attr.AddLabel(entity.title, add, desc);
				}
			}
			yield break;
		}
	}
}
