using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Game.Entity;
using Game.Util;
using Level.Util;
using NoSLoofah.BuffSystem;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

// NOTE: Reconstructed from IL2CPP/Ghidra output for Plant.Entity.Plant.Plant155Entity.
// The structure below (namespace, usings, class/base, fields, method signatures, nested
// iterator classes) is taken verbatim from the authoritative stub.cs / dump.cs; only the
// method bodies (and the coroutine MoveNext state machines) were filled in.
//
// Field-offset map (from dump.cs, relative to the object):
//   Plant155Entity:  effectEntity @0x120  buff3ValueList @0x128  OnExplosionAction @0x130
// Inherited (PlantEntity / BaseBody), confirmed against the reconstructed base sources:
//   attr @0xE0 (PlantBaseAttr)   defaultAttr @0xE8   partEntity @0x100 (PlantPartEntity)
//   _animator @0x78              BuffHandler @0x88
// PlantBaseAttr layout used below: attack @0x20, attackSpeed @0x28,
//   attackIntervalTime @0x2C, attackIntervalTimer @0x30, valueList @0x38.
// ValueEntity.baseValue @0x20. StrengthenEntity.index @0x10, GetValue(PlantEntity,int).
//
// A few call sites in the pseudocode dereference members that are NOT named in any
// authoritative dump (a ZombieEntity bool at raw offset 0x36, a ZombieEntity virtual at
// vtable 0x238, and DOTween's DOVirtual.DelayedCall targeting an unresolved virtual slot).
// Per the reconstruction rules those are left out with a "// TODO: reconstruct" note rather
// than invented, while every member that IS referenced was verified to exist in
// Assembly-CSharp with the signature used here.

namespace Plant.Entity.Plant
{
	public class Plant155Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__10 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant155Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__10(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant155Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null || plant.attr == null)
				{
					return false;
				}
				// Spawn the plant's effect at its current position.
				Transform t = plant.transform;
				if (t == null)
				{
					return false;
				}
				GameUtils.CreateEffect(plant.effectEntity, t.position, Quaternion.identity);
				// Apply the acceleration buff (id 3) to every zombie on the lanes and clear the
				// two conflicting slow/stun buffs (ids 5 and 6) first.
				List<ZombieEntity> zombieList = LevelUtils.GetLandZombieList();
				if (zombieList == null)
				{
					return false;
				}
				foreach (ZombieEntity zombie in zombieList)
				{
					if (zombie == null || !zombie.CompareTag(ZombieTag))
					{
						continue;
					}
					// TODO: reconstruct — the pseudocode skips zombies for which a ZombieEntity
					// bool at raw offset 0x36 is set (no member name in any authoritative dump),
					// so that skip-guard is omitted here.
					BuffHandler buffHandler = zombie.BuffHandler;
					if (buffHandler == null)
					{
						continue;
					}
					if (buffHandler.HasBuff(5))
					{
						buffHandler.RemoveBuff(5);
					}
					if (buffHandler.HasBuff(6))
					{
						buffHandler.RemoveBuff(6);
					}
					// buff3ValueList[0].baseValue carries the buff duration value (attr value #1).
					plant.buff3ValueList[0].baseValue = plant.attr.GetValue(plant, 1);
					buffHandler.AddBuff(3, plant.gameObject, plant.attr.GetValue(plant, 0), plant.buff3ValueList);
					// TODO: reconstruct — the pseudocode then set DamageTypeEntity.Explosion.deathType
					// and invoked a ZombieEntity virtual at vtable 0x238 (no member name available);
					// that per-zombie call is omitted here.
				}
				// Notify explosion listeners with the affected zombie list.
				if (plant.OnExplosionAction != null)
				{
					plant.OnExplosionAction(zombieList);
				}
				// TODO: reconstruct — a trailing virtual call on the plant (vtable 0x278) could not
				// be resolved to a named member and is omitted.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CChangeSleepStateCoroutine_003Ed__6 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant155Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CChangeSleepStateCoroutine_003Ed__6(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant155Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (plant == null)
					{
						return false;
					}
					// Wait one frame before applying the awake/sleep transition.
					// (The pseudocode yields a nested wait iterator; a single-frame yield
					// preserves the observable two-phase behaviour.)
					_003C_003E2__current = null;
					_003C_003E1__state = 1;
					return true;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null || plant.partEntity == null)
				{
					return false;
				}
				// When awake, mark the plant invincible while the wake animation plays.
				if (!plant.partEntity.isSleeping && plant.attr != null)
				{
					plant.attr.isInvincible = true;
					// TODO: reconstruct — the pseudocode then scheduled a DOVirtual.DelayedCall
					// to a virtual slot (0x430) that could not be resolved; it is omitted here.
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__12 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant155Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__12(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant155Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				// Scale attribute value #2 by the strengthen value against the default value #2.
				if (plant == null || plant.attr == null || plant.attr.valueList == null || plant.attr.valueList.Count <= 2)
				{
					return false;
				}
				ValueEntity current = plant.attr.valueList[2];
				if (plant.defaultAttr == null || plant.defaultAttr.valueList == null || plant.defaultAttr.valueList.Count <= 2)
				{
					return false;
				}
				ValueEntity defaultValue = plant.defaultAttr.valueList[2];
				if (entity == null)
				{
					return false;
				}
				current.baseValue = entity.GetValue(plant, 0) * defaultValue.baseValue + current.baseValue;
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__13 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant155Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__13(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant155Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				// Add (defaultAttr.attack * strengthenValue) to the current attack.
				if (plant == null || plant.attr == null || plant.defaultAttr == null || entity == null)
				{
					return false;
				}
				plant.attr.attack = (int)((float)plant.defaultAttr.attack * entity.GetValue(plant, 0)) + plant.attr.attack;
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("特效")]
		public EffectEntity effectEntity;

		[Tooltip("加速Buff值集合")]
		public List<ValueEntity> buff3ValueList;

		public Action<List<ZombieEntity>> OnExplosionAction;

		// TODO: the zombie tag string is a data pointer in the pseudocode; "Zombie" is the
		// conventional PvZ tag but the literal could not be recovered from the dump.
		private const string ZombieTag = "Zombie";

		// TODO: the attack-animator float parameter name and the attack-speed frame-rate
		// multiplier are unresolved data pointers / globals in the pseudocode.
		private const string AttackSpeedAnimParam = "AttackSpeed";

		private const float AttackSpeedFrameRate = 30f;

		public override void Reset()
		{
			base.Reset();
			if (partEntity == null)
			{
				return;
			}
			// TODO: reconstruct — when the plant is awake the pseudocode also scheduled a
			// DOVirtual.DelayedCall to an unresolved virtual slot (0x430); that DOTween call
			// is omitted here because its target could not be named reliably.
			CardEntity card = CardEntity;
			if (card != null && LevelUtils.GetCard(card.id) != null && card.IsAvailablePower())
			{
				UsePower();
			}
		}

		protected override void Start()
		{
			base.Start();
			// Fresh (non-sleeping) plants start out invincible until the wake sequence finishes.
			if (partEntity != null && !partEntity.isSleeping && attr != null)
			{
				attr.isInvincible = true;
			}
		}

		protected override void Update()
		{
			base.Update();
			if (partEntity == null || partEntity.isSleeping)
			{
				return;
			}
			// Attack-interval accumulator: fire an attack once the interval elapses.
			if (attr != null && attr.attackIntervalTime > 0f)
			{
				attr.attackIntervalTimer += Time.deltaTime;
				if (attr.attackIntervalTimer >= attr.attackIntervalTime)
				{
					attr.attackIntervalTimer = 0f;
					if (CheckAttack())
					{
						Attack();
					}
				}
			}
			EyeUpdate();
			if (isHasSpecialSkill && specialCooldownTimer > 0f)
			{
				specialCooldownTimer -= Time.deltaTime;
			}
		}

		[IteratorStateMachine(typeof(_003CChangeSleepStateCoroutine_003Ed__6))]
		protected override IEnumerator ChangeSleepStateCoroutine()
		{
			return new _003CChangeSleepStateCoroutine_003Ed__6(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// Empty in the original (RVA 0x381980 folds to a bare return).
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// Add the strengthen value to attribute value #1.
				if (attr != null && attr.valueList != null && attr.valueList.Count > 1)
				{
					ValueEntity value = attr.valueList[1];
					value.baseValue = entity.GetValue(this, 0) + value.baseValue;
				}
			}
			else if (entity.index == 1)
			{
				// Scale attribute value #0 by the strengthen value against the default value #0.
				if (attr != null && attr.valueList != null && attr.valueList.Count > 0 &&
					defaultAttr != null && defaultAttr.valueList != null && defaultAttr.valueList.Count > 0)
				{
					ValueEntity value = attr.valueList[0];
					ValueEntity defaultValue = defaultAttr.valueList[0];
					value.baseValue = entity.GetValue(this, 0) * defaultValue.baseValue + value.baseValue;
				}
			}
		}

		protected override void Attack()
		{
			if (attr == null || _animator == null)
			{
				return;
			}
			// Drive the attack animation speed from the plant's attack speed.
			_animator.SetFloat(AttackSpeedAnimParam, attr.attackSpeed * AttackSpeedFrameRate);
			IEnumerator coroutine = AttackCoroutine();
			if (CheckAttack())
			{
				StartCoroutine(coroutine);
			}
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__10))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__10(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			// Original body (RVA 0x387B60) folds to a bare "return false".
			return false;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__12))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__12(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__13))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__13(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
