using System;
using System.Collections;
using System.Collections.Generic;
using Game.Entity;
using Game.Util;
using Level.Util;
using NoSLoofah.BuffSystem;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant155Entity : PlantEntity
	{
		[Tooltip("特效")]
		public EffectEntity effectEntity;

		[Tooltip("加速Buff值集合")]
		public List<ValueEntity> buff3ValueList;

		public Action<List<ZombieEntity>> OnExplosionAction;

		private const string ZombieTag = "Zombie";

		private const string AttackSpeedAnimParam = "AttackSpeed";

		private const float AttackSpeedFrameRate = 30f;

		public override void Reset()
		{
			base.Reset();
			if (partEntity == null)
			{
				return;
			}
			CardEntity card = CardEntity;
			if (card != null && LevelUtils.GetCard(card.id) != null && card.IsAvailablePower())
			{
				UsePower();
			}
		}

		protected override void Start()
		{
			base.Start();
			// Fresh (non-sleeping) plants start out invincible until the wake sequence finishes.
			if (partEntity != null && !partEntity.isSleeping && attr != null)
			{
				attr.isInvincible = true;
			}
		}

		protected override void Update()
		{
			base.Update();
			if (partEntity == null || partEntity.isSleeping)
			{
				return;
			}
			// Attack-interval accumulator: fire an attack once the interval elapses.
			if (attr != null && attr.attackIntervalTime > 0f)
			{
				attr.attackIntervalTimer += Time.deltaTime;
				if (attr.attackIntervalTimer >= attr.attackIntervalTime)
				{
					attr.attackIntervalTimer = 0f;
					if (CheckAttack())
					{
						Attack();
					}
				}
			}
			EyeUpdate();
			if (isHasSpecialSkill && specialCooldownTimer > 0f)
			{
				specialCooldownTimer -= Time.deltaTime;
			}
		}

		protected override IEnumerator ChangeSleepStateCoroutine()
		{
			if (this == null)
			{
				yield break;
			}
			yield return null;
			if (this == null || partEntity == null)
			{
				yield break;
			}
			// When awake, mark the plant invincible while the wake animation plays.
			if (!partEntity.isSleeping && attr != null)
			{
				attr.isInvincible = true;
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// Add the strengthen value to attribute value #1.
				if (attr != null && attr.valueList != null && attr.valueList.Count > 1)
				{
					ValueEntity value = attr.valueList[1];
					value.baseValue = entity.GetValue(this, 0) + value.baseValue;
				}
			}
			else if (entity.index == 1)
			{
				// Scale attribute value #0 by the strengthen value against the default value #0.
				if (attr != null && attr.valueList != null && attr.valueList.Count > 0 &&
					defaultAttr != null && defaultAttr.valueList != null && defaultAttr.valueList.Count > 0)
				{
					ValueEntity value = attr.valueList[0];
					ValueEntity defaultValue = defaultAttr.valueList[0];
					value.baseValue = entity.GetValue(this, 0) * defaultValue.baseValue + value.baseValue;
				}
			}
		}

		protected override void Attack()
		{
			if (attr == null || _animator == null)
			{
				return;
			}
			// Drive the attack animation speed from the plant's attack speed.
			_animator.SetFloat(AttackSpeedAnimParam, attr.attackSpeed * AttackSpeedFrameRate);
			IEnumerator coroutine = AttackCoroutine();
			if (CheckAttack())
			{
				StartCoroutine(coroutine);
			}
		}

		private IEnumerator AttackCoroutine()
		{
			if (this == null || attr == null)
			{
				yield break;
			}
			// Spawn the plant's effect at its current position.
			Transform t = transform;
			if (t == null)
			{
				yield break;
			}
			GameUtils.CreateEffect(effectEntity, t.position, Quaternion.identity);
			// Apply the acceleration buff (id 3) to every zombie on the lanes and clear the
			// two conflicting slow/stun buffs (ids 5 and 6) first.
			List<ZombieEntity> zombieList = LevelUtils.GetLandZombieList();
			if (zombieList == null)
			{
				yield break;
			}
			foreach (ZombieEntity zombie in zombieList)
			{
				if (zombie == null || !zombie.CompareTag(ZombieTag))
				{
					continue;
				}
				BuffHandler buffHandler = zombie.BuffHandler;
				if (buffHandler == null)
				{
					continue;
				}
				if (buffHandler.HasBuff(5))
				{
					buffHandler.RemoveBuff(5);
				}
				if (buffHandler.HasBuff(6))
				{
					buffHandler.RemoveBuff(6);
				}
				// buff3ValueList[0].baseValue carries the buff duration value (attr value #1).
				buff3ValueList[0].baseValue = attr.GetValue(this, 1);
				buffHandler.AddBuff(3, gameObject, attr.GetValue(this, 0), buff3ValueList);
			}
			// Notify explosion listeners with the affected zombie list.
			if (OnExplosionAction != null)
			{
				OnExplosionAction(zombieList);
			}
		}

		protected override bool CheckAttack()
		{
			return false;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// Scale attribute value #2 by the strengthen value against the default value #2.
			if (this == null || attr == null || attr.valueList == null || attr.valueList.Count <= 2)
			{
				yield break;
			}
			ValueEntity current = attr.valueList[2];
			if (defaultAttr == null || defaultAttr.valueList == null || defaultAttr.valueList.Count <= 2)
			{
				yield break;
			}
			ValueEntity defaultValue = defaultAttr.valueList[2];
			if (entity == null)
			{
				yield break;
			}
			current.baseValue = entity.GetValue(this, 0) * defaultValue.baseValue + current.baseValue;
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			// Add (defaultAttr.attack * strengthenValue) to the current attack.
			if (this == null || attr == null || defaultAttr == null || entity == null)
			{
				yield break;
			}
			attr.attack = (int)((float)defaultAttr.attack * entity.GetValue(this, 0)) + attr.attack;
		}
	}
}
