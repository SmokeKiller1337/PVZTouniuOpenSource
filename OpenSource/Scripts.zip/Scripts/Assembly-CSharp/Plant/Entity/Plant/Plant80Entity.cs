using System;
using System.Collections;
using System.Collections.Generic;
using Common.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant80Entity : PlantEntity
	{
		[Tooltip("子弹位置")]
		public Transform bulletPosition;

		[Tooltip("头部物体")]
		public GameObject headObj;

		private const string AttackAnimName = "Attack";
		private const float AttackWindupFactor = 0f;
		private const float AttackRecoverFactor = 0f;
		private const float OnUsePower0Interval = 0f;

		// TODO: unresolved eye-blink interval bounds used by Reset (random-range globals).
		private const float EyeBlinkMin = 2f;
		private const float EyeBlinkMax = 6f;

		public override void Reset()
		{
			base.Reset();
			CardEntity card = CardEntity;
			if (ExtraCardEntity != null)
			{
				card = ExtraCardEntity;
			}
			title = card.title;
			defaultAttr = new PlantBaseAttr(card.plantAttr);
			priority = card.priority;
			if (partEntity == null)
			{
				return;
			}
			partEntity.sleepType = card.sleepType;
			partEntity.isEyeAnimation = card.isEyeAnimation;
			switch ((int)card.placeType)
			{
				case 0:
					addSortingOrder = 0;
					break;
				case 1:
					addSortingOrder = 2;
					break;
				case 2:
					addSortingOrder = -1;
					break;
				case 3:
					addSortingOrder = 1;
					break;
			}
			attr = new PlantBaseAttr(defaultAttr);
			attr.Reset();
			CardEntity card2 = CardEntity;
			if (card2 != null && card2.plantAttr != null)
			{
				attr.currentHealth = card2.plantAttr.currentHealth;
				partEntity.blinkTime = UnityEngine.Random.Range(EyeBlinkMin, EyeBlinkMax);
				partEntity.blinkTimer = 0f;
				partEntity.isSleeping = false;
				partEntity.isCloseEye = false;
				UpdateHealthTextField();
				if (attr.currentHealth <= 0f)
				{
					Clear();
				}
				ResetSleep();
			}
		}

		protected override void Update()
		{
			base.Update();
			if (partEntity == null)
			{
				return;
			}
			if (partEntity.isSleeping)
			{
				return;
			}
			PlantBaseAttr a = attr;
			if (a.attackIntervalTime > 0f)
			{
				a.attackIntervalTimer += Time.deltaTime;
				if (a.attackIntervalTimer >= a.attackIntervalTime)
				{
					a.attackIntervalTimer = 0f;
					if (CheckAttack())
					{
						Attack();
					}
				}
			}
			EyeUpdate();
			if (isHasSpecialSkill && specialCooldownTimer > 0f)
			{
				specialCooldownTimer -= Time.deltaTime;
			}
		}

		public override void EyeBlink()
		{
			if (partEntity == null)
			{
				return;
			}
			if (partEntity.isCloseEye)
			{
				return;
			}
			if (Animator == null)
			{
				return;
			}
			// Only blink when the blink tag is active on both animator layers.
			AnimatorStateInfo state0 = Animator.GetCurrentAnimatorStateInfo(0);
			if (!state0.IsTag(BlinkTag))
			{
				return;
			}
			AnimatorStateInfo state1 = Animator.GetCurrentAnimatorStateInfo(1);
			if (!state1.IsTag(BlinkTag))
			{
				return;
			}
			Animator.Play(EyeBlinkAnimName);
		}

		private const string BlinkTag = "Blink";
		private const string EyeBlinkAnimName = "EyeBlink";

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				if (attr != null && defaultAttr != null)
				{
					attr.attack = (int)((float)defaultAttr.attack * entity.GetValue(this)) + attr.attack;
				}
			}
			else if (entity.index == 1)
			{
				if (attr != null && defaultAttr != null)
				{
					// set_AttackSpeed applies the clamped attack-speed increment.
					attr.AttackSpeed = entity.GetValue(this) * defaultAttr.attackSpeed + attr.attackSpeed;
				}
			}
		}

		protected override void Attack()
		{
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			// 两连击：播放攻击动画 -> 前摇等待 -> 发第一发 -> 后摇等待 -> 发第二发
			if (this != null && Animator != null)
			{
				Animator.Play(AttackAnimName);
				if (attr != null)
				{
					yield return new WaitForSeconds(attr.attackIntervalTime * AttackWindupFactor);
					if (this != null && headObj != null)
					{
						if (headObj.activeSelf && bulletPosition != null)
						{
							CreateBullet(0, bulletPosition.position);
						}
						if (attr != null)
						{
							yield return new WaitForSeconds(attr.attackIntervalTime * AttackRecoverFactor);
							if (this != null && headObj != null && headObj.activeSelf)
							{
								if (bulletPosition != null)
								{
									CreateBullet(0, bulletPosition.position);
								}
							}
						}
					}
				}
			}
		}

		protected override bool CheckAttack()
		{
			return default;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 按强化数值触发多次基础攻击，每次之间固定间隔
			for (int i = 0; entity != null && i < (int)entity.GetValue(this); i++)
			{
				yield return new WaitForSeconds(OnUsePower0Interval);
				if (this == null)
				{
					yield break;
				}
				StartCoroutine(AttackCoroutine());
			}
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			// 永久提升攻击力并记录强化标签
			if (this != null && attr != null && defaultAttr != null && entity != null)
			{
				attr.attack = (int)((float)defaultAttr.attack * entity.GetValue(this)) + attr.attack;
				if (attr != null)
				{
					attr.AddLabel(entity.title, 1, entity.GetDesc(this));
				}
			}
			yield break;
		}

		public override int GetHeadNumber()
		{
			return headObj.activeSelf ? 1 : 0;
		}
	}
}
