using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant80Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__8 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant80Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__8(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// State machine for the two-shot attack:
				//   state 0: play the attack animation, wait attackIntervalTime * factor0
				//   state 1: fire the first bullet, wait attackIntervalTime * factor1
				//   state 2: fire the second bullet, finish
				int num = _003C_003E1__state;
				Plant80Entity self = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (self != null && self.Animator != null)
					{
						// TODO: the attack animation state name is a data pointer in the pseudocode.
						self.Animator.Play(AttackAnimName);
						if (self.attr != null)
						{
							// yield return new WaitForSeconds(attackIntervalTime * AttackWindupFactor);
							_003C_003E2__current = new WaitForSeconds(self.attr.attackIntervalTime * AttackWindupFactor);
							_003C_003E1__state = 1;
							return true;
						}
					}
					return false;
				}
				if (num == 1)
				{
					_003C_003E1__state = -1;
					if (self != null && self.headObj != null)
					{
						if (self.headObj.activeSelf && self.bulletPosition != null)
						{
							self.CreateBullet(0, self.bulletPosition.position);
						}
						if (self.attr != null)
						{
							// yield return new WaitForSeconds(attackIntervalTime * AttackRecoverFactor);
							_003C_003E2__current = new WaitForSeconds(self.attr.attackIntervalTime * AttackRecoverFactor);
							_003C_003E1__state = 2;
							return true;
						}
					}
					return false;
				}
				if (num != 2)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (self != null && self.headObj != null && self.headObj.activeSelf)
				{
					if (self.bulletPosition != null)
					{
						self.CreateBullet(0, self.bulletPosition.position);
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__10 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant80Entity _003C_003E4__this;

			public StrengthenEntity entity;

			private int _003Ci_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__10(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// Fires the base attack coroutine once per hit, GetValue(entity) times,
				// waiting a fixed interval between shots.
				int num = _003C_003E1__state;
				Plant80Entity self = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					_003Ci_003E5__2 = 0;
				}
				else
				{
					if (num != 1)
					{
						return false;
					}
					_003C_003E1__state = -1;
					if (self == null)
					{
						return false;
					}
					self.StartCoroutine(self.AttackCoroutine());
					_003Ci_003E5__2++;
				}
				if (entity != null && _003Ci_003E5__2 < (int)entity.GetValue(self))
				{
					// yield return new WaitForSeconds(OnUsePower0Interval);
					_003C_003E2__current = new WaitForSeconds(OnUsePower0Interval);
					_003C_003E1__state = 1;
					return true;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__11 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant80Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__11(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// Single-step power: permanently boosts attack by defaultAttr.attack * GetValue(entity)
				// and records a strengthen label on the live attr.
				if (_003C_003E1__state != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				Plant80Entity self = _003C_003E4__this;
				if (self != null && self.attr != null && self.defaultAttr != null && entity != null)
				{
					self.attr.attack = (int)((float)self.defaultAttr.attack * entity.GetValue(self)) + self.attr.attack;
					if (self.attr != null)
					{
						self.attr.AddLabel(entity.title, 1, entity.GetDesc(self));
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("子弹位置")]
		public Transform bulletPosition;

		[Tooltip("头部物体")]
		public GameObject headObj;

		// TODO: unresolved animation-state name / timing-factor globals used by the
		// attack coroutine. These were stored as data pointers / float globals in the
		// pseudocode and could not be recovered to their literal values.
		private const string AttackAnimName = "Attack"; // TODO: reconstruct literal
		private const float AttackWindupFactor = 0f; // TODO: reconstruct constant (_DAT_18252cd08)
		private const float AttackRecoverFactor = 0f; // TODO: reconstruct constant (_DAT_18252cb80)
		private const float OnUsePower0Interval = 0f; // TODO: reconstruct constant (_DAT_18252ccfc)

		// TODO: unresolved eye-blink interval bounds used by Reset (random-range globals).
		private const float EyeBlinkMin = 2f; // TODO: reconstruct constant
		private const float EyeBlinkMax = 6f; // TODO: reconstruct constant

		public override void Reset()
		{
			base.Reset();
			CardEntity card = CardEntity;
			if (ExtraCardEntity != null)
			{
				card = ExtraCardEntity;
			}
			title = card.title;
			defaultAttr = new PlantBaseAttr(card.plantAttr);
			priority = card.priority;
			if (partEntity == null)
			{
				return;
			}
			partEntity.sleepType = card.sleepType;
			partEntity.isEyeAnimation = card.isEyeAnimation;
			switch ((int)card.placeType)
			{
				case 0:
					addSortingOrder = 0;
					break;
				case 1:
					addSortingOrder = 2;
					break;
				case 2:
					addSortingOrder = -1;
					break;
				case 3:
					addSortingOrder = 1;
					break;
			}
			attr = new PlantBaseAttr(defaultAttr);
			attr.Reset();
			CardEntity card2 = CardEntity;
			if (card2 != null && card2.plantAttr != null)
			{
				attr.currentHealth = card2.plantAttr.currentHealth;
				partEntity.blinkTime = UnityEngine.Random.Range(EyeBlinkMin, EyeBlinkMax);
				partEntity.blinkTimer = 0f;
				partEntity.isSleeping = false;
				partEntity.isCloseEye = false;
				UpdateHealthTextField();
				if (attr.currentHealth <= 0f)
				{
					Clear();
				}
				ResetSleep();
			}
		}

		protected override void Update()
		{
			base.Update();
			if (partEntity == null)
			{
				return;
			}
			if (partEntity.isSleeping)
			{
				return;
			}
			PlantBaseAttr a = attr;
			if (a.attackIntervalTime > 0f)
			{
				a.attackIntervalTimer += Time.deltaTime;
				if (a.attackIntervalTimer >= a.attackIntervalTime)
				{
					a.attackIntervalTimer = 0f;
					if (CheckAttack())
					{
						Attack();
					}
				}
			}
			EyeUpdate();
			if (isHasSpecialSkill && specialCooldownTimer > 0f)
			{
				specialCooldownTimer -= Time.deltaTime;
			}
		}

		public override void EyeBlink()
		{
			if (partEntity == null)
			{
				return;
			}
			if (partEntity.isCloseEye)
			{
				return;
			}
			if (Animator == null)
			{
				return;
			}
			// Only blink when the blink tag is active on both animator layers.
			AnimatorStateInfo state0 = Animator.GetCurrentAnimatorStateInfo(0);
			if (!state0.IsTag(BlinkTag))
			{
				return;
			}
			AnimatorStateInfo state1 = Animator.GetCurrentAnimatorStateInfo(1);
			if (!state1.IsTag(BlinkTag))
			{
				return;
			}
			// TODO: eye-blink animation state name is a data pointer in the pseudocode.
			Animator.Play(EyeBlinkAnimName);
		}

		// TODO: unresolved animator tag / eye-blink state name (data pointers in the pseudocode).
		private const string BlinkTag = "Blink"; // TODO: reconstruct animator tag literal
		private const string EyeBlinkAnimName = "EyeBlink"; // TODO: reconstruct literal

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// Folded (RVA 0x3D9020) onto the shared empty method in the binary; intentionally empty.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				if (attr != null && defaultAttr != null)
				{
					attr.attack = (int)((float)defaultAttr.attack * entity.GetValue(this)) + attr.attack;
				}
			}
			else if (entity.index == 1)
			{
				if (attr != null && defaultAttr != null)
				{
					// set_AttackSpeed applies the clamped attack-speed increment.
					attr.AttackSpeed = entity.GetValue(this) * defaultAttr.attackSpeed + attr.attackSpeed;
				}
			}
		}

		protected override void Attack()
		{
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__8))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__8(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			// TODO: reconstruct — the pseudocode performs a Physics2D.RaycastAll gated on
			// several global config/manager singletons (_DAT_182e706b8, _DAT_182e2bc20,
			// _DAT_182e3d598, _DAT_182e30fc8, ...) whose types and member offsets
			// (0xB8/0xD8/0x68/0x70) cannot be resolved to real project members. Reconstructing
			// it faithfully would require inventing members on unknown types, so it is left as
			// a stub.
			return default;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__10))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__10(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__11))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__11(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		public override int GetHeadNumber()
		{
			return headObj.activeSelf ? 1 : 0;
		}
	}
}
