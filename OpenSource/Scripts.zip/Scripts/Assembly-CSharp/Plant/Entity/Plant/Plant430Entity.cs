using System;
using System.Collections;
using System.Collections.Generic;
using Game.Entity;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant430Entity : PlantEntity
	{
		private List<ZombieEntity> _targetZombieList;

		public override void Reset()
		{
			base.Reset();
		}

		protected override void Update()
		{
			base.Update();
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// 加算攻击加成：attack += round(defaultAttr.attack * value)
				if (attr != null && defaultAttr != null)
				{
					float ratio = entity.GetValue(this);
					attr.attack = (int)((float)defaultAttr.attack * ratio) + attr.attack;
				}
			}
			else if (entity.index == 1)
			{
				if (attr != null && defaultAttr != null)
				{
					float ratio = entity.GetValue(this);
					attr.AttackSpeed = ratio * defaultAttr.attackSpeed + attr.attackSpeed;
				}
			}
		}

		protected override void Attack()
		{
			// 先执行共用的攻击动画，再驱动多段攻击协程
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			yield break;
		}

		protected override bool CheckAttack()
		{
			return false;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 以默认攻速乘强化值构建单值负载，并对本植物施加编号 10 的 buff
			List<ValueEntity> valueList = new List<ValueEntity>();
			if (entity != null && this != null && defaultAttr != null)
			{
				float ratio = entity.GetValue(this);
				float attackSpeed = defaultAttr.attackSpeed;
				ValueEntity value = new ValueEntity();
				value.baseValue = attackSpeed * ratio;
				valueList.Add(value);
				float duration = entity.GetValue(this, 1);
				BuffHandler.AddBuff(10, null, duration, valueList);
			}
			yield break;
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			// 按强化值（以默认攻速为基准）提升攻速，并在 attr 上打上强化标签
			if (this != null && attr != null && defaultAttr != null && entity != null)
			{
				float ratio = entity.GetValue(this);
				attr.AttackSpeed = ratio * defaultAttr.attackSpeed + attr.attackSpeed;
				attr.AddLabel(entity.title, 1, entity.GetDesc(this));
			}
			yield break;
		}
	}
}
