using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Game.Entity;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant430Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__6 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant430Entity _003C_003E4__this;

			private Vector3 _003Cposition_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__6(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct - the attack state machine walks 5 states (aim, then four
				// bullet-spawn ticks) driven by animator playback and per-shot WaitForSeconds
				// timers. The spawn calls are virtual-slot invocations (0x408 / 0x1c8) whose
				// concrete member/signature could not be resolved from the pseudocode, and the
				// animator state name is an unresolved data pointer. Left as an inert iterator
				// rather than invent members.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__8 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public StrengthenEntity entity;

			public Plant430Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__8(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				if (_003C_003E1__state != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				Plant430Entity plant = _003C_003E4__this;
				// Build a single-value payload for the buff: defaultAttr.attackSpeed scaled by
				// the strengthen entity's value, then apply buff id 10 to this plant.
				List<ValueEntity> valueList = new List<ValueEntity>();
				if (entity != null && plant != null && plant.defaultAttr != null)
				{
					float ratio = entity.GetValue(plant);
					float attackSpeed = plant.defaultAttr.attackSpeed;
					ValueEntity value = new ValueEntity();
					value.baseValue = attackSpeed * ratio;
					valueList.Add(value);
					float duration = entity.GetValue(plant, 1);
					plant.BuffHandler.AddBuff(10, null, duration, valueList);
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__9 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant430Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__9(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				if (_003C_003E1__state != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				Plant430Entity plant = _003C_003E4__this;
				if (plant != null && plant.attr != null && plant.defaultAttr != null && entity != null)
				{
					// Boost attack speed by the strengthen value scaled off the default attack
					// speed, then stamp a label describing the strengthen on the attr.
					float ratio = entity.GetValue(plant);
					plant.attr.AttackSpeed = ratio * plant.defaultAttr.attackSpeed + plant.attr.attackSpeed;
					plant.attr.AddLabel(entity.title, 1, entity.GetDesc(plant));
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		private List<ZombieEntity> _targetZombieList;

		public override void Reset()
		{
			// ICF-folded onto the shared PlantEntity.Reset body (re-reads the card, rebuilds
			// attr/defaultAttr, remaps placeType -> sorting order, rerolls the blink timer and
			// resets sleep state). Delegates to the base implementation.
			base.Reset();
		}

		protected override void Update()
		{
			// ICF-folded onto the shared PlantEntity.Update body (attack-interval ticking,
			// eye update, special-skill cooldown). Delegates to the base implementation.
			base.Update();
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// Empty in the pseudocode (no base level-up behaviour for this plant).
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// Additive attack bonus: attack += round(defaultAttr.attack * value)
				if (attr != null && defaultAttr != null)
				{
					float ratio = entity.GetValue(this);
					attr.attack = (int)((float)defaultAttr.attack * ratio) + attr.attack;
				}
			}
			else if (entity.index == 1)
			{
				// Attack-speed strengthen. NOTE: the exact value composition was dropped by the
				// decompiler (the AttackSpeed setter arg was lost to a void-typed GetValue), so
				// this mirrors the OnUsePower1 attack-speed formula.
				// TODO: reconstruct the precise attack-speed composition if it differs.
				if (attr != null && defaultAttr != null)
				{
					float ratio = entity.GetValue(this);
					attr.AttackSpeed = ratio * defaultAttr.attackSpeed + attr.attackSpeed;
				}
			}
		}

		protected override void Attack()
		{
			// Run the shared attack animation setup, then drive the multi-shot attack coroutine.
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__6))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__6(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			// TODO: reconstruct - the pseudocode rebuilds _targetZombieList via a
			// Physics2D.OverlapCircleAll sweep in front of the plant, filters the hits to
			// ZombieEntity components, then enumerates the list invoking two unresolved
			// ZombieEntity virtual slots (0x378 / 0x388) to decide whether any target is
			// attackable. Those members could not be mapped to confirmed signatures, so this
			// is left as a stub rather than invent them.
			return false;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__8))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__8(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__9))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__9(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
