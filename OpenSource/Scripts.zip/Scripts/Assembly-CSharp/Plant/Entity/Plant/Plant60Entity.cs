using System;
using System.Collections;
using System.Collections.Generic;
using Bullet.Entity;
using Level.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant60Entity : PlantEntity
	{
		[Tooltip("子弹位置")]
		public Transform bulletPosition;

		[Tooltip("头部物体")]
		public GameObject headObj;

		public override void Reset()
		{
			base.Reset();
		}

		protected override void Update()
		{
			base.Update();
		}

		public override void EyeBlink()
		{
			if (partEntity == null)
			{
				return;
			}
			// Don't blink while the eyes are closed.
			if (partEntity.isCloseEye)
			{
				return;
			}
			if (_animator == null)
			{
				return;
			}
			AnimatorStateInfo layer0 = _animator.GetCurrentAnimatorStateInfo(0);
			if (layer0.IsTag("Blink"))
			{
				AnimatorStateInfo layer1 = _animator.GetCurrentAnimatorStateInfo(1);
				if (layer1.IsTag("Blink"))
				{
					_animator.Play("EyeBlink");
				}
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// Reduce attack by a fraction of the default attack, scaled by the strengthen value.
				if (attr == null || defaultAttr == null)
				{
					return;
				}
				int currentAttack = attr.attack;
				int defaultAttack = defaultAttr.attack;
				float ratio = entity.GetValue(this, 0);
				attr.attack = currentAttack - (int)((float)defaultAttack * ratio);
				// Upgrade the primary bullet to piercing and grant it one extra hit.
				if (bulletList != null && bulletList.Count > 0)
				{
					BulletAttr bullet = bulletList[0];
					if (bullet != null)
					{
						bullet.damageType = DamageTypeEntity.Pierce;
						// triggerCount += 1 (extra pierce hit).
						bullet.triggerCount += 1f;
					}
				}
			}
			else if (entity.index == 1)
			{
				// Add the strengthen value onto the first attr value entry.
				if (attr == null || attr.valueList == null || attr.valueList.Count == 0)
				{
					return;
				}
				var value = attr.valueList[0];
				if (value != null)
				{
					value.baseValue += entity.GetValue(this, 0);
				}
			}
		}

		public override BulletEntity CreateBullet(int index, Vector2 startPosition)
		{
			return base.CreateBullet(index, startPosition);
		}

		protected override void Attack()
		{
			// Play the base attack animation, then run the projectile-firing coroutine.
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			if (this != null && _animator != null)
			{
				_animator.Play("Attack", 1, 0f);
				if (attr != null)
				{
					// 攻击间隔后再发射子弹
					yield return new WaitForSeconds(attr.attackIntervalTime);
					if (this != null && headObj != null && headObj.activeSelf && bulletPosition != null)
					{
						CreateBullet(0, bulletPosition.position);
					}
				}
			}
		}

		protected override bool CheckAttack()
		{
			return false;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			if (this != null && _animator != null)
			{
				_animator.Play("Attack", 1, 0f);
				yield return new WaitForSeconds(0f);
				if (this != null && headObj != null && headObj.activeSelf && bulletPosition != null)
				{
					CreateBullet(1, bulletPosition.position);
				}
			}
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			if (this != null && entity != null && attr != null)
			{
				// 同一强化标签叠加超过 3 次后不再生效
				if (attr.GetLabel(entity.title) > 2)
				{
					yield break;
				}
				if (attr.valueList != null && defaultAttr != null && defaultAttr.valueList != null)
				{
					var attrValue = attr.valueList[1];
					var defaultValue = defaultAttr.valueList[1];
					if (attrValue != null && defaultValue != null)
					{
						// value[1] 基础值增加 强化系数 * 默认 value[1] 基础值
						float baseVal = attrValue.baseValue;
						float defaultBase = defaultValue.baseValue;
						float add = entity.GetValue(this, 0);
						attrValue.baseValue = add * defaultBase + baseVal;
						attr.AddLabel(entity.title, 1, entity.GetDesc(this));
					}
				}
			}
		}

		public override int GetHeadNumber()
		{
			// Head is "shown" (returns 1) while the head object is active, otherwise 0.
			if (headObj != null)
			{
				return headObj.activeSelf ? 1 : 0;
			}
			return 0;
		}
	}
}
