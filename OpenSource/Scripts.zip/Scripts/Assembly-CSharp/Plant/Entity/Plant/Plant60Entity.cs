using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Bullet.Entity;
using Level.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant60Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__9 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant60Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__9(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant60Entity self = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (self != null && self._animator != null)
					{
						// TODO: attack animation state name is a data pointer in the pseudocode.
						self._animator.Play("Attack", 1, 0f);
						if (self.attr != null)
						{
							// WaitForSeconds(attr.attackIntervalTime * global). The global multiplier
							// (_DAT_18252cd08) could not be recovered; using the interval directly.
							_003C_003E2__current = new WaitForSeconds(self.attr.attackIntervalTime);
							_003C_003E1__state = 1;
							return true;
						}
					}
					return false;
				}
				if (num == 1)
				{
					_003C_003E1__state = -1;
					if (self != null && self.headObj != null && self.headObj.activeSelf && self.bulletPosition != null)
					{
						self.CreateBullet(0, self.bulletPosition.position);
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__11 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant60Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__11(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant60Entity self = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (self != null && self._animator != null)
					{
						// TODO: power animation state name is a data pointer in the pseudocode.
						self._animator.Play("Attack", 1, 0f);
						// WaitForSeconds(fixed global duration _DAT_18252ccfc) — the exact value
						// could not be recovered; using 0 (wait a single tick) as a placeholder.
						_003C_003E2__current = new WaitForSeconds(0f); // TODO: reconstruct wait duration
						_003C_003E1__state = 1;
						return true;
					}
					return false;
				}
				if (num == 1)
				{
					_003C_003E1__state = -1;
					if (self != null && self.headObj != null && self.headObj.activeSelf && self.bulletPosition != null)
					{
						self.CreateBullet(1, self.bulletPosition.position);
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__12 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant60Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__12(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				Plant60Entity self = _003C_003E4__this;
				if (self != null && entity != null && self.attr != null)
				{
					// Bail out once this power's stacking label has been applied 3+ times.
					if (self.attr.GetLabel(entity.title) > 2)
					{
						return false;
					}
					if (self.attr.valueList != null && self.defaultAttr != null && self.defaultAttr.valueList != null)
					{
						// value[1].baseValue += strengthenValue * defaultValue[1].baseValue
						var attrValue = self.attr.valueList[1];
						var defaultValue = self.defaultAttr.valueList[1];
						if (attrValue != null && defaultValue != null)
						{
							float baseVal = attrValue.baseValue;
							float defaultBase = defaultValue.baseValue;
							float add = entity.GetValue(self, 0);
							attrValue.baseValue = add * defaultBase + baseVal;
							self.attr.AddLabel(entity.title, 1, entity.GetDesc(self));
						}
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("子弹位置")]
		public Transform bulletPosition;

		[Tooltip("头部物体")]
		public GameObject headObj;

		public override void Reset()
		{
			// ICF-folded onto the shared PlantEntity.Reset body; this override adds no
			// Plant60-specific behavior beyond the base card/attr initialization.
			base.Reset();
		}

		protected override void Update()
		{
			// ICF-folded onto the shared PlantEntity.Update body (attack tick + eye/cooldown
			// update); no Plant60-specific additions.
			base.Update();
		}

		public override void EyeBlink()
		{
			if (partEntity == null)
			{
				return;
			}
			// Don't blink while the eyes are closed.
			if (partEntity.isCloseEye)
			{
				return;
			}
			if (_animator == null)
			{
				return;
			}
			// Only blink when both animator layers currently carry the blink tag.
			// TODO: the animator tag and blink state name are data pointers in the pseudocode.
			AnimatorStateInfo layer0 = _animator.GetCurrentAnimatorStateInfo(0);
			if (layer0.IsTag("Blink"))
			{
				AnimatorStateInfo layer1 = _animator.GetCurrentAnimatorStateInfo(1);
				if (layer1.IsTag("Blink"))
				{
					_animator.Play("EyeBlink");
				}
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// ICF-folded onto an empty body; this level-0 hook does nothing for Plant60.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// Reduce attack by a fraction of the default attack, scaled by the strengthen value.
				if (attr == null || defaultAttr == null)
				{
					return;
				}
				int currentAttack = attr.attack;
				int defaultAttack = defaultAttr.attack;
				float ratio = entity.GetValue(this, 0);
				attr.attack = currentAttack - (int)((float)defaultAttack * ratio);
				// Upgrade the primary bullet to piercing and grant it one extra hit.
				if (bulletList != null && bulletList.Count > 0)
				{
					BulletAttr bullet = bulletList[0];
					if (bullet != null)
					{
						bullet.damageType = DamageTypeEntity.Pierce;
						// triggerCount += 1 (extra pierce hit).
						bullet.triggerCount += 1f;
					}
				}
			}
			else if (entity.index == 1)
			{
				// Add the strengthen value onto the first attr value entry.
				if (attr == null || attr.valueList == null || attr.valueList.Count == 0)
				{
					return;
				}
				var value = attr.valueList[0];
				if (value != null)
				{
					value.baseValue += entity.GetValue(this, 0);
				}
			}
		}

		public override BulletEntity CreateBullet(int index, Vector2 startPosition)
		{
			// Base spawns the bullet from bulletList[index] with the plant's attack applied.
			// TODO: reconstruct — the pseudocode then customized a bullet-specific component
			// (an unresolved GetComponent<T>() whose nested value-list fields at +0x28/+0x18
			// were written from attr.GetValue(this, 0/1)). That component type and its members
			// could not be identified in the project, so the customization is dropped here.
			return base.CreateBullet(index, startPosition);
		}

		protected override void Attack()
		{
			// Play the base attack animation, then run the projectile-firing coroutine.
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__9))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__9(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			// TODO: reconstruct — the pseudocode performs a Physics2D.RaycastAll in front of the
			// plant to detect a zombie, but the ray length / origin are read from two unresolved
			// manager singletons (a level config holder and a zombie/home-house manager) and a
			// layer mask that do not map to any member reachable in the project. Kept as a stub.
			return false;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__11))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__11(0)
			{
				_003C_003E4__this = this
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__12))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__12(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		public override int GetHeadNumber()
		{
			// Head is "shown" (returns 1) while the head object is active, otherwise 0.
			if (headObj != null)
			{
				return headObj.activeSelf ? 1 : 0;
			}
			return 0;
		}
	}
}
