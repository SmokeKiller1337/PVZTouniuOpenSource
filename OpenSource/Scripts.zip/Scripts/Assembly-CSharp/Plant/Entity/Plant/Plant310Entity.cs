using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Bullet.Entity;
using Bullet.Util;
using Game.Entity;
using Game.Util;
using Level.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant310Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__20 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant310Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__20(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// Single-pass power coroutine (no yield points in the pseudocode): on the
				// first MoveNext it applies the "death explosion" upgrade flag and registers
				// the power's attribute label, then finishes.
				int num = _003C_003E1__state;
				Plant310Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant != null && entity != null)
				{
					plant._isDeathExplosion = true;
					if (plant.attr != null)
					{
						plant.attr.AddLabel(entity.title, 0, entity.GetDesc(plant));
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__21 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public StrengthenEntity entity;

			public Plant310Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__21(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// Single-pass power coroutine (no yield points in the pseudocode): on the
				// first MoveNext it raises the plant's max health by the upgrade value,
				// tops the plant back up to full, registers the power label, then finishes.
				int num = _003C_003E1__state;
				Plant310Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (entity != null && plant != null)
				{
					plant.ChangeMaxHealth(entity.GetValue(plant));
					if (plant.attr != null)
					{
						plant.ChangeHealth(plant.attr.maxHealth);
						plant.attr.AddLabel(entity.title, 1, entity.GetDesc(plant));
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("南瓜渲染器")]
		public SpriteRenderer bodySpriteRenderer;

		[Tooltip("南瓜贴图集合")]
		public List<Sprite> bodySpriteList;

		[Tooltip("南瓜外壳渲染器")]
		public SpriteRenderer shellSpriteRenderer;

		[Tooltip("被吃效果")]
		public EffectEntity eatEffect;

		[Tooltip("爆炸效果")]
		public EffectEntity explosionEffect;

		private float _hitTimer;

		private StrengthenEntity _addHealthEntity;

		private bool _isAddHealth;

		private float _addHealthIntervalTimer;

		private bool _isDeathCooldown;

		private bool _isDeathExplosion;

		// TODO: unresolved health-ratio thresholds that pick the body sprite (data pointers
		// _UNK_18252cf78 / _UNK_18252cf28 in the pseudocode). Placeholders below.
		private const float BodySpriteThresholdHigh = 0.66f; // TODO: reconstruct constant

		private const float BodySpriteThresholdLow = 0.33f; // TODO: reconstruct constant

		// TODO: unresolved animator idle speed (data pointer _DAT_18252cb28 == 1f).
		private const float IdleAnimatorSpeed = 1f; // TODO: reconstruct constant

		// TODO: unresolved hit-freeze duration (immediate 0x3f19999a == 0.6f).
		private const float HitFreezeTime = 0.6f; // TODO: reconstruct constant

		// TODO: unresolved instant-kill buff duration (data pointer _DAT_18252cb88).
		private const float InstantKillBuffDuration = -1f; // TODO: reconstruct constant

		// TODO: unresolved explosion radius (data pointer _UNK_18252cd2c).
		private const float ExplosionRadius = 1f; // TODO: reconstruct constant

		// TODO: unresolved explosion layer-mask name (data pointer _DAT_182e30fc8).
		private const string ExplosionLayerName = "Zombie"; // TODO: reconstruct literal

		public override void Reset()
		{
			base.Reset();
			if (IsHasCardSlot)
			{
				CardEntity card = CardEntity;
				if (card != null && card.IsAvailablePower())
				{
					// TODO: virtual slot 0x478 gated on IsAvailablePower(); the only
					// power-related public virtual is UsePower(). Inferred call.
					UsePower();
				}
			}
			UpdateBodySprite();
		}

		protected override void Update()
		{
			base.Update();
			if (_isAddHealth)
			{
				_addHealthIntervalTimer += Time.deltaTime;
				if (_addHealthEntity != null && _addHealthEntity.GetValue(this, 0) <= _addHealthIntervalTimer)
				{
					_addHealthIntervalTimer = 0f;
					if (attr != null)
					{
						ChangeHealth(_addHealthEntity.GetValue(this, 1) * attr.maxHealth);
					}
				}
			}
			if (_hitTimer > 0f)
			{
				_hitTimer -= Time.deltaTime;
				if (_hitTimer <= 0f && _buffHandler != null && !_buffHandler.HasBuff(2) && !_buffHandler.HasBuff(4) && _animator != null)
				{
					_animator.speed = IdleAnimatorSpeed;
				}
			}
		}

		protected override void UpdateSortingOrder()
		{
			// TODO: reconstruct - the pseudocode reads _rigidbody.position, then fetches an
			// object via an unresolved virtual slot (0x178) and reads an unnamed int field at
			// +0x64 from it to derive the shell sprite renderer's sorting order. The virtual
			// target and that field cannot be identified from the available inputs, so the
			// method is left as a stub rather than inventing members.
		}

		private void UpdateBodySprite()
		{
			if (bodySpriteRenderer == null)
			{
				return;
			}
			if (attr == null)
			{
				return;
			}
			float ratio = attr.HealthRatio;
			int index;
			if (ratio > BodySpriteThresholdHigh)
			{
				index = 0;
			}
			else if (ratio > BodySpriteThresholdLow)
			{
				index = 1;
			}
			else
			{
				index = 2;
			}
			bodySpriteRenderer.sprite = bodySpriteList[index];
		}

		public override bool Hit(float value, DamageTypeEntity damageType = null, BulletEntity sourceBullet = null)
		{
			if (value > 0f)
			{
				_hitTimer = HitFreezeTime;
				if (_animator != null)
				{
					_animator.speed = 0f;
				}
				GameUtils.CreateEffect(eatEffect, base.transform.position, Quaternion.identity, 1f);
			}
			if (damageType == null)
			{
				damageType = DamageTypeEntity.Common;
			}
			if (attr == null)
			{
				return false;
			}
			if (attr.isInvincible)
			{
				return false;
			}
			// Explosion-type damage: immune when buff id 4 is immune-listed or isNotPick2.
			if ((int)damageType.damageType == 2)
			{
				if (immuneBuffIdList.Contains(4))
				{
					return false;
				}
				if (attr.isNotPick2)
				{
					return false;
				}
			}
			// TODO: reconstruct - the pseudocode also gated this on a global "damage disabled"
			// flag read via a level singleton (_DAT_182e2bc20). That guard is dropped; the
			// non-positive-damage guard below is preserved.
			if (value <= 0f)
			{
				return false;
			}
			if ((int)damageType.deathType != 1)
			{
				ChangeHealth(0f - value);
				Flicker();
				return true;
			}
			if (value < attr.currentHealth)
			{
				ChangeHealth(0f - value);
				Flicker();
				return true;
			}
			if (_buffHandler != null)
			{
				_buffHandler.AddBuff(4, null, InstantKillBuffDuration);
				return true;
			}
			return false;
		}

		public override void ChangeHealth(float value)
		{
			base.ChangeHealth(value);
			UpdateBodySprite();
		}

		public override void Death()
		{
			base.Death();
			if (_lastDamageType == null)
			{
				return;
			}
			if ((int)_lastDamageType.deathType == 2)
			{
				return;
			}
			if (_isDeathCooldown && IsHasCardSlot)
			{
				StrengthenEntity se = GetStrengthenEntity(2, 1);
				CardEntity card = CardEntity;
				if (card == null || card.attr == null)
				{
					return;
				}
				float timer = card.attr.cooldownTimer;
				CardEntity card2 = CardEntity;
				if (card2 == null || card2.attr == null || se == null)
				{
					return;
				}
				float cooldownTime = card2.attr.cooldownTime;
				card.attr.cooldownTimer = timer - se.GetValue(this) * cooldownTime;
			}
			if (_isDeathExplosion && IsHasCardSlot)
			{
				StrengthenEntity se = GetStrengthenEntity(3, 0);
				if (se != null)
				{
					float damage = se.GetValue(this);
					Vector2 position = base.transform.position;
					GameUtils.CreateEffect(explosionEffect, position, Quaternion.identity, 1f);
					position = base.transform.position;
					int layerMask = LayerMask.GetMask(ExplosionLayerName);
					DamageUtils.Explosion(position, ExplosionRadius, damage, layerMask);
				}
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// ICF-folded onto a shared empty method (RVA 0x3D9020); no body in the binary.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				if (defaultAttr == null)
				{
					return;
				}
				ChangeMaxHealth(entity.GetValue(this) * defaultAttr.maxHealth);
			}
			else if (entity.index == 1)
			{
				_isDeathCooldown = true;
			}
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__20))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__20(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__21))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__21(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		public override int GetHeadNumber()
		{
			// ICF-folded onto a shared method returning 0 (RVA 0x3D5CA0).
			return 0;
		}
	}
}
