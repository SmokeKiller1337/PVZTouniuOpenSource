using System;
using System.Collections;
using System.Collections.Generic;
using Bullet.Entity;
using Bullet.Util;
using Game.Entity;
using Game.Util;
using Level.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant310Entity : PlantEntity
	{
		[Tooltip("南瓜渲染器")]
		public SpriteRenderer bodySpriteRenderer;

		[Tooltip("南瓜贴图集合")]
		public List<Sprite> bodySpriteList;

		[Tooltip("南瓜外壳渲染器")]
		public SpriteRenderer shellSpriteRenderer;

		[Tooltip("被吃效果")]
		public EffectEntity eatEffect;

		[Tooltip("爆炸效果")]
		public EffectEntity explosionEffect;

		private float _hitTimer;

		private StrengthenEntity _addHealthEntity;

		private bool _isAddHealth;

		private float _addHealthIntervalTimer;

		private bool _isDeathCooldown;

		private bool _isDeathExplosion;

		private const float BodySpriteThresholdHigh = 0.66f;

		private const float BodySpriteThresholdLow = 0.33f;

		private const float IdleAnimatorSpeed = 1f;

		// 受击僵直时长
		private const float HitFreezeTime = 0.6f;

		private const float InstantKillBuffDuration = -1f;

		private const float ExplosionRadius = 1f;

		private const string ExplosionLayerName = "Zombie";

		public override void Reset()
		{
			base.Reset();
			if (IsHasCardSlot)
			{
				CardEntity card = CardEntity;
				if (card != null && card.IsAvailablePower())
				{
					UsePower();
				}
			}
			UpdateBodySprite();
		}

		protected override void Update()
		{
			base.Update();
			if (_isAddHealth)
			{
				_addHealthIntervalTimer += Time.deltaTime;
				if (_addHealthEntity != null && _addHealthEntity.GetValue(this, 0) <= _addHealthIntervalTimer)
				{
					_addHealthIntervalTimer = 0f;
					if (attr != null)
					{
						ChangeHealth(_addHealthEntity.GetValue(this, 1) * attr.maxHealth);
					}
				}
			}
			if (_hitTimer > 0f)
			{
				_hitTimer -= Time.deltaTime;
				if (_hitTimer <= 0f && _buffHandler != null && !_buffHandler.HasBuff(2) && !_buffHandler.HasBuff(4) && _animator != null)
				{
					_animator.speed = IdleAnimatorSpeed;
				}
			}
		}

		protected override void UpdateSortingOrder()
		{
		}

		private void UpdateBodySprite()
		{
			if (bodySpriteRenderer == null)
			{
				return;
			}
			if (attr == null)
			{
				return;
			}
			float ratio = attr.HealthRatio;
			int index;
			if (ratio > BodySpriteThresholdHigh)
			{
				index = 0;
			}
			else if (ratio > BodySpriteThresholdLow)
			{
				index = 1;
			}
			else
			{
				index = 2;
			}
			bodySpriteRenderer.sprite = bodySpriteList[index];
		}

		public override bool Hit(float value, DamageTypeEntity damageType = null, BulletEntity sourceBullet = null)
		{
			if (value > 0f)
			{
				_hitTimer = HitFreezeTime;
				if (_animator != null)
				{
					_animator.speed = 0f;
				}
				GameUtils.CreateEffect(eatEffect, base.transform.position, Quaternion.identity, 1f);
			}
			if (damageType == null)
			{
				damageType = DamageTypeEntity.Common;
			}
			if (attr == null)
			{
				return false;
			}
			if (attr.isInvincible)
			{
				return false;
			}
			// Explosion-type damage: immune when buff id 4 is immune-listed or isNotPick2.
			if ((int)damageType.damageType == 2)
			{
				if (immuneBuffIdList.Contains(4))
				{
					return false;
				}
				if (attr.isNotPick2)
				{
					return false;
				}
			}
			if (value <= 0f)
			{
				return false;
			}
			if ((int)damageType.deathType != 1)
			{
				ChangeHealth(0f - value);
				Flicker();
				return true;
			}
			if (value < attr.currentHealth)
			{
				ChangeHealth(0f - value);
				Flicker();
				return true;
			}
			if (_buffHandler != null)
			{
				_buffHandler.AddBuff(4, null, InstantKillBuffDuration);
				return true;
			}
			return false;
		}

		public override void ChangeHealth(float value)
		{
			base.ChangeHealth(value);
			UpdateBodySprite();
		}

		public override void Death()
		{
			base.Death();
			if (_lastDamageType == null)
			{
				return;
			}
			if ((int)_lastDamageType.deathType == 2)
			{
				return;
			}
			if (_isDeathCooldown && IsHasCardSlot)
			{
				StrengthenEntity se = GetStrengthenEntity(2, 1);
				CardEntity card = CardEntity;
				if (card == null || card.attr == null)
				{
					return;
				}
				float timer = card.attr.cooldownTimer;
				CardEntity card2 = CardEntity;
				if (card2 == null || card2.attr == null || se == null)
				{
					return;
				}
				float cooldownTime = card2.attr.cooldownTime;
				card.attr.cooldownTimer = timer - se.GetValue(this) * cooldownTime;
			}
			if (_isDeathExplosion && IsHasCardSlot)
			{
				StrengthenEntity se = GetStrengthenEntity(3, 0);
				if (se != null)
				{
					float damage = se.GetValue(this);
					Vector2 position = base.transform.position;
					GameUtils.CreateEffect(explosionEffect, position, Quaternion.identity, 1f);
					position = base.transform.position;
					int layerMask = LayerMask.GetMask(ExplosionLayerName);
					DamageUtils.Explosion(position, ExplosionRadius, damage, layerMask);
				}
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				if (defaultAttr == null)
				{
					return;
				}
				ChangeMaxHealth(entity.GetValue(this) * defaultAttr.maxHealth);
			}
			else if (entity.index == 1)
			{
				_isDeathCooldown = true;
			}
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 标记死亡爆炸，并挂上强化标签
			if (entity != null)
			{
				_isDeathExplosion = true;
				if (attr != null)
				{
					attr.AddLabel(entity.title, 0, entity.GetDesc(this));
				}
			}
			yield break;
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			// 提升最大生命并回满，再挂上强化标签
			if (entity != null)
			{
				ChangeMaxHealth(entity.GetValue(this));
				if (attr != null)
				{
					ChangeHealth(attr.maxHealth);
					attr.AddLabel(entity.title, 1, entity.GetDesc(this));
				}
			}
			yield break;
		}

		public override int GetHeadNumber()
		{
			return 0;
		}
	}
}
