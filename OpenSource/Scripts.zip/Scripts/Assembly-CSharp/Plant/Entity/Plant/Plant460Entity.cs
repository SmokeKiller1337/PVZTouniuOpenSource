using System;
using System.Collections;
using System.Collections.Generic;
using Audio.Manager;
using Common.Entity;
using DG.Tweening;
using Game.Entity;
using Level.Manager;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant460Entity : PlantEntity
	{
		[Tooltip("金属位置")]
		public Transform metalTransform;

		[Tooltip("金属渲染器")]
		public SpriteRenderer metalSpriteRenderer;

		[Tooltip("吸取音效")]
		public AudioClip biteSound;

		[Tooltip("减速效果")]
		public List<ValueEntity> slowBuffList;

		private bool _isSlow;

		private bool _isSun;

		private StrengthenEntity _currentPowerEntity;

		private const string MetalShaderProperty = "_FlashAmount";
		private static readonly Vector3 MetalMoveTarget = Vector3.zero;
		private const float MetalMoveDuration = 0.5f;
		private const float AttackWaitDuration = 0.5f;

		public override void Reset()
		{
			base.Reset();
			// Play the pull-in sound.
			if (biteSound != null && AudioManager.Instance != null)
			{
				AudioManager.Instance.PlayOneShot(biteSound);
			}
			if (IsHasCardSlot)
			{
				CardEntity card = CardEntity;
				if (card != null && card.IsAvailablePower())
				{
					UsePower();
				}
			}
		}

		protected override void Start()
		{
			base.Start();
			if (attr != null)
			{
				// This magnet plant is invincible.
				attr.isInvincible = true;
			}
			if (!_isSun)
			{
				return;
			}
			// Sun-producing variant: spawn a sun worth the level-2 strengthen value at the
			// plant's body position.
			StrengthenEntity sunEntity = GetStrengthenEntity(2, 1);
			if (_rigidbody != null && sunEntity != null && RewardManager.Instance != null)
			{
				Vector2 position = _rigidbody.position;
				int value = (int)sunEntity.GetValue(this);
				RewardManager.Instance.CreateSun(position, value, 1f, true);
			}
		}

		protected override void Update()
		{
			base.Update();
			if (partEntity == null)
			{
				return;
			}
			// Only tick while awake.
			if (partEntity.isSleeping)
			{
				return;
			}
			PlantBaseAttr a = attr;
			if (a.attackIntervalTime > 0f)
			{
				a.attackIntervalTimer += Time.deltaTime;
				if (a.attackIntervalTimer >= a.attackIntervalTime)
				{
					a.attackIntervalTimer = 0f;
					if (CheckAttack())
					{
						Attack();
					}
				}
			}
			EyeUpdate();
			if (isHasSpecialSkill && specialCooldownTimer > 0f)
			{
				specialCooldownTimer -= Time.deltaTime;
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			// The two level-2 strengthens toggle the slow / sun behaviours.
			if (entity.index == 0)
			{
				_isSlow = true;
			}
			else if (entity.index == 1)
			{
				_isSun = true;
			}
		}

		protected override void Attack()
		{
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			// 播放吸取音效
			if (biteSound != null && AudioManager.Instance != null)
			{
				AudioManager.Instance.PlayOneShot(biteSound);
			}
			// 找到需要被吸取金属的僵尸，为每个僵尸生成一个飞向磁铁的金属克隆体
			List<ZombieEntity> targets = GetTargetZombieList();
			if (targets != null)
			{
				foreach (ZombieEntity zombie in targets)
				{
					if (zombie == null)
					{
						continue;
					}
					SpriteRenderer metalRenderer = zombie.GetMetalRenderer();
					if (metalSpriteRenderer == null)
					{
						continue;
					}
					GameObject clone = UnityEngine.Object.Instantiate(metalSpriteRenderer.gameObject, metalTransform);
					if (clone == null)
					{
						continue;
					}
					SpriteRenderer cloneRenderer = clone.GetComponent<SpriteRenderer>();
					if (cloneRenderer == null || metalRenderer == null)
					{
						continue;
					}
					// 让克隆体贴合僵尸金属的位置与朝向
					cloneRenderer.transform.position = metalRenderer.transform.position;
					cloneRenderer.transform.eulerAngles = metalRenderer.transform.eulerAngles;
					// 复制僵尸金属的外观状态
					cloneRenderer.sprite = metalRenderer.sprite;
					cloneRenderer.sharedMaterial = new Material(metalRenderer.material);
					Material cloneMaterial = cloneRenderer.material;
					if (cloneMaterial != null)
					{
						cloneMaterial.SetFloat(MetalShaderProperty, 0f);
					}
					cloneRenderer.transform.DOLocalMove(MetalMoveTarget, MetalMoveDuration);
				}
			}
			yield return new WaitForSeconds(AttackWaitDuration);
		}

		protected override bool CheckAttack()
		{
			return false;
		}

		private List<ZombieEntity> GetTargetZombieList()
		{
			return null;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 记录当前激活的强化（三级强化）
			_currentPowerEntity = entity;
			yield break;
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			// 记录当前激活的强化（三级强化）
			_currentPowerEntity = entity;
			yield break;
		}
	}
}
