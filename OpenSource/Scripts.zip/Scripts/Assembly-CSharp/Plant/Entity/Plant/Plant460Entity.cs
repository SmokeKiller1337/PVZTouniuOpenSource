using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Audio.Manager;
using Common.Entity;
using DG.Tweening;
using Game.Entity;
using Level.Manager;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant460Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__13 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant460Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__13(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant460Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					// Play the "bite" pull-in sound.
					if (plant.biteSound != null && AudioManager.Instance != null)
					{
						AudioManager.Instance.PlayOneShot(plant.biteSound);
					}
					// Gather the zombies whose metal this magnet should pull, then spawn a
					// flying metal-clone for each of them.
					List<ZombieEntity> targets = plant.GetTargetZombieList();
					if (targets != null)
					{
						foreach (ZombieEntity zombie in targets)
						{
							if (zombie == null)
							{
								continue;
							}
							SpriteRenderer metalRenderer = zombie.GetMetalRenderer();
							if (plant.metalSpriteRenderer == null)
							{
								continue;
							}
							// Instantiate a clone of the plant's metal-effect object under metalTransform.
							GameObject clone = UnityEngine.Object.Instantiate(plant.metalSpriteRenderer.gameObject, plant.metalTransform);
							if (clone == null)
							{
								continue;
							}
							SpriteRenderer cloneRenderer = clone.GetComponent<SpriteRenderer>();
							if (cloneRenderer == null || metalRenderer == null)
							{
								continue;
							}
							// Snap the clone onto the zombie's metal renderer (position + rotation).
							cloneRenderer.transform.position = metalRenderer.transform.position;
							cloneRenderer.transform.eulerAngles = metalRenderer.transform.eulerAngles;
							// Copy the visual state from the zombie's metal.
							cloneRenderer.sprite = metalRenderer.sprite;
							cloneRenderer.sharedMaterial = new Material(metalRenderer.material);
							Material cloneMaterial = cloneRenderer.material;
							if (cloneMaterial != null)
							{
								// TODO: reconstruct — shader property name is a data pointer in the
								// pseudocode; the value written is 0f.
								cloneMaterial.SetFloat(MetalShaderProperty, 0f);
							}
							// Tween the clone back towards the magnet.
							// TODO: reconstruct — the local move target is a global config Vector3
							// in the pseudocode (Vector3.zero used here as a placeholder).
							cloneRenderer.transform.DOLocalMove(MetalMoveTarget, MetalMoveDuration);
						}
					}
					// Wait one attack cycle before pulling again.
					// TODO: reconstruct — the wait duration is a global config float in the
					// pseudocode (_DAT_182e73b18); placeholder used here.
					_003C_003E2__current = new WaitForSeconds(AttackWaitDuration);
					_003C_003E1__state = 1;
					return true;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__16 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant460Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__16(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				if (_003C_003E1__state == 0)
				{
					_003C_003E1__state = -1;
					// Remember which power (level-3 strengthen) is currently active.
					_003C_003E4__this._currentPowerEntity = entity;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__17 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant460Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__17(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				if (_003C_003E1__state == 0)
				{
					_003C_003E1__state = -1;
					// Remember which power (level-3 strengthen) is currently active.
					_003C_003E4__this._currentPowerEntity = entity;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("金属位置")]
		public Transform metalTransform;

		[Tooltip("金属渲染器")]
		public SpriteRenderer metalSpriteRenderer;

		[Tooltip("吸取音效")]
		public AudioClip biteSound;

		[Tooltip("减速效果")]
		public List<ValueEntity> slowBuffList;

		private bool _isSlow;

		private bool _isSun;

		private StrengthenEntity _currentPowerEntity;

		// TODO: unresolved data-pointer literals used by the metal-pull coroutine.
		private const string MetalShaderProperty = "_FlashAmount"; // TODO: reconstruct shader property name
		private static readonly Vector3 MetalMoveTarget = Vector3.zero; // TODO: reconstruct move target (_DAT_182e70d90)
		private const float MetalMoveDuration = 0.5f; // TODO: reconstruct tween duration
		private const float AttackWaitDuration = 0.5f; // TODO: reconstruct wait duration (_DAT_182e73b18)

		public override void Reset()
		{
			base.Reset();
			// Play the pull-in sound.
			if (biteSound != null && AudioManager.Instance != null)
			{
				AudioManager.Instance.PlayOneShot(biteSound);
			}
			// TODO: reconstruct — the pseudocode also scheduled a DOVirtual.DelayedCall to a
			// virtual method (slot 0x430) after a short delay; the target method could not be
			// resolved from the dump, so that delayed call is dropped here.
			// Auto-fire the plant's power once on reset if the card slot has one available.
			if (IsHasCardSlot)
			{
				CardEntity card = CardEntity;
				if (card != null && card.IsAvailablePower())
				{
					UsePower();
				}
			}
		}

		protected override void Start()
		{
			base.Start();
			if (attr != null)
			{
				// This magnet plant is invincible.
				attr.isInvincible = true;
			}
			if (!_isSun)
			{
				return;
			}
			// Sun-producing variant: spawn a sun worth the level-2 strengthen value at the
			// plant's body position.
			StrengthenEntity sunEntity = GetStrengthenEntity(2, 1);
			if (_rigidbody != null && sunEntity != null && RewardManager.Instance != null)
			{
				Vector2 position = _rigidbody.position;
				int value = (int)sunEntity.GetValue(this);
				RewardManager.Instance.CreateSun(position, value, 1f, true);
			}
		}

		protected override void Update()
		{
			base.Update();
			if (partEntity == null)
			{
				return;
			}
			// Only tick while awake.
			if (partEntity.isSleeping)
			{
				return;
			}
			PlantBaseAttr a = attr;
			if (a.attackIntervalTime > 0f)
			{
				a.attackIntervalTimer += Time.deltaTime;
				if (a.attackIntervalTimer >= a.attackIntervalTime)
				{
					a.attackIntervalTimer = 0f;
					if (CheckAttack())
					{
						Attack();
					}
				}
			}
			EyeUpdate();
			if (isHasSpecialSkill && specialCooldownTimer > 0f)
			{
				specialCooldownTimer -= Time.deltaTime;
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// Genuinely empty in the original (folded onto an empty method body).
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			// The two level-2 strengthens toggle the slow / sun behaviours.
			if (entity.index == 0)
			{
				_isSlow = true;
			}
			else if (entity.index == 1)
			{
				_isSun = true;
			}
		}

		protected override void Attack()
		{
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__13))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__13(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			// Folded onto a stub returning false; the magnet does not use the generic
			// distance-based attack gate.
			return false;
		}

		private List<ZombieEntity> GetTargetZombieList()
		{
			// TODO: reconstruct — the pseudocode computes an overlap radius from attr /
			// defaultAttr / _currentPowerEntity, runs Physics2D.OverlapCircleAll against a
			// layer mask whose name is a data pointer, filters the hits through a Linq.Where
			// predicate that invokes an unresolved virtual slot and compares an unnamed
			// zombie-state member (currentState @+0x100 != 2), then applies a slow buff
			// (BuffHandler.AddBuff(5, ...)) to each survivor. Several of those members are
			// only reachable by raw offset and are not exposed in the skeleton, so the body
			// is left as a faithful stub rather than fabricating member names.
			return null;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__16))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__16(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__17))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__17(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
