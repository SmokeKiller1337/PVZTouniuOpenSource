namespace Plant.Entity.Plant
{
	public class Plant315Entity : Plant310Entity
	{
	}
}
