using System;
using System.Collections;
using System.Collections.Generic;
using Common.Entity;
using Game.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant160Entity : PlantEntity
	{
		[Tooltip("种植时音效")]
		public AudioClip startSound;

		[Tooltip("爆炸效果")]
		public EffectEntity explosionEffect;

		public Action<List<BaseBody>> OnExplosionAfter;

		private StrengthenEntity _currentPowerEntity;

		private const string AttackSpeedParamName = "AttackSpeed";

		// TODO: unresolved global float multiplier applied to attackSpeed in Attack().
		private const float AttackSpeedAnimMultiplier = 1f;

		public override void Reset()
		{
			base.Reset();
		}

		protected override IEnumerator ChangeSleepStateCoroutine()
		{
			// 等待一帧后再切换睡眠状态。
			yield return null;
		}

		protected override void Start()
		{
			base.Start();
			if (partEntity != null)
			{
				// While the plant is not sleeping, make it invincible on spawn.
				if (!partEntity.isSleeping)
				{
					if (attr != null)
					{
						attr.isInvincible = true;
					}
				}
			}
		}

		public override void Death()
		{
			DeathHandle();
			ClearLand();
			UnityEngine.Object.Destroy(base.gameObject);
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// Strengthen option 0: add defaultAttr.attack * value to the live attack.
				if (attr != null && defaultAttr != null)
				{
					int currentAttack = attr.attack;
					int baseAttack = defaultAttr.attack;
					float value = entity.GetValue(this, 0);
					attr.attack = (int)((float)baseAttack * value) + currentAttack;
				}
			}
			else if (entity.index == 1)
			{
				// Strengthen option 1: reduce value entry [1] by value * defaultAttr's entry [1].
				if (attr != null && attr.valueList != null)
				{
					ValueEntity liveValue = attr.valueList[1];
					if (liveValue != null && defaultAttr != null && defaultAttr.valueList != null)
					{
						ValueEntity baseValue = defaultAttr.valueList[1];
						if (baseValue != null)
						{
							float value = entity.GetValue(this, 0);
							liveValue.baseValue = liveValue.baseValue - value * baseValue.baseValue;
						}
					}
				}
			}
		}

		protected override void Attack()
		{
			if (attr == null || _animator == null)
			{
				return;
			}
			// Drive the attack-speed animator parameter, then run the attack coroutine.
			_animator.SetFloat(AttackSpeedParamName, attr.attackSpeed * AttackSpeedAnimMultiplier);
			if (base.enabled)
			{
				StartCoroutine(AttackCoroutine());
			}
		}

		private IEnumerator AttackCoroutine()
		{
			yield break;
		}

		protected override bool CheckAttack()
		{
			return false;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 记录当前使用的强化实体。
			_currentPowerEntity = entity;
			yield break;
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			// 记录当前使用的强化实体。
			_currentPowerEntity = entity;
			yield break;
		}
	}
}
