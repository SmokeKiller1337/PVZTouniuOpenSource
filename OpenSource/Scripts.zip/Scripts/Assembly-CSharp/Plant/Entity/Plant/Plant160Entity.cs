using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Entity;
using Game.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant160Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__11 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant160Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__11(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct — the attack payload (screen flash / camera impulse via
				// unresolved global holders, GameUtils.CreateEffect + DamageUtils.Explosion with
				// an ICF-mangled argument list, BuildingManager.AddCrater writing an internal
				// CraterEntity field at +0x78, and card-slot internal offsets +0x70/+0x18) reads
				// members that are not verifiable from the available inputs. Left as a stub to
				// avoid inventing external members / producing uncompilable code.
				int num = _003C_003E1__state;
				if (num == 0)
				{
					_003C_003E1__state = -1;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CChangeSleepStateCoroutine_003Ed__5 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant160Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CChangeSleepStateCoroutine_003Ed__5(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct — after yielding once the pseudocode wakes the plant by
				// scheduling a DG.Tweening.DOVirtual.DelayedCall (a type that is not present in
				// this project), playing an animator state whose name is an unresolved data
				// pointer, and firing a one-shot via AudioManager. The DOVirtual dependency and
				// the unresolved animation-state string make a faithful body impossible, so this
				// is stubbed. Only the state-machine skeleton (a single yield return null) is kept.
				int num = _003C_003E1__state;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					_003C_003E2__current = null;
					_003C_003E1__state = 1;
					return true;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__13 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant160Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__13(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// Stores the strengthen entity that triggered this power on the plant, then
				// completes immediately (the pseudocode never yields).
				int num = _003C_003E1__state;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					_003C_003E4__this._currentPowerEntity = entity;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__14 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant160Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__14(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// Stores the strengthen entity that triggered this power on the plant, then
				// completes immediately (the pseudocode never yields).
				int num = _003C_003E1__state;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					_003C_003E4__this._currentPowerEntity = entity;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("种植时音效")]
		public AudioClip startSound;

		[Tooltip("爆炸效果")]
		public EffectEntity explosionEffect;

		public Action<List<BaseBody>> OnExplosionAfter;

		private StrengthenEntity _currentPowerEntity;

		// TODO: the animator float parameter name driven in Attack() is a data pointer in the
		// pseudocode and could not be resolved to its literal string. Replace with the real
		// Animator parameter name when known.
		private const string AttackSpeedParamName = "AttackSpeed"; // TODO: reconstruct literal

		// TODO: unresolved global float multiplier applied to attackSpeed in Attack().
		private const float AttackSpeedAnimMultiplier = 1f; // TODO: reconstruct constant

		public override void Reset()
		{
			// TODO: reconstruct — the pseudocode wakes the plant by scheduling a
			// DG.Tweening.DOVirtual.DelayedCall (a type not present in this project), playing an
			// animator state whose name is an unresolved data pointer, firing a one-shot via
			// AudioManager, and — when the card slot's power is available — invoking the power.
			// The DOVirtual dependency and the unresolved animation-state string make a faithful
			// body impossible, so the whole method (beyond the base call) is left as a stub.
			base.Reset();
		}

		[IteratorStateMachine(typeof(_003CChangeSleepStateCoroutine_003Ed__5))]
		protected override IEnumerator ChangeSleepStateCoroutine()
		{
			return new _003CChangeSleepStateCoroutine_003Ed__5(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override void Start()
		{
			base.Start();
			if (partEntity != null)
			{
				// While the plant is not sleeping, make it invincible on spawn.
				if (!partEntity.isSleeping)
				{
					if (attr != null)
					{
						attr.isInvincible = true;
					}
				}
			}
		}

		public override void Death()
		{
			DeathHandle();
			ClearLand();
			UnityEngine.Object.Destroy(base.gameObject);
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// ICF-folded onto the shared empty method (RVA 0x381980); no body.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// Strengthen option 0: add defaultAttr.attack * value to the live attack.
				if (attr != null && defaultAttr != null)
				{
					int currentAttack = attr.attack;
					int baseAttack = defaultAttr.attack;
					float value = entity.GetValue(this, 0);
					attr.attack = (int)((float)baseAttack * value) + currentAttack;
				}
			}
			else if (entity.index == 1)
			{
				// Strengthen option 1: reduce value entry [1] by value * defaultAttr's entry [1].
				if (attr != null && attr.valueList != null)
				{
					ValueEntity liveValue = attr.valueList[1];
					if (liveValue != null && defaultAttr != null && defaultAttr.valueList != null)
					{
						ValueEntity baseValue = defaultAttr.valueList[1];
						if (baseValue != null)
						{
							float value = entity.GetValue(this, 0);
							liveValue.baseValue = liveValue.baseValue - value * baseValue.baseValue;
						}
					}
				}
			}
		}

		protected override void Attack()
		{
			if (attr == null || _animator == null)
			{
				return;
			}
			// Drive the attack-speed animator parameter, then run the attack coroutine.
			_animator.SetFloat(AttackSpeedParamName, attr.attackSpeed * AttackSpeedAnimMultiplier);
			if (base.enabled)
			{
				StartCoroutine(AttackCoroutine());
			}
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__11))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__11(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			// ICF-folded onto a shared stub returning false.
			return false;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__13))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__13(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__14))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__14(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
