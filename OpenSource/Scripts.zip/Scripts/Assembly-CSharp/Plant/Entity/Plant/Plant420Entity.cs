using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Entity;
using Game.Entity;
using Level.Manager;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant420Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__10 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant420Entity _003C_003E4__this;

			public StrengthenEntity entity;

			private int _003Ci_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__10(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant420Entity plant = _003C_003E4__this;
				switch (num)
				{
				default:
					return false;
				case 0:
					_003C_003E1__state = -1;
					if (plant == null)
					{
						return false;
					}
					// TODO: reconstruct - state 0 first tinted the head sprite materials
					// via SpriteRenderer.material.DOFloat with a shader property id and target
					// value that are unresolved data pointers in the pseudocode; that visual
					// tween is dropped. The wait that follows is preserved.
					_003C_003E2__current = new WaitForSeconds(PowerStepDelay);
					_003C_003E1__state = 1;
					return true;
				case 1:
					_003C_003E1__state = -1;
					_003Ci_003E5__2 = 0;
					break;
				case 2:
					_003C_003E1__state = -1;
					_003Ci_003E5__2++;
					break;
				case 3:
					// resumed after the final wait: the ramp is over, terminate.
					_003C_003E1__state = -1;
					return false;
				}
				StrengthenEntity strengthen = entity;
				if (strengthen == null || plant == null)
				{
					return false;
				}
				int count = (int)strengthen.GetValue(plant);
				if (count <= _003Ci_003E5__2)
				{
					// ramp finished: do one final wait, then terminate (state 3 ends).
					// TODO: reconstruct - dropped head-sprite tint tween (see state 0).
					_003C_003E2__current = new WaitForSeconds(PowerStepDelay);
					_003C_003E1__state = 3;
					return true;
				}
				// still ramping: fire the callback and drop suns under any active heads
				if (plant.OnProduceSun != null)
				{
					plant.OnProduceSun();
				}
				PlantBaseAttr attr = plant.attr;
				if (attr == null)
				{
					return false;
				}
				int sunValue = attr.GetValueInt(plant, 1);
				List<SpriteRenderer> leftHeads = plant.leftHeadSpriteRendererList;
				if (leftHeads != null && leftHeads.Count > 0 && leftHeads[0] != null)
				{
					GameObject leftGo = leftHeads[0].gameObject;
					if (leftGo != null && leftGo.activeSelf)
					{
						RewardManager.Instance.CreateSun(plant.transform.position, sunValue, 1f, true);
					}
				}
				List<SpriteRenderer> rightHeads = plant.rightHeadSpriteRendererList;
				if (rightHeads == null || rightHeads.Count < 1 || rightHeads[0] == null)
				{
					return false;
				}
				GameObject rightGo = rightHeads[0].gameObject;
				if (rightGo == null)
				{
					return false;
				}
				if (rightGo.activeSelf)
				{
					RewardManager.Instance.CreateSun(plant.transform.position, sunValue, 1f, true);
				}
				// loop back through state 2 (which increments i) after a step delay
				_003C_003E2__current = new WaitForSeconds(PowerStepDelay);
				_003C_003E1__state = 2;
				return true;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__11 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant420Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__11(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant420Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null)
				{
					return false;
				}
				PlantBaseAttr attr = plant.attr;
				if (attr == null || attr.valueList == null)
				{
					return false;
				}
				// power 1: permanently boosts the sun value (valueList[1]) by the strengthen
				// amount and records a label describing the bonus.
				ValueEntity value = attr.valueList[1];
				if (value == null)
				{
					return false;
				}
				StrengthenEntity strengthen = entity;
				if (strengthen == null)
				{
					return false;
				}
				value.baseValue += strengthen.GetValue(plant);
				string desc = strengthen.GetDesc(plant);
				attr.AddLabel(strengthen.title, 1, desc);
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CProduceSun_003Ed__9 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant420Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CProduceSun_003Ed__9(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant420Entity plant = _003C_003E4__this;
				switch (num)
				{
				default:
					return false;
				case 0:
					_003C_003E1__state = -1;
					if (plant == null)
					{
						return false;
					}
					// TODO: reconstruct - state 0 first tinted the head sprite materials
					// via SpriteRenderer.material.DOFloat with a shader property id and target
					// value that are unresolved data pointers in the pseudocode; that visual
					// tween is dropped. The wait that follows is preserved.
					_003C_003E2__current = new WaitForSeconds(ProduceStepDelay);
					_003C_003E1__state = 1;
					return true;
				case 1:
					break;
				}
				_003C_003E1__state = -1;
				if (plant == null)
				{
					return false;
				}
				// fire the produce-sun callback
				if (plant.OnProduceSun != null)
				{
					plant.OnProduceSun();
				}
				PlantBaseAttr attr = plant.attr;
				if (attr == null)
				{
					return false;
				}
				int sunValue = attr.GetValueInt(plant, 1);
				List<SpriteRenderer> leftHeads = plant.leftHeadSpriteRendererList;
				if (leftHeads == null || leftHeads.Count < 1 || leftHeads[0] == null)
				{
					return false;
				}
				GameObject leftGo = leftHeads[0].gameObject;
				if (leftGo == null)
				{
					return false;
				}
				if (leftGo.activeSelf)
				{
					RewardManager.Instance.CreateSun(plant.transform.position, sunValue, 1f, true);
				}
				List<SpriteRenderer> rightHeads = plant.rightHeadSpriteRendererList;
				if (rightHeads == null || rightHeads.Count < 1 || rightHeads[0] == null)
				{
					return false;
				}
				GameObject rightGo = rightHeads[0].gameObject;
				if (rightGo == null)
				{
					return false;
				}
				if (rightGo.activeSelf)
				{
					RewardManager.Instance.CreateSun(plant.transform.position, sunValue, 1f, true);
					// TODO: reconstruct - dropped a trailing head-sprite tint tween (unresolved
					// shader property/value data pointers) followed by the final wait below.
					_003C_003E2__current = new WaitForSeconds(ProduceStepDelay);
					_003C_003E1__state = 2;
					return true;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		// TODO: unresolved WaitForSeconds durations for the head-produce / power ramps
		// (the pseudocode reads them from global config pointers 0x182e73b18 etc.).
		private const float ProduceStepDelay = 0f; // TODO: reconstruct constant
		private const float PowerStepDelay = 0f; // TODO: reconstruct constant

		// TODO: unresolved random-start multiplier applied to the initial production timer.
		private const float IntervalTimerStartFactor = 0f; // TODO: reconstruct constant

		[Tooltip("头贴图渲染器集合")]
		public List<SpriteRenderer> headSpriteRendererList;

		[Tooltip("左头渲染器集合")]
		public List<SpriteRenderer> leftHeadSpriteRendererList;

		[Tooltip("右头渲染器集合")]
		public List<SpriteRenderer> rightHeadSpriteRendererList;

		private float _intervalTimer;

		public Action OnProduceSun;

		public override void Reset()
		{
			base.Reset();
			if (attr == null)
			{
				return;
			}
			// Seed the production interval timer from the configured interval so the
			// first sun does not appear on the exact same frame for every plant.
			// TODO: IntervalTimerStartFactor is an unresolved global multiplier.
			_intervalTimer = attr.GetValue(this, 0) * IntervalTimerStartFactor;
		}

		protected override void Update()
		{
			base.Update();
			if (partEntity == null)
			{
				return;
			}
			// only tick while awake
			if (partEntity.isSleeping)
			{
				return;
			}
			_intervalTimer += Time.deltaTime;
			if (attr == null)
			{
				return;
			}
			// once the interval elapses, reset and kick off a sun-production coroutine
			if (attr.GetValue(this, 0) <= _intervalTimer)
			{
				_intervalTimer = 0f;
				StartCoroutine(ProduceSun());
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// ICF-folded onto an empty body; no level-0 effect for this plant.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// upgrade branch 0: trade some production interval (valueList[0]) for
				// faster output, scaled by the sun value (defaultAttr.valueList[0]).
				if (attr == null || attr.valueList == null)
				{
					return;
				}
				ValueEntity intervalValue = attr.valueList[0];
				if (intervalValue == null)
				{
					return;
				}
				if (defaultAttr == null || defaultAttr.valueList == null)
				{
					return;
				}
				ValueEntity defaultSunValue = defaultAttr.valueList[0];
				if (defaultSunValue == null)
				{
					return;
				}
				intervalValue.baseValue -= entity.GetValue(this) * defaultSunValue.baseValue;
			}
			else if (entity.index == 1)
			{
				// upgrade branch 1: increases the sun value (valueList[1]).
				if (attr == null || attr.valueList == null)
				{
					return;
				}
				ValueEntity sunValue = attr.valueList[1];
				if (sunValue == null)
				{
					return;
				}
				sunValue.baseValue += entity.GetValue(this);
			}
		}

		[IteratorStateMachine(typeof(_003CProduceSun_003Ed__9))]
		private IEnumerator ProduceSun()
		{
			return new _003CProduceSun_003Ed__9(0)
			{
				_003C_003E4__this = this
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__10))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__10(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__11))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__11(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		public override int GetHeadNumber()
		{
			// Count how many of the two side heads are currently active (0, 1 or 2).
			if (leftHeadSpriteRendererList == null || leftHeadSpriteRendererList.Count < 1)
			{
				return 0;
			}
			SpriteRenderer left = leftHeadSpriteRendererList[0];
			if (left == null)
			{
				return 0;
			}
			GameObject leftGo = left.gameObject;
			if (leftGo == null)
			{
				return 0;
			}
			bool leftActive = leftGo.activeSelf;
			if (rightHeadSpriteRendererList == null || rightHeadSpriteRendererList.Count < 1)
			{
				return 0;
			}
			SpriteRenderer right = rightHeadSpriteRendererList[0];
			if (right == null)
			{
				return 0;
			}
			GameObject rightGo = right.gameObject;
			if (rightGo == null)
			{
				return 0;
			}
			int count = leftActive ? 1 : 0;
			if (rightGo.activeSelf)
			{
				count++;
			}
			return count;
		}
	}
}
