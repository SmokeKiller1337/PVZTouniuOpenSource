using System;
using System.Collections;
using System.Collections.Generic;
using Common.Entity;
using Game.Entity;
using Level.Manager;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant420Entity : PlantEntity
	{
		private const float ProduceStepDelay = 0f;
		private const float PowerStepDelay = 0f;

		// TODO: unresolved random-start multiplier applied to the initial production timer.
		private const float IntervalTimerStartFactor = 0f;

		[Tooltip("头贴图渲染器集合")]
		public List<SpriteRenderer> headSpriteRendererList;

		[Tooltip("左头渲染器集合")]
		public List<SpriteRenderer> leftHeadSpriteRendererList;

		[Tooltip("右头渲染器集合")]
		public List<SpriteRenderer> rightHeadSpriteRendererList;

		private float _intervalTimer;

		public Action OnProduceSun;

		public override void Reset()
		{
			base.Reset();
			if (attr == null)
			{
				return;
			}
			// Seed the production interval timer from the configured interval so the
			// first sun does not appear on the exact same frame for every plant.
			// TODO: IntervalTimerStartFactor is an unresolved global multiplier.
			_intervalTimer = attr.GetValue(this, 0) * IntervalTimerStartFactor;
		}

		protected override void Update()
		{
			base.Update();
			if (partEntity == null)
			{
				return;
			}
			// only tick while awake
			if (partEntity.isSleeping)
			{
				return;
			}
			_intervalTimer += Time.deltaTime;
			if (attr == null)
			{
				return;
			}
			// once the interval elapses, reset and kick off a sun-production coroutine
			if (attr.GetValue(this, 0) <= _intervalTimer)
			{
				_intervalTimer = 0f;
				StartCoroutine(ProduceSun());
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// upgrade branch 0: trade some production interval (valueList[0]) for
				// faster output, scaled by the sun value (defaultAttr.valueList[0]).
				if (attr == null || attr.valueList == null)
				{
					return;
				}
				ValueEntity intervalValue = attr.valueList[0];
				if (intervalValue == null)
				{
					return;
				}
				if (defaultAttr == null || defaultAttr.valueList == null)
				{
					return;
				}
				ValueEntity defaultSunValue = defaultAttr.valueList[0];
				if (defaultSunValue == null)
				{
					return;
				}
				intervalValue.baseValue -= entity.GetValue(this) * defaultSunValue.baseValue;
			}
			else if (entity.index == 1)
			{
				// upgrade branch 1: increases the sun value (valueList[1]).
				if (attr == null || attr.valueList == null)
				{
					return;
				}
				ValueEntity sunValue = attr.valueList[1];
				if (sunValue == null)
				{
					return;
				}
				sunValue.baseValue += entity.GetValue(this);
			}
		}

		private IEnumerator ProduceSun()
		{
			if (this == null)
			{
				yield break;
			}
			// 等待一个产出步进间隔
			yield return new WaitForSeconds(ProduceStepDelay);
			if (this == null)
			{
				yield break;
			}
			// 触发产阳光回调
			if (OnProduceSun != null)
			{
				OnProduceSun();
			}
			PlantBaseAttr attr = this.attr;
			if (attr == null)
			{
				yield break;
			}
			int sunValue = attr.GetValueInt(this, 1);
			// 左头激活时在植株位置生成阳光
			List<SpriteRenderer> leftHeads = leftHeadSpriteRendererList;
			if (leftHeads == null || leftHeads.Count < 1 || leftHeads[0] == null)
			{
				yield break;
			}
			GameObject leftGo = leftHeads[0].gameObject;
			if (leftGo == null)
			{
				yield break;
			}
			if (leftGo.activeSelf)
			{
				RewardManager.Instance.CreateSun(transform.position, sunValue, 1f, true);
			}
			// 右头激活时再生成一份阳光，并再等待一个步进间隔
			List<SpriteRenderer> rightHeads = rightHeadSpriteRendererList;
			if (rightHeads == null || rightHeads.Count < 1 || rightHeads[0] == null)
			{
				yield break;
			}
			GameObject rightGo = rightHeads[0].gameObject;
			if (rightGo == null)
			{
				yield break;
			}
			if (rightGo.activeSelf)
			{
				RewardManager.Instance.CreateSun(transform.position, sunValue, 1f, true);
				yield return new WaitForSeconds(ProduceStepDelay);
			}
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			if (this == null)
			{
				yield break;
			}
			// 首个步进间隔后开始按强化数量分次产出阳光
			yield return new WaitForSeconds(PowerStepDelay);
			int i = 0;
			while (true)
			{
				StrengthenEntity strengthen = entity;
				if (strengthen == null || this == null)
				{
					yield break;
				}
				int count = (int)strengthen.GetValue(this);
				// 已产出足够次数：再等一个间隔后结束
				if (count <= i)
				{
					yield return new WaitForSeconds(PowerStepDelay);
					yield break;
				}
				// 触发产阳光回调
				if (OnProduceSun != null)
				{
					OnProduceSun();
				}
				PlantBaseAttr attr = this.attr;
				if (attr == null)
				{
					yield break;
				}
				int sunValue = attr.GetValueInt(this, 1);
				// 左头激活时生成阳光
				List<SpriteRenderer> leftHeads = leftHeadSpriteRendererList;
				if (leftHeads != null && leftHeads.Count > 0 && leftHeads[0] != null)
				{
					GameObject leftGo = leftHeads[0].gameObject;
					if (leftGo != null && leftGo.activeSelf)
					{
						RewardManager.Instance.CreateSun(transform.position, sunValue, 1f, true);
					}
				}
				// 右头激活时生成阳光
				List<SpriteRenderer> rightHeads = rightHeadSpriteRendererList;
				if (rightHeads == null || rightHeads.Count < 1 || rightHeads[0] == null)
				{
					yield break;
				}
				GameObject rightGo = rightHeads[0].gameObject;
				if (rightGo == null)
				{
					yield break;
				}
				if (rightGo.activeSelf)
				{
					RewardManager.Instance.CreateSun(transform.position, sunValue, 1f, true);
				}
				// 一个步进间隔后进入下一次产出
				yield return new WaitForSeconds(PowerStepDelay);
				i++;
			}
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			if (this == null)
			{
				yield break;
			}
			PlantBaseAttr attr = this.attr;
			if (attr == null || attr.valueList == null)
			{
				yield break;
			}
			// power 1: permanently boosts the sun value (valueList[1]) by the strengthen
			// amount and records a label describing the bonus.
			ValueEntity value = attr.valueList[1];
			if (value == null)
			{
				yield break;
			}
			if (entity == null)
			{
				yield break;
			}
			value.baseValue += entity.GetValue(this);
			string desc = entity.GetDesc(this);
			attr.AddLabel(entity.title, 1, desc);
		}

		public override int GetHeadNumber()
		{
			// Count how many of the two side heads are currently active (0, 1 or 2).
			if (leftHeadSpriteRendererList == null || leftHeadSpriteRendererList.Count < 1)
			{
				return 0;
			}
			SpriteRenderer left = leftHeadSpriteRendererList[0];
			if (left == null)
			{
				return 0;
			}
			GameObject leftGo = left.gameObject;
			if (leftGo == null)
			{
				return 0;
			}
			bool leftActive = leftGo.activeSelf;
			if (rightHeadSpriteRendererList == null || rightHeadSpriteRendererList.Count < 1)
			{
				return 0;
			}
			SpriteRenderer right = rightHeadSpriteRendererList[0];
			if (right == null)
			{
				return 0;
			}
			GameObject rightGo = right.gameObject;
			if (rightGo == null)
			{
				return 0;
			}
			int count = leftActive ? 1 : 0;
			if (rightGo.activeSelf)
			{
				count++;
			}
			return count;
		}
	}
}
