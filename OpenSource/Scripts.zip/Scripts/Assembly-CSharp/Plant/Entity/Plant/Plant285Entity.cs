using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using Level.Manager;
using Level.Util;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;
using Zombie.Entity.Data;

namespace Plant.Entity.Plant
{
	public class Plant285Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__10 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant285Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__10(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct - the AttackCoroutine state machine drives the wind attack
				// (plays blowSound, blows land/balloon zombies via unresolved virtual slots
				// 0x418/0x238, applies pierce damage, and animates knock-back via DG.Tweening
				// DOLocalMoveX/OnComplete chains). Those vtable slots and tween targets are
				// indirect calls that cannot be mapped to concrete public members from the
				// dump, so the body is left as a non-yielding stub.
				int num = _003C_003E1__state;
				if (num == 0)
				{
					_003C_003E1__state = -1;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__13 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant285Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__13(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant285Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					// Cache the strengthen entity that drives this power so the attack
					// coroutine can read its scaled values while the power is active.
					plant._currentPowerEntity = entity;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__14 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant285Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__14(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant285Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					// Cache the strengthen entity that drives this power so the attack
					// coroutine can read its scaled values while the power is active.
					plant._currentPowerEntity = entity;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("吹风音效")]
		public AudioClip blowSound;

		private bool _isSun;

		private StrengthenEntity _currentPowerEntity;

		public Action OnBlowAction;

		public override void Reset()
		{
			// TODO: reconstruct - after base.Reset() the pseudocode schedules two
			// DG.Tweening DOVirtual.DelayedCall callbacks whose targets are indirect
			// delegate slots (0x430 / 0x280) that cannot be mapped to named members,
			// then conditionally triggers the power (virtual slot 0x478) and invokes an
			// unresolved Action-list on this instance. Those indirect targets are not
			// recoverable from the dump, so the override is left as a stub.
		}

		protected override void Start()
		{
			base.Start();
			// _isSun (0x128): sun-producing variant spawns a sun burst on start.
			if (!_isSun)
			{
				return;
			}
			// GetStrengthenEntity(2, 1) supplies the sun value for this plant.
			StrengthenEntity strengthenEntity = GetStrengthenEntity(2, 1);
			RewardManager rewardManager = RewardManager.Instance;
			if (Rigidbody != null && strengthenEntity != null && rewardManager != null)
			{
				Vector2 position = Rigidbody.position;
				int value = (int)strengthenEntity.GetValue(this, 0);
				rewardManager.CreateSun(position, value, 1f, true);
			}
		}

		public override void Death()
		{
			// TODO: reconstruct - the pseudocode invokes an unresolved virtual slot (0x288)
			// before ClearLand()/Destroy(gameObject). That leading slot cannot be mapped to
			// a concrete named member from the dump, so this override is left as a stub
			// rather than guess which cleanup method it routes to.
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// The pseudocode body folded to an empty method (no per-level-0 effect).
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			// TODO: reconstruct - after base.OnLevelUp2 the pseudocode mutates raw value
			// entries inside attr/defaultAttr (fields reached via offsets 0x38 -> list ->
			// item 0x20) keyed on entity.index. Those internal value-list item members are
			// not named in the skeleton or the dump, so the mutation cannot be reconstructed
			// safely and the override is left as a stub.
		}

		protected override void Attack()
		{
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__10))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__10(0)
			{
				_003C_003E4__this = this
			};
		}

		private List<Zombie160Entity> GetBalloonZombieList(int row = -1)
		{
			// Collect on-field zombies that are balloon zombies (Zombie160Entity) still
			// carrying a balloon, optionally restricted to a single row.
			return (from ZombieEntity zombie in LevelUtils.GetLandZombieList()
				where row == -1 || zombie.GetRow() == row
				let balloon = zombie as Zombie160Entity
				where balloon != null && balloon.isHasBalloon
				select balloon).ToList();
		}

		protected override bool CheckAttack()
		{
			// The pseudocode body folded to a constant-false return: this plant's attack
			// cadence is driven by the power/wind logic rather than the default check.
			return false;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__13))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__13(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__14))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__14(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
