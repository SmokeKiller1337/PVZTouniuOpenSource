using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Level.Manager;
using Level.Util;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;
using Zombie.Entity.Data;

namespace Plant.Entity.Plant
{
	public class Plant285Entity : PlantEntity
	{
		[Tooltip("吹风音效")]
		public AudioClip blowSound;

		private bool _isSun;

		private StrengthenEntity _currentPowerEntity;

		public Action OnBlowAction;

		public override void Reset()
		{
		}

		protected override void Start()
		{
			base.Start();
			// 产阳光变体在出生时生成一次阳光。
			if (!_isSun)
			{
				return;
			}
			// GetStrengthenEntity(2, 1) 提供本植物的阳光数值。
			StrengthenEntity strengthenEntity = GetStrengthenEntity(2, 1);
			RewardManager rewardManager = RewardManager.Instance;
			if (Rigidbody != null && strengthenEntity != null && rewardManager != null)
			{
				Vector2 position = Rigidbody.position;
				int value = (int)strengthenEntity.GetValue(this, 0);
				rewardManager.CreateSun(position, value, 1f, true);
			}
		}

		public override void Death()
		{
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
		}

		protected override void Attack()
		{
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			yield break;
		}

		private List<Zombie160Entity> GetBalloonZombieList(int row = -1)
		{
			// 收集场上仍带着气球的气球僵尸（Zombie160Entity），可按行筛选。
			return (from ZombieEntity zombie in LevelUtils.GetLandZombieList()
				where row == -1 || zombie.GetRow() == row
				let balloon = zombie as Zombie160Entity
				where balloon != null && balloon.isHasBalloon
				select balloon).ToList();
		}

		protected override bool CheckAttack()
		{
			return false;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 记录驱动本次能力的强化实体，供攻击协程读取其数值。
			_currentPowerEntity = entity;
			yield break;
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			// 记录驱动本次能力的强化实体，供攻击协程读取其数值。
			_currentPowerEntity = entity;
			yield break;
		}
	}
}
