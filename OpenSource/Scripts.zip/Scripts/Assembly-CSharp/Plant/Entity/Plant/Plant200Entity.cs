using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Collider;
using Common.Entity;
using Game.Entity;
using Level.Entity;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant200Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass13_0
		{
			public string labelTitle;
		}

		[CompilerGenerated]
		private sealed class _003CExplosion_003Ed__13 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant200Entity _003C_003E4__this;

			private _003C_003Ec__DisplayClass13_0 _003C_003E8__1;

			private float _003Cdamage_003E5__2;

			private float _003CeffectScale_003E5__3;

			private DamageTypeEntity _003CdamageTypeEntity_003E5__4;

			private List<ZombieEntity> _003CzombieList_003E5__5;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CExplosion_003Ed__13(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			// TODO: reconstruct
			// The explosion state machine is a 3-state coroutine that:
			//   * flags the plant invincible, plays explosionSound via AudioManager,
			//     spawns the explosion effect + a camera impulse, computes the AoE damage,
			//     runs DamageUtils.Explosion over the "Zombie" layer, collects the hit
			//     zombies into <zombieList>5__5, waits, then applies per-zombie damage /
			//     labels / effects across two more yield points.
			// The body is dominated by ZombieEntity members reached only by raw offset
			// (attr @0x118, unnamed flags @0x130/0x55, child objects @0x60/0x48), by a
			// second compiler-generated closure (<>c__DisplayClass13_1) that is not present
			// in the provided skeleton, and by several effect/impulse manager singletons
			// that do not exist in the project. Reconstructing it faithfully would require
			// inventing those members and a nested type, so per the reconstruction rules it
			// is left as a faithful stub.
			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__16 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant200Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__16(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant200Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant != null && plant.attr != null)
				{
					// Big-explosion power: make the plant briefly invincible, mark the next
					// explosion as the big variant, restart the explosion coroutine.
					plant.attr.isInvincible = true;
					plant._isBigExplosion = true;
					if (plant._explosionCoroutine != null)
					{
						plant.StopCoroutine(plant._explosionCoroutine);
					}
					plant.StartCoroutine(plant.Explosion());
					if (plant.attr != null)
					{
						plant.attr.isInvincible = false;
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__17 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public StrengthenEntity entity;

			public Plant200Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__17(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant200Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (entity != null)
				{
					// Extra-explosion-count power: read the strengthen value, bump the extra
					// explosion counter, and stamp a matching label onto the plant's attr.
					float value = entity.GetValue(plant, 0);
					if (plant != null)
					{
						plant._extraExplosionCount += (int)value;
						PlantBaseAttr attr = plant.attr;
						if (attr != null)
						{
							attr.AddLabel(entity.title, (int)value, entity.GetDesc(plant));
						}
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("爆炸效果")]
		public EffectEntity explosionEffect;

		[Tooltip("爆炸音效")]
		public AudioClip explosionSound;

		private int _extraExplosionCount;

		private bool _isSun;

		private bool _isBigExplosion;

		private List<ZombieEntity> _targetList;

		private Coroutine _explosionCoroutine;

		// TODO: the tag/layer name is a data pointer in the pseudocode (_DAT_182e30fc8);
		// it gates the custom-trigger zombie detection and the explosion layer mask.
		private const string ZombieTag = "Zombie"; // TODO: reconstruct literal

		// TODO: the animation state name played on reset is a data pointer (_DAT_182e3cae0).
		private const string ResetAnimName = "Idle"; // TODO: reconstruct literal

		public override void Reset()
		{
			base.Reset();
			// attr.isNotEat (0xE0 + 0x19) = true
			if (attr != null)
			{
				attr.isNotEat = true;
			}
			if (_targetList != null)
			{
				_targetList.Clear();
				if (_animator != null)
				{
					_animator.Play(ResetAnimName);
					// reset the per-explosion state
					_isSun = false;
					_isBigExplosion = false;
					_extraExplosionCount = 0;
					_explosionCoroutine = null;
				}
			}
		}

		public void ResetSelf()
		{
			if (_targetList != null)
			{
				_targetList.Clear();
				if (_animator != null)
				{
					// Animator.Play(StringToHash(anim), -1, 0f)
					_animator.Play(Animator.StringToHash(ResetAnimName), -1, 0f);
				}
			}
		}

		protected override void Update()
		{
			base.Update();
			if (_targetList == null)
			{
				return;
			}
			if (_targetList.Count < 1)
			{
				return;
			}
			// Count the live targets currently in range. The pseudocode's per-zombie
			// liveness test reads ZombieEntity flags by raw offset (0x130 + 0x55) and a
			// virtual slot (0x388) whose member names are not present in the skeleton, so
			// the exact predicate is approximated here by a non-null check.
			int count = 0;
			foreach (ZombieEntity zombie in _targetList)
			{
				// TODO: reconstruct the exact liveness predicate (zombie flags @0x130/0x55 + vtable 0x388)
				if (zombie != null)
				{
					count++;
				}
			}
			// When there is at least one target and no explosion is already running, arm it.
			if (count >= 1 && _explosionCoroutine == null)
			{
				_explosionCoroutine = StartCoroutine(Explosion());
			}
		}

		public override void HitEat(float value, ZombieEntity zombieEntity)
		{
			base.HitEat(value, zombieEntity);
			if (zombieEntity == null)
			{
				return;
			}
			if (_targetList == null)
			{
				return;
			}
			if (!_targetList.Contains(zombieEntity))
			{
				_targetList.Add(zombieEntity);
			}
			if (_explosionCoroutine == null)
			{
				_explosionCoroutine = StartCoroutine(Explosion());
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// ICF-folded onto an empty method in the pseudocode; base OnLevelUp is a no-op.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (entity.index != 0)
			{
				// index == 1 : this plant now produces sun on explosion
				if (entity.index == 1)
				{
					_isSun = true;
				}
				return;
			}
			// index == 0 : scale the attack up by (defaultAttr.attack * value)
			PlantBaseAttr a = attr;
			if (a == null)
			{
				return;
			}
			int oldAttack = a.attack;
			float value = entity.GetValue(this, 0);
			if (defaultAttr != null)
			{
				a.attack = (int)((float)defaultAttr.attack * value) + oldAttack;
			}
		}

		[IteratorStateMachine(typeof(_003CExplosion_003Ed__13))]
		public IEnumerator Explosion()
		{
			return new _003CExplosion_003Ed__13(0)
			{
				_003C_003E4__this = this
			};
		}

		public override void OnTriggerCustomEnter(Collider2D col, int index)
		{
			base.OnTriggerCustomEnter(col, index);
			if (col == null)
			{
				return;
			}
			GameObject gameObject = col.gameObject;
			if (gameObject == null)
			{
				return;
			}
			if (!gameObject.CompareTag(ZombieTag))
			{
				return;
			}
			ZombieBodyColliderEntity colliderEntity = gameObject.GetComponent<ZombieBodyColliderEntity>();
			if (colliderEntity == null)
			{
				return;
			}
			if (_targetList == null)
			{
				return;
			}
			ZombieEntity zombieEntity = colliderEntity.zombieEntity;
			if (!_targetList.Contains(zombieEntity))
			{
				_targetList.Add(zombieEntity);
			}
		}

		public override void OnTriggerCustomExit(Collider2D col, int index)
		{
			base.OnTriggerCustomExit(col, index);
			if (col == null)
			{
				return;
			}
			GameObject gameObject = col.gameObject;
			if (gameObject == null)
			{
				return;
			}
			ZombieBodyColliderEntity colliderEntity = gameObject.GetComponent<ZombieBodyColliderEntity>();
			if (colliderEntity == null)
			{
				return;
			}
			if (_targetList == null)
			{
				return;
			}
			ZombieEntity zombieEntity = colliderEntity.zombieEntity;
			if (_targetList.Contains(zombieEntity))
			{
				_targetList.Remove(zombieEntity);
			}
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__16))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__16(0)
			{
				_003C_003E4__this = this
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__17))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__17(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
