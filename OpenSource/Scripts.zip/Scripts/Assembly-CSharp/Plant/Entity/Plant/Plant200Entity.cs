using System;
using System.Collections;
using System.Collections.Generic;
using Common.Collider;
using Common.Entity;
using Game.Entity;
using Level.Entity;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant200Entity : PlantEntity
	{
		[Tooltip("爆炸效果")]
		public EffectEntity explosionEffect;

		[Tooltip("爆炸音效")]
		public AudioClip explosionSound;

		private int _extraExplosionCount;

		private bool _isSun;

		private bool _isBigExplosion;

		private List<ZombieEntity> _targetList;

		private Coroutine _explosionCoroutine;

		private const string ZombieTag = "Zombie";

		private const string ResetAnimName = "Idle";

		public override void Reset()
		{
			base.Reset();
			// 该植物不可被啃食
			if (attr != null)
			{
				attr.isNotEat = true;
			}
			if (_targetList != null)
			{
				_targetList.Clear();
				if (_animator != null)
				{
					_animator.Play(ResetAnimName);
					// reset the per-explosion state
					_isSun = false;
					_isBigExplosion = false;
					_extraExplosionCount = 0;
					_explosionCoroutine = null;
				}
			}
		}

		public void ResetSelf()
		{
			if (_targetList != null)
			{
				_targetList.Clear();
				if (_animator != null)
				{
					_animator.Play(Animator.StringToHash(ResetAnimName), -1, 0f);
				}
			}
		}

		protected override void Update()
		{
			base.Update();
			if (_targetList == null)
			{
				return;
			}
			if (_targetList.Count < 1)
			{
				return;
			}
			int count = 0;
			foreach (ZombieEntity zombie in _targetList)
			{
				if (zombie != null)
				{
					count++;
				}
			}
			// When there is at least one target and no explosion is already running, arm it.
			if (count >= 1 && _explosionCoroutine == null)
			{
				_explosionCoroutine = StartCoroutine(Explosion());
			}
		}

		public override void HitEat(float value, ZombieEntity zombieEntity)
		{
			base.HitEat(value, zombieEntity);
			if (zombieEntity == null)
			{
				return;
			}
			if (_targetList == null)
			{
				return;
			}
			if (!_targetList.Contains(zombieEntity))
			{
				_targetList.Add(zombieEntity);
			}
			if (_explosionCoroutine == null)
			{
				_explosionCoroutine = StartCoroutine(Explosion());
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (entity.index != 0)
			{
				// index == 1 : this plant now produces sun on explosion
				if (entity.index == 1)
				{
					_isSun = true;
				}
				return;
			}
			// index == 0 : scale the attack up by (defaultAttr.attack * value)
			PlantBaseAttr a = attr;
			if (a == null)
			{
				return;
			}
			int oldAttack = a.attack;
			float value = entity.GetValue(this, 0);
			if (defaultAttr != null)
			{
				a.attack = (int)((float)defaultAttr.attack * value) + oldAttack;
			}
		}

		public IEnumerator Explosion()
		{
			yield break;
		}

		public override void OnTriggerCustomEnter(Collider2D col, int index)
		{
			base.OnTriggerCustomEnter(col, index);
			if (col == null)
			{
				return;
			}
			GameObject gameObject = col.gameObject;
			if (gameObject == null)
			{
				return;
			}
			if (!gameObject.CompareTag(ZombieTag))
			{
				return;
			}
			ZombieBodyColliderEntity colliderEntity = gameObject.GetComponent<ZombieBodyColliderEntity>();
			if (colliderEntity == null)
			{
				return;
			}
			if (_targetList == null)
			{
				return;
			}
			ZombieEntity zombieEntity = colliderEntity.zombieEntity;
			if (!_targetList.Contains(zombieEntity))
			{
				_targetList.Add(zombieEntity);
			}
		}

		public override void OnTriggerCustomExit(Collider2D col, int index)
		{
			base.OnTriggerCustomExit(col, index);
			if (col == null)
			{
				return;
			}
			GameObject gameObject = col.gameObject;
			if (gameObject == null)
			{
				return;
			}
			ZombieBodyColliderEntity colliderEntity = gameObject.GetComponent<ZombieBodyColliderEntity>();
			if (colliderEntity == null)
			{
				return;
			}
			if (_targetList == null)
			{
				return;
			}
			ZombieEntity zombieEntity = colliderEntity.zombieEntity;
			if (_targetList.Contains(zombieEntity))
			{
				_targetList.Remove(zombieEntity);
			}
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 大爆炸能力：短暂进入无敌，标记下一次为大爆炸，并重启爆炸协程
			if (attr != null)
			{
				attr.isInvincible = true;
				_isBigExplosion = true;
				if (_explosionCoroutine != null)
				{
					StopCoroutine(_explosionCoroutine);
				}
				StartCoroutine(Explosion());
				if (attr != null)
				{
					attr.isInvincible = false;
				}
			}
			yield break;
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			// 额外爆炸次数能力：读取强化数值，累加额外爆炸计数，并在 attr 上打上对应标签
			if (entity != null)
			{
				float value = entity.GetValue(this, 0);
				_extraExplosionCount += (int)value;
				PlantBaseAttr plantBaseAttr = attr;
				if (plantBaseAttr != null)
				{
					plantBaseAttr.AddLabel(entity.title, (int)value, entity.GetDesc(this));
				}
			}
			yield break;
		}
	}
}
