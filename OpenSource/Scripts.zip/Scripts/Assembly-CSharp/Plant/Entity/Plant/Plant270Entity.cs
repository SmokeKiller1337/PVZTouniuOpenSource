using System;
using System.Collections;
using System.Collections.Generic;
using Audio.Manager;
using Bullet.Entity;
using Land.Entity;
using Level.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant270Entity : PlantEntity
	{
		private const string GrowAnimName = "Grow";
		private const string ShrinkAnimName = "Shrink";
		private const string RiseGrowAnimName = "RiseGrow";
		private const string RiseShrinkAnimName = "RiseShrink";

		private const float RiseWaitFactor = 1f;
		private const float ShrinkWaitFactor = 1f;
		private const float RiseTransitionTime = 0f;
		private const float Power0WaitTime = 0f;
		private const float RiseCheckInterval = 0f;

		private const float PierceTriggerBonus = 1f;

		[Tooltip("子弹位置")]
		public Transform bulletPosition;

		[Tooltip("高子弹位置")]
		public Transform bulletPosition1;

		[Tooltip("生长音效")]
		public AudioClip growSound;

		[Tooltip("缩小音效")]
		public AudioClip decreaseSound;

		[HideInInspector]
		public bool isRise;

		private bool _isRising;

		private float _riseTimer;

		public bool IsRising
		{
			get
			{
				return _isRising;
			}
			set
			{
				_isRising = value;
			}
		}

		public override void Reset()
		{
			base.Reset();
			_isRising = false;
		}

		protected override void Update()
		{
			base.Update();
			// Only tick the rise check while no rise transition is currently running.
			if (_isRising)
			{
				return;
			}
			_riseTimer += Time.deltaTime;
			if (_riseTimer > RiseCheckInterval)
			{
				_riseTimer = 0f;
				IEnumerator routine = CheckRise();
				if (routine == null)
				{
					throw new NullReferenceException();
				}
				StartCoroutine(routine);
			}
		}

		protected virtual IEnumerator CheckRise()
		{
			// 没有落脚点则无需检测
			if (CurrentLandEntity == null)
			{
				yield break;
			}
			IsRising = true;
			LandEntity land = CurrentLandEntity;
			if (land == null)
			{
				yield break;
			}
			if (IsHasBalloonRow(land.rowId) && !isRise)
			{
				// 同一行有气球僵尸且当前较矮：长高
				AudioManager audioManager = AudioManager.Instance;
				if (audioManager != null)
				{
					audioManager.PlayOneShot(growSound);
					isRise = true;
					if (_animator != null)
					{
						_animator.Play(RiseGrowAnimName);
						yield return new WaitForSeconds(RiseTransitionTime);
						IsRising = false;
					}
				}
				yield break;
			}
			land = CurrentLandEntity;
			if (land == null)
			{
				yield break;
			}
			if (IsHasBalloonRow(land.rowId))
			{
				// 仍有气球且已升起：保持当前姿态
				IsRising = false;
				yield break;
			}
			if (isRise)
			{
				// 气球已消失但当前较高：缩回
				AudioManager audioManager = AudioManager.Instance;
				if (audioManager != null)
				{
					audioManager.PlayOneShot(decreaseSound);
					isRise = false;
					if (_animator != null)
					{
						_animator.Play(RiseShrinkAnimName);
						yield return new WaitForSeconds(RiseTransitionTime);
						IsRising = false;
					}
				}
				yield break;
			}
			IsRising = false;
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// Intentionally empty: the compiled body is a no-op override.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// Level-2 branch 0: lower attack and make both bullets piercing.
				if (attr == null || defaultAttr == null)
				{
					return;
				}
				int currentAttack = attr.attack;
				int defaultAttack = defaultAttr.attack;
				float ratio = entity.GetValue(this, 0);
				attr.attack = currentAttack - (int)((float)defaultAttack * ratio);
				if (bulletList == null)
				{
					return;
				}
				BulletAttr bullet0 = bulletList[0];
				if (bullet0 == null)
				{
					return;
				}
				bullet0.damageType = DamageTypeEntity.Pierce;
				bullet0.triggerCount += PierceTriggerBonus;
				BulletAttr bullet1 = bulletList[1];
				if (bullet1 == null)
				{
					return;
				}
				bullet1.damageType = DamageTypeEntity.Pierce;
				bullet1.triggerCount += PierceTriggerBonus;
			}
			else if (entity.index == 1)
			{
				// Level-2 branch 1: raise attack.
				if (attr == null || defaultAttr == null)
				{
					return;
				}
				int currentAttack = attr.attack;
				int defaultAttack = defaultAttr.attack;
				float ratio = entity.GetValue(this, 0);
				attr.attack = (int)((float)defaultAttack * ratio) + currentAttack;
			}
		}

		protected override void Attack()
		{
			base.Attack();
			IEnumerator routine = AttackCoroutine();
			if (routine == null)
			{
				throw new NullReferenceException();
			}
			StartCoroutine(routine);
		}

		protected virtual IEnumerator AttackCoroutine()
		{
			// 升/降过渡进行中则不攻击
			if (IsRising)
			{
				yield break;
			}
			float riseAttackRatio = 0f;
			// 升起攻击加成比例取自二级强化实体
			StrengthenEntity entity = GetStrengthenEntity(2, 1);
			if (entity != null)
			{
				riseAttackRatio = entity.GetValue(this, 1);
			}
			if (!isRise)
			{
				// 尚未升起：先生长，再发射地面子弹
				if (_animator != null)
				{
					_animator.Play(GrowAnimName);
					if (attr != null)
					{
						yield return new WaitForSeconds(attr.attackIntervalTime * RiseWaitFactor);
						if (bulletPosition != null)
						{
							CreateBullet(0, bulletPosition.position);
						}
					}
				}
			}
			else if (attr != null && defaultAttr != null)
			{
				// 已升起：临时提升攻击、缩小后发射高子弹
				attr.attack += (int)((float)defaultAttr.attack * riseAttackRatio);
				if (_animator != null)
				{
					_animator.Play(ShrinkAnimName);
					if (attr != null)
					{
						yield return new WaitForSeconds(attr.attackIntervalTime * ShrinkWaitFactor);
						if (bulletPosition1 != null)
						{
							CreateBullet(1, bulletPosition1.position);
							if (attr != null && defaultAttr != null)
							{
								attr.attack -= (int)((float)defaultAttr.attack * riseAttackRatio);
							}
						}
					}
				}
			}
		}

		protected override bool CheckAttack()
		{
			// Attack if a zombie is directly in front...
			if (CheckIsFrontZombie())
			{
				return true;
			}
			// ...or if a balloon zombie shares this row and the plant is currently risen.
			LandEntity land = CurrentLandEntity;
			if (land != null && IsHasBalloonRow(land.rowId) && isRise)
			{
				return true;
			}
			return false;
		}

		private bool IsHasBalloonRow(int row = -1)
		{
			return false;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			if (_animator == null)
			{
				yield break;
			}
			_animator.Play(GrowAnimName);
			yield return new WaitForSeconds(Power0WaitTime);
			if (bulletPosition == null)
			{
				yield break;
			}
			// 发射特殊子弹（索引2），其伤害由强化数值加成
			BulletEntity bullet = CreateBullet(2, bulletPosition.position);
			if (bullet == null || bullet.attr == null)
			{
				yield break;
			}
			int baseDamage = bullet.attr.damage;
			if (entity == null)
			{
				yield break;
			}
			float value = entity.GetValue(this, 0);
			bullet.attr.damage = (int)value + baseDamage;
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			if (attr != null)
			{
				float baseSpeed = attr.attackSpeed;
				if (defaultAttr != null)
				{
					float defaultSpeed = defaultAttr.attackSpeed;
					if (entity != null)
					{
						float ratio = entity.GetValue(this, 0);
						attr.AttackSpeed = ratio * defaultSpeed + baseSpeed;
						if (attr != null)
						{
							// 添加描述该加成的强化标签
							attr.AddLabel(entity.title, 1, entity.GetDesc(this));
						}
					}
				}
			}
			yield break;
		}
	}
}
