using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Audio.Manager;
using Bullet.Entity;
using Land.Entity;
using Level.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant270Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__16 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant270Entity _003C_003E4__this;

			private float _003CriseAttackRatio_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__16(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant270Entity plant = _003C_003E4__this;
				switch (num)
				{
				case 0:
				{
					_003C_003E1__state = -1;
					// Abort if a rise transition is already in progress.
					if (plant.IsRising)
					{
						return false;
					}
					_003CriseAttackRatio_003E5__2 = 0f;
					// The rise/attack scaling ratio comes from the level-2 strengthen entity.
					StrengthenEntity entity = plant.GetStrengthenEntity(2, 1);
					if (entity != null)
					{
						_003CriseAttackRatio_003E5__2 = entity.GetValue(plant, 1);
					}
					if (!plant.isRise)
					{
						// Not yet risen: grow, then fire the ground bullet.
						if (plant._animator != null)
						{
							plant._animator.Play(GrowAnimName);
							if (plant.attr != null)
							{
								// yield return new WaitForSeconds(attr.attackIntervalTime * RiseWaitFactor);
								_003C_003E2__current = new WaitForSeconds(plant.attr.attackIntervalTime * RiseWaitFactor);
								_003C_003E1__state = 2;
								return true;
							}
						}
					}
					else if (plant.attr != null && plant.defaultAttr != null)
					{
						// Already risen: temporarily boost attack, shrink, then fire the high bullet.
						plant.attr.attack += (int)((float)plant.defaultAttr.attack * _003CriseAttackRatio_003E5__2);
						if (plant._animator != null)
						{
							plant._animator.Play(ShrinkAnimName);
							if (plant.attr != null)
							{
								// yield return new WaitForSeconds(attr.attackIntervalTime * ShrinkWaitFactor);
								_003C_003E2__current = new WaitForSeconds(plant.attr.attackIntervalTime * ShrinkWaitFactor);
								_003C_003E1__state = 1;
								return true;
							}
						}
					}
					return false;
				}
				case 1:
					_003C_003E1__state = -1;
					if (plant != null && plant.bulletPosition1 != null)
					{
						plant.CreateBullet(1, plant.bulletPosition1.position);
						if (plant.attr != null && plant.defaultAttr != null)
						{
							plant.attr.attack -= (int)((float)plant.defaultAttr.attack * _003CriseAttackRatio_003E5__2);
						}
					}
					return false;
				case 2:
					_003C_003E1__state = -1;
					if (plant != null && plant.bulletPosition != null)
					{
						plant.CreateBullet(0, plant.bulletPosition.position);
					}
					return false;
				default:
					return false;
				}
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CCheckRise_003Ed__12 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant270Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CCheckRise_003Ed__12(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant270Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (plant == null)
					{
						return false;
					}
					// No land -> nothing to check.
					if (plant.CurrentLandEntity == null)
					{
						return false;
					}
					plant.IsRising = true;
					LandEntity land = plant.CurrentLandEntity;
					if (land == null)
					{
						return false;
					}
					if (plant.IsHasBalloonRow(land.rowId) && !plant.isRise)
					{
						// A balloon zombie shares this row and the plant is short: grow up.
						AudioManager audioManager = AudioManager.Instance;
						if (audioManager != null)
						{
							audioManager.PlayOneShot(plant.growSound);
							plant.isRise = true;
							if (plant._animator != null)
							{
								plant._animator.Play(RiseGrowAnimName);
								_003C_003E2__current = new WaitForSeconds(RiseTransitionTime);
								_003C_003E1__state = 1;
								return true;
							}
						}
						return false;
					}
					land = plant.CurrentLandEntity;
					if (land == null)
					{
						return false;
					}
					if (plant.IsHasBalloonRow(land.rowId))
					{
						// Balloon still present and already risen: keep current pose.
						plant.IsRising = false;
						return false;
					}
					if (plant.isRise)
					{
						// No balloon left but currently tall: shrink back down.
						AudioManager audioManager = AudioManager.Instance;
						if (audioManager != null)
						{
							audioManager.PlayOneShot(plant.decreaseSound);
							plant.isRise = false;
							if (plant._animator != null)
							{
								plant._animator.Play(RiseShrinkAnimName);
								_003C_003E2__current = new WaitForSeconds(RiseTransitionTime);
								_003C_003E1__state = 2;
								return true;
							}
						}
						return false;
					}
				}
				else if (num != 1 && num != 2)
				{
					return false;
				}
				else
				{
					_003C_003E1__state = -1;
				}
				if (plant != null)
				{
					plant.IsRising = false;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__19 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant270Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__19(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant270Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (plant == null || plant._animator == null)
					{
						return false;
					}
					plant._animator.Play(GrowAnimName);
					_003C_003E2__current = new WaitForSeconds(Power0WaitTime);
					_003C_003E1__state = 1;
					return true;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null || plant.bulletPosition == null)
				{
					return false;
				}
				// Fire a special (index 2) bullet whose damage is scaled by the strengthen value.
				BulletEntity bullet = plant.CreateBullet(2, plant.bulletPosition.position);
				if (bullet == null || bullet.attr == null)
				{
					return false;
				}
				int baseDamage = bullet.attr.damage;
				if (entity == null)
				{
					return false;
				}
				float value = entity.GetValue(plant, 0);
				bullet.attr.damage = (int)value + baseDamage;
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__20 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant270Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__20(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				Plant270Entity plant = _003C_003E4__this;
				if (_003C_003E1__state != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant != null && plant.attr != null)
				{
					float baseSpeed = plant.attr.attackSpeed;
					if (plant.defaultAttr != null)
					{
						float defaultSpeed = plant.defaultAttr.attackSpeed;
						if (entity != null)
						{
							float ratio = entity.GetValue(plant, 0);
							plant.attr.AttackSpeed = ratio * defaultSpeed + baseSpeed;
							if (plant.attr != null)
							{
								// Add a strengthen label describing the boost.
								plant.attr.AddLabel(entity.title, 1, entity.GetDesc(plant));
							}
						}
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		// TODO: reconstruct — the following Animator state names are data pointers in the
		// pseudocode and could not be resolved to their literal strings. Replace with the
		// real Animator state names when known.
		private const string GrowAnimName = "Grow"; // TODO: reconstruct literal
		private const string ShrinkAnimName = "Shrink"; // TODO: reconstruct literal
		private const string RiseGrowAnimName = "RiseGrow"; // TODO: reconstruct literal
		private const string RiseShrinkAnimName = "RiseShrink"; // TODO: reconstruct literal

		// TODO: reconstruct — the following timing factors/durations are unresolved global
		// float constants (_DAT_18252cd08 / _DAT_18252cd00 / _DAT_18252cb24 / _DAT_18252ccfc /
		// _DAT_18252cb64) from the pseudocode. Placeholder values keep the code compiling.
		private const float RiseWaitFactor = 1f; // TODO: reconstruct constant (_DAT_18252cd08)
		private const float ShrinkWaitFactor = 1f; // TODO: reconstruct constant (_DAT_18252cd00)
		private const float RiseTransitionTime = 0f; // TODO: reconstruct constant (_DAT_18252cb24)
		private const float Power0WaitTime = 0f; // TODO: reconstruct constant (_DAT_18252ccfc)
		private const float RiseCheckInterval = 0f; // TODO: reconstruct constant (_DAT_18252cb64)

		// TODO: reconstruct — unresolved float constant applied per level-2 bullet upgrade
		// (_DAT_18252cb28, expected to be 1f based on sibling classes).
		private const float PierceTriggerBonus = 1f; // TODO: reconstruct constant (_DAT_18252cb28)

		[Tooltip("子弹位置")]
		public Transform bulletPosition;

		[Tooltip("高子弹位置")]
		public Transform bulletPosition1;

		[Tooltip("生长音效")]
		public AudioClip growSound;

		[Tooltip("缩小音效")]
		public AudioClip decreaseSound;

		[HideInInspector]
		public bool isRise;

		private bool _isRising;

		private float _riseTimer;

		public bool IsRising
		{
			get
			{
				return _isRising;
			}
			set
			{
				_isRising = value;
			}
		}

		public override void Reset()
		{
			base.Reset();
			_isRising = false;
		}

		protected override void Update()
		{
			base.Update();
			// Only tick the rise check while no rise transition is currently running.
			if (_isRising)
			{
				return;
			}
			_riseTimer += Time.deltaTime;
			if (_riseTimer > RiseCheckInterval)
			{
				_riseTimer = 0f;
				IEnumerator routine = CheckRise();
				if (routine == null)
				{
					throw new NullReferenceException();
				}
				StartCoroutine(routine);
			}
		}

		[IteratorStateMachine(typeof(_003CCheckRise_003Ed__12))]
		protected virtual IEnumerator CheckRise()
		{
			return new _003CCheckRise_003Ed__12(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// Intentionally empty: the compiled body is a no-op override.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// Level-2 branch 0: lower attack and make both bullets piercing.
				if (attr == null || defaultAttr == null)
				{
					return;
				}
				int currentAttack = attr.attack;
				int defaultAttack = defaultAttr.attack;
				float ratio = entity.GetValue(this, 0);
				attr.attack = currentAttack - (int)((float)defaultAttack * ratio);
				if (bulletList == null)
				{
					return;
				}
				BulletAttr bullet0 = bulletList[0];
				if (bullet0 == null)
				{
					return;
				}
				bullet0.damageType = DamageTypeEntity.Pierce;
				bullet0.triggerCount += PierceTriggerBonus;
				BulletAttr bullet1 = bulletList[1];
				if (bullet1 == null)
				{
					return;
				}
				bullet1.damageType = DamageTypeEntity.Pierce;
				bullet1.triggerCount += PierceTriggerBonus;
			}
			else if (entity.index == 1)
			{
				// Level-2 branch 1: raise attack.
				if (attr == null || defaultAttr == null)
				{
					return;
				}
				int currentAttack = attr.attack;
				int defaultAttack = defaultAttr.attack;
				float ratio = entity.GetValue(this, 0);
				attr.attack = (int)((float)defaultAttack * ratio) + currentAttack;
			}
		}

		protected override void Attack()
		{
			base.Attack();
			IEnumerator routine = AttackCoroutine();
			if (routine == null)
			{
				throw new NullReferenceException();
			}
			StartCoroutine(routine);
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__16))]
		protected virtual IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__16(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			// Attack if a zombie is directly in front...
			if (CheckIsFrontZombie())
			{
				return true;
			}
			// ...or if a balloon zombie shares this row and the plant is currently risen.
			LandEntity land = CurrentLandEntity;
			if (land != null && IsHasBalloonRow(land.rowId) && isRise)
			{
				return true;
			}
			return false;
		}

		private bool IsHasBalloonRow(int row = -1)
		{
			// TODO: reconstruct — the original filters LevelUtils.GetLandZombieList() for
			// balloon/flying zombies in the given row and compares their world X against this
			// plant's facing direction. The predicate dereferences ZombieEntity / RowLandEntity
			// members purely by raw offset (the zombie's row source at +0x148 and a flying flag
			// at +0x1f0), whose real member names are not present in the skeleton and are left
			// unreconstructed in ZombieEntity itself. Inventing them is forbidden, so this is
			// left as a stub returning false.
			return false;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__19))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__19(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__20))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__20(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
