using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Bullet.Entity;
using Land.Entity.Fog;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant235Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__11 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public StrengthenEntity entity;

			public Plant235Entity _003C_003E4__this;

			private float _003Cratio_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__11(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant235Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					// value used to scale the plant's first attribute; waitTime is a
					// second strengthen value used as the effect's active duration.
					float value = entity.GetValue(plant, 0);
					float waitTime = entity.GetValue(plant, 1);
					plant.attr.AddLabel(entity.title, 0, entity.GetDesc(plant));
					_003Cratio_003E5__2 = plant.defaultAttr.GetValue(plant, 0) * value;
					plant.attr.valueList[0].baseValue += _003Cratio_003E5__2;
					_003C_003E2__current = new WaitForSeconds(waitTime);
					_003C_003E1__state = 1;
					return true;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				// after the duration elapses, revert the temporary boost and label.
				plant.attr.valueList[0].baseValue -= _003Cratio_003E5__2;
				plant.attr.ReduceLabel(entity.title, 0);
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__12 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant235Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__12(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant235Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				// permanent boost: add (strengthenValue * defaultValue) to the first
				// attribute and stack a persistent label (layer 1) describing it.
				float baseVal = plant.attr.valueList[0].baseValue;
				float defaultValue = plant.defaultAttr.GetValue(plant, 0);
				float strengthenValue = entity.GetValue(plant, 0);
				plant.attr.valueList[0].baseValue = strengthenValue * defaultValue + baseVal;
				plant.attr.AddLabel(entity.title, 1, entity.GetDesc(plant));
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("火焰渲染器集合")]
		public List<SpriteRenderer> fireSpriteRendererList;

		[Tooltip("火焰子弹")]
		public BulletAttr peaFireBullet;

		[Tooltip("豌豆子弹")]
		public BulletAttr peaBullet;

		[Tooltip("驱散迷雾实体")]
		public DispelFog dispelFog;

		public override void Reset()
		{
			base.Reset();
			// TODO: reconstruct — the pseudocode tail invokes an unrecoverable delegate
			// resolved from a jump table that Ghidra could not recover (globals
			// _DAT_18302c910 / _DAT_18302c8f8 called on the field at offset 0x78 with a
			// -1 argument). Its target member and semantics cannot be determined from the
			// dump, so only the base reset is reconstructed here.
		}

		protected override void Start()
		{
			base.Start();
			if (dispelFog != null)
			{
				GameObject obj = dispelFog.gameObject;
				if (obj != null)
				{
					obj.SetActive(true);
				}
			}
		}

		public void ChangeFire(bool flag)
		{
			if (fireSpriteRendererList != null)
			{
				foreach (SpriteRenderer spriteRenderer in fireSpriteRendererList)
				{
					if (spriteRenderer != null)
					{
						GameObject obj = spriteRenderer.gameObject;
						if (obj != null)
						{
							obj.SetActive(flag);
						}
					}
				}
			}
			if (dispelFog != null)
			{
				dispelFog.enabled = flag;
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// The pseudocode at this RVA is an ICF-folded empty method (bare return); the
			// base-level strengthen has no per-plant effect for Plant235.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// permanently scale the first attribute by the strengthen value times the
				// plant's default attribute value.
				if (attr == null || attr.valueList == null || defaultAttr == null)
				{
					return;
				}
				float baseVal = attr.valueList[0].baseValue;
				attr.valueList[0].baseValue = entity.GetValue(this, 0) * defaultAttr.GetValue(this, 0) + baseVal;
				return;
			}
			if (entity.index == 1)
			{
				// TODO: reconstruct — for the second upgrade the pseudocode reads
				// defaultAttr.maxHealth and invokes a virtual method (vtable slot +0x268)
				// with (entity.GetValue(this, 0) * defaultAttr.maxHealth). The exact
				// virtual target could not be resolved from the dump, so this max-health
				// scaling branch is left unimplemented rather than guessing the member.
			}
		}

		public override void OnTriggerCustomEnter(Collider2D col, int index)
		{
			if (fireSpriteRendererList == null)
			{
				return;
			}
			SpriteRenderer spriteRenderer = fireSpriteRendererList[0];
			if (spriteRenderer == null)
			{
				return;
			}
			GameObject fireObj = spriteRenderer.gameObject;
			if (fireObj == null)
			{
				return;
			}
			// only convert incoming peas while the fire mode is visually active.
			if (!fireObj.activeSelf)
			{
				return;
			}
			if (col == null)
			{
				return;
			}
			GameObject colObj = col.gameObject;
			if (colObj == null)
			{
				return;
			}
			BulletEntity bulletEntity = colObj.GetComponent<BulletEntity>();
			if (bulletEntity == null)
			{
				return;
			}
			// only pea (10) and boosted-pea (20) bullets get upgraded to fire peas.
			if (bulletEntity.typeId != 10 && bulletEntity.typeId != 20)
			{
				return;
			}
			ReplaceBullet(bulletEntity, peaFireBullet);
		}

		private BulletEntity ReplaceBullet(BulletEntity oldBulletEntity, BulletAttr newBulletAttr)
		{
			if (oldBulletEntity == null)
			{
				return null;
			}
			// bullets we already own are left untouched.
			if (oldBulletEntity.sourceBaseBody == this)
			{
				return null;
			}
			BulletEntity newBullet = oldBulletEntity.ReplaceBullet(newBulletAttr);
			if (newBullet == null)
			{
				return null;
			}
			newBullet.sourceBaseBody = this;
			if (newBulletAttr != peaFireBullet)
			{
				return newBullet;
			}
			// fire-pea specific tuning: scale damage by the plant's attribute value and
			// attack, and set the splash radius / ratio.
			BulletAttr bulletAttr = newBullet.attr;
			if (bulletAttr != null && attr != null)
			{
				int baseDamage = bulletAttr.damage;
				float ratio = attr.GetValue(this, 0);
				bulletAttr.damage = (int)((float)baseDamage * ratio) + baseDamage;
				newBullet.attr.damage += attr.attack;
				bulletAttr.radius = 0.2f;
				bulletAttr.splashRatio = 0.15f;
				if (oldBulletEntity.typeId == 20)
				{
					bulletAttr.damage *= 2;
				}
			}
			return newBullet;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__11))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			_003COnUsePower0_003Ed__11 stateMachine = new _003COnUsePower0_003Ed__11(0);
			stateMachine._003C_003E4__this = this;
			stateMachine.entity = entity;
			return stateMachine;
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__12))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			_003COnUsePower1_003Ed__12 stateMachine = new _003COnUsePower1_003Ed__12(0);
			stateMachine._003C_003E4__this = this;
			stateMachine.entity = entity;
			return stateMachine;
		}
	}
}
