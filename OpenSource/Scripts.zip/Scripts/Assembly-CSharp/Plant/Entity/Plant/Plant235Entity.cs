using System;
using System.Collections;
using System.Collections.Generic;
using Bullet.Entity;
using Land.Entity.Fog;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant235Entity : PlantEntity
	{
		[Tooltip("火焰渲染器集合")]
		public List<SpriteRenderer> fireSpriteRendererList;

		[Tooltip("火焰子弹")]
		public BulletAttr peaFireBullet;

		[Tooltip("豌豆子弹")]
		public BulletAttr peaBullet;

		[Tooltip("驱散迷雾实体")]
		public DispelFog dispelFog;

		public override void Reset()
		{
			base.Reset();
		}

		protected override void Start()
		{
			base.Start();
			if (dispelFog != null)
			{
				GameObject obj = dispelFog.gameObject;
				if (obj != null)
				{
					obj.SetActive(true);
				}
			}
		}

		public void ChangeFire(bool flag)
		{
			if (fireSpriteRendererList != null)
			{
				foreach (SpriteRenderer spriteRenderer in fireSpriteRendererList)
				{
					if (spriteRenderer != null)
					{
						GameObject obj = spriteRenderer.gameObject;
						if (obj != null)
						{
							obj.SetActive(flag);
						}
					}
				}
			}
			if (dispelFog != null)
			{
				dispelFog.enabled = flag;
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// permanently scale the first attribute by the strengthen value times the
				// plant's default attribute value.
				if (attr == null || attr.valueList == null || defaultAttr == null)
				{
					return;
				}
				float baseVal = attr.valueList[0].baseValue;
				attr.valueList[0].baseValue = entity.GetValue(this, 0) * defaultAttr.GetValue(this, 0) + baseVal;
				return;
			}
			if (entity.index == 1)
			{
			}
		}

		public override void OnTriggerCustomEnter(Collider2D col, int index)
		{
			if (fireSpriteRendererList == null)
			{
				return;
			}
			SpriteRenderer spriteRenderer = fireSpriteRendererList[0];
			if (spriteRenderer == null)
			{
				return;
			}
			GameObject fireObj = spriteRenderer.gameObject;
			if (fireObj == null)
			{
				return;
			}
			// only convert incoming peas while the fire mode is visually active.
			if (!fireObj.activeSelf)
			{
				return;
			}
			if (col == null)
			{
				return;
			}
			GameObject colObj = col.gameObject;
			if (colObj == null)
			{
				return;
			}
			BulletEntity bulletEntity = colObj.GetComponent<BulletEntity>();
			if (bulletEntity == null)
			{
				return;
			}
			// only pea (10) and boosted-pea (20) bullets get upgraded to fire peas.
			if (bulletEntity.typeId != 10 && bulletEntity.typeId != 20)
			{
				return;
			}
			ReplaceBullet(bulletEntity, peaFireBullet);
		}

		private BulletEntity ReplaceBullet(BulletEntity oldBulletEntity, BulletAttr newBulletAttr)
		{
			if (oldBulletEntity == null)
			{
				return null;
			}
			// bullets we already own are left untouched.
			if (oldBulletEntity.sourceBaseBody == this)
			{
				return null;
			}
			BulletEntity newBullet = oldBulletEntity.ReplaceBullet(newBulletAttr);
			if (newBullet == null)
			{
				return null;
			}
			newBullet.sourceBaseBody = this;
			if (newBulletAttr != peaFireBullet)
			{
				return newBullet;
			}
			// fire-pea specific tuning: scale damage by the plant's attribute value and
			// attack, and set the splash radius / ratio.
			BulletAttr bulletAttr = newBullet.attr;
			if (bulletAttr != null && attr != null)
			{
				int baseDamage = bulletAttr.damage;
				float ratio = attr.GetValue(this, 0);
				bulletAttr.damage = (int)((float)baseDamage * ratio) + baseDamage;
				newBullet.attr.damage += attr.attack;
				bulletAttr.radius = 0.2f;
				bulletAttr.splashRatio = 0.15f;
				if (oldBulletEntity.typeId == 20)
				{
					bulletAttr.damage *= 2;
				}
			}
			return newBullet;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 临时增益：按强化值缩放第一条属性，持续 waitTime 秒后还原
			float value = entity.GetValue(this, 0);
			float waitTime = entity.GetValue(this, 1);
			attr.AddLabel(entity.title, 0, entity.GetDesc(this));
			float ratio = defaultAttr.GetValue(this, 0) * value;
			attr.valueList[0].baseValue += ratio;
			yield return new WaitForSeconds(waitTime);
			attr.valueList[0].baseValue -= ratio;
			attr.ReduceLabel(entity.title, 0);
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			// 永久增益：把 (强化值 * 默认属性值) 加到第一条属性，并叠加持久标签
			float baseVal = attr.valueList[0].baseValue;
			float defaultValue = defaultAttr.GetValue(this, 0);
			float strengthenValue = entity.GetValue(this, 0);
			attr.valueList[0].baseValue = strengthenValue * defaultValue + baseVal;
			attr.AddLabel(entity.title, 1, entity.GetDesc(this));
			yield break;
		}
	}
}
