using System;
using System.Collections;
using System.Collections.Generic;
using Game.Entity;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant220Entity : PlantEntity
	{
		[Tooltip("攻击效果")]
		public EffectEntity attackEffect;

		private List<ZombieEntity> _targetList;

		private const string ResetAnimName = "Idle";

		public override void Reset()
		{
			base.Reset();
			if (attr != null)
			{
				attr.isNotPick1 = true;
				if (_targetList != null)
				{
					_targetList.Clear();
				}
				if (_animator != null)
				{
					_animator.Play(Animator.StringToHash(ResetAnimName), -1, 0f);
				}
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				if (attr != null && defaultAttr != null)
				{
					int baseAttack = attr.attack;
					int defaultAttack = defaultAttr.attack;
					float value = entity.GetValue(this, 0);
					attr.attack = (int)((float)defaultAttack * value) + baseAttack;
				}
			}
			else if (entity.index == 1)
			{
				if (attr != null && defaultAttr != null)
				{
					float value = entity.GetValue(this, 0);
					attr.AttackSpeed = defaultAttr.attackSpeed * value + attr.attackSpeed;
				}
			}
		}

		protected override void Attack()
		{
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			yield break;
		}

		protected override bool CheckAttack()
		{
			if (_targetList == null)
			{
				return false;
			}
			int count = 0;
			foreach (ZombieEntity zombie in _targetList)
			{
				if (zombie != null && !zombie.IsDeath)
				{
					count++;
				}
			}
			return count > 0;
		}

		public override void OnTriggerCustomEnter(Collider2D col, int index)
		{
		}

		public override void OnTriggerCustomExit(Collider2D col, int index)
		{
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 构建 buff（id 10）的数值：基础值 = 植物默认攻速 × 强化值[0]，持续时间 = 强化值[1]
			List<ValueEntity> valueList = new List<ValueEntity>();
			if (entity != null)
			{
				float scale = entity.GetValue(this, 0);
				if (this != null && defaultAttr != null)
				{
					float baseSpeed = defaultAttr.attackSpeed;
					float duration = entity.GetValue(this, 1);
					ValueEntity valueEntity = new ValueEntity();
					valueEntity.baseValue = baseSpeed * scale;
					valueList.Add(valueEntity);
					if (_buffHandler != null)
					{
						_buffHandler.AddBuff(10, null, duration, valueList);
					}
				}
			}
			yield break;
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			if (this != null && attr != null)
			{
				int baseAttack = attr.attack;
				if (defaultAttr != null && entity != null)
				{
					int defaultAttack = defaultAttr.attack;
					float value = entity.GetValue(this, 0);
					attr.attack = (int)((float)defaultAttack * value) + baseAttack;
					// 记录强化的标签与描述到当前属性
					attr.AddLabel(entity.title, 1, entity.GetDesc(this));
				}
			}
			yield break;
		}
	}
}
