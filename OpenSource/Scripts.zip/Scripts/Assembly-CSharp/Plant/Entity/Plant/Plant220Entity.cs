using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Game.Entity;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant220Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__6 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant220Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__6(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct - the two-step state machine here (state 0: play an
				// attack animation then `yield return new WaitForSeconds(t)`, state 1:
				// spawn attackEffect at the plant's position and deal parabolic damage to
				// every live zombie in _targetList) depends on values that are unrecoverable
				// data pointers in the pseudocode: the animator state-name hash, the
				// WaitForSeconds duration, the effect-spawn rotation global, and the exact
				// virtual damage entry-point (vtable slot 0x238) with its damage amount.
				// Filling these would require fabricating members/literals, so the body is
				// left as a faithful no-op state machine.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__10 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public StrengthenEntity entity;

			public Plant220Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__10(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant220Entity self = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					// Build a single-value payload for the buff (buff id 10). The payload's
					// base value is the plant's default attack speed scaled by the strengthen
					// value at index 0; the buff duration comes from the value at index 1.
					List<ValueEntity> valueList = new List<ValueEntity>();
					if (entity != null)
					{
						float scale = entity.GetValue(self, 0);
						if (self != null && self.defaultAttr != null)
						{
							float baseSpeed = self.defaultAttr.attackSpeed;
							float duration = entity.GetValue(self, 1);
							ValueEntity valueEntity = new ValueEntity();
							valueEntity.baseValue = baseSpeed * scale;
							valueList.Add(valueEntity);
							if (self._buffHandler != null)
							{
								self._buffHandler.AddBuff(10, null, duration, valueList);
							}
						}
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__11 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant220Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__11(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant220Entity self = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (self != null && self.attr != null)
					{
						int baseAttack = self.attr.attack;
						if (self.defaultAttr != null && entity != null)
						{
							int defaultAttack = self.defaultAttr.attack;
							float value = entity.GetValue(self, 0);
							self.attr.attack = (int)((float)defaultAttack * value) + baseAttack;
							// Record the strengthen's label/description on the current attr.
							self.attr.AddLabel(entity.title, 1, entity.GetDesc(self));
						}
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("攻击效果")]
		public EffectEntity attackEffect;

		private List<ZombieEntity> _targetList;

		// TODO: unresolved animator state-name literal used by Reset (data pointer in the
		// pseudocode). Following the base-class convention, kept as a named placeholder.
		private const string ResetAnimName = "Idle"; // TODO: reconstruct literal

		public override void Reset()
		{
			base.Reset();
			if (attr != null)
			{
				// attr.isNotPick1 (0x1A) = true
				attr.isNotPick1 = true;
				if (_targetList != null)
				{
					_targetList.Clear();
				}
				if (_animator != null)
				{
					// TODO: animator state name is an unresolved data pointer.
					_animator.Play(Animator.StringToHash(ResetAnimName), -1, 0f);
				}
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// Intentionally empty: the decompiled body is a bare return.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				if (attr != null && defaultAttr != null)
				{
					int baseAttack = attr.attack;
					int defaultAttack = defaultAttr.attack;
					float value = entity.GetValue(this, 0);
					attr.attack = (int)((float)defaultAttack * value) + baseAttack;
				}
			}
			else if (entity.index == 1)
			{
				if (attr != null && defaultAttr != null)
				{
					float value = entity.GetValue(this, 0);
					// TODO: the decompiler dropped the value argument passed to the
					// PlantBaseAttr.AttackSpeed setter; the expression below is inferred
					// from the symmetric index-0 branch (scale the default by the strengthen
					// value and add it to the current value) and is unverified.
					attr.AttackSpeed = defaultAttr.attackSpeed * value + attr.attackSpeed;
				}
			}
		}

		protected override void Attack()
		{
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__6))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__6(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			if (_targetList == null)
			{
				return false;
			}
			int count = 0;
			foreach (ZombieEntity zombie in _targetList)
			{
				if (zombie != null && !zombie.IsDeath)
				{
					count++;
				}
			}
			return count > 0;
		}

		public override void OnTriggerCustomEnter(Collider2D col, int index)
		{
			// TODO: reconstruct - the pseudocode gates on col.gameObject.CompareTag(<tag>)
			// where the tag is an unrecoverable data-pointer string, then reads the owning
			// ZombieEntity through GetComponent<T>() on an unnamed collider MonoBehaviour
			// and dereferences its field at offset 0x30 (whose real member name is not in
			// the provided skeleton), adds it to _targetList, and conditionally triggers a
			// Zombie120Entity.WheelieAttack via another unnamed 0x55 flag. Reconstructing
			// this faithfully would require fabricating those literals/members, so the body
			// is left as a stub.
		}

		public override void OnTriggerCustomExit(Collider2D col, int index)
		{
			// TODO: reconstruct - like OnTriggerCustomEnter, this resolves the owning
			// ZombieEntity through GetComponent<T>() on an unnamed collider MonoBehaviour
			// and its field at offset 0x30 before removing it from _targetList. Those
			// member names are not present in the provided skeleton, so the body is left
			// as a stub rather than fabricating them.
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__10))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__10(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__11))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__11(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
