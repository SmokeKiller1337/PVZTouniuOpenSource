using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant250Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__7 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant250Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__7(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant250Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (plant == null || plant._animator == null)
					{
						return false;
					}
					// TODO: attack animation state name is a data pointer in the pseudocode.
					plant._animator.Play(AttackAnimName);
					if (plant.attr == null)
					{
						return false;
					}
					// wait one attack-interval scaled by an unresolved timing constant, then fire.
					_003C_003E2__current = new WaitForSeconds(plant.attr.attackIntervalTime * AttackWindupScale);
					_003C_003E1__state = 1;
					return true;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null || plant.bulletPosition == null)
				{
					return false;
				}
				// spawn the bullet at the configured muzzle transform
				plant.CreateBullet(0, plant.bulletPosition.position);
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__9 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant250Entity _003C_003E4__this;

			public StrengthenEntity entity;

			private int _003Ci_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__9(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant250Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					_003Ci_003E5__2 = 0;
				}
				else
				{
					if (num != 1)
					{
						return false;
					}
					_003C_003E1__state = -1;
					if (plant == null)
					{
						return false;
					}
					plant.StartCoroutine(plant.AttackCoroutine());
					_003Ci_003E5__2++;
				}
				if (entity == null)
				{
					return false;
				}
				// fire the extra shot GetValue()-many times, one per power-attack interval
				if ((int)entity.GetValue(plant) <= _003Ci_003E5__2)
				{
					return false;
				}
				_003C_003E2__current = new WaitForSeconds(PowerAttackInterval);
				_003C_003E1__state = 1;
				return true;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__10 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant250Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__10(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant250Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null || plant.attr == null || plant.defaultAttr == null || entity == null)
				{
					return false;
				}
				// permanent attack-speed buff: += ratio * default attack speed, then tag it
				float ratio = entity.GetValue(plant);
				plant.attr.AttackSpeed = ratio * plant.defaultAttr.attackSpeed + plant.attr.attackSpeed;
				plant.attr.AddLabel(entity.title, 1, entity.GetDesc(plant));
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("子弹位置")]
		public Transform bulletPosition;

		private float _maxAttackDistance;

		// TODO: unresolved timing constants (float globals in the pseudocode).
		private const float AttackWindupScale = 1f; // TODO: reconstruct constant (_DAT_18252cd08)
		private const float PowerAttackInterval = 0.1f; // TODO: reconstruct constant (_DAT_18252ccfc)

		// TODO: unresolved attack animation state name (data pointer in the pseudocode).
		private const string AttackAnimName = "Attack"; // TODO: reconstruct literal

		public override void Reset()
		{
			// ICF-folded onto the base body; identical to PlantEntity.Reset().
			base.Reset();
		}

		protected override void Update()
		{
			// ICF-folded onto the base body; identical to PlantEntity.Update().
			base.Update();
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// Empty override (RVA 0x3D9020 is a bare return).
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// index 0: flat attack boost scaled off the default attack value
				if (attr != null && defaultAttr != null)
				{
					float ratio = entity.GetValue(this);
					attr.attack = (int)((float)defaultAttr.attack * ratio) + attr.attack;
				}
			}
			else if (entity.index == 1)
			{
				// index 1: attack-speed boost scaled off the default attack speed
				if (attr != null && defaultAttr != null)
				{
					float ratio = entity.GetValue(this);
					attr.AttackSpeed = ratio * defaultAttr.attackSpeed + attr.attackSpeed;
				}
			}
		}

		protected override void Attack()
		{
			// ICF-folded onto the base Attack (plays the attack animation), then kicks off
			// the bullet-firing coroutine.
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__7))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__7(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			// TODO: reconstruct - the pseudocode raycasts from this plant toward the home /
			// zombie house transforms, whose positions are read from several unresolved
			// manager/config globals (a level manager at _DAT_182e2bc20 and a config holder
			// at _DAT_182e706b8), plus a layer-mask config. None of those globals can be
			// mapped to a concrete type/member in the project, so the check is stubbed to
			// "no valid target" rather than referencing members that may not exist.
			return false;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__9))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__9(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__10))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__10(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
