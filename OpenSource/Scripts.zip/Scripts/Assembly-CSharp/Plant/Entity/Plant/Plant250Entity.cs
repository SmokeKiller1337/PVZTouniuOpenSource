using System.Collections;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant250Entity : PlantEntity
	{
		[Tooltip("子弹位置")]
		public Transform bulletPosition;

		private float _maxAttackDistance;

		private const float AttackWindupScale = 1f;
		private const float PowerAttackInterval = 0.1f;

		private const string AttackAnimName = "Attack";

		public override void Reset()
		{
			base.Reset();
		}

		protected override void Update()
		{
			base.Update();
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// index 0：以默认攻击力为基准增加攻击力
				if (attr != null && defaultAttr != null)
				{
					float ratio = entity.GetValue(this);
					attr.attack = (int)((float)defaultAttr.attack * ratio) + attr.attack;
				}
			}
			else if (entity.index == 1)
			{
				// index 1：以默认攻击速度为基准提升攻击速度
				if (attr != null && defaultAttr != null)
				{
					float ratio = entity.GetValue(this);
					attr.AttackSpeed = ratio * defaultAttr.attackSpeed + attr.attackSpeed;
				}
			}
		}

		protected override void Attack()
		{
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			if (this == null || _animator == null)
			{
				yield break;
			}
			_animator.Play(AttackAnimName);
			if (attr == null)
			{
				yield break;
			}
			// 播放攻击动画后等待一个攻击间隔，再发射子弹
			yield return new WaitForSeconds(attr.attackIntervalTime * AttackWindupScale);
			if (this == null || bulletPosition == null)
			{
				yield break;
			}
			// 在配置的枪口位置生成子弹
			CreateBullet(0, bulletPosition.position);
		}

		protected override bool CheckAttack()
		{
			return false;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 按 GetValue 的次数额外发射，每次间隔一个攻击周期
			int i = 0;
			while (entity != null && (int)entity.GetValue(this) > i)
			{
				yield return new WaitForSeconds(PowerAttackInterval);
				if (this == null)
				{
					yield break;
				}
				StartCoroutine(AttackCoroutine());
				i++;
			}
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			if (this == null || attr == null || defaultAttr == null || entity == null)
			{
				yield break;
			}
			// 永久攻击速度加成：按默认攻击速度的比例叠加，并打上标签
			float ratio = entity.GetValue(this);
			attr.AttackSpeed = ratio * defaultAttr.attackSpeed + attr.attackSpeed;
			attr.AddLabel(entity.title, 1, entity.GetDesc(this));
		}
	}
}
