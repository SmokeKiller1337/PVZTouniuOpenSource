using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Audio.Manager;
using Building.Entity;
using Land.Entity.Fog;
using Level.Util;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant260Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__11 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant260Entity _003C_003E4__this;

			public StrengthenEntity entity;

			private int _003Ci_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__11(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct — this coroutine repeatedly spawns suns via
				// RewardManager.Instance.CreateSun on a WaitForSeconds cadence (looped
				// entity.GetValue(_003C_003E4__this) times) and, on each pass, tweens the
				// dispel-effect child materials with DG.Tweening ShortcutExtensions.DOFloat.
				// The material list is read from unmapped BaseBody fields (0xA0/0xA8) and the
				// WaitForSeconds durations are unresolved global constants, so the state
				// machine cannot be faithfully rebuilt without inventing members. Left stubbed.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__12 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public StrengthenEntity entity;

			public Plant260Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__12(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// Single-pass coroutine (no yields): grows the first dispel value by the
				// strengthen amount, then re-drives the fog dispel to the new size, then
				// completes immediately.
				int num = _003C_003E1__state;
				Plant260Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (entity != null && plant != null && plant.attr != null && plant.attr.valueList != null && plant.attr.valueList.Count > 0)
					{
						plant.attr.valueList[0].baseValue += entity.GetValue(plant);
						plant.UpdateDispelFog(plant.attr.valueList[0].baseValue);
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("驱散迷雾实体")]
		public DispelFog dispelFog;

		[Tooltip("驱散特效物体")]
		public GameObject dispelFogEffectObj;

		[Tooltip("种植音效")]
		public AudioClip startSound;

		public override void Reset()
		{
			// ICF-folded onto the generic PlantEntity card-reset routine; the override adds
			// nothing plant-specific beyond the base reset.
			base.Reset();
		}

		protected override void Start()
		{
			base.Start();
			if (dispelFog == null)
			{
				return;
			}
			GameObject fogObj = dispelFog.gameObject;
			if (fogObj == null)
			{
				return;
			}
			fogObj.SetActive(true);
			if (dispelFogEffectObj == null)
			{
				return;
			}
			dispelFogEffectObj.SetActive(true);
			if (AudioManager.Instance == null)
			{
				return;
			}
			AudioManager.Instance.PlayOneShot(startSound);
			if (attr == null || attr.valueList == null || attr.valueList.Count <= 0)
			{
				return;
			}
			UpdateDispelFog(attr.valueList[0].baseValue);
			List<BuildingEntity> buildingList = LevelUtils.GetLandBuildingList();
			if (buildingList == null)
			{
				return;
			}
			foreach (BuildingEntity building in buildingList)
			{
				if (building != null && building is PotEntity pot)
				{
					pot.UpdateDispel();
				}
			}
		}

		public override void Death()
		{
			// ICF-folded onto the generic PlantEntity death routine (DeathHandle + ClearLand
			// + Destroy); the override adds nothing plant-specific.
			base.Death();
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// ICF-folded onto an empty body — no level-0 behaviour for this plant.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				if (attr != null && attr.valueList != null && attr.valueList.Count > 0)
				{
					attr.valueList[0].baseValue += entity.GetValue(this);
					UpdateDispelFog(attr.valueList[0].baseValue);
				}
			}
			// TODO: reconstruct — the entity.index == 1 branch scaled defaultAttr.maxHealth by
			// entity.GetValue(this) and forwarded the result through an unidentified virtual
			// slot (0x268). The target method could not be resolved with certainty, so that
			// branch is intentionally omitted rather than guessed.
		}

		public void UpdateDispelFog(float ratio, float duration = 1f)
		{
			// TODO: reconstruct — the body builds DG.Tweening DOGetter/DOSetter closures over
			// the DispelFog instance and DOTween.To's the dispel size to baseDispelSize * ratio
			// over `duration`, while the setter also rewrites several private DispelFog shader
			// fields and toggles a FogManager byte. Those DispelFog members are private/unmapped
			// and the DOTween plumbing relies on unresolved globals, so this is left stubbed.
		}

		protected override void Attack()
		{
			// TODO: reconstruct — the folded body reads an attr float and invokes a delegate on
			// an unmapped instance field (0x78) with an unresolved global multiplier. The target
			// member cannot be resolved, so this is left stubbed.
		}

		protected override bool CheckAttack()
		{
			// TODO: reconstruct — folded onto an unrelated body that returns false; the true
			// per-plant predicate is not recoverable. Kept as the safe stub value.
			return false;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__11))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__11(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__12))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__12(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
