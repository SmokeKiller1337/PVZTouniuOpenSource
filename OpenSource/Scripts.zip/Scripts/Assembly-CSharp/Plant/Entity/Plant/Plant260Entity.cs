using System;
using System.Collections;
using System.Collections.Generic;
using Audio.Manager;
using Building.Entity;
using Land.Entity.Fog;
using Level.Util;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant260Entity : PlantEntity
	{
		[Tooltip("驱散迷雾实体")]
		public DispelFog dispelFog;

		[Tooltip("驱散特效物体")]
		public GameObject dispelFogEffectObj;

		[Tooltip("种植音效")]
		public AudioClip startSound;

		public override void Reset()
		{
			base.Reset();
		}

		protected override void Start()
		{
			base.Start();
			if (dispelFog == null)
			{
				return;
			}
			GameObject fogObj = dispelFog.gameObject;
			if (fogObj == null)
			{
				return;
			}
			fogObj.SetActive(true);
			if (dispelFogEffectObj == null)
			{
				return;
			}
			dispelFogEffectObj.SetActive(true);
			if (AudioManager.Instance == null)
			{
				return;
			}
			AudioManager.Instance.PlayOneShot(startSound);
			if (attr == null || attr.valueList == null || attr.valueList.Count <= 0)
			{
				return;
			}
			UpdateDispelFog(attr.valueList[0].baseValue);
			List<BuildingEntity> buildingList = LevelUtils.GetLandBuildingList();
			if (buildingList == null)
			{
				return;
			}
			foreach (BuildingEntity building in buildingList)
			{
				if (building != null && building is PotEntity pot)
				{
					pot.UpdateDispel();
				}
			}
		}

		public override void Death()
		{
			base.Death();
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				if (attr != null && attr.valueList != null && attr.valueList.Count > 0)
				{
					attr.valueList[0].baseValue += entity.GetValue(this);
					UpdateDispelFog(attr.valueList[0].baseValue);
				}
			}
		}

		public void UpdateDispelFog(float ratio, float duration = 1f)
		{
		}

		protected override void Attack()
		{
		}

		protected override bool CheckAttack()
		{
			return false;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			yield break;
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			// 按强化量提升第一个驱散数值，并将迷雾驱散重新驱动到新的范围
			if (entity != null && this != null && attr != null && attr.valueList != null && attr.valueList.Count > 0)
			{
				attr.valueList[0].baseValue += entity.GetValue(this);
				UpdateDispelFog(attr.valueList[0].baseValue);
			}
			yield break;
		}
	}
}
