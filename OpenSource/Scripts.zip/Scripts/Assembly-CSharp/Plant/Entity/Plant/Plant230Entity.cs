using System;
using System.Collections;
using System.Collections.Generic;
using Bullet.Entity;
using Common.Entity;
using Game.Entity;
using Land.Entity.Fog;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant230Entity : PlantEntity
	{
		[Tooltip("火焰渲染器集合")]
		public List<SpriteRenderer> fireSpriteRendererList;

		[Tooltip("火焰子弹")]
		public BulletAttr peaFireBullet;

		[Tooltip("豌豆子弹")]
		public BulletAttr peaBullet;

		[Tooltip("驱散迷雾实体")]
		public DispelFog dispelFog;

		public override void Reset()
		{
			base.Reset();
		}

		protected override void Start()
		{
			base.Start();
			if (dispelFog != null)
			{
				GameObject go = dispelFog.gameObject;
				if (go != null)
				{
					go.SetActive(true);
				}
			}
		}

		public void ChangeFire(bool flag)
		{
			if (fireSpriteRendererList == null)
			{
				return;
			}
			foreach (SpriteRenderer spriteRenderer in fireSpriteRendererList)
			{
				if (spriteRenderer != null)
				{
					GameObject go = spriteRenderer.gameObject;
					if (go != null)
					{
						go.SetActive(flag);
					}
				}
			}
			if (dispelFog != null)
			{
				dispelFog.enabled = flag;
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (entity.index != 0)
			{
				if (entity.index == 1)
				{
					if (defaultAttr == null)
					{
						return;
					}
					// Boost max health by (strengthen ratio) * (base max health).
					float baseMaxHealth = defaultAttr.maxHealth;
					float ratio = entity.GetValue(this, 0);
					ChangeMaxHealthAndShow(ratio * baseMaxHealth);
				}
				return;
			}
			// entity.index == 0: permanently boost the first attr value.
			if (attr != null && attr.valueList != null && attr.valueList.Count > 0)
			{
				ValueEntity value = attr.valueList[0];
				if (value != null && defaultAttr != null)
				{
					float baseValue = defaultAttr.GetValue(this, 0);
					float strengthenValue = entity.GetValue(this, 0);
					value.baseValue = strengthenValue * baseValue + value.baseValue;
				}
			}
		}

		public override void OnTriggerCustomEnter(Collider2D col, int index)
		{
			if (fireSpriteRendererList == null || fireSpriteRendererList.Count < 1)
			{
				return;
			}
			SpriteRenderer first = fireSpriteRendererList[0];
			if (first == null)
			{
				return;
			}
			GameObject firstObj = first.gameObject;
			if (firstObj == null)
			{
				return;
			}
			// Only replace bullets while the fire visual is active.
			if (!firstObj.activeSelf)
			{
				return;
			}
			base.OnTriggerCustomEnter(col, index);
			if (col == null)
			{
				return;
			}
			GameObject colObj = col.gameObject;
			if (colObj == null)
			{
				return;
			}
			BulletEntity bulletEntity = colObj.GetComponent<BulletEntity>();
			if (bulletEntity == null)
			{
				return;
			}
			BulletAttr newBulletAttr;
			if (bulletEntity.typeId == 10)
			{
				newBulletAttr = peaFireBullet;
			}
			else if (bulletEntity.typeId == 20)
			{
				newBulletAttr = peaBullet;
			}
			else
			{
				return;
			}
			ReplaceBullet(bulletEntity, newBulletAttr);
		}

		private BulletEntity ReplaceBullet(BulletEntity oldBulletEntity, BulletAttr newBulletAttr)
		{
			if (oldBulletEntity == null)
			{
				return null;
			}
			// Don't re-adopt a bullet we already own.
			if (oldBulletEntity.sourceBaseBody == this)
			{
				return null;
			}
			BulletEntity newBullet = oldBulletEntity.ReplaceBullet(newBulletAttr);
			if (newBullet == null)
			{
				return null;
			}
			newBullet.sourceBaseBody = this;
			if (newBulletAttr != peaFireBullet)
			{
				return newBullet;
			}
			// Fire replacement: scale damage by this plant's attr value, add its flat attack,
			// and give the fire bullet a small splash radius.
			BulletAttr bulletAttr = newBullet.attr;
			if (bulletAttr == null || attr == null)
			{
				return newBullet;
			}
			int baseDamage = bulletAttr.damage;
			float ratio = attr.GetValue(this, 0);
			bulletAttr.damage = (int)((float)baseDamage * ratio) + baseDamage;
			bulletAttr.damage += attr.attack;
			bulletAttr.radius = 0.2f;
			bulletAttr.splashRatio = 0.15f;
			return newBullet;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			List<ValueEntity> valueList = new List<ValueEntity>();
			if (entity != null && this != null && defaultAttr != null)
			{
				// 强化比例 * 基础属性值得到加成值，强化值 1 作为 buff 持续时间
				float strengthenValue = entity.GetValue(this, 0);
				float defaultValue = defaultAttr.GetValue(this, 0);
				float duration = entity.GetValue(this, 1);
				ValueEntity value = new ValueEntity();
				value.baseValue = defaultValue * strengthenValue;
				valueList.Add(value);
				if (_buffHandler != null)
				{
					// 添加 11 号 buff，无施法者，持续 duration
					_buffHandler.AddBuff(11, null, duration, valueList);
				}
			}
			yield break;
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			if (this != null && attr != null && attr.valueList != null && attr.valueList.Count > 0)
			{
				ValueEntity value = attr.valueList[0];
				if (value != null)
				{
					float baseValue = value.baseValue;
					if (defaultAttr != null && entity != null)
					{
						// 永久提升首个属性值，并标记强化来源
						float defaultValue = defaultAttr.GetValue(this, 0);
						float strengthenValue = entity.GetValue(this, 0);
						value.baseValue = strengthenValue * defaultValue + baseValue;
						attr.AddLabel(entity.title, 1, entity.GetDesc(this));
					}
				}
			}
			yield break;
		}
	}
}
