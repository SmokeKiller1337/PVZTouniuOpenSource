using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Bullet.Entity;
using Common.Entity;
using Game.Entity;
using Land.Entity.Fog;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant230Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__11 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public StrengthenEntity entity;

			public Plant230Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__11(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				if (_003C_003E1__state != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				Plant230Entity self = _003C_003E4__this;
				// new List<ValueEntity>() — the buff value payload built for this power.
				List<ValueEntity> valueList = new List<ValueEntity>();
				if (entity != null && self != null && self.defaultAttr != null)
				{
					// strengthen ratio (index 0) * base attr value (index 0) -> boosted value,
					// with the strengthen value at index 1 used as the buff duration.
					float strengthenValue = entity.GetValue(self, 0);
					float defaultValue = self.defaultAttr.GetValue(self, 0);
					float duration = entity.GetValue(self, 1);
					ValueEntity value = new ValueEntity();
					value.baseValue = defaultValue * strengthenValue;
					valueList.Add(value);
					if (self._buffHandler != null)
					{
						// AddBuff(buffId: 11, caster: null, duration, valueList)
						self._buffHandler.AddBuff(11, null, duration, valueList);
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__12 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant230Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__12(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				if (_003C_003E1__state != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				Plant230Entity self = _003C_003E4__this;
				if (self != null && self.attr != null && self.attr.valueList != null && self.attr.valueList.Count > 0)
				{
					ValueEntity value = self.attr.valueList[0];
					if (value != null)
					{
						float baseValue = value.baseValue;
						if (self.defaultAttr != null && entity != null)
						{
							// Permanently boost the first attr value by
							// strengthenValue * defaultAttrValue, then tag it with a label
							// describing the strengthen source.
							float defaultValue = self.defaultAttr.GetValue(self, 0);
							float strengthenValue = entity.GetValue(self, 0);
							value.baseValue = strengthenValue * defaultValue + baseValue;
							self.attr.AddLabel(entity.title, 1, entity.GetDesc(self));
						}
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("火焰渲染器集合")]
		public List<SpriteRenderer> fireSpriteRendererList;

		[Tooltip("火焰子弹")]
		public BulletAttr peaFireBullet;

		[Tooltip("豌豆子弹")]
		public BulletAttr peaBullet;

		[Tooltip("驱散迷雾实体")]
		public DispelFog dispelFog;

		public override void Reset()
		{
			base.Reset();
			// TODO: reconstruct — after base.Reset() the pseudocode makes an unresolved
			// indirect (jump-table) call on a BaseBody reference field (offset 0x78) with a
			// converted global color and 0xFFFFFFFF, likely resetting a renderer/material
			// color. The target method and the color-source global could not be recovered,
			// so this trailing call is dropped rather than inventing members.
		}

		protected override void Start()
		{
			base.Start();
			if (dispelFog != null)
			{
				GameObject go = dispelFog.gameObject;
				if (go != null)
				{
					go.SetActive(true);
				}
			}
		}

		public void ChangeFire(bool flag)
		{
			if (fireSpriteRendererList == null)
			{
				return;
			}
			foreach (SpriteRenderer spriteRenderer in fireSpriteRendererList)
			{
				if (spriteRenderer != null)
				{
					GameObject go = spriteRenderer.gameObject;
					if (go != null)
					{
						go.SetActive(flag);
					}
				}
			}
			if (dispelFog != null)
			{
				dispelFog.enabled = flag;
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// The pseudocode body at this RVA is ICF-folded onto an empty method
			// (ES3Internal.ES3JSONWriter.EndWriteProperty), i.e. the real body is empty.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (entity.index != 0)
			{
				if (entity.index == 1)
				{
					if (defaultAttr == null)
					{
						return;
					}
					// Boost max health by (strengthen ratio) * (base max health).
					float baseMaxHealth = defaultAttr.maxHealth;
					float ratio = entity.GetValue(this, 0);
					ChangeMaxHealthAndShow(ratio * baseMaxHealth);
				}
				return;
			}
			// entity.index == 0: permanently boost the first attr value.
			if (attr != null && attr.valueList != null && attr.valueList.Count > 0)
			{
				ValueEntity value = attr.valueList[0];
				if (value != null && defaultAttr != null)
				{
					float baseValue = defaultAttr.GetValue(this, 0);
					float strengthenValue = entity.GetValue(this, 0);
					value.baseValue = strengthenValue * baseValue + value.baseValue;
				}
			}
		}

		public override void OnTriggerCustomEnter(Collider2D col, int index)
		{
			if (fireSpriteRendererList == null || fireSpriteRendererList.Count < 1)
			{
				return;
			}
			SpriteRenderer first = fireSpriteRendererList[0];
			if (first == null)
			{
				return;
			}
			GameObject firstObj = first.gameObject;
			if (firstObj == null)
			{
				return;
			}
			// Only replace bullets while the fire visual is active.
			if (!firstObj.activeSelf)
			{
				return;
			}
			base.OnTriggerCustomEnter(col, index);
			if (col == null)
			{
				return;
			}
			GameObject colObj = col.gameObject;
			if (colObj == null)
			{
				return;
			}
			BulletEntity bulletEntity = colObj.GetComponent<BulletEntity>();
			if (bulletEntity == null)
			{
				return;
			}
			BulletAttr newBulletAttr;
			// TODO: offset->field mapping inferred — the pseudocode reads an int field on the
			// bullet (10 -> fire, 20 -> pea) which maps to the bullet's type number.
			if (bulletEntity.typeId == 10)
			{
				newBulletAttr = peaFireBullet;
			}
			else if (bulletEntity.typeId == 20)
			{
				newBulletAttr = peaBullet;
			}
			else
			{
				return;
			}
			ReplaceBullet(bulletEntity, newBulletAttr);
		}

		private BulletEntity ReplaceBullet(BulletEntity oldBulletEntity, BulletAttr newBulletAttr)
		{
			if (oldBulletEntity == null)
			{
				return null;
			}
			// Don't re-adopt a bullet we already own.
			if (oldBulletEntity.sourceBaseBody == this)
			{
				return null;
			}
			BulletEntity newBullet = oldBulletEntity.ReplaceBullet(newBulletAttr);
			if (newBullet == null)
			{
				return null;
			}
			newBullet.sourceBaseBody = this;
			if (newBulletAttr != peaFireBullet)
			{
				return newBullet;
			}
			// Fire replacement: scale damage by this plant's attr value, add its flat attack,
			// and give the fire bullet a small splash radius.
			BulletAttr bulletAttr = newBullet.attr;
			if (bulletAttr == null || attr == null)
			{
				return newBullet;
			}
			int baseDamage = bulletAttr.damage;
			float ratio = attr.GetValue(this, 0);
			bulletAttr.damage = (int)((float)baseDamage * ratio) + baseDamage;
			bulletAttr.damage += attr.attack;
			bulletAttr.radius = 0.2f;
			bulletAttr.splashRatio = 0.15f;
			return newBullet;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__11))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__11(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__12))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__12(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
