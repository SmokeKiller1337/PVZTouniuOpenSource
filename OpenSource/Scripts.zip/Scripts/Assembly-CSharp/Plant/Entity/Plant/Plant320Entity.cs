using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Common.Entity;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using Game.Entity;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant320Entity : PlantEntity
	{
		[Tooltip("金属渲染器")]
		public SpriteRenderer metalSpriteRenderer;

		[Tooltip("吸取音效")]
		public AudioClip biteSound;

		private bool _isBiting;

		private float _biteTimer;

		private bool _isEndBiting;

		private bool _isPower0;

		private Coroutine _swallowEndCoroutine;

		private TweenerCore<Vector3, Vector3, VectorOptions> _metalMoveTween;

		public Action OnBiteAction;

		private const string BiteAnimName = "Bite";
		private const string SwallowEndAnimName = "Idle";
		private const float SwallowEndDelay = 0f;
		private const float MaxAttackSpeed = 10f;
		private const float BiteMoveDuration = 0f;

		public override void Reset()
		{
			base.Reset();
		}

		protected override void Update()
		{
			base.Update();
			// Tick the bite timer only while biting and not yet ending the bite.
			if (_isEndBiting || !_isBiting)
			{
				return;
			}
			_biteTimer += Time.deltaTime;
			if (attr == null)
			{
				return;
			}
			// attr.GetValue(this, 1) is the maximum bite hold duration.
			if (attr.GetValue(this, 1) <= _biteTimer)
			{
				SwallowEnd();
			}
			if (_isPower0)
			{
				SwallowEnd();
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				if (attr != null && attr.valueList != null && defaultAttr != null && defaultAttr.valueList != null)
				{
					ValueEntity target = attr.valueList[0];
					ValueEntity def = defaultAttr.valueList[0];
					target.baseValue = entity.GetValue(this, 0) * def.baseValue + target.baseValue;
				}
			}
			else if (entity.index == 1)
			{
				if (attr != null && attr.valueList != null && defaultAttr != null && defaultAttr.valueList != null)
				{
					ValueEntity target = attr.valueList[1];
					ValueEntity def = defaultAttr.valueList[1];
					target.baseValue = target.baseValue - entity.GetValue(this, 0) * def.baseValue;
				}
			}
		}

		protected override void Attack()
		{
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			// Cross-fade into the bite animation, then run the bite logic.
			if (_animator != null)
			{
				_animator.CrossFade(BiteAnimName, defaultTransitionDuration);
			}
			BiteAttack();
			yield break;
		}

		public void BiteAttack()
		{
			// Play the bite SFX.
			if (biteSound != null)
			{
				Audio.Manager.AudioManager.Instance.PlayOneShot(biteSound);
			}
			ZombieEntity target = GetNearestTargetZombie();
			if (target == null)
			{
				return;
			}
			if (_metalMoveTween != null)
			{
				_metalMoveTween.Kill();
			}
			// Copy the target zombie's metal renderer onto our metal sprite, then make the
			// zombie lose its metal and tween our metal towards the zombie.
			SpriteRenderer metalRenderer = target.GetMetalRenderer();
			if (metalSpriteRenderer == null || metalRenderer == null)
			{
				return;
			}
			Transform metalTf = metalSpriteRenderer.transform;
			Transform sourceTf = metalRenderer.transform;
			if (metalTf == null || sourceTf == null)
			{
				return;
			}
			metalTf.position = sourceTf.position;
			metalTf.eulerAngles = sourceTf.eulerAngles;
			metalSpriteRenderer.sprite = metalRenderer.sprite;
			metalSpriteRenderer.sharedMaterial = new Material(metalRenderer.material);
			_metalMoveTween = metalSpriteRenderer.transform.DOLocalMove(Vector3.zero, BiteMoveDuration);
			target.LoseMetal();
			_isBiting = true;
			_biteTimer = 0f;
			if (OnBiteAction != null)
			{
				OnBiteAction();
			}
		}

		public void SwallowEnd()
		{
			if (_swallowEndCoroutine == null)
			{
				_swallowEndCoroutine = StartCoroutine(SwallowEndCoroutine());
			}
		}

		private IEnumerator SwallowEndCoroutine()
		{
			// Wait for the swallow animation to play out before resetting.
			yield return new WaitForSeconds(SwallowEndDelay);
			if (_animator != null)
			{
				_animator.CrossFade(SwallowEndAnimName, defaultTransitionDuration);
				if (metalSpriteRenderer != null)
				{
					metalSpriteRenderer.sprite = null;
					_isBiting = false;
					_isEndBiting = false;
					_swallowEndCoroutine = null;
				}
			}
		}

		protected override bool CheckAttack()
		{
			// Can attack when not already biting and there is a zombie in range.
			if (!_isBiting)
			{
				if (GetNearestTargetZombie() != null)
				{
					return true;
				}
			}
			return false;
		}

		private ZombieEntity GetNearestTargetZombie()
		{
			if (attr == null)
			{
				return null;
			}
			// Overlap a circle of radius attr.GetValue(this,0) around this plant and collect
			// every candidate zombie, then return the closest.
			float radius = attr.GetValue(this, 0);
			Vector2 center = GetPosition();
			int mask = LayerMask.GetMask(ZombieLayerName);
			Collider2D[] hits = Physics2D.OverlapCircleAll(center, radius, mask);
			if (hits == null)
			{
				return null;
			}
			List<ZombieEntity> candidates = new List<ZombieEntity>();
			for (int i = 0; i < hits.Length; i++)
			{
				Collider2D hit = hits[i];
				if (hit == null)
				{
					continue;
				}
				ZombieEntity zombie = hit.gameObject.GetComponent<ZombieEntity>();
				if (zombie != null)
				{
					candidates.Add(zombie);
				}
			}
			List<ZombieEntity> filtered = candidates.Where(z => z != null).ToList();
			if (filtered.Count < 1)
			{
				return null;
			}
			// Order by distance from this plant and take the nearest zombie.
			return filtered.OrderBy(delegate(ZombieEntity zombieEntity)
			{
				Vector2 self = GetPosition();
				if (zombieEntity == null)
				{
					return 0f;
				}
				Transform t = zombieEntity.transform;
				if (t == null)
				{
					return 0f;
				}
				Vector3 zombiePos = t.position;
				float dx = self.x - zombiePos.x;
				float dy = self.y - zombiePos.y;
				return Mathf.Sqrt(dy * dy + dx * dx);
			}).First();
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// While biting, refresh the bite timer target from the second value.
			if (_isBiting)
			{
				_biteTimer = attr.GetValue(this, 1);
			}
			if (entity != null)
			{
				float duration = entity.GetValue(this, 0);
				_isPower0 = true;
				// Compute the attack-speed boost as the headroom up to the cap.
				float boost = 0f;
				if (attr != null && attr.attackSpeed <= MaxAttackSpeed && attr.attackSpeed != MaxAttackSpeed)
				{
					boost = MaxAttackSpeed - attr.attackSpeed;
				}
				List<ValueEntity> valueList = new List<ValueEntity>();
				ValueEntity value = new ValueEntity();
				value.baseValue = boost;
				valueList.Add(value);
				if (_buffHandler != null)
				{
					_buffHandler.AddBuff(10, null, duration, valueList);
					yield return new WaitForSeconds(duration);
					if (this != null)
					{
						_isPower0 = false;
					}
				}
			}
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			if (this != null && attr != null && defaultAttr != null && entity != null)
			{
				float currentSpeed = attr.attackSpeed;
				float defaultSpeed = defaultAttr.attackSpeed;
				float ratio = entity.GetValue(this, 0);
				attr.AttackSpeed = ratio * defaultSpeed + currentSpeed;
				attr.AddLabel(entity.title, 1, entity.GetDesc(this));
			}
			yield break;
		}

		// TODO: unresolved physics layer name for GetNearestTargetZombie.
		private const string ZombieLayerName = "Zombie";
	}
}
