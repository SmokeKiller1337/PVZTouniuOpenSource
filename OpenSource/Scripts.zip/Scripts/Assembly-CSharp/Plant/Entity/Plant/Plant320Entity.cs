using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using Common.Entity;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using Game.Entity;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant320Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__14 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant320Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__14(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant320Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				// Cross-fade into the bite animation, then run the bite logic.
				if (plant._animator != null)
				{
					plant._animator.CrossFade(BiteAnimName, plant.defaultTransitionDuration);
				}
				plant.BiteAttack();
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__20 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant320Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__20(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant320Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					// While biting, refresh the bite timer target from the second value.
					if (plant._isBiting)
					{
						plant._biteTimer = plant.attr.GetValue(plant, 1);
					}
					if (entity != null)
					{
						float duration = entity.GetValue(plant, 0);
						plant._isPower0 = true;
						// Compute the attack-speed boost as the headroom up to the cap.
						float boost = 0f;
						if (plant.attr != null && plant.attr.attackSpeed <= MaxAttackSpeed && plant.attr.attackSpeed != MaxAttackSpeed)
						{
							boost = MaxAttackSpeed - plant.attr.attackSpeed;
						}
						List<ValueEntity> valueList = new List<ValueEntity>();
						ValueEntity value = new ValueEntity();
						value.baseValue = boost;
						valueList.Add(value);
						if (plant._buffHandler != null)
						{
							plant._buffHandler.AddBuff(10, null, duration, valueList);
							_003C_003E2__current = new WaitForSeconds(duration);
							_003C_003E1__state = 1;
							return true;
						}
					}
					return false;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant != null)
				{
					plant._isPower0 = false;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__21 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant320Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__21(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant320Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant != null && plant.attr != null && plant.defaultAttr != null && entity != null)
				{
					float currentSpeed = plant.attr.attackSpeed;
					float defaultSpeed = plant.defaultAttr.attackSpeed;
					float ratio = entity.GetValue(plant, 0);
					plant.attr.AttackSpeed = ratio * defaultSpeed + currentSpeed;
					plant.attr.AddLabel(entity.title, 1, entity.GetDesc(plant));
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CSwallowEndCoroutine_003Ed__17 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant320Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CSwallowEndCoroutine_003Ed__17(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant320Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					// Wait for the swallow animation to play out before resetting.
					_003C_003E2__current = new WaitForSeconds(SwallowEndDelay);
					_003C_003E1__state = 1;
					return true;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant._animator != null)
				{
					plant._animator.CrossFade(SwallowEndAnimName, plant.defaultTransitionDuration);
					if (plant.metalSpriteRenderer != null)
					{
						plant.metalSpriteRenderer.sprite = null;
						plant._isBiting = false;
						plant._isEndBiting = false;
						plant._swallowEndCoroutine = null;
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("金属渲染器")]
		public SpriteRenderer metalSpriteRenderer;

		[Tooltip("吸取音效")]
		public AudioClip biteSound;

		private bool _isBiting;

		private float _biteTimer;

		private bool _isEndBiting;

		private bool _isPower0;

		private Coroutine _swallowEndCoroutine;

		private TweenerCore<Vector3, Vector3, VectorOptions> _metalMoveTween;

		public Action OnBiteAction;

		// TODO: the following animation-state names and tuning constants are data pointers /
		// globals in the pseudocode that could not be resolved to their literal values.
		// Replace with the real Animator state names / values when known.
		private const string BiteAnimName = "Bite"; // TODO: reconstruct literal (state hash 0x182e3a2b8)
		private const string SwallowEndAnimName = "Idle"; // TODO: reconstruct literal (state hash 0x182e3cae0)
		private const float SwallowEndDelay = 0f; // TODO: reconstruct constant (_DAT_18252ce20)
		private const float MaxAttackSpeed = 10f; // TODO: reconstruct cap constant (_DAT_18252cb88)
		private const float BiteMoveDuration = 0f; // TODO: reconstruct constant (_DAT_18252cb64)

		public override void Reset()
		{
			// ICF-folded onto the shared PlantEntity.Reset body; delegate to the base
			// which rebuilds attr/defaultAttr from the card and resets sleep state.
			base.Reset();
		}

		protected override void Update()
		{
			base.Update();
			// Tick the bite timer only while biting and not yet ending the bite.
			if (_isEndBiting || !_isBiting)
			{
				return;
			}
			_biteTimer += Time.deltaTime;
			if (attr == null)
			{
				return;
			}
			// attr.GetValue(this, 1) is the maximum bite hold duration.
			if (attr.GetValue(this, 1) <= _biteTimer)
			{
				SwallowEnd();
			}
			if (_isPower0)
			{
				SwallowEnd();
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// ICF-folded onto an empty body in the pseudocode.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				if (attr != null && attr.valueList != null && defaultAttr != null && defaultAttr.valueList != null)
				{
					ValueEntity target = attr.valueList[0];
					ValueEntity def = defaultAttr.valueList[0];
					target.baseValue = entity.GetValue(this, 0) * def.baseValue + target.baseValue;
				}
			}
			else if (entity.index == 1)
			{
				if (attr != null && attr.valueList != null && defaultAttr != null && defaultAttr.valueList != null)
				{
					ValueEntity target = attr.valueList[1];
					ValueEntity def = defaultAttr.valueList[1];
					target.baseValue = target.baseValue - entity.GetValue(this, 0) * def.baseValue;
				}
			}
		}

		protected override void Attack()
		{
			// ICF-folded onto the base attack (plays the attack animation), then kicks off
			// the bite coroutine.
			base.Attack();
			// TODO: reconstruct — the pseudocode gated the StartCoroutine on the private
			// PlantEntity.IsPlaying getter, which is inaccessible here; that gate is dropped.
			StartCoroutine(AttackCoroutine());
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__14))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__14(0)
			{
				_003C_003E4__this = this
			};
		}

		public void BiteAttack()
		{
			// Play the bite SFX.
			if (biteSound != null)
			{
				Audio.Manager.AudioManager.Instance.PlayOneShot(biteSound);
			}
			ZombieEntity target = GetNearestTargetZombie();
			if (target == null)
			{
				return;
			}
			if (_metalMoveTween != null)
			{
				_metalMoveTween.Kill();
			}
			// Copy the target zombie's metal renderer onto our metal sprite, then make the
			// zombie lose its metal and tween our metal towards the zombie.
			SpriteRenderer metalRenderer = target.GetMetalRenderer();
			if (metalSpriteRenderer == null || metalRenderer == null)
			{
				return;
			}
			Transform metalTf = metalSpriteRenderer.transform;
			Transform sourceTf = metalRenderer.transform;
			if (metalTf == null || sourceTf == null)
			{
				return;
			}
			metalTf.position = sourceTf.position;
			metalTf.eulerAngles = sourceTf.eulerAngles;
			metalSpriteRenderer.sprite = metalRenderer.sprite;
			metalSpriteRenderer.sharedMaterial = new Material(metalRenderer.material);
			// TODO: the shader property name is a data pointer (0x182e3b3a0) and its value a
			// global (_DAT_18252cb28); the SetFloat call is dropped to avoid inventing them.
			// TODO: the tween target local position is a global config (_DAT_182e70d90 + 0xb8).
			_metalMoveTween = metalSpriteRenderer.transform.DOLocalMove(Vector3.zero, BiteMoveDuration);
			target.LoseMetal();
			_isBiting = true;
			_biteTimer = 0f;
			if (OnBiteAction != null)
			{
				OnBiteAction();
			}
		}

		public void SwallowEnd()
		{
			if (_swallowEndCoroutine == null)
			{
				_swallowEndCoroutine = StartCoroutine(SwallowEndCoroutine());
			}
		}

		[IteratorStateMachine(typeof(_003CSwallowEndCoroutine_003Ed__17))]
		private IEnumerator SwallowEndCoroutine()
		{
			return new _003CSwallowEndCoroutine_003Ed__17(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			// Can attack when not already biting and there is a zombie in range.
			if (!_isBiting)
			{
				if (GetNearestTargetZombie() != null)
				{
					return true;
				}
			}
			return false;
		}

		private ZombieEntity GetNearestTargetZombie()
		{
			if (attr == null)
			{
				return null;
			}
			// Overlap a circle of radius attr.GetValue(this,0) around this plant and collect
			// every candidate zombie, then return the closest.
			float radius = attr.GetValue(this, 0);
			Vector2 center = GetPosition();
			// TODO: the physics layer mask name is a data pointer (_DAT_182e30fc8); using the
			// "Zombie" layer as the faithful default.
			int mask = LayerMask.GetMask(ZombieLayerName);
			Collider2D[] hits = Physics2D.OverlapCircleAll(center, radius, mask);
			if (hits == null)
			{
				return null;
			}
			List<ZombieEntity> candidates = new List<ZombieEntity>();
			for (int i = 0; i < hits.Length; i++)
			{
				Collider2D hit = hits[i];
				if (hit == null)
				{
					continue;
				}
				ZombieEntity zombie = hit.gameObject.GetComponent<ZombieEntity>();
				if (zombie != null)
				{
					candidates.Add(zombie);
				}
			}
			// TODO: the pseudocode filtered the candidate list through a cached predicate
			// delegate (<GetNearestTargetZombie>b__19_0) reading a zombie state field that
			// could not be resolved to a member; that filter is dropped here.
			List<ZombieEntity> filtered = candidates.Where(z => z != null).ToList();
			if (filtered.Count < 1)
			{
				return null;
			}
			return filtered.OrderBy(_003CGetNearestTargetZombie_003Eb__19_1).First();
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__20))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__20(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__21))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__21(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[CompilerGenerated]
		private float _003CGetNearestTargetZombie_003Eb__19_1(ZombieEntity zombieEntity)
		{
			// Squared distance from this plant to the candidate zombie (used as the OrderBy key).
			Vector2 self = GetPosition();
			if (zombieEntity == null)
			{
				return 0f;
			}
			Transform t = zombieEntity.transform;
			if (t == null)
			{
				return 0f;
			}
			Vector3 zombiePos = t.position;
			float dx = self.x - zombiePos.x;
			float dy = self.y - zombiePos.y;
			return Mathf.Sqrt(dy * dy + dx * dx);
		}

		// TODO: unresolved physics layer name for GetNearestTargetZombie.
		private const string ZombieLayerName = "Zombie"; // TODO: reconstruct literal (_DAT_182e30fc8)
	}
}
