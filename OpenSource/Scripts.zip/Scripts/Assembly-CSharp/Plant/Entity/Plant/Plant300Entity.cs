using System.Collections;
using System.Collections.Generic;
using Bullet.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant300Entity : PlantEntity
	{
		[Tooltip("子弹位置")]
		public List<Transform> bulletPositionList;

		private List<Vector2> _directionList;

		private const string AttackAnimName = "Attack";
		private const float AttackWaitScale = 1f;
		private const float OnUsePower0Interval = 0.1f;

		protected override void Awake()
		{
			base.Awake();
		}

		public override void Reset()
		{
			base.Reset();
		}

		protected override void Update()
		{
			base.Update();
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// 强化 0：在当前攻击力上叠加 (defaultAttr.attack * value)
				if (attr != null && defaultAttr != null)
				{
					int baseAttack = attr.attack;
					int defaultAttack = defaultAttr.attack;
					float value = entity.GetValue(this);
					attr.attack = (int)((float)defaultAttack * value) + baseAttack;
				}
			}
			else if (entity.index == 1)
			{
				// 强化 1：用强化数值设置攻击速度
				if (attr != null && defaultAttr != null)
				{
					attr.AttackSpeed = entity.GetValue(this);
				}
			}
		}

		protected override void Attack()
		{
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			if (this == null || Animator == null)
			{
				yield break;
			}
			Animator.Play(AttackAnimName);
			if (attr == null)
			{
				yield break;
			}
			yield return new WaitForSeconds(attr.attackIntervalTime * AttackWaitScale);
			if (this == null)
			{
				yield break;
			}
			// 依次从 bulletPositionList 中每个枪口发射一发子弹，沿 _directionList 对应方向瞄准（翻转时水平镜像）
			for (int i = 0; bulletPositionList != null && i < bulletPositionList.Count; i++)
			{
				Transform muzzle = bulletPositionList[i];
				if (muzzle == null)
				{
					break;
				}
				BulletEntity bullet = CreateBullet(0, muzzle.position);
				if (bulletPositionList == null)
				{
					break;
				}
				Transform muzzle2 = bulletPositionList[i];
				if (muzzle2 == null)
				{
					break;
				}
				Vector3 origin = muzzle2.position;
				if (_directionList == null)
				{
					break;
				}
				Vector2 dir = _directionList[i];
				Vector2 target;
				if (!IsFlipX)
				{
					target = new Vector2(dir.x + origin.x, dir.y + origin.y);
				}
				else
				{
					target = new Vector2(origin.x - dir.x, origin.y - dir.y);
				}
				if (bullet == null)
				{
					break;
				}
				bullet.RotationToTarget(target);
			}
		}

		protected override bool CheckAttack()
		{
			return false;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 每隔固定时间发动一轮攻击，重复 GetValue(...) 次
			int i = 0;
			while (true)
			{
				if (entity == null)
				{
					yield break;
				}
				if ((int)entity.GetValue(this) <= i)
				{
					yield break;
				}
				yield return new WaitForSeconds(OnUsePower0Interval);
				if (this == null)
				{
					yield break;
				}
				StartCoroutine(AttackCoroutine());
				i++;
			}
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			// 永久提升攻击力 (defaultAttr.attack * strengthenValue) 并添加对应描述标签，仅执行一次
			if (this != null && attr != null && defaultAttr != null && entity != null)
			{
				int baseAttack = attr.attack;
				int defaultAttack = defaultAttr.attack;
				float value = entity.GetValue(this);
				attr.attack = (int)((float)defaultAttack * value) + baseAttack;
				attr.AddLabel(entity.title, 1, entity.GetDesc(this));
			}
			yield break;
		}
	}
}
