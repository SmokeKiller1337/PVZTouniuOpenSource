using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Bullet.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant300Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__8 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant300Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__8(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant300Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (plant == null || plant.Animator == null)
					{
						return false;
					}
					// Play the attack animation, then wait one attack interval before firing.
					// TODO: AttackAnimName is a data-pointer string constant in the pseudocode
					// (uRam0000000182e3a2b8) that could not be resolved to its literal text.
					plant.Animator.Play(AttackAnimName);
					if (plant.attr == null)
					{
						return false;
					}
					// WaitForSeconds(attr.attackIntervalTime * AttackWaitScale)
					// TODO: AttackWaitScale (_DAT_18252cd08) is an unresolved global multiplier.
					_003C_003E2__current = new WaitForSeconds(plant.attr.attackIntervalTime * AttackWaitScale);
					_003C_003E1__state = 1;
					return true;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null)
				{
					return false;
				}
				// Fire one bullet from each muzzle in bulletPositionList, aimed along the
				// matching direction in _directionList (mirrored horizontally when flipped).
				for (int i = 0; plant.bulletPositionList != null && i < plant.bulletPositionList.Count; i++)
				{
					Transform muzzle = plant.bulletPositionList[i];
					if (muzzle == null)
					{
						break;
					}
					BulletEntity bullet = plant.CreateBullet(0, muzzle.position);
					if (plant.bulletPositionList == null)
					{
						break;
					}
					Transform muzzle2 = plant.bulletPositionList[i];
					if (muzzle2 == null)
					{
						break;
					}
					Vector3 origin = muzzle2.position;
					if (plant._directionList == null)
					{
						break;
					}
					Vector2 dir = plant._directionList[i];
					Vector2 target;
					if (!plant.IsFlipX)
					{
						target = new Vector2(dir.x + origin.x, dir.y + origin.y);
					}
					else
					{
						target = new Vector2(origin.x - dir.x, origin.y - dir.y);
					}
					if (bullet == null)
					{
						break;
					}
					bullet.RotationToTarget(target);
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__10 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant300Entity _003C_003E4__this;

			public StrengthenEntity entity;

			private int _003Ci_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__10(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant300Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					_003Ci_003E5__2 = 0;
				}
				else
				{
					if (num != 1)
					{
						return false;
					}
					_003C_003E1__state = -1;
					if (plant == null)
					{
						return false;
					}
					// Kick off another volley, then count it.
					plant.StartCoroutine(plant.AttackCoroutine());
					_003Ci_003E5__2++;
				}
				// Repeat GetValue(...) times, waiting a fixed interval between volleys.
				if (entity != null)
				{
					if ((int)entity.GetValue(plant) <= _003Ci_003E5__2)
					{
						return false;
					}
					// TODO: OnUsePower0Interval (_DAT_18252ccfc) is an unresolved global interval.
					_003C_003E2__current = new WaitForSeconds(OnUsePower0Interval);
					_003C_003E1__state = 1;
					return true;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__11 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant300Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__11(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				if (_003C_003E1__state != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				Plant300Entity plant = _003C_003E4__this;
				// Permanently boost attack by (defaultAttr.attack * strengthenValue) and add a
				// descriptive label for it. Runs once, synchronously (no yield).
				if (plant != null && plant.attr != null && plant.defaultAttr != null && entity != null)
				{
					int baseAttack = plant.attr.attack;
					int defaultAttack = plant.defaultAttr.attack;
					float value = entity.GetValue(plant);
					plant.attr.attack = (int)((float)defaultAttack * value) + baseAttack;
					plant.attr.AddLabel(entity.title, 1, entity.GetDesc(plant));
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("子弹位置")]
		public List<Transform> bulletPositionList;

		private List<Vector2> _directionList;

		// TODO: reconstruct — the following constants are unresolved globals / data pointers in
		// the decompiled pseudocode. Placeholder values keep the class compilable and the
		// semantics plausible.
		private const string AttackAnimName = "Attack"; // uRam0000000182e3a2b8 (attack anim state name)
		private const float AttackWaitScale = 1f;        // _DAT_18252cd08 (attack-interval multiplier)
		private const float OnUsePower0Interval = 0.1f;  // _DAT_18252ccfc (volley interval)

		protected override void Awake()
		{
			// TODO: reconstruct — the pseudocode seeds _directionList with a fixed set of
			// direction vectors (four List.Add calls of raw float pairs from unresolved globals
			// _DAT_18252cb70 / _DAT_18252cb28 / _DAT_18252ce20 / _UNK_18252cfc4). The exact
			// vector literals could not be recovered, so the seeding is left out; base.Awake()
			// is invoked to preserve inherited initialization.
			base.Awake();
		}

		public override void Reset()
		{
			// The decompiled body (ICF-folded with other PlantEntity subclasses) is byte-identical
			// to the base PlantEntity.Reset() card/attribute setup, so it simply re-runs that logic.
			base.Reset();
		}

		protected override void Update()
		{
			// The decompiled body (ICF-folded with other PlantEntity subclasses) is byte-identical
			// to the base PlantEntity.Update() tick, so it simply re-runs that logic.
			base.Update();
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// ICF-folded onto an empty method in the pseudocode: this override is intentionally empty.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// Strengthen 0: add (defaultAttr.attack * value) to the current attack.
				if (attr != null && defaultAttr != null)
				{
					int baseAttack = attr.attack;
					int defaultAttack = defaultAttr.attack;
					float value = entity.GetValue(this);
					attr.attack = (int)((float)defaultAttack * value) + baseAttack;
				}
			}
			else if (entity.index == 1)
			{
				// Strengthen 1: set attack speed from the strengthen value.
				if (attr != null && defaultAttr != null)
				{
					attr.AttackSpeed = entity.GetValue(this);
				}
			}
		}

		protected override void Attack()
		{
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__8))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__8(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			// TODO: reconstruct — the pseudocode raycasts along each entry of _directionList
			// (Physics2D.RaycastAll from transform.position, mirrored on flip) using an
			// unresolved distance/layer-mask pair, then probes each hit's collider for a
			// component and invokes two virtual bool predicates (vtable slots 0x388 / 0x378)
			// on an object stored at that component's 0x28 field. Those predicate methods and
			// the target component type could not be mapped to real members, and the distance /
			// layer-name literals are unresolved globals, so the check cannot be reconstructed
			// faithfully. Left as a stub.
			return false;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__10))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__10(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__11))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__11(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
