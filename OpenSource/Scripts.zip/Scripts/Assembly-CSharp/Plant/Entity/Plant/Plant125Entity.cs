using System;
using System.Collections;
using System.Collections.Generic;
using Building.Entity;
using Game.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant125Entity : PlantEntity
	{
		[Tooltip("吃墓碑特效")]
		public EffectEntity effectEntity;

		private bool _power0;

		private bool _power1;

		private TombstoneEntity _tombstoneEntity;

		private const string AttackSpeedAnimatorParam = "attackSpeed";
		private const float AttackSpeedMultiplier = 1f;

		public override void Reset()
		{
			base.Reset();
		}

		protected override void Start()
		{
			base.Start();
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// 强化项 0：按默认首项数值的一定比例削减当前首项数值。
				if (attr == null || attr.valueList == null)
				{
					return;
				}
				ValueEntity liveValue = attr.valueList[0];
				if (liveValue == null)
				{
					return;
				}
				if (defaultAttr == null || defaultAttr.valueList == null)
				{
					return;
				}
				ValueEntity defaultValue = defaultAttr.valueList[0];
				if (defaultValue == null)
				{
					return;
				}
				liveValue.baseValue -= entity.GetValue(this) * defaultValue.baseValue;
			}
			else if (entity.index == 1)
			{
				// 强化项 1：按默认最大生命的一定比例提升最大生命。
				if (defaultAttr == null)
				{
					return;
				}
				float maxHealth = defaultAttr.maxHealth;
				float ratio = entity.GetValue(this);
				ChangeMaxHealth(ratio * maxHealth);
			}
		}

		public override void DeathHandle()
		{
			// 先触发死亡回调，再清理该植物持有的墓碑（若有）。
			if (OnDeathAction != null)
			{
				OnDeathAction();
			}
			if (_tombstoneEntity != null)
			{
				_tombstoneEntity.Clear();
			}
		}

		protected override void Attack()
		{
			if (attr == null || _animator == null)
			{
				return;
			}
			// 用植物的攻击速度驱动攻击动画速度，然后执行“吃墓碑”攻击协程。
			_animator.SetFloat(AttackSpeedAnimatorParam, attr.attackSpeed * AttackSpeedMultiplier);
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			yield break;
		}

		protected override bool CheckAttack()
		{
			return false;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 使用能量 0：置位 _power0 标记。
			_power0 = true;
			yield break;
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			// 使用能量 1：置位 _power1 标记。
			_power1 = true;
			yield break;
		}

		public override int GetHeadNumber()
		{
			return 0;
		}
	}
}
