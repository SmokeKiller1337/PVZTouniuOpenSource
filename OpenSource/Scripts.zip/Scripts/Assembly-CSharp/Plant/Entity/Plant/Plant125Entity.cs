using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Building.Entity;
using Game.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant125Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__10 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant125Entity _003C_003E4__this;

			private float _003Cduration_003E5__2;

			private float _003Ctimer_003E5__3;

			private Vector3 _003CtargetPosReanim_003E5__4;

			private Vector3 _003CstartPosTombstone_003E5__5;

			private Vector3 _003CstartPosReanim_003E5__6;

			private Vector3 _003CtargetPosTombstone_003E5__7;

			private StrengthenEntity _003CstrengthenEntity_003E5__8;

			private int _003Ci_003E5__9;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__10(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct - the attack coroutine drives a multi-phase "eat the
				// tombstone" animation: it spawns a tombstone via
				// BuildingManager.Instance.AddTombstone(CurrentLandEntity), plays the eat
				// effect / animator clip, lerps the reanimation body and the tombstone body
				// transforms towards each other over a duration read from attr, then spawns a
				// number of suns (RewardManager.Instance.CreateSun) driven by
				// GetStrengthenEntity(3).GetValue(...) with DOTween DOMove tweens and
				// WaitForSeconds delays, and finally reduces the card sun cost and clears the
				// tombstone. The lerp phases dereference reanimation-body sub-objects at
				// offsets (plVar2[0x14]+0x28, plVar2[0x26]+0x90) that could not be mapped to
				// confirmed members on the real types, so translating them literally would
				// require inventing members. Left as a stub rather than fabricating that logic.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__12 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant125Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__12(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// Power 0 simply latches the _power0 flag on the owning plant. There is no
				// actual yield point; the state machine sets the flag on the first pump and
				// then completes.
				if (_003C_003E1__state == 0)
				{
					Plant125Entity plant = _003C_003E4__this;
					_003C_003E1__state = -1;
					plant._power0 = true;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__13 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant125Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__13(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// Power 1 latches the _power1 flag on the owning plant. As with power 0 there
				// is no actual yield point.
				if (_003C_003E1__state == 0)
				{
					Plant125Entity plant = _003C_003E4__this;
					_003C_003E1__state = -1;
					plant._power1 = true;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("吃墓碑特效")]
		public EffectEntity effectEntity;

		private bool _power0;

		private bool _power1;

		private TombstoneEntity _tombstoneEntity;

		// TODO: unresolved animator-parameter name / speed multiplier used by Attack.
		// In the pseudocode these were data pointers / float globals (the SetFloat parameter
		// name string and the _DAT_18252cf40 multiplier). Placeholders keep the intent while
		// referencing only real members.
		private const string AttackSpeedAnimatorParam = "attackSpeed"; // TODO: reconstruct literal
		private const float AttackSpeedMultiplier = 1f; // TODO: reconstruct constant

		public override void Reset()
		{
			// The pseudocode for this override (RVA 0x592570) is ICF-folded onto the generic
			// plant reset body: it calls BaseBody.Reset() and then rebuilds title / defaultAttr /
			// priority / partEntity / attr from the card definition. That is exactly what
			// PlantEntity.Reset() already does (PlantEntity.Reset itself begins with
			// base.Reset()), and the folded body touches none of this class's own fields
			// (effectEntity / _power0 / _power1 / _tombstoneEntity). C# cannot skip a level to
			// call BaseBody.Reset directly, and duplicating the card-reset body here would run
			// it twice, so the faithful non-duplicating translation is a single chain to the
			// base implementation.
			base.Reset();
		}

		protected override void Start()
		{
			// The pseudocode first chains to PlantEntity.Start (card OnLevelUp hookup +
			// land health refresh), then seeds the card slot's sun counter from this plant's
			// card sun cost plus a CardSlotManager field. That second step reads a
			// CardSlotManager field (offset 0x80) that could not be mapped to a confirmed
			// member, and CardSlotManager.SunValue's own setter is a no-op in this build, so
			// the sun-seed is left unreconstructed rather than inventing a member.
			base.Start();
			// TODO: reconstruct - CardSlotManager.Instance.SunValue = CardEntity.attr.sun + <CardSlotManager field @0x80>.
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// Folded onto the shared empty method (RVA 0x381980); no per-instance body.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// Strengthen option 0: reduce the plant's first value entry by a fraction of
				// its default first value entry.
				if (attr == null || attr.valueList == null)
				{
					return;
				}
				ValueEntity liveValue = attr.valueList[0];
				if (liveValue == null)
				{
					return;
				}
				if (defaultAttr == null || defaultAttr.valueList == null)
				{
					return;
				}
				ValueEntity defaultValue = defaultAttr.valueList[0];
				if (defaultValue == null)
				{
					return;
				}
				liveValue.baseValue -= entity.GetValue(this) * defaultValue.baseValue;
			}
			else if (entity.index == 1)
			{
				// Strengthen option 1: add a fraction of the default max health to max health.
				if (defaultAttr == null)
				{
					return;
				}
				float maxHealth = defaultAttr.maxHealth;
				float ratio = entity.GetValue(this);
				ChangeMaxHealth(ratio * maxHealth);
			}
		}

		public override void DeathHandle()
		{
			// Fire the death callback, then clear the tombstone this plant is holding (if any).
			if (OnDeathAction != null)
			{
				OnDeathAction();
			}
			if (_tombstoneEntity != null)
			{
				_tombstoneEntity.Clear();
			}
		}

		protected override void Attack()
		{
			if (attr == null || _animator == null)
			{
				return;
			}
			// Drive the attack animation speed from the plant's attack speed, then run the
			// "eat tombstone" attack coroutine.
			_animator.SetFloat(AttackSpeedAnimatorParam, attr.attackSpeed * AttackSpeedMultiplier);
			StartCoroutine(AttackCoroutine());
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__10))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__10(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			// Folded body returns false (RVA 0x387B60 is the shared "return 0" method).
			return false;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__12))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__12(0)
			{
				_003C_003E4__this = this
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__13))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__13(0)
			{
				_003C_003E4__this = this
			};
		}

		public override int GetHeadNumber()
		{
			// Folded body returns 0 (RVA 0x3D5CA0 is the shared "return 0" method).
			return 0;
		}
	}
}
