using System;
using System.Collections;
using System.Collections.Generic;
using Common.Entity;
using Plant.Enum;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant90Entity : PlantEntity
	{
		[Tooltip("子弹位置")]
		public Transform bulletPosition;

		private float _maxAttackDistance;

		private const string AttackAnimName = "Attack";
		private const float AttackWaitScale = 1f;
		private const float PowerAttackInterval = 0.1f;

		public override void Reset()
		{
			base.Reset();
			CardEntity card = CardEntity;
			if (ExtraCardEntity != null)
			{
				card = ExtraCardEntity;
			}
			if (card == null)
			{
				return;
			}
			title = card.title;
			defaultAttr = new PlantBaseAttr(card.plantAttr);
			priority = card.priority;
			if (partEntity == null)
			{
				return;
			}
			partEntity.sleepType = card.sleepType;
			partEntity.isEyeAnimation = card.isEyeAnimation;
			switch ((int)card.placeType)
			{
				case 0:
					addSortingOrder = 0;
					break;
				case 1:
					addSortingOrder = 2;
					break;
				case 2:
					addSortingOrder = -1;
					break;
				case 3:
					addSortingOrder = 1;
					break;
			}
			attr = new PlantBaseAttr(defaultAttr);
			attr.Reset();
			CardEntity card2 = CardEntity;
			if (card2 != null && card2.plantAttr != null)
			{
				attr.currentHealth = card2.plantAttr.currentHealth;
				partEntity.blinkTime = UnityEngine.Random.Range(EyeBlinkMin, EyeBlinkMax);
				partEntity.blinkTimer = 0f;
				partEntity.isSleeping = false;
				partEntity.isCloseEye = false;
				UpdateHealthTextField();
				if (attr.currentHealth <= 0f)
				{
					Clear();
				}
				ResetSleep();
			}
		}

		// TODO: unresolved random-range bounds for eye blink interval.
		private const float EyeBlinkMin = 2f;
		private const float EyeBlinkMax = 6f;

		protected override void Update()
		{
			base.Update();
			if (partEntity == null)
			{
				return;
			}
			if (partEntity.isSleeping)
			{
				return;
			}
			PlantBaseAttr a = attr;
			if (a != null && a.attackIntervalTime > 0f)
			{
				a.attackIntervalTimer += Time.deltaTime;
				if (a.attackIntervalTimer >= a.attackIntervalTime)
				{
					a.attackIntervalTimer = 0f;
					if (CheckAttack())
					{
						Attack();
					}
				}
			}
			EyeUpdate();
			if (isHasSpecialSkill && specialCooldownTimer > 0f)
			{
				specialCooldownTimer -= Time.deltaTime;
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				PlantBaseAttr a = attr;
				if (a != null && defaultAttr != null)
				{
					int baseAttack = a.attack;
					int defAttack = defaultAttr.attack;
					float value = entity.GetValue(this);
					a.attack = (int)((float)defAttack * value) + baseAttack;
				}
			}
			else if (entity.index == 1)
			{
				PlantBaseAttr a = attr;
				if (a != null && defaultAttr != null)
				{
					float value = entity.GetValue(this);
					a.AttackSpeed = value * defaultAttr.attackSpeed + a.attackSpeed;
				}
			}
		}

		protected override void Attack()
		{
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			// 播放攻击动画，等待攻击间隔后生成子弹
			if (this != null && Animator != null)
			{
				Animator.Play(AttackAnimName);
				if (attr != null)
				{
					yield return new WaitForSeconds(attr.attackIntervalTime * AttackWaitScale);
					if (this != null && bulletPosition != null)
					{
						CreateBullet(0, bulletPosition.position);
					}
				}
			}
		}

		protected override bool CheckAttack()
		{
			return false;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 按强化数值决定的次数连续发动攻击，每次间隔 PowerAttackInterval
			for (int i = 0; entity != null && i < (int)entity.GetValue(this); i++)
			{
				yield return new WaitForSeconds(PowerAttackInterval);
				if (this == null)
				{
					yield break;
				}
				StartCoroutine(AttackCoroutine());
			}
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			// 按强化数值提升攻击速度并添加对应标签
			if (this != null && attr != null && defaultAttr != null && entity != null)
			{
				float value = entity.GetValue(this);
				attr.AttackSpeed = value * defaultAttr.attackSpeed + attr.attackSpeed;
				attr.AddLabel(entity.title, 1, entity.GetDesc(this));
			}
			yield break;
		}
	}
}
