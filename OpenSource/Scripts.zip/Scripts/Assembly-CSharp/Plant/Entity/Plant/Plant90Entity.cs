using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Entity;
using Plant.Enum;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant90Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__7 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant90Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__7(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant90Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (plant != null && plant.Animator != null)
					{
						// TODO: attack animation state name is a data pointer in the pseudocode.
						plant.Animator.Play(AttackAnimName);
						if (plant.attr != null)
						{
							// wait one attack interval (attr.attackIntervalTime scaled by a global factor)
							// TODO: AttackWaitScale is an unresolved global constant (_DAT_18252cd08).
							_003C_003E2__current = new WaitForSeconds(plant.attr.attackIntervalTime * AttackWaitScale);
							_003C_003E1__state = 1;
							return true;
						}
					}
					return false;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant != null && plant.bulletPosition != null)
				{
					plant.CreateBullet(0, plant.bulletPosition.position);
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__9 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant90Entity _003C_003E4__this;

			public StrengthenEntity entity;

			private int _003Ci_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__9(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant90Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					_003Ci_003E5__2 = 0;
				}
				else
				{
					if (num != 1)
					{
						return false;
					}
					_003C_003E1__state = -1;
					if (plant == null)
					{
						return false;
					}
					plant.StartCoroutine(plant.AttackCoroutine());
					_003Ci_003E5__2++;
				}
				if (entity != null && _003Ci_003E5__2 < (int)entity.GetValue(plant))
				{
					// TODO: PowerAttackInterval is an unresolved global constant (_DAT_18252ccfc).
					_003C_003E2__current = new WaitForSeconds(PowerAttackInterval);
					_003C_003E1__state = 1;
					return true;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__10 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant90Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__10(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant90Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant != null && plant.attr != null && plant.defaultAttr != null && entity != null)
				{
					// AttackSpeed = entity.GetValue(this) * defaultAttr.attackSpeed + attr.attackSpeed
					float value = entity.GetValue(plant);
					plant.attr.AttackSpeed = value * plant.defaultAttr.attackSpeed + plant.attr.attackSpeed;
					plant.attr.AddLabel(entity.title, 1, entity.GetDesc(plant));
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("子弹位置")]
		public Transform bulletPosition;

		private float _maxAttackDistance;

		// TODO: the following animation / interval constants are data pointers or
		// unresolved globals in the pseudocode. Replace with the real values when known.
		private const string AttackAnimName = "Attack"; // TODO: reconstruct literal
		private const float AttackWaitScale = 1f; // TODO: reconstruct constant (_DAT_18252cd08)
		private const float PowerAttackInterval = 0.1f; // TODO: reconstruct constant (_DAT_18252ccfc)

		public override void Reset()
		{
			base.Reset();
			CardEntity card = CardEntity;
			if (ExtraCardEntity != null)
			{
				card = ExtraCardEntity;
			}
			if (card == null)
			{
				return;
			}
			title = card.title;
			defaultAttr = new PlantBaseAttr(card.plantAttr);
			priority = card.priority;
			if (partEntity == null)
			{
				return;
			}
			partEntity.sleepType = card.sleepType;
			partEntity.isEyeAnimation = card.isEyeAnimation;
			switch ((int)card.placeType)
			{
				case 0:
					addSortingOrder = 0;
					break;
				case 1:
					addSortingOrder = 2;
					break;
				case 2:
					addSortingOrder = -1;
					break;
				case 3:
					addSortingOrder = 1;
					break;
			}
			attr = new PlantBaseAttr(defaultAttr);
			attr.Reset();
			CardEntity card2 = CardEntity;
			if (card2 != null && card2.plantAttr != null)
			{
				attr.currentHealth = card2.plantAttr.currentHealth;
				// TODO: EyeBlinkMin / EyeBlinkMax are unresolved random-range globals
				// (_DAT_18252cfb4 / _DAT_18252cf4c).
				partEntity.blinkTime = UnityEngine.Random.Range(EyeBlinkMin, EyeBlinkMax);
				partEntity.blinkTimer = 0f;
				partEntity.isSleeping = false;
				partEntity.isCloseEye = false;
				UpdateHealthTextField();
				if (attr.currentHealth <= 0f)
				{
					Clear();
				}
				ResetSleep();
			}
		}

		// TODO: unresolved random-range bounds for eye blink interval.
		private const float EyeBlinkMin = 2f; // TODO: reconstruct constant
		private const float EyeBlinkMax = 6f; // TODO: reconstruct constant

		protected override void Update()
		{
			base.Update();
			if (partEntity == null)
			{
				return;
			}
			if (partEntity.isSleeping)
			{
				return;
			}
			PlantBaseAttr a = attr;
			if (a != null && a.attackIntervalTime > 0f)
			{
				a.attackIntervalTimer += Time.deltaTime;
				if (a.attackIntervalTimer >= a.attackIntervalTime)
				{
					a.attackIntervalTimer = 0f;
					if (CheckAttack())
					{
						Attack();
					}
				}
			}
			EyeUpdate();
			if (isHasSpecialSkill && specialCooldownTimer > 0f)
			{
				specialCooldownTimer -= Time.deltaTime;
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// No-op in the original (folds onto an empty method body).
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				PlantBaseAttr a = attr;
				if (a != null && defaultAttr != null)
				{
					int baseAttack = a.attack;
					int defAttack = defaultAttr.attack;
					float value = entity.GetValue(this);
					a.attack = (int)((float)defAttack * value) + baseAttack;
				}
			}
			else if (entity.index == 1)
			{
				PlantBaseAttr a = attr;
				if (a != null && defaultAttr != null)
				{
					float value = entity.GetValue(this);
					a.AttackSpeed = value * defaultAttr.attackSpeed + a.attackSpeed;
				}
			}
		}

		protected override void Attack()
		{
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__7))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__7(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			// TODO: reconstruct - the original performs a Physics2D raycast from the level's
			// home/zombie-house transform towards this plant (clamped to _maxAttackDistance),
			// using a layer mask and per-hit checks against zombie virtual methods. It reads
			// several unresolved global managers/config holders (_DAT_182e2bc20, _DAT_182e706b8)
			// whose types/members cannot be verified in the project, so this is left stubbed.
			return false;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__9))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__9(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__10))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__10(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
