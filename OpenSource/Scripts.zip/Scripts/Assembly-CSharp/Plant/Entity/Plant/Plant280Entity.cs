using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using Level.Manager;
using Level.Util;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;
using Zombie.Entity.Data;

namespace Plant.Entity.Plant
{
	public class Plant280Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__10 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant280Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__10(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// The decompiled body of this coroutine is dominated by unnamed virtual-slot
				// calls on zombie entities (vtable offsets 0x418/0x238/0x298), raw-offset
				// field access, and DOTween blow-back tweening whose target member names are
				// not present in the provided skeleton. Reconstructing it faithfully would
				// require inventing external members, so the single-shot iterator is left as
				// a faithful no-yield stub.
				int num = this._003C_003E1__state;
				if (num == 0)
				{
					this._003C_003E1__state = -1;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__13 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant280Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__13(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				if (this._003C_003E1__state == 0)
				{
					this._003C_003E1__state = -1;
					this._003C_003E4__this._currentPowerEntity = this.entity;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__14 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant280Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__14(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				if (this._003C_003E1__state == 0)
				{
					this._003C_003E1__state = -1;
					this._003C_003E4__this._currentPowerEntity = this.entity;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("吹风音效")]
		public AudioClip blowSound;

		private bool _isSun;

		private StrengthenEntity _currentPowerEntity;

		public Action OnBlowAction;

		public override void Reset()
		{
			// TODO: reconstruct
			// base.Reset() is followed by two DOVirtual.DelayedCall scheduling calls and an
			// available-power invocation whose delegate targets are unnamed virtual-slot
			// methods (vtable offsets 0x430/0x280/0x478) not present in the skeleton. These
			// cannot be named without guessing, so the body is left as a faithful stub.
			base.Reset();
		}

		protected override void Start()
		{
			base.Start();
			if (!_isSun)
			{
				return;
			}
			StrengthenEntity strengthenEntity = GetStrengthenEntity(2, 1);
			RewardManager instance = RewardManager.Instance;
			if (_rigidbody != null && strengthenEntity != null && instance != null)
			{
				Vector2 position = _rigidbody.position;
				int value = (int)strengthenEntity.GetValue(this, 0);
				instance.CreateSun(position, value, 1f, true);
			}
		}

		public override void Death()
		{
			// TODO: reconstruct
			// The real body begins with an unnamed virtual-slot call on this entity (vtable
			// offset 0x288, most likely a "stop blowing" hook) that cannot be named without
			// guessing at an external member. Omitting it would make the reconstruction
			// unfaithful, so the method is left as a faithful stub that defers to the base
			// destruction path.
			base.Death();
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// The decompiled body folds to an empty method (no operations besides return).
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				if (attr != null && attr.valueList != null && attr.valueList.Count > 0
					&& defaultAttr != null && defaultAttr.valueList != null && defaultAttr.valueList.Count > 0)
				{
					attr.valueList[0].baseValue += entity.GetValue(this, 0) * defaultAttr.valueList[0].baseValue;
				}
			}
			else if (entity.index == 1)
			{
				if (attr != null && attr.valueList != null && attr.valueList.Count > 1)
				{
					attr.valueList[1].baseValue += entity.GetValue(this, 0);
				}
			}
		}

		protected override void Attack()
		{
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__10))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__10(0)
			{
				_003C_003E4__this = this
			};
		}

		private List<Zombie160Entity> GetBalloonZombieList(int row = -1)
		{
			List<Zombie160Entity> list = new List<Zombie160Entity>();
			foreach (ZombieEntity zombie in LevelUtils.GetLandZombieList().Where(delegate(ZombieEntity z)
			{
				if (row != -1 && z.currentRowLandEntity != null && row != z.currentRowLandEntity.row)
				{
					return false;
				}
				Zombie160Entity zombie160Entity = z as Zombie160Entity;
				return zombie160Entity != null && zombie160Entity.isHasBalloon;
			}).ToList())
			{
				list.Add(zombie as Zombie160Entity);
			}
			return list;
		}

		protected override bool CheckAttack()
		{
			return false;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__13))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__13(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__14))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__14(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
