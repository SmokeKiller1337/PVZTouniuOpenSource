using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Level.Manager;
using Level.Util;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;
using Zombie.Entity.Data;

namespace Plant.Entity.Plant
{
	public class Plant280Entity : PlantEntity
	{
		[Tooltip("吹风音效")]
		public AudioClip blowSound;

		private bool _isSun;

		private StrengthenEntity _currentPowerEntity;

		public Action OnBlowAction;

		public override void Reset()
		{
			base.Reset();
		}

		protected override void Start()
		{
			base.Start();
			if (!_isSun)
			{
				return;
			}
			StrengthenEntity strengthenEntity = GetStrengthenEntity(2, 1);
			RewardManager instance = RewardManager.Instance;
			if (_rigidbody != null && strengthenEntity != null && instance != null)
			{
				Vector2 position = _rigidbody.position;
				int value = (int)strengthenEntity.GetValue(this, 0);
				instance.CreateSun(position, value, 1f, true);
			}
		}

		public override void Death()
		{
			base.Death();
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				if (attr != null && attr.valueList != null && attr.valueList.Count > 0
					&& defaultAttr != null && defaultAttr.valueList != null && defaultAttr.valueList.Count > 0)
				{
					attr.valueList[0].baseValue += entity.GetValue(this, 0) * defaultAttr.valueList[0].baseValue;
				}
			}
			else if (entity.index == 1)
			{
				if (attr != null && attr.valueList != null && attr.valueList.Count > 1)
				{
					attr.valueList[1].baseValue += entity.GetValue(this, 0);
				}
			}
		}

		protected override void Attack()
		{
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			yield break;
		}

		private List<Zombie160Entity> GetBalloonZombieList(int row = -1)
		{
			List<Zombie160Entity> list = new List<Zombie160Entity>();
			foreach (ZombieEntity zombie in LevelUtils.GetLandZombieList().Where(delegate(ZombieEntity z)
			{
				if (row != -1 && z.currentRowLandEntity != null && row != z.currentRowLandEntity.row)
				{
					return false;
				}
				Zombie160Entity zombie160Entity = z as Zombie160Entity;
				return zombie160Entity != null && zombie160Entity.isHasBalloon;
			}).ToList())
			{
				list.Add(zombie as Zombie160Entity);
			}
			return list;
		}

		protected override bool CheckAttack()
		{
			return false;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 记录当前使用能量的强化实体
			_currentPowerEntity = entity;
			yield break;
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			// 记录当前使用能量的强化实体
			_currentPowerEntity = entity;
			yield break;
		}
	}
}
