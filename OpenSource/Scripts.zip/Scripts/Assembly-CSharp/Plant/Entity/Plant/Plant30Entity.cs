using System;
using System.Collections;
using System.Collections.Generic;
using Audio.Manager;
using Common.Entity;
using Game.Entity;
using Level.Manager;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant30Entity : PlantEntity
	{
		[Tooltip("种植时音效")]
		public AudioClip startSound;

		[Tooltip("爆炸效果")]
		public EffectEntity explosionEffect;

		private bool _isSun;

		public Action<List<BaseBody>> OnExplosionAfter;

		private StrengthenEntity _currentPowerEntity;

		public override void Reset()
		{
			base.Reset();
			if (AudioManager.Instance != null)
			{
				AudioManager.Instance.PlayOneShot(startSound);
			}
			// If this plant sits in a real card slot and its power is available, fire it.
			if (IsHasCardSlot)
			{
				CardEntity card = CardEntity;
				if (card != null && card.IsAvailablePower())
				{
					UsePower();
				}
			}
		}

		protected override void Start()
		{
			base.Start();
			if (attr == null)
			{
				return;
			}
			attr.isInvincible = true;
			if (!_isSun)
			{
				return;
			}
			StrengthenEntity entity = GetStrengthenEntity(2, 1);
			if (_rigidbody != null && entity != null && RewardManager.Instance != null)
			{
				Vector2 position = _rigidbody.position;
				float value = entity.GetValue(this, 0);
				RewardManager.Instance.CreateSun(position, (int)value, 1f, true);
			}
		}

		public override void Death()
		{
			DeathHandle();
			ClearLand();
			UnityEngine.Object.Destroy(gameObject);
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index != 0)
			{
				if (entity.index == 1)
				{
					_isSun = true;
				}
				return;
			}
			// index == 0: boost attack by defaultAttr.attack * strengthenValue.
			PlantBaseAttr a = attr;
			if (a == null)
			{
				return;
			}
			int baseAttack = a.attack;
			if (defaultAttr == null)
			{
				return;
			}
			int defaultAttack = defaultAttr.attack;
			float ratio = entity.GetValue(this, 0);
			a.attack = (int)((float)defaultAttack * ratio) + baseAttack;
		}

		protected override void Attack()
		{
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			yield break;
		}

		protected override bool CheckAttack()
		{
			return true;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 记录当前生效的强化实体
			_currentPowerEntity = entity;
			yield break;
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			// 记录当前生效的强化实体
			_currentPowerEntity = entity;
			yield break;
		}

		public override int GetHeadNumber()
		{
			return 2;
		}
	}
}
