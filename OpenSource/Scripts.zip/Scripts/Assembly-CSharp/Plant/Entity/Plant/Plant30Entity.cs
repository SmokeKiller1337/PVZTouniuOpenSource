using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Audio.Manager;
using Common.Entity;
using Game.Entity;
using Level.Manager;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant30Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__11 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant30Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__11(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct - the attack coroutine's state machine could not be
				// faithfully translated. Its body reads several unresolved runtime globals:
				//   * a Cinemachine impulse source used for the camera shake (the project
				//     contains no GenerateImpulse call-site or reachable singleton for it),
				//   * a camera-rotation Quaternion global fed into GameUtils.CreateEffect,
				//   * the explosion radius / LayerMask arguments to DamageUtils.Explosion,
				//   * a final unresolved virtual dispatch (slot 0x278) after the blast.
				// Reconstructing these would require inventing members / constants, so the
				// coroutine body is left as an inert stub.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__13 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant30Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__13(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// State machine has no yields: it simply records the active power entity
				// on the owning plant and completes. (this._currentPowerEntity @0x140 = entity)
				if (_003C_003E1__state == 0)
				{
					_003C_003E1__state = -1;
					_003C_003E4__this._currentPowerEntity = entity;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__14 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant30Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__14(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// Same shape as <OnUsePower0>d__13: record the active power entity and finish.
				if (_003C_003E1__state == 0)
				{
					_003C_003E1__state = -1;
					_003C_003E4__this._currentPowerEntity = entity;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("种植时音效")]
		public AudioClip startSound;

		[Tooltip("爆炸效果")]
		public EffectEntity explosionEffect;

		private bool _isSun;

		public Action<List<BaseBody>> OnExplosionAfter;

		private StrengthenEntity _currentPowerEntity;

		public override void Reset()
		{
			base.Reset();
			// TODO: reconstruct - the original also scheduled a DOVirtual.DelayedCall(1f, ...)
			// whose delegate target (method pointer @0x430) could not be resolved from the
			// pseudocode, so that deferred call is dropped here.
			// Play the planting sound.
			if (AudioManager.Instance != null)
			{
				AudioManager.Instance.PlayOneShot(startSound);
			}
			// If this plant sits in a real card slot and its power is available, fire it.
			if (IsHasCardSlot)
			{
				CardEntity card = CardEntity;
				if (card != null && card.IsAvailablePower())
				{
					UsePower();
				}
			}
		}

		protected override void Start()
		{
			base.Start();
			// attr (@0xE0) exists check; mark it invincible (attr.isInvincible @0x18 = true).
			if (attr == null)
			{
				return;
			}
			attr.isInvincible = true;
			// _isSun (@0x130): only sun producers spawn sun on plant.
			if (!_isSun)
			{
				return;
			}
			StrengthenEntity entity = GetStrengthenEntity(2, 1);
			// _rigidbody (@0x80) and the strengthen entity are both required to know where /
			// how much sun to create.
			if (_rigidbody != null && entity != null && RewardManager.Instance != null)
			{
				Vector2 position = _rigidbody.position;
				float value = entity.GetValue(this, 0);
				RewardManager.Instance.CreateSun(position, (int)value, 1f, true);
			}
		}

		public override void Death()
		{
			// TODO: reconstruct - the original additionally spawned a death/explosion effect
			// through effect-manager globals that could not be resolved to concrete members,
			// so only the reliably recovered teardown is reproduced here.
			DeathHandle();
			ClearLand();
			UnityEngine.Object.Destroy(gameObject);
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// Genuinely empty in the binary (folded onto an empty body).
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			// entity.index (@0x10) selects which level-2 strengthen was chosen.
			if (entity.index != 0)
			{
				if (entity.index == 1)
				{
					// _isSun (@0x130): this upgrade turns the plant into a sun producer.
					_isSun = true;
				}
				return;
			}
			// index == 0: boost attack by defaultAttr.attack * strengthenValue.
			PlantBaseAttr a = attr;
			if (a == null)
			{
				return;
			}
			int baseAttack = a.attack;
			if (defaultAttr == null)
			{
				return;
			}
			int defaultAttack = defaultAttr.attack;
			float ratio = entity.GetValue(this, 0);
			a.attack = (int)((float)defaultAttack * ratio) + baseAttack;
		}

		protected override void Attack()
		{
			StartCoroutine(AttackCoroutine());
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__11))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__11(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			// The Ghidra body is ICF-folded onto a shared constant-return stub; a plant that
			// drives Attack() off its attack interval always reports ready here (base returns true).
			return true;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__13))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__13(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__14))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__14(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		public override int GetHeadNumber()
		{
			return 2;
		}
	}
}
