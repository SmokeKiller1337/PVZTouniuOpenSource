using System;
using System.Collections;
using System.Collections.Generic;
using Building.Entity;
using Common.Entity;
using Game.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant120Entity : PlantEntity
	{
		[Tooltip("吃墓碑特效")]
		public EffectEntity effectEntity;

		[Tooltip("减速效果")]
		public List<ValueEntity> slowBuffList;

		[HideInInspector]
		public bool isTrack;

		[HideInInspector]
		public bool isSlow;

		[HideInInspector]
		public bool isDiamond;

		private bool _power0;

		private bool _power1;

		private TombstoneEntity _tombstoneEntity;

		private const string AttackSpeedParam = "AttackSpeed";

		private const float AttackAnimSpeedFactor = 1f;

		public override void Reset()
		{
			// Mirrors the standard PlantEntity reset flow: pull the card (or extra card),
			// rebuild attr/defaultAttr from the card's plant attributes, seed the part
			// entity state and refresh the health display.
			base.Reset();
			CardEntity card = CardEntity;
			if (ExtraCardEntity != null)
			{
				card = ExtraCardEntity;
			}
			if (card == null)
			{
				return;
			}
			title = card.title;
			defaultAttr = new PlantBaseAttr(card.plantAttr);
			priority = card.priority;
			if (partEntity == null)
			{
				return;
			}
			partEntity.sleepType = card.sleepType;
			partEntity.isEyeAnimation = card.isEyeAnimation;
			switch ((int)card.placeType)
			{
				case 0:
					addSortingOrder = 0;
					break;
				case 1:
					addSortingOrder = 2;
					break;
				case 2:
					addSortingOrder = -1;
					break;
				case 3:
					addSortingOrder = 1;
					break;
			}
			attr = new PlantBaseAttr(defaultAttr);
			attr.Reset();
			CardEntity card2 = CardEntity;
			if (card2 != null && card2.plantAttr != null)
			{
				attr.currentHealth = card2.plantAttr.currentHealth;
				partEntity.blinkTime = UnityEngine.Random.Range(2f, 6f);
				partEntity.blinkTimer = 0f;
				partEntity.isSleeping = false;
				partEntity.isCloseEye = false;
				UpdateHealthTextField();
				if (attr.currentHealth <= 0f)
				{
					Clear();
				}
				ResetSleep();
			}
		}

		protected override void Start()
		{
			base.Start();
			// The plant immediately walks toward and mounts the nearest tombstone.
			StartCoroutine(ToTombstoneCoroutine());
		}

		private void ToTombstone()
		{
			StartCoroutine(ToTombstoneCoroutine());
		}

		private IEnumerator ToTombstoneCoroutine()
		{
			yield break;
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			// entity.index selects which upgrade branch applies.
			if (entity.index != 0)
			{
				if (entity.index == 1)
				{
					isSlow = true;
				}
				return;
			}
			// index 0: reduce the first attr value by (upgrade value * default first value).
			if (attr == null || attr.valueList == null)
			{
				return;
			}
			ValueEntity current = attr.valueList[0];
			if (current == null)
			{
				return;
			}
			if (defaultAttr == null || defaultAttr.valueList == null)
			{
				return;
			}
			ValueEntity baseValue = defaultAttr.valueList[0];
			if (baseValue == null)
			{
				return;
			}
			float value = entity.GetValue(this, 0);
			current.baseValue -= value * baseValue.baseValue;
		}

		public override void DeathHandle()
		{
			// Fire the death callback (base BaseBody behavior).
			if (OnDeathAction != null)
			{
				OnDeathAction();
			}
			if (_tombstoneEntity != null)
			{
				_tombstoneEntity = null;
			}
		}

		protected override void Attack()
		{
			if (attr == null || _animator == null)
			{
				return;
			}
			// Drive the eat animation speed off the plant's attack speed.
			_animator.SetFloat(AttackSpeedParam, attr.attackSpeed * AttackAnimSpeedFactor);
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			yield break;
		}

		protected override bool CheckAttack()
		{
			return false;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 开启吃墓碑时产出阳光的能力
			_power0 = true;
			yield break;
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			// 开启产出钻石，并在吃墓碑时奖励钻石
			_power1 = true;
			isDiamond = true;
			yield break;
		}

		public override int GetHeadNumber()
		{
			return 0;
		}
	}
}
