using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Building.Entity;
using Common.Entity;
using Game.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant120Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__16 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant120Entity _003C_003E4__this;

			private float _003Cduration_003E5__2;

			private float _003Ctimer_003E5__3;

			private Vector3 _003CstartPosReanim_003E5__4;

			private Vector3 _003CtargetPosTombstone_003E5__5;

			private Vector3 _003CtargetPosReanim_003E5__6;

			private Vector3 _003CstartPosTombstone_003E5__7;

			private StrengthenEntity _003CstrengthenEntity_003E5__8;

			private int _003Ci_003E5__9;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__16(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct - the pseudocode state machine at RVA 0x59b970 drives the
				// full melee/reanim tombstone-eating animation: it lerps a reanim sprite (base
				// field at raw offset 0x14, +0x28 transform) and the tombstone body
				// (_tombstoneEntity + 0x90 transform) between interpolated local positions over
				// a duration derived from PlantBaseAttr.GetValue, then applies an area explosion
				// (DamageUtils.Explosion) with per-body slow buffs (BuffHandler.AddBuff) and
				// optionally spawns diamonds/suns (RewardManager) with DOTween moves. Those raw
				// offsets (reanim/tombstone internal transforms, land-building internals) cannot
				// be mapped to verified public members, so the body is left as a stub.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__18 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant120Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__18(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// State machine at RVA 0x59eb70: on first pump, flags the plant so it produces
				// suns while eating (sets _power0 at raw offset 0x133), then completes.
				if (_003C_003E1__state == 0)
				{
					_003C_003E1__state = -1;
					Plant120Entity plant120Entity = _003C_003E4__this;
					plant120Entity._power0 = true;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__19 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant120Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__19(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// State machine at RVA 0x5a0160: on first pump, flags the plant to produce
				// diamonds (isDiamond at raw offset 0x132) and to reward diamonds while eating
				// (_power1 at raw offset 0x134), then completes.
				if (_003C_003E1__state == 0)
				{
					_003C_003E1__state = -1;
					Plant120Entity plant120Entity = _003C_003E4__this;
					plant120Entity._power1 = true;
					plant120Entity.isDiamond = true;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CToTombstoneCoroutine_003Ed__11 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant120Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CToTombstoneCoroutine_003Ed__11(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct - the pseudocode state machine at RVA 0x5a1890 searches the
				// nearest tombstone building (LevelUtils.GetLandBuildingList filtered by an
				// unresolved building-type/offset test), DOMoves this plant toward it, then binds
				// the tombstone and refunds sun via CardSlotManager. The heavy use of raw
				// building/land internal offsets (0x130 place tag, 0xc8 type table, 0x88/0x48
				// occupant links, plStack_90[7]) cannot be mapped to verified public members,
				// so the body is left as a stub.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("吃墓碑特效")]
		public EffectEntity effectEntity;

		[Tooltip("减速效果")]
		public List<ValueEntity> slowBuffList;

		[HideInInspector]
		public bool isTrack;

		[HideInInspector]
		public bool isSlow;

		[HideInInspector]
		public bool isDiamond;

		private bool _power0;

		private bool _power1;

		private TombstoneEntity _tombstoneEntity;

		// TODO: unresolved animator float-parameter name used by Attack (data pointer
		// _DAT_182e37c80 in the pseudocode). Replace with the real Animator parameter name.
		private const string AttackSpeedParam = "AttackSpeed"; // TODO: reconstruct literal

		// TODO: unresolved global constant multiplying attackSpeed for the animator SetFloat
		// (_DAT_18252cf40 in the pseudocode).
		private const float AttackAnimSpeedFactor = 1f; // TODO: reconstruct constant

		public override void Reset()
		{
			// Mirrors the standard PlantEntity reset flow: pull the card (or extra card),
			// rebuild attr/defaultAttr from the card's plant attributes, seed the part
			// entity state and refresh the health display.
			base.Reset();
			CardEntity card = CardEntity;
			if (ExtraCardEntity != null)
			{
				card = ExtraCardEntity;
			}
			if (card == null)
			{
				return;
			}
			title = card.title;
			defaultAttr = new PlantBaseAttr(card.plantAttr);
			priority = card.priority;
			if (partEntity == null)
			{
				return;
			}
			partEntity.sleepType = card.sleepType;
			partEntity.isEyeAnimation = card.isEyeAnimation;
			switch ((int)card.placeType)
			{
				case 0:
					addSortingOrder = 0;
					break;
				case 1:
					addSortingOrder = 2;
					break;
				case 2:
					addSortingOrder = -1;
					break;
				case 3:
					addSortingOrder = 1;
					break;
			}
			attr = new PlantBaseAttr(defaultAttr);
			attr.Reset();
			CardEntity card2 = CardEntity;
			if (card2 != null && card2.plantAttr != null)
			{
				attr.currentHealth = card2.plantAttr.currentHealth;
				partEntity.blinkTime = UnityEngine.Random.Range(2f, 6f);
				partEntity.blinkTimer = 0f;
				partEntity.isSleeping = false;
				partEntity.isCloseEye = false;
				UpdateHealthTextField();
				if (attr.currentHealth <= 0f)
				{
					Clear();
				}
				ResetSleep();
			}
		}

		protected override void Start()
		{
			base.Start();
			// The plant immediately walks toward and mounts the nearest tombstone.
			StartCoroutine(ToTombstoneCoroutine());
		}

		private void ToTombstone()
		{
			StartCoroutine(ToTombstoneCoroutine());
		}

		[IteratorStateMachine(typeof(_003CToTombstoneCoroutine_003Ed__11))]
		private IEnumerator ToTombstoneCoroutine()
		{
			return new _003CToTombstoneCoroutine_003Ed__11(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// RVA 0x381980 is a shared empty-body stub (ICF-folded). No level-0 behavior.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			// entity.index selects which upgrade branch applies.
			if (entity.index != 0)
			{
				if (entity.index == 1)
				{
					isSlow = true;
				}
				return;
			}
			// index 0: reduce the first attr value by (upgrade value * default first value).
			if (attr == null || attr.valueList == null)
			{
				return;
			}
			ValueEntity current = attr.valueList[0];
			if (current == null)
			{
				return;
			}
			if (defaultAttr == null || defaultAttr.valueList == null)
			{
				return;
			}
			ValueEntity baseValue = defaultAttr.valueList[0];
			if (baseValue == null)
			{
				return;
			}
			float value = entity.GetValue(this, 0);
			current.baseValue -= value * baseValue.baseValue;
		}

		public override void DeathHandle()
		{
			// Fire the death callback (base BaseBody behavior).
			if (OnDeathAction != null)
			{
				OnDeathAction();
			}
			// Release the tombstone this plant was mounted on, if any.
			// TODO: reconstruct - the pseudocode also reset the tombstone body's local
			// position (via _tombstoneEntity + 0x90 child transform) before clearing the
			// reference. That child transform maps to an internal TombstoneEntity offset with
			// no verified public member, so only the reference clear is reproduced here.
			if (_tombstoneEntity != null)
			{
				_tombstoneEntity = null;
			}
		}

		protected override void Attack()
		{
			if (attr == null || _animator == null)
			{
				return;
			}
			// Drive the eat animation speed off the plant's attack speed.
			_animator.SetFloat(AttackSpeedParam, attr.attackSpeed * AttackAnimSpeedFactor);
			StartCoroutine(AttackCoroutine());
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__16))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__16(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			// RVA 0x387b60 is a shared stub returning false (ICF-folded).
			return false;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__18))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__18(0)
			{
				_003C_003E4__this = this
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__19))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__19(0)
			{
				_003C_003E4__this = this
			};
		}

		public override int GetHeadNumber()
		{
			// RVA 0x3d5ca0 is a shared stub returning 0 (ICF-folded).
			return 0;
		}
	}
}
