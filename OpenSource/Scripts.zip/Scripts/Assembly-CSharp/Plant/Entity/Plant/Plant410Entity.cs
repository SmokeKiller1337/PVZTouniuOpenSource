using System;
using System.Collections;
using System.Collections.Generic;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant410Entity : PlantEntity
	{
		private const string AttackAnimName = "Attack";
		private const float AttackWindupRatio = 1f;
		private const float AttackShotRatio = 1f;
		private const float OnUsePower0Interval = 0f;

		private const string EyeBlinkAnimName = "EyeBlink";
		private const string EyeBlinkTag = "Blink";

		[Tooltip("子弹位置")]
		public Transform bulletPosition;

		[Tooltip("头部物体")]
		public GameObject headObj;

		public override void Reset()
		{
			base.Reset();
		}

		protected override void Update()
		{
			base.Update();
		}

		public override void EyeBlink()
		{
			if (partEntity == null)
			{
				return;
			}
			if (partEntity.isCloseEye)
			{
				return;
			}
			if (_animator == null)
			{
				return;
			}
			if (_animator.GetCurrentAnimatorStateInfo(0).IsTag(EyeBlinkTag)
				&& _animator.GetCurrentAnimatorStateInfo(1).IsTag(EyeBlinkTag))
			{
				_animator.Play(EyeBlinkAnimName, 0);
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (attr == null || defaultAttr == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				int baseAttack = attr.attack;
				float ratio = entity.GetValue(this);
				attr.attack = (int)((float)defaultAttr.attack * ratio) + baseAttack;
			}
			else if (entity.index == 1)
			{
				attr.AttackSpeed = entity.GetValue(this);
			}
		}

		protected override void Attack()
		{
			// 先播放基类攻击动画，再启动多连发攻击协程
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			if (this == null || _animator == null)
			{
				yield break;
			}
			_animator.Play(AttackAnimName, 1, 0f);
			// 蓄力阶段
			if (attr == null)
			{
				yield break;
			}
			yield return new WaitForSeconds(attr.attackIntervalTime * AttackWindupRatio);
			// 连续四次开火，每次之间间隔一段时间
			FireOnce(this);
			if (attr == null)
			{
				yield break;
			}
			yield return new WaitForSeconds(attr.attackIntervalTime * AttackShotRatio);
			FireOnce(this);
			if (attr == null)
			{
				yield break;
			}
			yield return new WaitForSeconds(attr.attackIntervalTime * AttackShotRatio);
			FireOnce(this);
			if (attr == null)
			{
				yield break;
			}
			yield return new WaitForSeconds(attr.attackIntervalTime * AttackShotRatio);
			FireOnce(this);
		}

		private static void FireOnce(Plant410Entity plant)
		{
			if (plant == null || plant.headObj == null)
			{
				return;
			}
			if (!plant.headObj.activeSelf)
			{
				return;
			}
			if (plant.bulletPosition == null)
			{
				return;
			}
			plant.CreateBullet(0, plant.bulletPosition.position);
		}

		protected override bool CheckAttack()
		{
			return false;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 按强化数值反复发动额外的攻击波次
			int i = 0;
			while (true)
			{
				if (entity == null)
				{
					yield break;
				}
				if ((int)entity.GetValue(this) <= i)
				{
					yield break;
				}
				yield return new WaitForSeconds(OnUsePower0Interval);
				if (this == null)
				{
					yield break;
				}
				StartCoroutine(AttackCoroutine());
				i++;
			}
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			// 永久提升攻击力（按默认攻击力乘以强化系数叠加），并登记强化标签
			if (this == null || attr == null || defaultAttr == null || entity == null)
			{
				yield break;
			}
			int baseAttack = attr.attack;
			float ratio = entity.GetValue(this);
			attr.attack = (int)((float)defaultAttr.attack * ratio) + baseAttack;
			attr.AddLabel(entity.title, 1, entity.GetDesc(this));
		}

		public override int GetHeadNumber()
		{
			if (headObj == null)
			{
				return 0;
			}
			return headObj.activeSelf ? 1 : 0;
		}
	}
}
