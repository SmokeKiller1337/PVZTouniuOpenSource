using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant410Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__8 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant410Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__8(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant410Entity plant = _003C_003E4__this;
				switch (num)
				{
				default:
					return false;
				case 0:
					_003C_003E1__state = -1;
					// Play the attack animation, then pace the shots by the plant's
					// attack interval. (Animator state name is a data pointer in the
					// pseudocode; using the shared placeholder constant.)
					if (plant == null || plant._animator == null)
					{
						return false;
					}
					plant._animator.Play(Plant410Entity.AttackAnimName, 1, 0f);
					if (plant.attr == null)
					{
						return false;
					}
					_003C_003E2__current = new WaitForSeconds(plant.attr.attackIntervalTime * AttackWindupRatio);
					_003C_003E1__state = 1;
					return true;
				case 1:
					_003C_003E1__state = -1;
					FireOnce(plant);
					if (plant.attr == null)
					{
						return false;
					}
					_003C_003E2__current = new WaitForSeconds(plant.attr.attackIntervalTime * AttackShotRatio);
					_003C_003E1__state = 2;
					return true;
				case 2:
					_003C_003E1__state = -1;
					FireOnce(plant);
					if (plant.attr == null)
					{
						return false;
					}
					_003C_003E2__current = new WaitForSeconds(plant.attr.attackIntervalTime * AttackShotRatio);
					_003C_003E1__state = 3;
					return true;
				case 3:
					_003C_003E1__state = -1;
					FireOnce(plant);
					if (plant.attr == null)
					{
						return false;
					}
					_003C_003E2__current = new WaitForSeconds(plant.attr.attackIntervalTime * AttackShotRatio);
					_003C_003E1__state = 4;
					return true;
				case 4:
					_003C_003E1__state = -1;
					FireOnce(plant);
					return false;
				}
			}

			// Spawn one bullet from the muzzle transform, but only while the head
			// object is active (headObj @0x128, bulletPosition @0x120 in the dump).
			private static void FireOnce(Plant410Entity plant)
			{
				if (plant == null || plant.headObj == null)
				{
					return;
				}
				if (!plant.headObj.activeSelf)
				{
					return;
				}
				if (plant.bulletPosition == null)
				{
					return;
				}
				plant.CreateBullet(0, plant.bulletPosition.position);
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__10 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant410Entity _003C_003E4__this;

			public StrengthenEntity entity;

			private int _003Ci_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__10(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant410Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					// Reset the shot counter (local <i>5__2 @0x30 in the pseudocode).
					_003Ci_003E5__2 = 0;
				}
				else
				{
					if (num != 1)
					{
						return false;
					}
					_003C_003E1__state = -1;
					// Fire an extra attack burst, then bump the counter.
					if (plant == null)
					{
						return false;
					}
					plant.StartCoroutine(plant.AttackCoroutine());
					_003Ci_003E5__2++;
				}
				// Keep launching bursts until the counter reaches the strengthen value.
				if (entity == null)
				{
					return false;
				}
				if ((int)entity.GetValue(plant) <= _003Ci_003E5__2)
				{
					return false;
				}
				_003C_003E2__current = new WaitForSeconds(OnUsePower0Interval);
				_003C_003E1__state = 1;
				return true;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__11 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant410Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__11(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant410Entity plant = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				// Permanently buff attack by defaultAttr.attack * strengthenValue and
				// register the strengthen label on the live attr.
				if (plant == null || plant.attr == null || plant.defaultAttr == null || entity == null)
				{
					return false;
				}
				int baseAttack = plant.attr.attack;
				float ratio = entity.GetValue(plant);
				plant.attr.attack = (int)((float)plant.defaultAttr.attack * ratio) + baseAttack;
				plant.attr.AddLabel(entity.title, 1, entity.GetDesc(plant));
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		// TODO: reconstruct — animation state name and the WaitForSeconds multipliers
		// below are unresolved data pointers / float globals in the pseudocode.
		private const string AttackAnimName = "Attack"; // TODO: reconstruct literal
		private const float AttackWindupRatio = 1f; // TODO: reconstruct constant (_DAT_18252cd08)
		private const float AttackShotRatio = 1f; // TODO: reconstruct constant (_UNK_18252ce18)
		private const float OnUsePower0Interval = 0f; // TODO: reconstruct constant (_DAT_18252ccfc)

		// TODO: reconstruct — eye-blink animation state name / tag are data pointers.
		private const string EyeBlinkAnimName = "EyeBlink"; // TODO: reconstruct literal
		private const string EyeBlinkTag = "Blink"; // TODO: reconstruct animator tag literal

		[Tooltip("子弹位置")]
		public Transform bulletPosition;

		[Tooltip("头部物体")]
		public GameObject headObj;

		public override void Reset()
		{
			// ICF-folded onto the base PlantEntity.Reset body; faithful reproduction.
			base.Reset();
		}

		protected override void Update()
		{
			// ICF-folded onto the base PlantEntity.Update body; faithful reproduction.
			base.Update();
		}

		public override void EyeBlink()
		{
			if (partEntity == null)
			{
				return;
			}
			// Don't blink while eyes are closed (partEntity.isCloseEye @0x16).
			if (partEntity.isCloseEye)
			{
				return;
			}
			if (_animator == null)
			{
				return;
			}
			// The pseudocode double-checks the blink tag on layer 0 then layer 1
			// before triggering the blink state.
			if (_animator.GetCurrentAnimatorStateInfo(0).IsTag(EyeBlinkTag)
				&& _animator.GetCurrentAnimatorStateInfo(1).IsTag(EyeBlinkTag))
			{
				_animator.Play(EyeBlinkAnimName, 0);
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// ICF-folded onto an empty body; the original OnLevelUp does nothing.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (attr == null || defaultAttr == null)
			{
				return;
			}
			// entity.index (@0x10) selects which stat this strengthen boosts.
			if (entity.index == 0)
			{
				int baseAttack = attr.attack;
				float ratio = entity.GetValue(this);
				attr.attack = (int)((float)defaultAttr.attack * ratio) + baseAttack;
			}
			else if (entity.index == 1)
			{
				attr.AttackSpeed = entity.GetValue(this);
			}
		}

		protected override void Attack()
		{
			// Play the shared attack animation via the base, then kick off the
			// multi-shot attack coroutine.
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__8))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__8(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			// TODO: reconstruct — the pseudocode performs a Physics2D.RaycastAll sweep
			// driven by several unresolved global config/manager singletons
			// (_DAT_182e706b8 muzzle-range config, _DAT_182e2bc20 level/scene holder,
			// layer-mask globals). None of these can be mapped to verified project
			// members, so this is left as a stub rather than inventing them.
			return false;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__10))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__10(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__11))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__11(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		public override int GetHeadNumber()
		{
			// headObj @0x128: one head when the head object is active, else none.
			if (headObj == null)
			{
				return 0;
			}
			return headObj.activeSelf ? 1 : 0;
		}
	}
}
