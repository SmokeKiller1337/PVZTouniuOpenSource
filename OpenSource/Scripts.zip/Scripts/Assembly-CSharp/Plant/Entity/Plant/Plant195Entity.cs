using System;
using System.Collections;
using System.Collections.Generic;
using Level.Util;

namespace Plant.Entity.Plant
{
	public class Plant195Entity : Plant190Entity
	{
		private PlantEntity _targetPlantEntity;

		public override bool IsSpecialAvailable()
		{
			// Special is available only if the base cooldown check passes AND there is a
			// (master) plant occupying the land slot immediately to the right of this one.
			if (!base.IsSpecialAvailable())
			{
				return false;
			}
			if (CurrentLandEntity == null)
			{
				return false;
			}
			PlantEntity neighbour = LevelUtils.GetLandPlant(CurrentLandEntity.rowId, CurrentLandEntity.columnId + 1);
			return neighbour != null;
		}

		public override void UseSpecialSkill()
		{
			base.UseSpecialSkill();
			if (CurrentLandEntity == null)
			{
				return;
			}
			PlantEntity neighbour = LevelUtils.GetLandPlant(CurrentLandEntity.rowId, CurrentLandEntity.columnId + 1);
			if (neighbour == null)
			{
				return;
			}
			StartCoroutine(SkillCoroutine(neighbour));
		}

		private IEnumerator SkillCoroutine(PlantEntity plantEntity)
		{
			// 技能协程当前不执行任何逐帧逻辑，立即结束。
			yield break;
		}

		public override void Death()
		{
			base.Death();
			// When this plant dies, also clear the neighbour it had absorbed (if any).
			if (_targetPlantEntity != null)
			{
				_targetPlantEntity.Clear();
			}
		}
	}
}
