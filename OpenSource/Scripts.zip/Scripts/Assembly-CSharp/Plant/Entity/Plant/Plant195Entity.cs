using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Level.Util;

namespace Plant.Entity.Plant
{
	public class Plant195Entity : Plant190Entity
	{
		[CompilerGenerated]
		private sealed class _003CSkillCoroutine_003Ed__3 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant195Entity _003C_003E4__this;

			public PlantEntity plantEntity;

			private int _003Cattack_003E5__2;

			private float _003CattackSpeed_003E5__3;

			private float _003Chealth_003E5__4;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CSkillCoroutine_003Ed__3(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct - the original state machine (@RVA 0x5c9840) transfers a
				// scaled copy of the absorbed neighbour plant's stats onto this plant and then
				// Clear()s the neighbour. Its numeric core cannot be reliably reconstructed:
				//   * the scale factor comes from Game.Util.GameUtils.Map(...) whose first
				//     argument is a mistyped CardBaseAttr pointer in the decompiler output,
				//     so the real value/range arguments are unknown;
				//   * the attack / attackSpeed / health clamp thresholds and multipliers are
				//     all unresolved data globals (_DAT_18252cb30 / _DAT_18252ce84 /
				//     _DAT_18252cb44 / _DAT_18252cb64 / _DAT_18252cd00 / _DAT_18252ce20 / ...);
				//   * the state-1 sound playback reads an AudioClip from an unidentified
				//     assets-manager field (FUN_180417a60 + 0x60).
				// Reconstructing any of these would require inventing values / members, so the
				// coroutine body is left as an empty (immediately-completing) state machine.
				_003C_003E1__state = -1;
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		private PlantEntity _targetPlantEntity;

		public override bool IsSpecialAvailable()
		{
			// Special is available only if the base cooldown check passes AND there is a
			// (master) plant occupying the land slot immediately to the right of this one.
			if (!base.IsSpecialAvailable())
			{
				return false;
			}
			if (CurrentLandEntity == null)
			{
				return false;
			}
			PlantEntity neighbour = LevelUtils.GetLandPlant(CurrentLandEntity.rowId, CurrentLandEntity.columnId + 1);
			return neighbour != null;
		}

		public override void UseSpecialSkill()
		{
			base.UseSpecialSkill();
			if (CurrentLandEntity == null)
			{
				return;
			}
			PlantEntity neighbour = LevelUtils.GetLandPlant(CurrentLandEntity.rowId, CurrentLandEntity.columnId + 1);
			if (neighbour == null)
			{
				return;
			}
			StartCoroutine(SkillCoroutine(neighbour));
		}

		[IteratorStateMachine(typeof(_003CSkillCoroutine_003Ed__3))]
		private IEnumerator SkillCoroutine(PlantEntity plantEntity)
		{
			return new _003CSkillCoroutine_003Ed__3(0)
			{
				_003C_003E4__this = this,
				plantEntity = plantEntity
			};
		}

		public override void Death()
		{
			base.Death();
			// When this plant dies, also clear the neighbour it had absorbed (if any).
			if (_targetPlantEntity != null)
			{
				_targetPlantEntity.Clear();
			}
		}
	}
}
