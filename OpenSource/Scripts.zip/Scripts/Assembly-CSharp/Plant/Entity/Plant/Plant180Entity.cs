using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Entity;
using Game.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant180Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__15 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant180Entity _003C_003E4__this;

			private float _003CanimatorSpeed_003E5__2;

			private Vector2 _003CtargetPosition_003E5__3;

			private Vector2 _003Cposition_003E5__4;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__15(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct - the pseudocode state machine drives a multi-step
				// "look then slam" attack animation: it reads _animator.speed, plays
				// unresolved animation-state names, plays lookSound / downSound via
				// AudioManager, and animates the plant with DG.Tweening DOMove /
				// DOLocalMoveY tweens keyed off _targetCollider2D's position. The
				// animation-state targets are data pointers that could not be resolved
				// to literals and the tween library is not referenced elsewhere in the
				// reconstructed sources, so the body is left as a no-op to avoid
				// fabricating members / unresolved globals.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CExplosion_003Ed__16 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant180Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CExplosion_003Ed__16(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct - the pseudocode plays the explosion sound via
				// AudioManager, runs one or two DamageUtils.Explosion passes over a
				// LayerMask.GetMask(...) of unresolved layer names, fires a Cinemachine
				// impulse (screen shake), and spawns explosion / dust EffectEntity via
				// GameUtils.CreateEffect. It also gates a secondary water-explosion on
				// BaseBody.IsInWater and yields WaitForSeconds between passes. The
				// explosion radius, layer names, impulse config and effect selection are
				// data pointers / globals that could not be resolved, so the body is
				// left as a no-op to avoid fabricating members / unresolved globals.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__19 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant180Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__19(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// Reconstructed from the pseudocode: on first step it stores the passed
				// StrengthenEntity into the plant's _currentPowerEntity (field @0x150)
				// and completes immediately (no yield). The nested type can reach the
				// enclosing plant's private field.
				Plant180Entity plant = _003C_003E4__this;
				if (_003C_003E1__state == 0)
				{
					_003C_003E1__state = -1;
					plant._currentPowerEntity = entity;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__20 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant180Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__20(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// Reconstructed from the pseudocode: on first step, if the plant has a
				// card slot, subtract the card attr's live cooldown timer from itself
				// (an obfuscated "reset the card cooldown timer to zero"), then complete
				// immediately (no yield). All referenced members are confirmed public:
				// PlantEntity.IsHasCardSlot / CardEntity, CardEntity.attr (CardBaseAttr),
				// CardBaseAttr.cooldownTimer (field @0x18).
				Plant180Entity plant = _003C_003E4__this;
				if (_003C_003E1__state == 0)
				{
					_003C_003E1__state = -1;
					if (plant != null && plant.IsHasCardSlot)
					{
						CardEntity card = plant.CardEntity;
						if (card != null && card.attr != null)
						{
							float timer = card.attr.cooldownTimer;
							CardEntity card2 = plant.CardEntity;
							if (card2 != null && card2.attr != null)
							{
								card.attr.cooldownTimer = timer - card2.attr.cooldownTimer;
							}
						}
					}
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("看音效")]
		public AudioClip lookSound;

		[Tooltip("砸下音效")]
		public AudioClip downSound;

		[Tooltip("灰尘特效")]
		public EffectEntity dustEffect;

		[Tooltip("爆炸效果")]
		public EffectEntity explosionEffect;

		public Action<List<BaseBody>> OnExplosionAction;

		private bool _isLook;

		private StrengthenEntity _currentPowerEntity;

		private Collider2D _targetCollider2D;

		public override void Reset()
		{
			// base.Reset() runs the PlantEntity reset (rebuild attrs, sleep, health, ...).
			base.Reset();
			// param_1[0x29] (offset 0x148) = _isLook, cleared on reset.
			_isLook = false;
			// TODO: reconstruct - when this plant has a card slot whose power is
			// available (CardEntity.IsAvailablePower()), the pseudocode then invokes a
			// virtual slot on this instance (vtable +0x478). The exact virtual method
			// behind that slot could not be resolved from the dump, so that follow-up
			// call is omitted rather than guessed.
		}

		protected override void Start()
		{
			// TODO: reconstruct - the pseudocode skips PlantEntity.Start and calls
			// BaseBody.Start directly, then subscribes a compiler-generated OnLevelUp
			// handler onto CardEntity.OnLevelUp and calls CurrentLandEntity.ResetShowHealth().
			// The handler is a private compiler-generated method that does not exist on
			// this class, and directly invoking the grand-base BaseBody.Start (skipping
			// PlantEntity.Start) is not expressible via base.Start(); left as a stub to
			// avoid fabricating members / altering the virtual dispatch.
		}

		public override void Death()
		{
			// TODO: reconstruct - the pseudocode invokes an unresolved virtual slot on
			// this instance (vtable +0x288) before clearing the land and destroying the
			// GameObject. That extra virtual call could not be mapped to a concrete
			// method, so the whole override is left as a stub rather than guessing.
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// The binary folds this body (RVA 0x3D9020) onto the shared empty method,
			// so the override is intentionally empty (matches the empty virtual base).
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			// base.OnLevelUp2 is empty; the folded ctor call in the pseudocode is that
			// no-op base invocation.
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (attr == null || defaultAttr == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// attack += (int)(defaultAttr.attack * strengthenValue)
				float value = entity.GetValue(this);
				attr.attack = (int)((float)defaultAttr.attack * value) + attr.attack;
			}
			else if (entity.index == 1)
			{
				// AttackSpeed = strengthenValue
				attr.AttackSpeed = entity.GetValue(this);
			}
		}

		public void AttackTarget(Collider2D targetCollider2D)
		{
			// Only latch a real target; the pseudocode guards on a Unity null-inequality.
			if (targetCollider2D != null)
			{
				// param_1[0x2b] (offset 0x158) = _targetCollider2D
				_targetCollider2D = targetCollider2D;
				// TODO: reconstruct - the pseudocode then invokes an unresolved virtual
				// slot on this instance (vtable +0x428), most plausibly kicking off the
				// attack sequence. The exact virtual method could not be resolved from
				// the dump, so that follow-up call is omitted rather than guessed.
			}
		}

		protected override void Attack()
		{
			// base.Attack() plays the base attack animation (the folded Plant130Entity
			// name in the pseudocode is ICF noise; it resolves to the virtual base).
			base.Attack();
			// Then run this plant's dedicated attack coroutine.
			StartCoroutine(AttackCoroutine());
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__15))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__15(0)
			{
				_003C_003E4__this = this
			};
		}

		[IteratorStateMachine(typeof(_003CExplosion_003Ed__16))]
		private IEnumerator Explosion()
		{
			return new _003CExplosion_003Ed__16(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			// While in the "look" phase this plant does not (re)acquire targets.
			if (_isLook)
			{
				return false;
			}
			// Cache the current front zombie collider and report whether one exists.
			_targetCollider2D = GetTargetZombieCollider2D();
			return _targetCollider2D != null;
		}

		private Collider2D GetTargetZombieCollider2D()
		{
			// TODO: reconstruct - the pseudocode raycasts from the plant towards the
			// house/zombie side, clamped by an attack-range value from the plant attr,
			// using Physics2D.RaycastAll against a LayerMask.GetMask(...) of unresolved
			// layer names. It walks the hits looking for a BaseBody (via GetComponent)
			// that reports "not in water" and returns that hit's collider. The scan
			// direction/range come from a global board-config singleton and the layer
			// names are data pointers that could not be resolved, so this is left as a
			// stub returning no target rather than fabricating members / globals.
			return null;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__19))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__19(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__20))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__20(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
