using System;
using System.Collections;
using System.Collections.Generic;
using Common.Entity;
using Game.Entity;
using Strengthen.Entity;
using UnityEngine;

namespace Plant.Entity.Plant
{
	public class Plant180Entity : PlantEntity
	{
		[Tooltip("看音效")]
		public AudioClip lookSound;

		[Tooltip("砸下音效")]
		public AudioClip downSound;

		[Tooltip("灰尘特效")]
		public EffectEntity dustEffect;

		[Tooltip("爆炸效果")]
		public EffectEntity explosionEffect;

		public Action<List<BaseBody>> OnExplosionAction;

		private bool _isLook;

		private StrengthenEntity _currentPowerEntity;

		private Collider2D _targetCollider2D;

		public override void Reset()
		{
			base.Reset();
			// 重置时清除观察状态
			_isLook = false;
		}

		protected override void Start()
		{
		}

		public override void Death()
		{
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			base.OnLevelUp2(entity);
			if (entity == null)
			{
				return;
			}
			if (attr == null || defaultAttr == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// 按强化系数增加攻击力
				float value = entity.GetValue(this);
				attr.attack = (int)((float)defaultAttr.attack * value) + attr.attack;
			}
			else if (entity.index == 1)
			{
				// 直接设置攻击速度
				attr.AttackSpeed = entity.GetValue(this);
			}
		}

		public void AttackTarget(Collider2D targetCollider2D)
		{
			if (targetCollider2D != null)
			{
				_targetCollider2D = targetCollider2D;
			}
		}

		protected override void Attack()
		{
			base.Attack();
			// 执行本植物专属的攻击协程
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			yield break;
		}

		private IEnumerator Explosion()
		{
			yield break;
		}

		protected override bool CheckAttack()
		{
			// 处于观察阶段时不再重新锁定目标
			if (_isLook)
			{
				return false;
			}
			// 缓存当前最前方的僵尸碰撞体并返回是否存在
			_targetCollider2D = GetTargetZombieCollider2D();
			return _targetCollider2D != null;
		}

		private Collider2D GetTargetZombieCollider2D()
		{
			return null;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 记录当前生效的强化实体
			_currentPowerEntity = entity;
			yield break;
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			// 抵消卡槽的冷却时间
			if (IsHasCardSlot)
			{
				CardEntity card = CardEntity;
				if (card != null && card.attr != null)
				{
					float timer = card.attr.cooldownTimer;
					CardEntity card2 = CardEntity;
					if (card2 != null && card2.attr != null)
					{
						card.attr.cooldownTimer = timer - card2.attr.cooldownTimer;
					}
				}
			}
			yield break;
		}
	}
}
