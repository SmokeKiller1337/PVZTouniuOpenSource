using System;
using System.Collections;
using System.Collections.Generic;
using Common.Entity;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant145Entity : PlantEntity
	{
		[Tooltip("子弹位置")]
		public Transform bulletPosition;

		[Tooltip("是否衰减攻速")]
		public bool isAttackSpeedReduce;

		[Tooltip("停止攻速")]
		public float stopAttackSpeed;

		private bool _isFlinch;

		private float _flinchTime;

		private float _flinchTimer;

		private List<ZombieEntity> _flinchZombieList;

		private bool _strengthen30Flag;

		private int _strengthen31Number;

		public override void Reset()
		{
			base.Reset();
			_isFlinch = false;
		}

		protected override void Update()
		{
			if (partEntity == null)
			{
				return;
			}
			if (partEntity.isSleeping)
			{
				return;
			}
			// 计时累加到达受击检测间隔后启动检测协程
			_flinchTimer += Time.deltaTime;
			if (_flinchTimer >= _flinchTime && _flinchTimer != _flinchTime)
			{
				_flinchTimer = 0f;
				StartCoroutine(CheckFlinch());
			}
			base.Update();
		}

		private IEnumerator CheckFlinch()
		{
			// 清空当前受击僵尸列表
			if (this != null && _flinchZombieList != null)
			{
				_flinchZombieList.Clear();
			}
			yield break;
		}

		protected override IEnumerator ChangeSleepStateCoroutine()
		{
			if (this != null)
			{
				yield return null;
				if (this == null)
				{
					yield break;
				}
				if (!_isFlinch)
				{
					yield break;
				}
				// 根据睡眠状态播放对应的待机动画
				if (partEntity != null && _animator != null)
				{
					if (!partEntity.isSleeping)
					{
						_animator.Play("AwakeIdle");
					}
					else
					{
						_animator.Play("SleepIdle");
					}
				}
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			// 依据 index 选择要强化的属性
			if (entity.index == 0)
			{
				// 强化攻击力
				if (attr == null || defaultAttr == null)
				{
					return;
				}
				int baseAttack = attr.attack;
				int defAttack = defaultAttr.attack;
				float ratio = entity.GetValue(this, 0);
				attr.attack = (int)((float)defAttack * ratio) + baseAttack;
			}
			else if (entity.index == 1)
			{
				// 强化攻速
				if (attr == null || defaultAttr == null)
				{
					return;
				}
				float ratio = entity.GetValue(this, 0);
				attr.AttackSpeed = ratio * defaultAttr.attackSpeed + attr.attackSpeed;
			}
		}

		protected override void Attack()
		{
			if (attr == null || _animator == null)
			{
				return;
			}
			_animator.SetFloat(AttackSpeedParam, attr.attackSpeed * AttackSpeedAnimScale);
			// 启动攻击协程（开火并处理攻速衰减）
			StartCoroutine(AttackCoroutine());
		}

		private const string AttackSpeedParam = "AttackSpeed";
		private const float AttackSpeedAnimScale = 1f;

		private IEnumerator AttackCoroutine()
		{
			// 播放攻击动画并等待攻击间隔后开火
			if (this != null && _animator != null)
			{
				_animator.Play("Attack");
				if (attr != null)
				{
					float wait = attr.attackIntervalTime * 1f;
					yield return new WaitForSeconds(wait);
					if (this == null || bulletPosition == null)
					{
						yield break;
					}
					// 从枪口位置生成子弹
					Vector2 muzzle = bulletPosition.position;
					CreateBullet(0, muzzle);
					if (!isAttackSpeedReduce)
					{
						yield break;
					}
					PlantBaseAttr a = attr;
					if (a == null)
					{
						yield break;
					}
					// 攻速逐级衰减
					float speed = a.attackSpeed;
					if (speed > 0f)
					{
						a.AttackSpeed = speed - 0f;
					}
					else if (speed > 0f)
					{
						a.AttackSpeed = speed - 0f;
					}
					else if (speed > 0f)
					{
						a.AttackSpeed = speed - 0f;
					}
					else if (speed > stopAttackSpeed && speed != stopAttackSpeed)
					{
						a.AttackSpeed = speed - 0f;
					}
				}
			}
		}

		protected override bool CheckAttack()
		{
			// 受击硬直时不能攻击
			return !_isFlinch;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			if (this == null)
			{
				yield break;
			}
			_strengthen30Flag = true;
			// 处于受击硬直时逐帧等待，直到硬直结束
			while (_isFlinch)
			{
				yield return null;
				if (this == null)
				{
					yield break;
				}
			}
			int i = 0;
			// 按强化数值重复触发额外攻击
			while (true)
			{
				if (entity == null)
				{
					yield break;
				}
				int count = (int)entity.GetValue(this, 0);
				if (i >= count)
				{
					_strengthen30Flag = false;
					yield break;
				}
				yield return new WaitForSeconds(0f);
				if (this == null)
				{
					yield break;
				}
				StartCoroutine(AttackCoroutine());
				i++;
			}
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			if (this == null || attr == null || defaultAttr == null)
			{
				yield break;
			}
			if (entity == null)
			{
				yield break;
			}
			// 按默认攻速比例叠加攻速并记录强化标签
			float ratio = entity.GetValue(this, 0);
			attr.AttackSpeed = ratio * defaultAttr.attackSpeed + attr.attackSpeed;
			attr.AddLabel(entity.title, 1, entity.GetDesc(this));
			_strengthen31Number++;
		}
	}
}
