using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Common.Entity;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant145Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__16 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant145Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__16(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant145Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (plant != null && plant._animator != null)
					{
						// Play the attack animation, then wait for the shot delay.
						// TODO: attack animation state name is a data pointer in the pseudocode.
						plant._animator.Play(AttackShootAnimName);
						if (plant.attr != null)
						{
							// attr.attackIntervalTime (0x2c) scaled by an unresolved global factor.
							float wait = plant.attr.attackIntervalTime * AttackWaitFactor;
							_003C_003E2__current = new WaitForSeconds(wait);
							_003C_003E1__state = 1;
							return true;
						}
					}
					return false;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null || plant.bulletPosition == null)
				{
					return false;
				}
				// Fire the bullet from the muzzle transform.
				Vector2 muzzle = plant.bulletPosition.position;
				plant.CreateBullet(0, muzzle);
				if (!plant.isAttackSpeedReduce)
				{
					return false;
				}
				PlantBaseAttr a = plant.attr;
				if (a == null)
				{
					return false;
				}
				// Progressive attack-speed decay: subtract a step sized by the current
				// speed tier, but never below stopAttackSpeed.
				// TODO: the four tier thresholds / decrement steps below are unresolved
				// globals in the pseudocode; placeholder constants are used.
				float speed = a.attackSpeed;
				if (speed > AttackSpeedTier1)
				{
					a.AttackSpeed = speed - AttackSpeedStep1;
				}
				else if (speed > AttackSpeedTier2)
				{
					a.AttackSpeed = speed - AttackSpeedStep2;
				}
				else if (speed > AttackSpeedTier3)
				{
					a.AttackSpeed = speed - AttackSpeedStep3;
				}
				else if (speed > plant.stopAttackSpeed && speed != plant.stopAttackSpeed)
				{
					a.AttackSpeed = speed - AttackSpeedStep4;
				}
				// Once the plant has decayed down to its stop speed, the original code
				// popped a floating value indicator via GameManager's value-box layer.
				// TODO: reconstruct - that manager member (ValueBoxLayer) does not exist
				// in the project, so the visual spawn is dropped here.
				return false;
			}

			// TODO: unresolved literals used by the attack coroutine.
			private const string AttackShootAnimName = "Attack"; // TODO: reconstruct literal
			private const float AttackWaitFactor = 1f; // TODO: reconstruct constant
			private const float AttackSpeedTier1 = 0f; // TODO: reconstruct constant
			private const float AttackSpeedTier2 = 0f; // TODO: reconstruct constant
			private const float AttackSpeedTier3 = 0f; // TODO: reconstruct constant
			private const float AttackSpeedStep1 = 0f; // TODO: reconstruct constant
			private const float AttackSpeedStep2 = 0f; // TODO: reconstruct constant
			private const float AttackSpeedStep3 = 0f; // TODO: reconstruct constant
			private const float AttackSpeedStep4 = 0f; // TODO: reconstruct constant

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CChangeSleepStateCoroutine_003Ed__12 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant145Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CChangeSleepStateCoroutine_003Ed__12(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant145Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (plant != null)
					{
						// The pseudocode yields the base ChangeSleepStateCoroutine here (via
						// the compiler <>n__0 forwarder) before refreshing the idle animation.
						// Reaching the outer instance's base method from this nested state
						// machine is not expressible without adding members, so we yield one
						// frame (the base coroutine's first action) instead.
						// TODO: chain base.ChangeSleepStateCoroutine() for full fidelity.
						_003C_003E2__current = null;
						_003C_003E1__state = 1;
						return true;
					}
					return false;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant == null)
				{
					return false;
				}
				// _isFlinch (0x130) gates the idle refresh.
				if (!plant._isFlinch)
				{
					return false;
				}
				if (plant.partEntity != null && plant._animator != null)
				{
					// partEntity.isSleeping (0x15) selects awake vs sleep idle.
					if (!plant.partEntity.isSleeping)
					{
						// TODO: awake / sleep idle animation state names are data pointers
						// in the pseudocode; placeholder literals are used.
						plant._animator.Play(AwakeIdleAnimName);
					}
					else
					{
						plant._animator.Play(SleepIdleAnimName);
					}
				}
				return false;
			}

			// TODO: unresolved animation state literals.
			private const string AwakeIdleAnimName = "AwakeIdle"; // TODO: reconstruct literal
			private const string SleepIdleAnimName = "SleepIdle"; // TODO: reconstruct literal

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CCheckFlinch_003Ed__11 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant145Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CCheckFlinch_003Ed__11(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct - the pseudocode for this coroutine is dominated by
				// unresolved external state:
				//   * a Physics2D.OverlapCircleAll scan whose radius / LayerMask.GetMask
				//     layer name are unnamed data-pointer globals,
				//   * GetComponent<...> / type-check pointers that cannot be resolved to a
				//     named component type, and
				//   * animator state-name data pointers for the flinch / recover animations.
				// The only fully named operations are clearing _flinchZombieList and toggling
				// _isFlinch; reconstructing the rest would require inventing members, which is
				// forbidden. Left as a faithful no-op state machine.
				int num = _003C_003E1__state;
				Plant145Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (plant != null && plant._flinchZombieList != null)
					{
						plant._flinchZombieList.Clear();
					}
					return false;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plant != null)
				{
					plant._isFlinch = false;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__18 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant145Entity _003C_003E4__this;

			public StrengthenEntity entity;

			private int _003Ci_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__18(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant145Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (plant == null)
					{
						return false;
					}
					// _strengthen30Flag (0x148) = true
					plant._strengthen30Flag = true;
				}
				else if (num == 1)
				{
					_003C_003E1__state = -1;
					if (plant == null)
					{
						return false;
					}
				}
				else
				{
					if (num != 2)
					{
						return false;
					}
					_003C_003E1__state = -1;
					if (plant == null)
					{
						return false;
					}
					// Trigger one extra attack burst, then count it.
					plant.StartCoroutine(plant.AttackCoroutine());
					_003Ci_003E5__2++;
				}
				// While the plant is flinching, wait a frame and re-check.
				if (num == 0 || num == 1)
				{
					if (plant._isFlinch)
					{
						_003C_003E2__current = null;
						_003C_003E1__state = 1;
						return true;
					}
					_003Ci_003E5__2 = 0;
				}
				if (entity == null)
				{
					return false;
				}
				// Repeat the burst GetValue(entity) times.
				int count = (int)entity.GetValue(plant, 0);
				if (_003Ci_003E5__2 >= count)
				{
					plant._strengthen30Flag = false;
					return false;
				}
				// TODO: per-burst interval is an unresolved global constant.
				_003C_003E2__current = new WaitForSeconds(BurstInterval);
				_003C_003E1__state = 2;
				return true;
			}

			// TODO: unresolved interval constant between attack bursts.
			private const float BurstInterval = 0f; // TODO: reconstruct constant

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__19 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant145Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__19(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				if (_003C_003E1__state != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				Plant145Entity plant = _003C_003E4__this;
				if (plant == null || plant.attr == null || plant.defaultAttr == null)
				{
					return false;
				}
				if (entity == null)
				{
					return false;
				}
				// attr.AttackSpeed = GetValue(entity) * defaultAttr.attackSpeed + attr.attackSpeed
				float ratio = entity.GetValue(plant, 0);
				plant.attr.AttackSpeed = ratio * plant.defaultAttr.attackSpeed + plant.attr.attackSpeed;
				// Add a label describing the buff, then bump the strengthen counter.
				plant.attr.AddLabel(entity.title, 1, entity.GetDesc(plant));
				plant._strengthen31Number++;
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("子弹位置")]
		public Transform bulletPosition;

		[Tooltip("是否衰减攻速")]
		public bool isAttackSpeedReduce;

		[Tooltip("停止攻速")]
		public float stopAttackSpeed;

		private bool _isFlinch;

		private float _flinchTime;

		private float _flinchTimer;

		private List<ZombieEntity> _flinchZombieList;

		private bool _strengthen30Flag;

		private int _strengthen31Number;

		public override void Reset()
		{
			base.Reset();
			// _isFlinch (0x130) = false
			_isFlinch = false;
		}

		protected override void Update()
		{
			if (partEntity == null)
			{
				return;
			}
			// Skip while sleeping (partEntity.isSleeping @0x15).
			if (partEntity.isSleeping)
			{
				return;
			}
			// _flinchTimer (0x138) accumulates until it reaches _flinchTime (0x134),
			// then a flinch check coroutine is launched.
			_flinchTimer += Time.deltaTime;
			if (_flinchTimer >= _flinchTime && _flinchTimer != _flinchTime)
			{
				_flinchTimer = 0f;
				StartCoroutine(CheckFlinch());
			}
			// The base Update (attack-interval tick + eye update + special cooldown) is
			// inlined by the compiler in the pseudocode; call it directly here.
			base.Update();
		}

		[IteratorStateMachine(typeof(_003CCheckFlinch_003Ed__11))]
		private IEnumerator CheckFlinch()
		{
			return new _003CCheckFlinch_003Ed__11(0)
			{
				_003C_003E4__this = this
			};
		}

		[IteratorStateMachine(typeof(_003CChangeSleepStateCoroutine_003Ed__12))]
		protected override IEnumerator ChangeSleepStateCoroutine()
		{
			return new _003CChangeSleepStateCoroutine_003Ed__12(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			// index (0x10) selects which stat to boost.
			if (entity.index == 0)
			{
				// attack boost: attr.attack = (int)(defaultAttr.attack * GetValue) + attr.attack
				if (attr == null || defaultAttr == null)
				{
					return;
				}
				int baseAttack = attr.attack;
				int defAttack = defaultAttr.attack;
				float ratio = entity.GetValue(this, 0);
				attr.attack = (int)((float)defAttack * ratio) + baseAttack;
			}
			else if (entity.index == 1)
			{
				// attack-speed boost handled via AttackSpeed setter.
				if (attr == null || defaultAttr == null)
				{
					return;
				}
				float ratio = entity.GetValue(this, 0);
				attr.AttackSpeed = ratio * defaultAttr.attackSpeed + attr.attackSpeed;
			}
		}

		protected override void Attack()
		{
			if (attr == null || _animator == null)
			{
				return;
			}
			// Set the animator attack-speed float from the current attack speed.
			// TODO: the animator float parameter name and scale factor are unresolved
			// data-pointer / global constants in the pseudocode; placeholders are used.
			_animator.SetFloat(AttackSpeedParam, attr.attackSpeed * AttackSpeedAnimScale);
			// Launch the attack coroutine (bullet fire + attack-speed decay).
			StartCoroutine(AttackCoroutine());
		}

		// TODO: unresolved animator parameter name / scale for Attack.
		private const string AttackSpeedParam = "AttackSpeed"; // TODO: reconstruct literal
		private const float AttackSpeedAnimScale = 1f; // TODO: reconstruct constant

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__16))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__16(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			// _isFlinch (0x130): can only attack when not flinching.
			return !_isFlinch;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__18))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__18(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__19))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__19(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
