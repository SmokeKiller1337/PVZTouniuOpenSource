using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Bullet.Entity;
using Common.Entity;
using Level.Util;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant440Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__6 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant440Entity _003C_003E4__this;

			private int _003CbulletIndex_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__6(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant440Entity plant = _003C_003E4__this;
				switch (num)
				{
				case 0:
					_003C_003E1__state = -1;
					// The bullet index depends on whether a balloon row is present.
					_003CbulletIndex_003E5__2 = (plant.IsHasBalloonRow(-1) ? 1 : 0);
					if (plant._animator != null)
					{
						// TODO: reconstruct — the attack animation state name is a data
						// pointer in the pseudocode that could not be resolved to a literal.
						plant._animator.Play(AttackAnimName);
						if (plant.attr != null)
						{
							// Wait attackIntervalTime scaled by an unresolved global factor
							// before firing the first bullet.
							_003C_003E2__current = new WaitForSeconds(plant.attr.attackIntervalTime * PreFireDelayFactor);
							_003C_003E1__state = 1;
							return true;
						}
					}
					return false;
				case 1:
					_003C_003E1__state = -1;
					if (plant.bulletPosition != null)
					{
						BulletEntity bullet = plant.CreateBullet(_003CbulletIndex_003E5__2, plant.bulletPosition.position);
						if (bullet != null)
						{
							BulletEntity comp = bullet.GetComponent<BulletEntity>();
							if (comp != null)
							{
								// TODO: reconstruct — the pseudocode sets an unnamed bool at
								// offset 0x30 on the spawned bullet's BulletEntity here; the
								// member name is not present in the skeleton, so the write is
								// dropped.
								if (plant.attr != null)
								{
									_003C_003E2__current = new WaitForSeconds(plant.attr.attackIntervalTime * PostFireDelayFactor);
									_003C_003E1__state = 2;
									return true;
								}
							}
						}
					}
					return false;
				case 2:
					_003C_003E1__state = -1;
					if (plant.bulletPosition != null)
					{
						BulletEntity bullet = plant.CreateBullet(_003CbulletIndex_003E5__2, plant.bulletPosition.position);
						if (bullet != null)
						{
							BulletEntity comp = bullet.GetComponent<BulletEntity>();
							if (comp != null)
							{
								// TODO: reconstruct — unnamed bool at offset 0x30 on the bullet
								// (see state 1); dropped.
							}
						}
					}
					return false;
				default:
					return false;
				}
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__9 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant440Entity _003C_003E4__this;

			public StrengthenEntity entity;

			private int _003Ci_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__9(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant440Entity plant = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					_003Ci_003E5__2 = 0;
				}
				else
				{
					if (num != 1)
					{
						return false;
					}
					_003C_003E1__state = -1;
					// Fire one more volley and count it.
					plant.StartCoroutine(plant.AttackCoroutine());
					_003Ci_003E5__2++;
				}
				// Repeat firing until the strengthen value's count is reached, waiting a
				// fixed interval (an unresolved global) between volleys.
				if (entity != null && (int)entity.GetValue(plant) > _003Ci_003E5__2)
				{
					_003C_003E2__current = new WaitForSeconds(Power0VolleyInterval);
					_003C_003E1__state = 1;
					return true;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__10 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant440Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__10(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				if (_003C_003E1__state != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				Plant440Entity plant = _003C_003E4__this;
				if (plant != null && plant.attr != null && plant.defaultAttr != null && entity != null)
				{
					// AttackSpeed += strengthenValue * defaultAttr.attackSpeed
					plant.attr.AttackSpeed = entity.GetValue(plant) * plant.defaultAttr.attackSpeed + plant.attr.attackSpeed;
					// Add a descriptive label so the buff shows up in the plant's attr panel.
					plant.attr.AddLabel(entity.title, 1, entity.GetDesc(plant));
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		// TODO: unresolved global constants referenced by the reconstructed bodies below.
		// These are data pointers / _DAT_* globals in the pseudocode whose literal values
		// could not be recovered from the dump.
		private const string AttackAnimName = "Attack"; // TODO: reconstruct literal
		private const float PreFireDelayFactor = 1f; // TODO: reconstruct constant (_DAT_18252cd08)
		private const float PostFireDelayFactor = 1f; // TODO: reconstruct constant (_DAT_18252cd00)
		private const float Power0VolleyInterval = 0f; // TODO: reconstruct constant (_DAT_18252ccfc)

		[Tooltip("子弹位置")]
		public Transform bulletPosition;

		public override void Reset()
		{
			// The decompiled body (ICF-folded onto Plant90Entity.Reset) reimplements the
			// exact card-driven attribute rebuild that PlantEntity.Reset already performs
			// with named members, so it is faithfully expressed by the base implementation.
			base.Reset();
		}

		protected override void Update()
		{
			// ICF-folded onto Plant90Entity.Update; the body matches PlantEntity.Update
			// (sleep gate, attack-interval tick, EyeUpdate, special cooldown) exactly.
			base.Update();
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// The decompiled body is an empty return (folded onto an empty method).
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				if (attr != null && defaultAttr != null)
				{
					// attack += round(defaultAttr.attack * strengthenValue)
					attr.attack = (int)((float)defaultAttr.attack * entity.GetValue(this)) + attr.attack;
				}
			}
			else if (entity.index == 1)
			{
				if (attr != null && defaultAttr != null)
				{
					// AttackSpeed += strengthenValue * defaultAttr.attackSpeed
					attr.AttackSpeed = entity.GetValue(this) * defaultAttr.attackSpeed + attr.attackSpeed;
				}
			}
		}

		protected override void Attack()
		{
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__6))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__6(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			List<ZombieEntity> list = LevelUtils.GetLandEnemyZombieList();
			if (list == null)
			{
				return true;
			}
			// Attack when there is at least one grounded enemy, or when a balloon row exists.
			if (list.Count < 1 && !IsHasBalloonRow(-1))
			{
				return false;
			}
			return true;
		}

		private bool IsHasBalloonRow(int row = -1)
		{
			// TODO: reconstruct — the original filters LevelUtils.GetLandZombieList() with a
			// captured-row predicate that also tests an unnamed "balloon" bool at offset 0x3e
			// on ZombieEntity (via a compiler-generated <>c__DisplayClass8_0 that is not part
			// of the provided skeleton). That member cannot be named from the dump, so the
			// predicate cannot be faithfully rebuilt; stubbed to "no balloon row".
			return false;
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__9))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__9(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__10))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__10(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
