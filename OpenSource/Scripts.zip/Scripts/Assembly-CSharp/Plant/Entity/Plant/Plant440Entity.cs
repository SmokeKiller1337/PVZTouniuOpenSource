using System;
using System.Collections;
using System.Collections.Generic;
using Bullet.Entity;
using Common.Entity;
using Level.Util;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant440Entity : PlantEntity
	{
		private const string AttackAnimName = "Attack";
		private const float PreFireDelayFactor = 1f;
		private const float PostFireDelayFactor = 1f;
		private const float Power0VolleyInterval = 0f;

		[Tooltip("子弹位置")]
		public Transform bulletPosition;

		public override void Reset()
		{
			base.Reset();
		}

		protected override void Update()
		{
			base.Update();
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				if (attr != null && defaultAttr != null)
				{
					// attack += round(defaultAttr.attack * strengthenValue)
					attr.attack = (int)((float)defaultAttr.attack * entity.GetValue(this)) + attr.attack;
				}
			}
			else if (entity.index == 1)
			{
				if (attr != null && defaultAttr != null)
				{
					// AttackSpeed += strengthenValue * defaultAttr.attackSpeed
					attr.AttackSpeed = entity.GetValue(this) * defaultAttr.attackSpeed + attr.attackSpeed;
				}
			}
		}

		protected override void Attack()
		{
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			// 是否存在气球行决定使用哪一种子弹。
			int bulletIndex = (IsHasBalloonRow(-1) ? 1 : 0);
			if (_animator == null)
			{
				yield break;
			}
			_animator.Play(AttackAnimName);
			if (attr == null)
			{
				yield break;
			}
			// 开火前等待一段攻击间隔。
			yield return new WaitForSeconds(attr.attackIntervalTime * PreFireDelayFactor);
			if (bulletPosition == null)
			{
				yield break;
			}
			BulletEntity bullet = CreateBullet(bulletIndex, bulletPosition.position);
			if (bullet == null || bullet.GetComponent<BulletEntity>() == null || attr == null)
			{
				yield break;
			}
			// 两发子弹之间再等待一段攻击间隔。
			yield return new WaitForSeconds(attr.attackIntervalTime * PostFireDelayFactor);
			if (bulletPosition == null)
			{
				yield break;
			}
			BulletEntity bullet2 = CreateBullet(bulletIndex, bulletPosition.position);
			if (bullet2 != null)
			{
				bullet2.GetComponent<BulletEntity>();
			}
		}

		protected override bool CheckAttack()
		{
			List<ZombieEntity> list = LevelUtils.GetLandEnemyZombieList();
			if (list == null)
			{
				return true;
			}
			// Attack when there is at least one grounded enemy, or when a balloon row exists.
			if (list.Count < 1 && !IsHasBalloonRow(-1))
			{
				return false;
			}
			return true;
		}

		private bool IsHasBalloonRow(int row = -1)
		{
			return false;
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 按强化值指定的次数持续开火，每轮之间等待固定间隔。
			int i = 0;
			while (entity != null && (int)entity.GetValue(this) > i)
			{
				yield return new WaitForSeconds(Power0VolleyInterval);
				StartCoroutine(AttackCoroutine());
				i++;
			}
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			if (this != null && attr != null && defaultAttr != null && entity != null)
			{
				// AttackSpeed += strengthenValue * defaultAttr.attackSpeed
				attr.AttackSpeed = entity.GetValue(this) * defaultAttr.attackSpeed + attr.attackSpeed;
				// 在属性面板上加一条描述标签，让增益可见。
				attr.AddLabel(entity.title, 1, entity.GetDesc(this));
			}
			yield break;
		}
	}
}
