using System;
using System.Collections;
using System.Collections.Generic;
using Game.Entity;
using Game.Util;
using Level.Entity;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity.Plant
{
	public class Plant470Entity : PlantEntity
	{
		private const string AttackAnimName = "Attack";
		private const float SpikeStrikeInterval = 0f;
		private const string ZombieTag = "Zombie";
		private const float SpikeHealthThreshold1 = 0.34f;
		private const float SpikeHealthThreshold2 = 0.67f;

		[Tooltip("攻击效果")]
		public EffectEntity attackEffect;

		[Tooltip("尖刺渲染器集合")]
		public List<SpriteRenderer> spikeSpriteRendererList;

		private List<ZombieEntity> _targetList;

		public override void Reset()
		{
			base.Reset();
			if (attr != null)
			{
				attr.isNotPick1 = true;
				if (_targetList != null)
				{
					_targetList.Clear();
				}
			}
		}

		public override void ChangeHealth(float value)
		{
			base.ChangeHealth(value);
			// 随着血量下降，依次隐藏三层尖刺贴图
			if (spikeSpriteRendererList == null || attr == null)
			{
				return;
			}
			if (spikeSpriteRendererList.Count > 0 && spikeSpriteRendererList[0] != null)
			{
				spikeSpriteRendererList[0].enabled = attr.HealthRatio > 0f;
			}
			if (spikeSpriteRendererList.Count > 1 && spikeSpriteRendererList[1] != null)
			{
				spikeSpriteRendererList[1].enabled = attr.HealthRatio > SpikeHealthThreshold1;
			}
			if (spikeSpriteRendererList.Count > 2 && spikeSpriteRendererList[2] != null)
			{
				spikeSpriteRendererList[2].enabled = attr.HealthRatio > SpikeHealthThreshold2;
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// 按 (defaultAttr.attack * value) 叠加攻击力
				if (attr == null)
				{
					return;
				}
				int currentAttack = attr.attack;
				if (defaultAttr == null)
				{
					return;
				}
				int baseAttack = defaultAttr.attack;
				float ratio = entity.GetValue(this, 0);
				attr.attack = (int)((float)baseAttack * ratio) + currentAttack;
			}
			else if (entity.index == 1)
			{
				// 根据强化值设置攻击速度
				if (attr == null || defaultAttr == null)
				{
					return;
				}
				attr.AttackSpeed = entity.GetValue(this, 0);
			}
		}

		protected override void Attack()
		{
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		private IEnumerator AttackCoroutine()
		{
			// 单次尖刺攻击：生成攻击特效，并对所有存活的目标僵尸造成抛物线伤害
			void SpikeStrike()
			{
				if (attackEffect != null && transform != null)
				{
					GameUtils.CreateEffect(attackEffect, transform.position, Quaternion.identity);
				}
				if (_targetList == null)
				{
					return;
				}
				// 复制一份列表，避免命中过程中追踪列表发生变化
				List<ZombieEntity> targets = new List<ZombieEntity>(_targetList);
				foreach (ZombieEntity zombie in targets)
				{
					if (zombie == null || zombie.IsDeath)
					{
						continue;
					}
					if (attr != null)
					{
						zombie.Hit(attr.attack, DamageTypeEntity.Parabolic);
					}
				}
			}

			// 播放尖刺攻击动画，随后等待间隔进行两次打击
			if (_animator != null)
			{
				_animator.Play(AttackAnimName);
				if (attr != null)
				{
					yield return new WaitForSeconds(SpikeStrikeInterval);
					SpikeStrike();
					if (attr != null)
					{
						yield return new WaitForSeconds(SpikeStrikeInterval);
						SpikeStrike();
					}
				}
			}
		}

		protected override bool CheckAttack()
		{
			if (_targetList == null)
			{
				return false;
			}
			// 只要有一个存活僵尸站在尖刺上就进行攻击
			int count = 0;
			foreach (ZombieEntity zombie in _targetList)
			{
				if (zombie != null && !zombie.IsDeath)
				{
					count++;
				}
			}
			return count > 0;
		}

		public override void OnTriggerCustomEnter(Collider2D col, int index)
		{
			base.OnTriggerCustomEnter(col, index);
			if (col == null || col.gameObject == null)
			{
				return;
			}
			if (!gameObject.CompareTag(ZombieTag))
			{
				return;
			}
			ZombieEntity zombie = col.gameObject.GetComponent<ZombieEntity>();
			if (zombie == null || _targetList == null)
			{
				return;
			}
			if (!_targetList.Contains(zombie))
			{
				_targetList.Add(zombie);
			}
		}

		public override void OnTriggerCustomExit(Collider2D col, int index)
		{
			base.OnTriggerCustomExit(col, index);
			if (col == null)
			{
				return;
			}
			ZombieEntity zombie = col.gameObject.GetComponent<ZombieEntity>();
			if (zombie == null || _targetList == null)
			{
				return;
			}
			if (_targetList.Contains(zombie))
			{
				_targetList.Remove(zombie);
			}
		}

		public override void OnTriggerCustomStay(Collider2D col, int index)
		{
			base.OnTriggerCustomStay(col, index);
		}

		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			List<ValueEntity> valueList = new List<ValueEntity>();
			if (entity == null)
			{
				yield break;
			}
			float ratio = entity.GetValue(this, 0);
			if (defaultAttr == null)
			{
				yield break;
			}
			float baseAttackSpeed = defaultAttr.attackSpeed;
			if (defaultAttr == null)
			{
				yield break;
			}
			float duration = entity.GetValue(this, 1);
			ValueEntity valueEntity = new ValueEntity();
			valueEntity.baseValue = baseAttackSpeed * ratio;
			valueList.Add(valueEntity);
			// 施加持续一段时间的攻速加成 buff
			if (BuffHandler != null)
			{
				BuffHandler.AddBuff(10, null, duration, valueList);
			}
		}

		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			if (attr == null)
			{
				yield break;
			}
			int currentAttack = attr.attack;
			if (defaultAttr == null)
			{
				yield break;
			}
			int baseAttack = defaultAttr.attack;
			if (entity == null)
			{
				yield break;
			}
			float ratio = entity.GetValue(this, 0);
			attr.attack = (int)((float)baseAttack * ratio) + currentAttack;
			if (entity == null)
			{
				yield break;
			}
			attr.AddLabel(entity.title, 1, entity.GetDesc(this));
		}
	}
}
