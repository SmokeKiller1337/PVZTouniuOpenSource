using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Game.Entity;
using Game.Util;
using Level.Entity;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

// NOTE: Added `using Game.Util;` (GameUtils.CreateEffect) and `using Level.Entity;`
// (DamageTypeEntity.Parabolic) to the stub's original using set; nothing removed.

namespace Plant.Entity.Plant
{
	public class Plant470Entity : PlantEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttackCoroutine_003Ed__8 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant470Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAttackCoroutine_003Ed__8(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Plant470Entity plant = _003C_003E4__this;
				switch (num)
				{
				default:
					return false;
				case 0:
					_003C_003E1__state = -1;
					// Play the spike attack animation, then wait before the first strike.
					if (plant != null && plant._animator != null)
					{
						// TODO: attack animation state name is a data pointer in the pseudocode.
						plant._animator.Play(AttackAnimName);
						if (plant.attr != null)
						{
							// TODO: wait duration is an unresolved global constant.
							_003C_003E2__current = new WaitForSeconds(SpikeStrikeInterval);
							_003C_003E1__state = 1;
							return true;
						}
					}
					return false;
				case 1:
					_003C_003E1__state = -1;
					SpikeStrike(plant);
					if (plant.attr != null)
					{
						// TODO: wait duration is an unresolved global constant.
						_003C_003E2__current = new WaitForSeconds(SpikeStrikeInterval);
						_003C_003E1__state = 2;
						return true;
					}
					return false;
				case 2:
					_003C_003E1__state = -1;
					SpikeStrike(plant);
					return false;
				}
			}

			// Local helper (kept inside the compiler-generated iterator so no new member is
			// added to Plant470Entity itself): one spike strike — spawn the attack effect and
			// deal parabolic damage to every live tracked zombie. Both strike passes share it.
			private static void SpikeStrike(Plant470Entity plant)
			{
				if (plant == null)
				{
					return;
				}
				if (plant.attackEffect != null && plant.transform != null)
				{
					GameUtils.CreateEffect(plant.attackEffect, plant.transform.position, Quaternion.identity);
				}
				if (plant._targetList == null)
				{
					return;
				}
				// Iterate a copy so the tracking list can change while we hit.
				List<ZombieEntity> targets = new List<ZombieEntity>(plant._targetList);
				foreach (ZombieEntity zombie in targets)
				{
					if (zombie == null || zombie.IsDeath)
					{
						continue;
					}
					if (plant.attr != null)
					{
						zombie.Hit(plant.attr.attack, DamageTypeEntity.Parabolic);
					}
				}
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__13 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public StrengthenEntity entity;

			public Plant470Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__13(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// Single-pass coroutine (no yield points in the pseudocode): applies an
				// attack-speed buff whose value scales with the strengthen entity's value.
				if (_003C_003E1__state != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				Plant470Entity plant = _003C_003E4__this;
				List<ValueEntity> valueList = new List<ValueEntity>();
				if (entity == null)
				{
					return false;
				}
				float ratio = entity.GetValue(plant, 0);
				if (plant == null || plant.defaultAttr == null)
				{
					return false;
				}
				float baseAttackSpeed = plant.defaultAttr.attackSpeed;
				if (plant.defaultAttr == null)
				{
					return false;
				}
				float duration = entity.GetValue(plant, 1);
				ValueEntity valueEntity = new ValueEntity();
				valueEntity.baseValue = baseAttackSpeed * ratio;
				valueList.Add(valueEntity);
				if (plant.BuffHandler != null)
				{
					// TODO: buff id (10) taken from the pseudocode.
					plant.BuffHandler.AddBuff(10, null, duration, valueList);
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__14 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Plant470Entity _003C_003E4__this;

			public StrengthenEntity entity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__14(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// Single-pass coroutine (no yield points in the pseudocode): permanently
				// raises this plant's attack and records the upgrade as an attr label.
				if (_003C_003E1__state != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				Plant470Entity plant = _003C_003E4__this;
				if (plant == null || plant.attr == null)
				{
					return false;
				}
				int currentAttack = plant.attr.attack;
				if (plant.defaultAttr == null)
				{
					return false;
				}
				int baseAttack = plant.defaultAttr.attack;
				if (entity == null)
				{
					return false;
				}
				float ratio = entity.GetValue(plant, 0);
				plant.attr.attack = (int)((float)baseAttack * ratio) + currentAttack;
				if (entity == null)
				{
					return false;
				}
				plant.attr.AddLabel(entity.title, 1, entity.GetDesc(plant));
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		// TODO: unresolved data-pointer literals / constants from the pseudocode.
		private const string AttackAnimName = "Attack"; // TODO: reconstruct literal (animator state name)
		private const float SpikeStrikeInterval = 0f; // TODO: reconstruct constant (WaitForSeconds duration)
		private const string ZombieTag = "Zombie"; // TODO: reconstruct literal (GameObject tag)
		private const float SpikeHealthThreshold1 = 0.34f; // TODO: reconstruct constant (spike renderer 2 health ratio)
		private const float SpikeHealthThreshold2 = 0.67f; // TODO: reconstruct constant (spike renderer 3 health ratio)

		[Tooltip("攻击效果")]
		public EffectEntity attackEffect;

		[Tooltip("尖刺渲染器集合")]
		public List<SpriteRenderer> spikeSpriteRendererList;

		private List<ZombieEntity> _targetList;

		public override void Reset()
		{
			base.Reset();
			if (attr != null)
			{
				// Spikeweeds cannot be picked up while planted.
				attr.isNotPick1 = true;
				if (_targetList != null)
				{
					_targetList.Clear();
				}
				// TODO: reconstruct — the pseudocode then played an idle/reset animation on
				// _animator via Animator.Play(hash, -1, ...); the state name is a data pointer
				// and could not be resolved, so the animator reset call is dropped here.
			}
		}

		public override void ChangeHealth(float value)
		{
			base.ChangeHealth(value);
			// Toggle the three spike sprites on/off as the plant's health drops.
			if (spikeSpriteRendererList == null || attr == null)
			{
				return;
			}
			if (spikeSpriteRendererList.Count > 0 && spikeSpriteRendererList[0] != null)
			{
				spikeSpriteRendererList[0].enabled = attr.HealthRatio > 0f;
			}
			if (spikeSpriteRendererList.Count > 1 && spikeSpriteRendererList[1] != null)
			{
				spikeSpriteRendererList[1].enabled = attr.HealthRatio > SpikeHealthThreshold1;
			}
			if (spikeSpriteRendererList.Count > 2 && spikeSpriteRendererList[2] != null)
			{
				spikeSpriteRendererList[2].enabled = attr.HealthRatio > SpikeHealthThreshold2;
			}
		}

		protected override void OnLevelUp(StrengthenEntity entity)
		{
			// Intentionally empty: the pseudocode body is ICF-folded onto an empty return.
		}

		protected override void OnLevelUp2(StrengthenEntity entity)
		{
			if (entity == null)
			{
				return;
			}
			if (entity.index == 0)
			{
				// Additively scale attack by (defaultAttr.attack * value).
				if (attr == null)
				{
					return;
				}
				int currentAttack = attr.attack;
				if (defaultAttr == null)
				{
					return;
				}
				int baseAttack = defaultAttr.attack;
				float ratio = entity.GetValue(this, 0);
				attr.attack = (int)((float)baseAttack * ratio) + currentAttack;
			}
			else if (entity.index == 1)
			{
				// Set attack speed from the strengthen value.
				if (attr == null || defaultAttr == null)
				{
					return;
				}
				attr.AttackSpeed = entity.GetValue(this, 0);
			}
		}

		protected override void Attack()
		{
			base.Attack();
			StartCoroutine(AttackCoroutine());
		}

		[IteratorStateMachine(typeof(_003CAttackCoroutine_003Ed__8))]
		private IEnumerator AttackCoroutine()
		{
			return new _003CAttackCoroutine_003Ed__8(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override bool CheckAttack()
		{
			if (_targetList == null)
			{
				return false;
			}
			// Attack when at least one live zombie is standing on the spikes.
			int count = 0;
			foreach (ZombieEntity zombie in _targetList)
			{
				// TODO: the pseudocode gated each target on a bool at zombie offset 0x1b1
				// whose member name is not in the skeleton; the live-target filter below
				// approximates it with the named IsDeath flag.
				if (zombie != null && !zombie.IsDeath)
				{
					count++;
				}
			}
			return count > 0;
		}

		public override void OnTriggerCustomEnter(Collider2D col, int index)
		{
			base.OnTriggerCustomEnter(col, index);
			if (col == null || col.gameObject == null)
			{
				return;
			}
			// TODO: the compared tag is a data pointer in the pseudocode; ZombieTag is a placeholder.
			if (!gameObject.CompareTag(ZombieTag))
			{
				return;
			}
			ZombieEntity zombie = col.gameObject.GetComponent<ZombieEntity>();
			if (zombie == null || _targetList == null)
			{
				return;
			}
			if (!_targetList.Contains(zombie))
			{
				_targetList.Add(zombie);
				// TODO: reconstruct — on first contact the pseudocode immediately popped a
				// Zombie120Entity's tires (Zombie120Entity.WheelieAttack) and applied this
				// plant's damage through an unresolved virtual slot (0x238), guarded by
				// several unnamed zombie offsets. That immediate-hit path is dropped here to
				// avoid fabricating those members; per-frame damage is handled elsewhere.
			}
		}

		public override void OnTriggerCustomExit(Collider2D col, int index)
		{
			base.OnTriggerCustomExit(col, index);
			if (col == null)
			{
				return;
			}
			ZombieEntity zombie = col.gameObject.GetComponent<ZombieEntity>();
			if (zombie == null || _targetList == null)
			{
				return;
			}
			if (_targetList.Contains(zombie))
			{
				_targetList.Remove(zombie);
			}
		}

		public override void OnTriggerCustomStay(Collider2D col, int index)
		{
			base.OnTriggerCustomStay(col, index);
			// TODO: reconstruct — the stay handler iterates _targetList and, for each live
			// Zombie120Entity, calls WheelieAttack() and applies this plant's damage via an
			// unresolved virtual slot (0x238). The per-target guards read several zombie
			// members only by raw offset (0x55, attr/state at 0x1c/0xe0/0x10) that are not
			// named in the skeleton, so the damage tick is left unreconstructed rather than
			// invented.
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__13))]
		protected override IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__13(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__14))]
		protected override IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__14(0)
			{
				_003C_003E4__this = this,
				entity = entity
			};
		}
	}
}
