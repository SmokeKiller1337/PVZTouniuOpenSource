using System;
using System.Collections.Generic;
using Common.Entity;
using Common.Enum;
using Land.Entity;
using Level.Enum;
using Plant.Enum;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity
{
	public abstract class CardEntity : MonoBehaviour
	{
		[Tooltip("编号")]
		public int id;

		[Tooltip("背景id")]
		public int backgroundId;

		[Tooltip("名称")]
		public string title;

		[Tooltip("简介")]
		public string simpleDesc;

		[Tooltip("描述")]
		[TextArea]
		public string desc;

		[Tooltip("默认解锁")]
		public bool defaultUnLock;

		[Tooltip("卡牌类型")]
		public CardType type;

		[Tooltip("睡眠类型")]
		public SleepType sleepType;

		[Tooltip("种植类型")]
		public PlaceType placeType;

		[Tooltip("优先级")]
		public int priority;

		[Tooltip("直接可种植位置")]
		public List<LandType> placeLandTypeList;

		[Tooltip("有基座时可种植位置")]
		public List<LandType> placeHasBaseLandTypeList;

		[Tooltip("是否有眼睛动画")]
		public bool isEyeAnimation;

		[Tooltip("卡牌属性")]
		public CardBaseAttr attr;

		[Tooltip("卡牌默认属性")]
		public CardBaseAttr defaultAttr;

		[Tooltip("卡牌额外属性图标")]
		public List<Sprite> cardExtraSpriteList;

		[Tooltip("植物属性")]
		public PlantBaseAttr plantAttr;

		[Tooltip("植物默认属性")]
		public PlantBaseAttr plantDefaultAttr;

		[Tooltip("植物额外属性图标")]
		public List<Sprite> plantExtraSpriteList;

		[Tooltip("可选强化")]
		public CardStrengthenEntity cardStrengthenEntity;

		[HideInInspector]
		public int level;

		public Dictionary<int, int> hasStrengthenDic;

		[HideInInspector]
		public bool isExtraCardSlot;

		public Action OnLevelUp;

		public Action<PlantEntity> OnPlacePlant;

		public Action<ZombieEntity> OnPlaceZombie;

		public string SleepTypeTitle
		{
			get
			{
				switch (sleepType)
				{
					case (SleepType)0:
						return SLEEP_TYPE_TITLE_0; // TODO: real string constant
					case (SleepType)1:
						return SLEEP_TYPE_TITLE_1; // TODO: real string constant
					case (SleepType)2:
						return SLEEP_TYPE_TITLE_2; // TODO: real string constant
					default:
						return SLEEP_TYPE_TITLE_DEFAULT; // TODO: real string constant
				}
			}
		}

		public string PlaceTypeTitle
		{
			get
			{
				switch ((int)placeType)
				{
					case -1:
						return PLACE_TYPE_TITLE_NONE; // TODO: real string constant
					case 0:
						return PLACE_TYPE_TITLE_0; // TODO: real string constant
					case 1:
						return PLACE_TYPE_TITLE_1; // TODO: real string constant
					case 2:
						return PLACE_TYPE_TITLE_2; // TODO: real string constant
					case 3:
						return PLACE_TYPE_TITLE_3; // TODO: real string constant
					default:
						return PLACE_TYPE_TITLE_DEFAULT; // TODO: real string constant
				}
			}
		}

		private const string SLEEP_TYPE_TITLE_0 = "";
		private const string SLEEP_TYPE_TITLE_1 = "";
		private const string SLEEP_TYPE_TITLE_2 = "";
		private const string SLEEP_TYPE_TITLE_DEFAULT = "";
		private const string PLACE_TYPE_TITLE_NONE = "";
		private const string PLACE_TYPE_TITLE_0 = "";
		private const string PLACE_TYPE_TITLE_1 = "";
		private const string PLACE_TYPE_TITLE_2 = "";
		private const string PLACE_TYPE_TITLE_3 = "";
		private const string PLACE_TYPE_TITLE_DEFAULT = "";

		public virtual void Reset()
		{
		}

		protected virtual void Awake()
		{
			for (int i = 0; i < 4; i++)
			{
				hasStrengthenDic.Add(i, -1);
			}
		}

		protected virtual void Update()
		{
		}

		public virtual bool IsPlaceable(LandEntity landEntity)
		{
			return default;
		}

		public void StartWarmUp()
		{
			// Only warm up if a positive warm-up time is configured; set the
			// cooldown-active flag and prime the countdown to the warm-up duration.
			if (attr == null)
			{
				return;
			}
			// TODO: uses CardBaseAttr internals (warmUpTime, isCooldown, cooldown).
			// if (attr.warmUpTime > 0f)
			// {
			//     attr.isCooldown = true;
			//     attr.cooldown = attr.warmUpTime;
			// }
		}

		public void StartCooldown()
		{
			// Begin the normal recharge: flag cooldown active and reset the
			// countdown to the full cooldown time.
			if (attr == null)
			{
				return;
			}
			// TODO: uses CardBaseAttr internals (isCooldown, cooldown, cooldownTime).
			// attr.isCooldown = true;
			// attr.cooldown = attr.cooldownTime;
		}

		private void CooldownUpdate()
		{
		}

		private void CooldownEnd()
		{
		}

		public void StartPowerCooldown()
		{
			// Begin the power (secondary ability) recharge.
			if (attr == null)
			{
				return;
			}
			// TODO: uses CardBaseAttr internals (isPowerCooldown, powerCooldown, powerCooldownTime).
			// attr.isPowerCooldown = true;
			// attr.powerCooldown = attr.powerCooldownTime;
		}

		private void PowerCooldownUpdate()
		{
		}

		private void PowerCooldownEnd()
		{
		}

		public bool IsAvailablePower()
		{
			// Power is available when strengthen-slot 3 is unlocked (!= -1) and the
			// power is not currently on cooldown.
			if (hasStrengthenDic == null)
			{
				return default;
			}
			if (hasStrengthenDic[3] == -1)
			{
				return false;
			}
			if (attr == null)
			{
				return default;
			}
			return default;
		}

		public float GetAttrValue(AttrEnum attrEnum)
		{
			return default;
		}

		public Vector2 GetPosition()
		{
			return default(Vector2);
		}

		public void LevelUp(int index)
		{
			// Advance to the next strengthen level, record the chosen option in
			// hasStrengthenDic, dispatch the matching LevelUp1/2/3 hook with the
			// selected StrengthenEntity, fire OnLevelUp, and refresh the card UI.
			level = level + 1;
			if (hasStrengthenDic == null)
			{
				return;
			}
			hasStrengthenDic[level] = index;

			switch (level)
			{
				case 1:
					break;
				case 2:
					break;
				case 3:
					break;
			}

			if (OnLevelUp != null)
			{
				OnLevelUp();
			}

		}

		protected virtual void LevelUp1(StrengthenEntity entity)
		{
			// Strengthen type 0 reduces the card's sun cost by defaultAttr.sun *
			// GetValue; type 1 scales the cooldown time by defaultAttr.cooldownTime *
			// GetValue while preserving the current cooldown ratio.
			if (entity == null)
			{
				return;
			}
		}

		protected virtual void LevelUp2(StrengthenEntity entity)
		{
		}

		protected virtual void LevelUp3(StrengthenEntity entity)
		{
			// Strengthen type triggers the power ability: copy the entity's power
			// value into both the live and default card attr power-cooldown-time.
			if (entity == null || attr == null)
			{
				return;
			}
		}

		public void SetSunAndShow(int value)
		{
			// Adjust the sun cost to an absolute target value and pop a floating
			// value indicator (good when cost drops, bad when it rises), then
			// refresh the UI. Delta = value - current sun.
			if (attr == null)
			{
				return;
			}
		}

		public void ChangeSunAndShow(int value)
		{
			// Add a relative delta to the sun cost and pop a floating indicator
			// (good when cost drops, bad when it rises), then refresh the UI.
			if (value == 0)
			{
				return;
			}
			if (attr == null)
			{
				return;
			}
		}

		public void ChangeCooldownAndShow(float ratio)
		{
			// Scale both the cooldown time and the remaining cooldown by
			// (1 + ratio * defaultAttr.cooldownTime factor), popping a value
			// indicator (a lower/negative cooldown change is "good"), then refresh.
			if (ratio == 0f)
			{
				return;
			}
			if (attr == null || defaultAttr == null)
			{
				return;
			}
		}

		public virtual float GetMaxHealth()
		{
			if (plantAttr == null)
			{
				return default;
			}
			return default;
		}

		public virtual void SetMaxHealthAndShow(int value)
		{
			// Convert an absolute max-health target into a delta relative to the
			// current value and forward to ChangeMaxHealthAndShow (virtual slot).
			if (plantAttr == null)
			{
				return;
			}
		}

		public virtual void ChangeMaxHealthAndShow(float value)
		{
			// Add a delta to both current health and max health, pop a value
			// indicator (increase is "good"), then refresh the UI.
			if (value == 0f)
			{
				return;
			}
			if (plantAttr == null)
			{
				return;
			}
		}

		public virtual void ChangeAttackAndShow(int value)
		{
			// Add a delta to the plant's attack, pop a value indicator (increase is
			// "good"), then refresh the UI.
			if (value == 0)
			{
				return;
			}
			if (plantAttr == null)
			{
				return;
			}
		}

		public virtual void ChangeMagicAndShow(int value)
		{
			// Add a delta to the plant's magic, pop a value indicator (increase is
			// "good"), then refresh the UI.
			if (value == 0)
			{
				return;
			}
			if (plantAttr == null)
			{
				return;
			}
		}

		public virtual void ChangeAttackSpeedAndShow(float ratio)
		{
			// Add ratio * plantDefaultAttr.attackSpeed to the live attack speed via
			// PlantBaseAttr.set_AttackSpeed, pop a value indicator (increase is
			// "good"), then refresh the UI.
			if (ratio == 0f)
			{
				return;
			}
			if (plantAttr == null || plantDefaultAttr == null)
			{
				return;
			}
		}

		public virtual void ChangeWalkSpeedAndShow(float ratio)
		{
		}

		private void UpdateUI()
		{
		}
	}
}
