using System;
using System.Collections.Generic;
using Common.Entity;
using Common.Enum;
using Land.Entity;
using Level.Enum;
using Plant.Enum;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

// NOTE: Reconstructed from IL2CPP/Ghidra output for Plant.Entity.CardEntity.
// The structure below (namespace, usings, class/base, fields, method signatures) is
// taken verbatim from the authoritative stub.cs / dump.cs.
//
// Several methods operate on the internal fields of CardBaseAttr / PlantBaseAttr,
// which are separate classes whose member layout is NOT part of this class's
// authoritative dump. The offsets observed in the pseudocode were mapped to the
// most plausible member names and are marked with "// TODO:" where the exact
// member identifier could not be confirmed from the available inputs. These are
// deliberately left as descriptive placeholders so the intended logic is preserved
// without fabricating a false structure.
//
// Inferred CardBaseAttr layout (relative to the object), used by cooldown logic:
//   +0x10 sun (int)            +0x14 cooldownTime (float)
//   +0x18 cooldown (float)     +0x1c isCooldown (bool)
//   +0x20 warmUpTime (float)   +0x24 powerCooldownTime (float)
//   +0x28 powerCooldown(float) +0x2c isPowerCooldown (bool)
// Inferred PlantBaseAttr layout:
//   +0x10 health (float)       +0x14 maxHealth (float)
//   +0x20 attack (int)         +0x24 magic (int)
//   +0x28 attackSpeed (float)  +0x38 extra-attr list
// Because these member names cannot be verified against a dump, the reconstructed
// bodies that depend on them are marked "// TODO: reconstruct" where translating
// them literally would require inventing members on external types.

namespace Plant.Entity
{
	public abstract class CardEntity : MonoBehaviour
	{
		[Tooltip("编号")]
		public int id;

		[Tooltip("背景id")]
		public int backgroundId;

		[Tooltip("名称")]
		public string title;

		[Tooltip("简介")]
		public string simpleDesc;

		[Tooltip("描述")]
		[TextArea]
		public string desc;

		[Tooltip("默认解锁")]
		public bool defaultUnLock;

		[Tooltip("卡牌类型")]
		public CardType type;

		[Tooltip("睡眠类型")]
		public SleepType sleepType;

		[Tooltip("种植类型")]
		public PlaceType placeType;

		[Tooltip("优先级")]
		public int priority;

		[Tooltip("直接可种植位置")]
		public List<LandType> placeLandTypeList;

		[Tooltip("有基座时可种植位置")]
		public List<LandType> placeHasBaseLandTypeList;

		[Tooltip("是否有眼睛动画")]
		public bool isEyeAnimation;

		[Tooltip("卡牌属性")]
		public CardBaseAttr attr;

		[Tooltip("卡牌默认属性")]
		public CardBaseAttr defaultAttr;

		[Tooltip("卡牌额外属性图标")]
		public List<Sprite> cardExtraSpriteList;

		[Tooltip("植物属性")]
		public PlantBaseAttr plantAttr;

		[Tooltip("植物默认属性")]
		public PlantBaseAttr plantDefaultAttr;

		[Tooltip("植物额外属性图标")]
		public List<Sprite> plantExtraSpriteList;

		[Tooltip("可选强化")]
		public CardStrengthenEntity cardStrengthenEntity;

		[HideInInspector]
		public int level;

		public Dictionary<int, int> hasStrengthenDic;

		[HideInInspector]
		public bool isExtraCardSlot;

		public Action OnLevelUp;

		public Action<PlantEntity> OnPlacePlant;

		public Action<ZombieEntity> OnPlaceZombie;

		public string SleepTypeTitle
		{
			get
			{
				// pseudocode switches on sleepType (field @0x48).
				// The returned values are localized/interned string constants whose
				// literal text is stored as data pointers and cannot be recovered.
				switch (sleepType)
				{
					case (SleepType)0:
						return SLEEP_TYPE_TITLE_0; // TODO: real string constant
					case (SleepType)1:
						return SLEEP_TYPE_TITLE_1; // TODO: real string constant
					case (SleepType)2:
						return SLEEP_TYPE_TITLE_2; // TODO: real string constant
					default:
						return SLEEP_TYPE_TITLE_DEFAULT; // TODO: real string constant
				}
			}
		}

		public string PlaceTypeTitle
		{
			get
			{
				// pseudocode switches on placeType (field @0x4C).
				// The returned values are localized/interned string constants whose
				// literal text is stored as data pointers and cannot be recovered.
				switch ((int)placeType)
				{
					case -1:
						return PLACE_TYPE_TITLE_NONE; // TODO: real string constant
					case 0:
						return PLACE_TYPE_TITLE_0; // TODO: real string constant
					case 1:
						return PLACE_TYPE_TITLE_1; // TODO: real string constant
					case 2:
						return PLACE_TYPE_TITLE_2; // TODO: real string constant
					case 3:
						return PLACE_TYPE_TITLE_3; // TODO: real string constant
					default:
						return PLACE_TYPE_TITLE_DEFAULT; // TODO: real string constant
				}
			}
		}

		// ---- Placeholder string constants for values stored as data pointers ----
		// TODO: replace with the real localized text once resolvable.
		private const string SLEEP_TYPE_TITLE_0 = "";
		private const string SLEEP_TYPE_TITLE_1 = "";
		private const string SLEEP_TYPE_TITLE_2 = "";
		private const string SLEEP_TYPE_TITLE_DEFAULT = "";
		private const string PLACE_TYPE_TITLE_NONE = "";
		private const string PLACE_TYPE_TITLE_0 = "";
		private const string PLACE_TYPE_TITLE_1 = "";
		private const string PLACE_TYPE_TITLE_2 = "";
		private const string PLACE_TYPE_TITLE_3 = "";
		private const string PLACE_TYPE_TITLE_DEFAULT = "";

		public virtual void Reset()
		{
			// The pseudocode constructs a fresh CardBaseAttr from `attr` and stores it
			// in `defaultAttr`, then a fresh PlantBaseAttr from `plantAttr` into
			// `plantDefaultAttr`, and copies a couple of live values into the new
			// snapshots. This relies on copy-constructors and internal members of
			// CardBaseAttr / PlantBaseAttr that are not part of this class's dump, so
			// the exact ctor signature cannot be verified.
			// defaultAttr      = new CardBaseAttr(attr);
			// plantDefaultAttr = new PlantBaseAttr(plantAttr);
			// (plus internal value copies into the new default snapshots)
			// TODO: reconstruct (rebuild default attr snapshots from live attrs).
		}

		protected virtual void Awake()
		{
			// The pseudocode snapshots the live attributes into the "default" copies
			// (via CardBaseAttr/PlantBaseAttr copy-constructors whose signatures are
			// not in this class's dump) and then seeds the strengthen dictionary with
			// four entries, all -1. The dictionary seeding is fully recoverable:
			// defaultAttr      = new CardBaseAttr(attr);
			// plantDefaultAttr = new PlantBaseAttr(plantAttr);
			for (int i = 0; i < 4; i++)
			{
				hasStrengthenDic.Add(i, -1);
			}
		}

		protected virtual void Update()
		{
			// Drives cooldown and power-cooldown timers each frame and refreshes
			// the card-slot UI. The bulk of this method dereferences internal fields
			// of CardBaseAttr and the global level/UI singletons whose layouts are
			// not part of this class's authoritative dump; translating it literally
			// would require inventing members on external types.
			// TODO: reconstruct (per-frame cooldown tick + card-slot UI sync).
		}

		public virtual bool IsPlaceable(LandEntity landEntity)
		{
			// Determines whether this card may be planted on the given land.
			// Depends on LandEntity's internal field layout (occupant slots at
			// +0x30/+0x38/+0x40/+0x48/+0x50/+0x58 and land-type at +0x28) which is
			// not part of this class's dump, so a faithful literal translation is
			// not possible without inventing members on LandEntity.
			// TODO: reconstruct placement rules against LandEntity.
			return default;
		}

		public void StartWarmUp()
		{
			// Only warm up if a positive warm-up time is configured; set the
			// cooldown-active flag and prime the countdown to the warm-up duration.
			if (attr == null)
			{
				return;
			}
			// TODO: uses CardBaseAttr internals (warmUpTime, isCooldown, cooldown).
			// if (attr.warmUpTime > 0f)
			// {
			//     attr.isCooldown = true;
			//     attr.cooldown = attr.warmUpTime;
			// }
		}

		public void StartCooldown()
		{
			// Begin the normal recharge: flag cooldown active and reset the
			// countdown to the full cooldown time.
			if (attr == null)
			{
				return;
			}
			// TODO: uses CardBaseAttr internals (isCooldown, cooldown, cooldownTime).
			// attr.isCooldown = true;
			// attr.cooldown = attr.cooldownTime;
		}

		private void CooldownUpdate()
		{
			// Ticks the recharge countdown while the global "cooldown enabled" flag
			// is set; when it reaches zero, resets it and replays the card-slot
			// ready transition. Relies on CardBaseAttr internals and level/UI
			// singletons not present in this class's dump.
			// TODO: reconstruct (cooldown countdown + CardCooldownEnd transition).
		}

		private void CooldownEnd()
		{
			// Force the recharge to complete immediately: zero the countdown, clear
			// the active flag, then stop/replay the card-slot "ready" transition and
			// refresh the open card text if this is the current card.
			// Relies on CardBaseAttr internals and the level/UI singletons.
			// TODO: reconstruct (immediate cooldown completion + UI transition).
		}

		public void StartPowerCooldown()
		{
			// Begin the power (secondary ability) recharge.
			if (attr == null)
			{
				return;
			}
			// TODO: uses CardBaseAttr internals (isPowerCooldown, powerCooldown, powerCooldownTime).
			// attr.isPowerCooldown = true;
			// attr.powerCooldown = attr.powerCooldownTime;
		}

		private void PowerCooldownUpdate()
		{
			// Ticks the power recharge while globally enabled; on completion resets
			// it and plays the power-ready transition on the card slot item.
			// Relies on CardBaseAttr internals and level/UI singletons.
			// TODO: reconstruct (power cooldown countdown + power transition).
		}

		private void PowerCooldownEnd()
		{
			// Force power recharge to complete and play the power-ready transition.
			// Relies on CardBaseAttr internals and level/UI singletons.
			// TODO: reconstruct (immediate power cooldown completion + transition).
		}

		public bool IsAvailablePower()
		{
			// Power is available when strengthen-slot 3 is unlocked (!= -1) and the
			// power is not currently on cooldown.
			if (hasStrengthenDic == null)
			{
				return default;
			}
			if (hasStrengthenDic[3] == -1)
			{
				return false;
			}
			if (attr == null)
			{
				return default;
			}
			// TODO: uses CardBaseAttr.isPowerCooldown (offset +0x2c).
			// return !attr.isPowerCooldown;
			return default; // TODO: reconstruct final power-availability check
		}

		public float GetAttrValue(AttrEnum attrEnum)
		{
			// Maps an AttrEnum onto a field of either the card attr (cases 1-3) or
			// the plant attr (cases 4-8), or an entry of the plant extra-attr list
			// (cases 10-12). The concrete field reads target CardBaseAttr /
			// PlantBaseAttr internals not present in this class's dump, so the value
			// selection cannot be reproduced without inventing those members.
			// The observed control flow was:
			//   case 1/2/3 -> read from attr
			//   case 4/5/6/7/8 -> read from plantAttr
			//   case 10/11/12 -> plantAttr extra-attr-list[0/1/2]
			// TODO: reconstruct the per-enum field selection.
			return default;
		}

		public Vector2 GetPosition()
		{
			// Computes the world position of this card's slot. For an extra card
			// slot it queries the current card slot; otherwise it looks the card up
			// via LevelUtils and its slot dictionary. In both branches it takes the
			// slot GObject's local position, converts to global, flips Y against the
			// screen height, and projects through the main camera to world space.
			// The intermediate FairyGUI/level types and their field offsets are not
			// part of this class's dump.
			// TODO: reconstruct (slot GObject -> global -> camera ScreenToWorldPoint).
			return default(Vector2);
		}

		public void LevelUp(int index)
		{
			// Advance to the next strengthen level, record the chosen option in
			// hasStrengthenDic, dispatch the matching LevelUp1/2/3 hook with the
			// selected StrengthenEntity, fire OnLevelUp, and refresh the card UI.
			level = level + 1;
			if (hasStrengthenDic == null)
			{
				return;
			}
			hasStrengthenDic[level] = index;

			// cardStrengthenEntity holds the per-level option lists; the specific
			// list members (level-1/2/3 lists at +0x18/+0x20/+0x28) are internal to
			// CardStrengthenEntity and not part of this class's dump.
			switch (level)
			{
				case 1:
					// entity = cardStrengthenEntity.level1List[index];
					// entity.selectedIndex = index;
					// LevelUp1(entity);
					// TODO: reconstruct level-1 strengthen dispatch.
					break;
				case 2:
					// entity = cardStrengthenEntity.level2List[index];
					// entity.selectedIndex = index;
					// LevelUp2(entity);
					// TODO: reconstruct level-2 strengthen dispatch.
					break;
				case 3:
					// entity = cardStrengthenEntity.level3List[index];
					// entity.selectedIndex = index;
					// LevelUp3(entity);
					// TODO: reconstruct level-3 strengthen dispatch.
					break;
			}

			if (OnLevelUp != null)
			{
				OnLevelUp();
			}

			// Refresh the (extra) card in the card-slot box UI and, if debug mode is
			// on, propagate the update to all card slots. This uses the level/UI
			// singleton whose layout is not part of this class's dump.
			// TODO: reconstruct (CardSlotBox UpdateCard / UpdateExtraCard refresh).
		}

		protected virtual void LevelUp1(StrengthenEntity entity)
		{
			// Strengthen type 0 reduces the card's sun cost by defaultAttr.sun *
			// GetValue; type 1 scales the cooldown time by defaultAttr.cooldownTime *
			// GetValue while preserving the current cooldown ratio.
			if (entity == null)
			{
				return;
			}
			// The reads/writes target CardBaseAttr internals (sun @+0x10,
			// cooldownTime @+0x14, cooldown @+0x18) not present in this class's dump.
			//
			// if (entity.type == 0)
			// {
			//     if (attr == null || defaultAttr == null) return;
			//     attr.sun -= (int)(defaultAttr.sun * entity.GetValue(this));
			// }
			// else if (entity.type == 1)
			// {
			//     float ratio = attr.cooldownTime > 0f
			//         ? Mathf.Clamp01(attr.cooldown / attr.cooldownTime) : 0f;
			//     float newCd = attr.cooldownTime - entity.GetValue(this) * defaultAttr.cooldownTime;
			//     if (newCd < 0f) newCd = 0f;
			//     attr.cooldownTime = newCd;
			//     attr.cooldown = ratio * attr.cooldownTime;
			// }
			// TODO: reconstruct (depends on CardBaseAttr/StrengthenEntity internals).
		}

		protected virtual void LevelUp2(StrengthenEntity entity)
		{
			// Body folded by ICF to an empty stub in the binary (RVA 0x381980 is the
			// shared empty method). Nothing to reconstruct.
		}

		protected virtual void LevelUp3(StrengthenEntity entity)
		{
			// Strengthen type triggers the power ability: copy the entity's power
			// value into both the live and default card attr power-cooldown-time.
			if (entity == null || attr == null)
			{
				return;
			}
			// attr.powerCooldownTime = entity.value; // entity @+0x28
			// if (defaultAttr != null) defaultAttr.powerCooldownTime = entity.value;
			// TODO: reconstruct (writes CardBaseAttr.powerCooldownTime from StrengthenEntity).
		}

		public void SetSunAndShow(int value)
		{
			// Adjust the sun cost to an absolute target value and pop a floating
			// value indicator (good when cost drops, bad when it rises), then
			// refresh the UI. Delta = value - current sun.
			if (attr == null)
			{
				return;
			}
			// int delta = value - attr.sun;
			// if (delta == 0) return;
			// attr.sun += delta;
			// Vector2 pos = isExtraCardSlot
			//     ? LevelUtils.GetExtraCardPosition()
			//     : LevelUtils.GetCardPosition(id);
			// var box = <level>.valueBox;   // singleton @0x68
			// if (delta < 0) box.CreateGoodValue(pos, ...);  // cheaper => good
			// else           box.CreateBadValue(pos, ...);
			// UpdateUI();
			// TODO: reconstruct (uses CardBaseAttr.sun + ValueBox singleton).
		}

		public void ChangeSunAndShow(int value)
		{
			// Add a relative delta to the sun cost and pop a floating indicator
			// (good when cost drops, bad when it rises), then refresh the UI.
			if (value == 0)
			{
				return;
			}
			if (attr == null)
			{
				return;
			}
			// attr.sun += value;
			// Vector2 pos = isExtraCardSlot
			//     ? LevelUtils.GetExtraCardPosition()
			//     : LevelUtils.GetCardPosition(id);
			// var box = <level>.valueBox;
			// if (value < 0) box.CreateGoodValue(pos, ...);
			// else           box.CreateBadValue(pos, ...);
			// UpdateUI();
			// TODO: reconstruct (uses CardBaseAttr.sun + ValueBox singleton).
		}

		public void ChangeCooldownAndShow(float ratio)
		{
			// Scale both the cooldown time and the remaining cooldown by
			// (1 + ratio * defaultAttr.cooldownTime factor), popping a value
			// indicator (a lower/negative cooldown change is "good"), then refresh.
			if (ratio == 0f)
			{
				return;
			}
			if (attr == null || defaultAttr == null)
			{
				return;
			}
			// attr.cooldownTime += ratio * defaultAttr.cooldownTime;
			// attr.cooldown     += ratio * attr.cooldown;
			// Vector2 pos = isExtraCardSlot
			//     ? LevelUtils.GetExtraCardPosition()
			//     : LevelUtils.GetCardPosition(id);
			// var box = <level>.valueBox;
			// if (ratio >= 0f) box.CreateBadValue(pos, ...);   // more cooldown => bad
			// else             box.CreateGoodValue(pos, ...);
			// UpdateUI();
			// TODO: reconstruct (uses CardBaseAttr cooldown internals + ValueBox).
		}

		public virtual float GetMaxHealth()
		{
			// Returns the plant's max health from plantAttr (+0x10).
			if (plantAttr == null)
			{
				return default;
			}
			// return plantAttr.maxHealth; // read as uint at +0x10
			return default; // TODO: reconstruct (read PlantBaseAttr max health @+0x10).
		}

		public virtual void SetMaxHealthAndShow(int value)
		{
			// Convert an absolute max-health target into a delta relative to the
			// current value and forward to ChangeMaxHealthAndShow (virtual slot).
			if (plantAttr == null)
			{
				return;
			}
			// ChangeMaxHealthAndShow(value - plantAttr.health); // health @+0x10
			// TODO: reconstruct (delta against PlantBaseAttr @+0x10, then Change...).
		}

		public virtual void ChangeMaxHealthAndShow(float value)
		{
			// Add a delta to both current health and max health, pop a value
			// indicator (increase is "good"), then refresh the UI.
			if (value == 0f)
			{
				return;
			}
			if (plantAttr == null)
			{
				return;
			}
			// plantAttr.health    += value; // +0x10
			// plantAttr.maxHealth += value; // +0x14
			// Vector2 pos = isExtraCardSlot
			//     ? LevelUtils.GetExtraCardPosition()
			//     : LevelUtils.GetCardPosition(id);
			// var box = <level>.valueBox;
			// if (value >= 0f) box.CreateGoodValue(pos, ...);
			// else             box.CreateBadValue(pos, ...);
			// UpdateUI();
			// TODO: reconstruct (uses PlantBaseAttr health/maxHealth + ValueBox).
		}

		public virtual void ChangeAttackAndShow(int value)
		{
			// Add a delta to the plant's attack, pop a value indicator (increase is
			// "good"), then refresh the UI.
			if (value == 0)
			{
				return;
			}
			if (plantAttr == null)
			{
				return;
			}
			// plantAttr.attack += value; // +0x20
			// Vector2 pos = isExtraCardSlot
			//     ? LevelUtils.GetExtraCardPosition()
			//     : LevelUtils.GetCardPosition(id);
			// var box = <level>.valueBox;
			// if (value < 0) box.CreateBadValue(pos, ...);
			// else           box.CreateGoodValue(pos, ...);
			// UpdateUI();
			// TODO: reconstruct (uses PlantBaseAttr.attack @+0x20 + ValueBox).
		}

		public virtual void ChangeMagicAndShow(int value)
		{
			// Add a delta to the plant's magic, pop a value indicator (increase is
			// "good"), then refresh the UI.
			if (value == 0)
			{
				return;
			}
			if (plantAttr == null)
			{
				return;
			}
			// plantAttr.magic += value; // +0x24
			// Vector2 pos = isExtraCardSlot
			//     ? LevelUtils.GetExtraCardPosition()
			//     : LevelUtils.GetCardPosition(id);
			// var box = <level>.valueBox;
			// if (value < 0) box.CreateBadValue(pos, ...);
			// else           box.CreateGoodValue(pos, ...);
			// UpdateUI();
			// TODO: reconstruct (uses PlantBaseAttr.magic @+0x24 + ValueBox).
		}

		public virtual void ChangeAttackSpeedAndShow(float ratio)
		{
			// Add ratio * plantDefaultAttr.attackSpeed to the live attack speed via
			// PlantBaseAttr.set_AttackSpeed, pop a value indicator (increase is
			// "good"), then refresh the UI.
			if (ratio == 0f)
			{
				return;
			}
			if (plantAttr == null || plantDefaultAttr == null)
			{
				return;
			}
			// plantAttr.AttackSpeed = ratio * plantDefaultAttr.attackSpeed + plantAttr.attackSpeed;
			// Vector2 pos = isExtraCardSlot
			//     ? LevelUtils.GetExtraCardPosition()
			//     : LevelUtils.GetCardPosition(id);
			// var box = <level>.valueBox;
			// if (ratio >= 0f) box.CreateGoodValue(pos, ...);
			// else             box.CreateBadValue(pos, ...);
			// UpdateUI();
			// TODO: reconstruct (uses PlantBaseAttr attack speed @+0x28 + ValueBox).
		}

		public virtual void ChangeWalkSpeedAndShow(float ratio)
		{
			// Body folded by ICF to an empty stub in the binary (RVA 0x381980 is the
			// shared empty method). Nothing to reconstruct.
		}

		private void UpdateUI()
		{
			// Refreshes the FairyGUI card slot representation for this card (or the
			// extra card slot): rebuilds the card item, sets its background, cost
			// text, power gem, and cooldown display. The body is dominated by
			// FairyGUI GObject/GComponent traversal and level/UI singleton access
			// whose field layouts are not part of this class's dump.
			// TODO: reconstruct (FairyGUI card-slot visual refresh).
		}
	}
}
