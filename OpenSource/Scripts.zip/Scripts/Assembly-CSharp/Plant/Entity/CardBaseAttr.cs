using System;
using System.Collections.Generic;
using Common.Entity;
using Game.Entity;
using UnityEngine;

namespace Plant.Entity
{
	[Serializable]
	public class CardBaseAttr
	{
		[Tooltip("阳光数")]
		public int sun;

		[Tooltip("冷却时间")]
		public float cooldownTime;

		[HideInInspector]
		public float cooldownTimer;

		[HideInInspector]
		public bool isCooldown;

		[Tooltip("预热时间")]
		public float warmUpCoolDownTime;

		[HideInInspector]
		public float powerCooldownTime;

		[HideInInspector]
		public float powerCooldownTimer;

		[HideInInspector]
		public bool isPowerCooldown;

		[Tooltip("值集合")]
		public List<ValueEntity> valueList;

		[Tooltip("标签集合")]
		public List<AttrLabelEntity> labelList;

		public CardBaseAttr()
		{
		}

		public CardBaseAttr(CardBaseAttr attr)
		{
			// Copy the configured (non-runtime) fields. Runtime timers/flags
			// (cooldownTimer, isCooldown, powerCooldownTimer, isPowerCooldown)
			// are intentionally left at their defaults.
			this.sun = attr.sun;
			this.cooldownTime = attr.cooldownTime;
			this.warmUpCoolDownTime = attr.warmUpCoolDownTime;
			this.powerCooldownTime = attr.powerCooldownTime;

			this.valueList = new List<ValueEntity>();
			if (attr.valueList != null)
			{
				foreach (ValueEntity value in attr.valueList)
				{
					this.valueList.Add(value);
				}
			}

			this.labelList = new List<AttrLabelEntity>();
			if (attr.labelList != null)
			{
				foreach (AttrLabelEntity label in attr.labelList)
				{
					this.labelList.Add(label);
				}
			}
		}

		public void Reset()
		{
			this.labelList = new List<AttrLabelEntity>();
		}

		public float GetValue(CardEntity cardEntity, int index = 0)
		{
			return this.valueList[index].GetValue(cardEntity);
		}

		public int GetValueInt(CardEntity cardEntity, int index = 0)
		{
			return (int)this.valueList[index].GetValue(cardEntity);
		}

		public float GetValue(CardEntity cardEntity, string title)
		{
			foreach (ValueEntity value in this.valueList)
			{
				if (value.title != null && value.title.Equals(title))
				{
					return value.GetValue(cardEntity);
				}
			}
			throw new Exception("找不到值: " + title);
		}

		public int GetValueInt(CardEntity cardEntity, string fieldName)
		{
			return (int)this.GetValue(cardEntity, fieldName);
		}

		public void AddLabel(string title, int layer = 0, string desc = "")
		{
			foreach (AttrLabelEntity label in this.labelList)
			{
				if (label.title != null && label.title.Equals(title))
				{
					label.layer += layer;
					if (desc != null && desc.Length > 0)
					{
						label.desc = desc;
					}
					return;
				}
			}

			this.labelList.Add(new AttrLabelEntity
			{
				title = title,
				layer = layer,
				desc = desc
			});
		}

		public void ReduceLabel(string title, int layer = 0)
		{
			foreach (AttrLabelEntity label in this.labelList)
			{
				if (label.title != null && label.title.Equals(title))
				{
					label.layer -= layer;
					if (label.layer < 1)
					{
						this.labelList.Remove(label);
					}
					return;
				}
			}
		}

		public int GetLabel(string title)
		{
			foreach (AttrLabelEntity label in this.labelList)
			{
				if (label.title != null && label.title.Equals(title))
				{
					return label.layer;
				}
			}
			return 0;
		}

		public bool HasLabel(string title)
		{
			foreach (AttrLabelEntity label in this.labelList)
			{
				if (label.title != null && label.title.Equals(title))
				{
					return true;
				}
			}
			return false;
		}
	}
}
