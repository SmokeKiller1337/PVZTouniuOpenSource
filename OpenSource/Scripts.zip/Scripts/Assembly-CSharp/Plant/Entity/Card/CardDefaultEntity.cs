namespace Plant.Entity.Card
{
	public class CardDefaultEntity : CardEntity
	{
	}
}
