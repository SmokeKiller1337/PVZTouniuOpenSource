using Land.Entity;

namespace Plant.Entity.Card
{
	public class Card125Entity : CardDefaultEntity
	{
		public override bool IsPlaceable(LandEntity landEntity)
		{
			// 伪代码逻辑：
			//   cVar3 = base.IsPlaceable(landEntity);
			//   if (cVar3) {
			//       uVar1 = *(landEntity + 0x50);              // LandEntity.masterBuilding
			//       if (op_Inequality(uVar1, null) == false)   // masterBuilding == null
			//           return true;
			//   }
			//   return false;
			// 即：基类允许放置且该地皮上没有建筑物时才可放置。
			// LandEntity+0x50 由 dump 确认为 public BuildingEntity masterBuilding。
			return base.IsPlaceable(landEntity) && landEntity.masterBuilding == null;
		}
	}
}
