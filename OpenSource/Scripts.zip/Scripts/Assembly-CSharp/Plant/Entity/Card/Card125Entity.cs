using Land.Entity;

namespace Plant.Entity.Card
{
	public class Card125Entity : CardDefaultEntity
	{
		public override bool IsPlaceable(LandEntity landEntity)
		{
			return base.IsPlaceable(landEntity) && landEntity.masterBuilding == null;
		}
	}
}
