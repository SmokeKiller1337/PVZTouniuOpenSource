using Building.Entity;
using Land.Entity;

namespace Plant.Entity.Card
{
	public class Card120Entity : CardDefaultEntity
	{
		public override bool IsPlaceable(LandEntity landEntity)
		{
			// 先走基类的通用可放置判定；基类不通过则直接不可放置。
			if (!base.IsPlaceable(landEntity))
			{
				return false;
			}

			BuildingEntity masterBuilding = landEntity.masterBuilding;
			if (masterBuilding != null && masterBuilding.id == 1)
			{
				return true;
			}

			return false;
		}
	}
}
