using Building.Entity;
using Land.Entity;

namespace Plant.Entity.Card
{
	public class Card120Entity : CardDefaultEntity
	{
		public override bool IsPlaceable(LandEntity landEntity)
		{
			// 先走基类的通用可放置判定；基类不通过则直接不可放置。
			if (!base.IsPlaceable(landEntity))
			{
				return false;
			}

			// 伪代码读取 landEntity + 0x50 == masterBuilding (BuildingEntity)，
			// Unity op_Equality 判空后再比较其 +0x20 == id 字段是否为 1。
			// 即：只有当该地皮上存在 id == 1 的建筑物时才可放置。
			BuildingEntity masterBuilding = landEntity.masterBuilding;
			if (masterBuilding != null && masterBuilding.id == 1)
			{
				return true;
			}

			return false;
		}
	}
}
