using Land.Entity;

namespace Plant.Entity.Card
{
	public class Card170Entity : CardDefaultEntity
	{
		public override bool IsPlaceable(LandEntity landEntity)
		{
			// 伪代码: 先调用基类 CardEntity.IsPlaceable(landEntity)（被 ICF 折叠显示为 CardEntity__IsPlaceable）。
			// 基类返回 false 则直接不可放置。
			if (!base.IsPlaceable(landEntity))
			{
				return false;
			}
			// 基类通过后，读取 LandEntity +0x30（占位槽首个，即主植物 masterPlant），
			// 用 UnityEngine.Object.op_Inequality(field, null) 判断该槽是否已被占用：
			//   field != null 为真  -> 已有主植物 -> 返回 false（落到末尾 return 0）
			//   field != null 为假  -> 槽为空     -> 返回 true
			// 即：仅当该地皮主植物槽为空时才可放置。
			return landEntity.masterPlant == null;
		}
	}
}
