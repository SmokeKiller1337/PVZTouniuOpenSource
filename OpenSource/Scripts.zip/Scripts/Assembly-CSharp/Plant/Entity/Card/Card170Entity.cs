using Land.Entity;

namespace Plant.Entity.Card
{
	public class Card170Entity : CardDefaultEntity
	{
		public override bool IsPlaceable(LandEntity landEntity)
		{
			if (!base.IsPlaceable(landEntity))
			{
				return false;
			}
			return landEntity.masterPlant == null;
		}
	}
}
