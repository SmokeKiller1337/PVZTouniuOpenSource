using Common.Entity;
using UnityEngine;

namespace Plant.Entity.Card
{
	public class CardZombieEntity : CardEntity
	{
		[Tooltip("是魅惑僵尸")]
		public bool isHypnosis;

		[Tooltip("僵尸属性")]
		public ZombieBaseAttr zombieAttr;

		[Tooltip("僵尸默认属性")]
		public ZombieBaseAttr zombieDefaultAttr;

		public override void Reset()
		{
			base.Reset();
			zombieAttr = new ZombieBaseAttr(zombieDefaultAttr);
		}

		public override float GetMaxHealth()
		{
			return zombieAttr.maxHealth;
		}

		public override void SetMaxHealthAndShow(int value)
		{
			ChangeMaxHealthAndShow(value - zombieAttr.maxHealth);
		}

		public override void ChangeMaxHealthAndShow(float value)
		{
			if (value == 0f)
			{
				return;
			}
			if (zombieAttr == null)
			{
				return;
			}
			zombieAttr.maxHealth += value;
		}

		public override void ChangeAttackAndShow(int value)
		{
			if (value == 0)
			{
				return;
			}
			if (zombieAttr == null)
			{
				return;
			}
			zombieAttr.attack += value;
		}

		public override void ChangeMagicAndShow(int value)
		{
			if (value == 0)
			{
				return;
			}
			if (zombieAttr == null)
			{
				return;
			}
			zombieAttr.magic += value;
		}

		public override void ChangeAttackSpeedAndShow(float ratio)
		{
			if (ratio == 0f)
			{
				return;
			}
			if (zombieAttr == null || zombieDefaultAttr == null)
			{
				return;
			}
			zombieAttr.AttackSpeed = ratio * zombieDefaultAttr.attackSpeed + zombieAttr.attackSpeed;
		}

		public override void ChangeWalkSpeedAndShow(float ratio)
		{
			if (ratio == 0f)
			{
				return;
			}
			if (zombieAttr == null || zombieDefaultAttr == null)
			{
				return;
			}
			zombieAttr.walkSpeedRatio += ratio * zombieDefaultAttr.walkSpeedRatio;
		}
	}
}
