using Common.Entity;
using UnityEngine;

// NOTE: Reconstructed from IL2CPP/Ghidra output for Plant.Entity.Card.CardZombieEntity.
// The structure below (namespace, usings, class/base, fields, method signatures) is
// taken verbatim from the authoritative stub.cs / dump.cs and is not modified.
//
// Confirmed field offsets on this class (from dump.cs):
//   +0xD8 isHypnosis (bool)
//   +0xE0 zombieAttr (ZombieBaseAttr)
//   +0xE8 zombieDefaultAttr (ZombieBaseAttr)
//
// Confirmed field offsets on Common.Entity.ZombieBaseAttr (from field-declaration order,
// cross-checked against the offsets dereferenced in the pseudocode):
//   +0x10 maxHealth (float)      +0x2C walkSpeedRatio (float)
//   +0x30 attack (int)           +0x34 magic (int)
//   +0x38 attackSpeed (float)    (set via the AttackSpeed property / set_AttackSpeed)
//
// Each "Change...AndShow" method mutates the live zombieAttr (fully recoverable) and
// then pops a floating value indicator through the ValueBox UI. That UI half is obtained
// in the pseudocode via GameManager.Instance (+0xB8 sub-manager, +0x68 field) chained to
// FGUI.Entity.UI.ValueBoxEntity.CreateGoodValue/CreateBadValue. That singleton chain
// cannot be resolved to a verifiable public member path (GameManager exposes no such
// field, and the +0xB8/+0x68 offsets map to internal members not present in any available
// dump). The identically-shaped base class Plant.Entity.CardEntity left the same UI calls
// unreconstructed for this reason. The attribute mutations are therefore applied here
// (verified against real members) while the value-indicator display is left as a TODO
// rather than fabricating members on external types.

namespace Plant.Entity.Card
{
	public class CardZombieEntity : CardEntity
	{
		[Tooltip("是魅惑僵尸")]
		public bool isHypnosis;

		[Tooltip("僵尸属性")]
		public ZombieBaseAttr zombieAttr;

		[Tooltip("僵尸默认属性")]
		public ZombieBaseAttr zombieDefaultAttr;

		public override void Reset()
		{
			// Re-snapshot the live zombie attributes from the default template.
			// pseudocode: base.Reset(); zombieAttr = new ZombieBaseAttr(zombieDefaultAttr);
			base.Reset();
			zombieAttr = new ZombieBaseAttr(zombieDefaultAttr);
		}

		public override float GetMaxHealth()
		{
			// pseudocode: returns *(uint*)(zombieAttr + 0x10) == zombieAttr.maxHealth.
			return zombieAttr.maxHealth;
		}

		public override void SetMaxHealthAndShow(int value)
		{
			// pseudocode forwards the delta to the ChangeMaxHealthAndShow virtual slot:
			//   ChangeMaxHealthAndShow((float)value - zombieAttr.maxHealth);
			ChangeMaxHealthAndShow(value - zombieAttr.maxHealth);
		}

		public override void ChangeMaxHealthAndShow(float value)
		{
			// pseudocode: no-op on zero; otherwise zombieAttr.maxHealth += value and pop a
			// value indicator (>=0 => good, <0 => bad) at GetPosition().
			if (value == 0f)
			{
				return;
			}
			if (zombieAttr == null)
			{
				return;
			}
			zombieAttr.maxHealth += value;
			// Vector2 pos = GetPosition();
			// if (value >= 0f) valueBox.CreateGoodValue(pos, ...);
			// else             valueBox.CreateBadValue(pos, ...);
			// TODO: reconstruct value-indicator display (unresolved GameManager -> ValueBox singleton chain).
		}

		public override void ChangeAttackAndShow(int value)
		{
			// pseudocode: no-op on zero; otherwise zombieAttr.attack (+0x30) += value and pop a
			// value indicator (<0 => bad, else good) at GetPosition().
			if (value == 0)
			{
				return;
			}
			if (zombieAttr == null)
			{
				return;
			}
			zombieAttr.attack += value;
			// Vector2 pos = GetPosition();
			// if (value < 0) valueBox.CreateBadValue(pos, ...);
			// else           valueBox.CreateGoodValue(pos, ...);
			// TODO: reconstruct value-indicator display (unresolved GameManager -> ValueBox singleton chain).
		}

		public override void ChangeMagicAndShow(int value)
		{
			// pseudocode: no-op on zero; otherwise zombieAttr.magic (+0x34) += value and pop a
			// value indicator (<0 => bad, else good) at GetPosition().
			if (value == 0)
			{
				return;
			}
			if (zombieAttr == null)
			{
				return;
			}
			zombieAttr.magic += value;
			// Vector2 pos = GetPosition();
			// if (value < 0) valueBox.CreateBadValue(pos, ...);
			// else           valueBox.CreateGoodValue(pos, ...);
			// TODO: reconstruct value-indicator display (unresolved GameManager -> ValueBox singleton chain).
		}

		public override void ChangeAttackSpeedAndShow(float ratio)
		{
			// pseudocode: no-op on zero; requires both zombieAttr and zombieDefaultAttr.
			// New attack speed = ratio * zombieDefaultAttr.attackSpeed + zombieAttr.attackSpeed,
			// written through the AttackSpeed property (set_AttackSpeed, which clamps + recomputes
			// the attack interval). Then pop a percentage value indicator (>=0 => good, else bad).
			if (ratio == 0f)
			{
				return;
			}
			if (zombieAttr == null || zombieDefaultAttr == null)
			{
				return;
			}
			zombieAttr.AttackSpeed = ratio * zombieDefaultAttr.attackSpeed + zombieAttr.attackSpeed;
			// Vector2 pos = GetPosition();
			// if (ratio >= 0f) valueBox.CreateGoodValue(pos, ..., isPercentage: true);
			// else             valueBox.CreateBadValue(pos, ..., isPercentage: true);
			// TODO: reconstruct value-indicator display (unresolved GameManager -> ValueBox singleton chain).
		}

		public override void ChangeWalkSpeedAndShow(float ratio)
		{
			// pseudocode: no-op on zero; requires both zombieAttr and zombieDefaultAttr.
			// zombieAttr.walkSpeedRatio (+0x2C) += ratio * zombieDefaultAttr.walkSpeedRatio.
			// Then pop a percentage value indicator (>=0 => good, else bad) at GetPosition().
			if (ratio == 0f)
			{
				return;
			}
			if (zombieAttr == null || zombieDefaultAttr == null)
			{
				return;
			}
			zombieAttr.walkSpeedRatio += ratio * zombieDefaultAttr.walkSpeedRatio;
			// Vector2 pos = GetPosition();
			// if (ratio >= 0f) valueBox.CreateGoodValue(pos, ..., isPercentage: true);
			// else             valueBox.CreateBadValue(pos, ..., isPercentage: true);
			// TODO: reconstruct value-indicator display (unresolved GameManager -> ValueBox singleton chain).
		}
	}
}
