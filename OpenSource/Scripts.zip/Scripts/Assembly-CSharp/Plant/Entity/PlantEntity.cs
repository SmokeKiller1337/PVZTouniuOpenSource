using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Bullet.Entity;
using Bullet.Manager;
using Common.Entity;
using FairyGUI;
using FGUI.Entity.UI;
using Game.Manager;
using Game.Util;
using Land.Entity;
using Level.Entity;
using Level.Manager;
using Level.Util;
using NoSLoofah.BuffSystem;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity
{
	public abstract class PlantEntity : BaseBody
	{
		// NOTE: The nested compiler-generated iterator classes below are kept so that
		// StartCoroutine(...) call-sites keep compiling. Their MoveNext bodies were
		// reconstructed from the pseudocode state machines.

		[CompilerGenerated]
		private sealed class _003CChangeSleepStateCoroutine_003Ed__85 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public PlantEntity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CChangeSleepStateCoroutine_003Ed__85(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				PlantEntity plantEntity = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					// yield return null; (wait one frame before switching the sleep animation)
					_003C_003E2__current = null;
					_003C_003E1__state = 1;
					return true;
				}
				if (num != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (plantEntity != null && plantEntity.partEntity != null)
				{
					if (!plantEntity.partEntity.isSleeping)
					{
						if (plantEntity._animator != null)
						{
							// TODO: animation state names are data pointers in the pseudocode.
							plantEntity._animator.Play(PlantEntity.AwakeAnimName);
							plantEntity._animator.Play(PlantEntity.AwakeIdleAnimName);
						}
					}
					else if (plantEntity._animator != null)
					{
						// TODO: animation state names are data pointers in the pseudocode.
						plantEntity._animator.Play(PlantEntity.SleepAnimName);
						plantEntity._animator.Play(PlantEntity.SleepIdleAnimName);
					}
					plantEntity._sleepCoroutine = null;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower0_003Ed__60 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower0_003Ed__60(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					// yield return null;
					_003C_003E2__current = null;
					_003C_003E1__state = 1;
					return true;
				}
				if (num == 1)
				{
					_003C_003E1__state = -1;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003COnUsePower1_003Ed__61 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003COnUsePower1_003Ed__61(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					// yield return null;
					_003C_003E2__current = null;
					_003C_003E1__state = 1;
					return true;
				}
				if (num == 1)
				{
					_003C_003E1__state = -1;
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		// TODO: The following animation-state name constants are data pointers in the
		// pseudocode that could not be resolved to their literal strings. Replace with
		// the real Animator state names when known.
		private const string AwakeAnimName = "Awake"; // TODO: reconstruct literal
		private const string AwakeIdleAnimName = "AwakeIdle"; // TODO: reconstruct literal
		private const string SleepAnimName = "Sleep"; // TODO: reconstruct literal
		private const string SleepIdleAnimName = "SleepIdle"; // TODO: reconstruct literal
		private const string EyeBlinkAnimName = "EyeBlink"; // TODO: reconstruct literal
		private const string BlinkTag = "Blink"; // TODO: reconstruct animator tag literal

		[Tooltip("属性")]
		public PlantBaseAttr attr;

		[Tooltip("默认属性")]
		public PlantBaseAttr defaultAttr;

		[Tooltip("是否有大招")]
		public bool isHasSpecialSkill;

		[Tooltip("大招冷却时间")]
		public float specialCooldownTime;

		[HideInInspector]
		public float specialCooldownTimer;

		[HideInInspector]
		public PlantPartEntity partEntity;

		private CardEntity _cardEntity;

		private CardEntity _extraCardEntity;

		protected Coroutine _sleepCoroutine;

		public override LandEntity CurrentLandEntity
		{
			get
			{
				// currentLandList[0] (BaseBody field at 0x40)
				if (currentLandList.Count < 1)
				{
					return null;
				}
				return currentLandList[0];
			}
			set
			{
				// Replace the single element the plant tracks: clear then add.
				currentLandList.Clear();
				currentLandList.Add(value);
			}
		}

		public bool IsHasCardSlot
		{
			get
			{
				// CardEntity != null && LevelUtils.GetCard(CardEntity.id).xxx != null
				CardEntity card = CardEntity;
				// TODO: LevelUtils.GetCard returns a card definition whose first reference
				// field (offset 0x10) is compared for null. Exact member name unknown.
				CardEntity def = LevelUtils.GetCard(card.id);
				if (def == null)
				{
					return false;
				}
				return def.attr != null;
			}
		}

		public CardEntity CardEntity
		{
			get
			{
				// Lazily look up the card by id from the global card slot manager if the
				// backing field has not been assigned yet.
				if (_cardEntity != null)
				{
					return _cardEntity;
				}
				return CardSlotManager.Instance.GetCard(id);
			}
			set
			{
				_cardEntity = value;
			}
		}

		public CardEntity ExtraCardEntity
		{
			get
			{
				return _extraCardEntity;
			}
			set
			{
				_extraCardEntity = value;
			}
		}

		private bool IsPlaying
		{
			get
			{
				// TODO: reconstruct — the getter tail-calls an unresolved delegate/global
				// (jump table not recovered). Original likely returns whether the reanim /
				// animator is currently playing.
				return false;
			}
		}

		public float defaultTransitionDuration
		{
			get
			{
				// attr (0xE0). If attackSpeed (0x28) > 0 return DefaultTransitionConst /
				// (attackSpeed * FrameRateConst) else 0.
				if (attr.attackSpeed > 0f)
				{
					// TODO: the two named constants below are globals in the pseudocode.
					return DefaultTransitionNumerator / (attr.attackSpeed * AttackSpeedFrameRate);
				}
				return 0f;
			}
		}

		// TODO: unresolved global constants used by defaultTransitionDuration / Attack.
		private const float DefaultTransitionNumerator = 1f; // TODO: reconstruct constant
		private const float AttackSpeedFrameRate = 30f; // TODO: reconstruct constant

		public override void Reset()
		{
			base.Reset();
			CardEntity card = CardEntity;
			if (ExtraCardEntity != null)
			{
				card = ExtraCardEntity;
			}
			// title (BaseBody @0x28 = param_1[5]) = card.title (CardEntity.title @0x28)
			title = card.title;
			// defaultAttr (@0xE8 = param_1[0x1d]) = new PlantBaseAttr(card.plantAttr @0x88)
			defaultAttr = new PlantBaseAttr(card.plantAttr);
			// priority (BaseBody @0x70) = card.priority (CardEntity.priority @0x50)
			priority = card.priority;
			if (partEntity != null)
			{
				// partEntity.sleepType (0x10) = card.sleepType (0x48)
				partEntity.sleepType = card.sleepType;
				// partEntity.isEyeAnimation (0x14) = card.isEyeAnimation (0x68)
				partEntity.isEyeAnimation = card.isEyeAnimation;
				// map card.placeType (0x4C) -> addSortingOrder ((longlong)param_1 + 0x74)
				switch ((int)card.placeType)
				{
					case 0:
						addSortingOrder = 0;
						break;
					case 1:
						addSortingOrder = 2;
						break;
					case 2:
						addSortingOrder = -1;
						break;
					case 3:
						addSortingOrder = 1;
						break;
				}
				// param_1[0x1c] (0xE0 attr) = new PlantBaseAttr(defaultAttr)
				attr = new PlantBaseAttr(defaultAttr);
				attr.Reset();
				CardEntity card2 = CardEntity;
				if (card2 != null && card2.plantAttr != null)
				{
					// attr.currentHealth (0x14) = card.plantAttr.currentHealth (0x14)
					attr.currentHealth = card2.plantAttr.currentHealth;
					// partEntity.blinkTimer (0x18) = Random.Range(min, max)
					partEntity.blinkTime = UnityEngine.Random.Range(EyeBlinkMin, EyeBlinkMax);
					partEntity.blinkTimer = 0f;
					// partEntity + 0x15 (isSleep) and +0x16 (isEyeClose) cleared
					partEntity.isSleeping = false;
					partEntity.isCloseEye = false;
					UpdateHealthTextField();
					if (attr.currentHealth <= 0f)
					{
						Clear();
					}
					ResetSleep();
				}
			}
		}

		// TODO: unresolved random-range bounds for eye blink interval.
		private const float EyeBlinkMin = 2f; // TODO: reconstruct constant
		private const float EyeBlinkMax = 6f; // TODO: reconstruct constant

		public virtual void ResetLevel()
		{
			CardEntity card = CardEntity;
			for (int i = 0; i < card.level; i++)
			{
				LevelUp(i + 1);
				card = CardEntity;
			}
		}

		public virtual void ResetSleep()
		{
			if (partEntity == null)
			{
				return;
			}
			// Whether this plant should currently be asleep depends on the level's
			// day/night state, resolved by IsNeedSleep().
			bool shouldSleep = IsNeedSleep();
			// partEntity.isSleep (0x15)
			if (partEntity.isSleeping != shouldSleep)
			{
				// sleepObj (0x58 = param_1[0xb])
				if (sleepObj != null)
				{
					sleepObj.SetActive(shouldSleep);
				}
				partEntity.isSleeping = shouldSleep;
				if (_sleepCoroutine != null)
				{
					StopCoroutine(_sleepCoroutine);
				}
				_sleepCoroutine = StartCoroutine(ChangeSleepStateCoroutine());
			}
		}

		protected override void Awake()
		{
			// TODO: reconstruct - the pseudocode resolves partEntity via a child
			// GetComponent chain, but PlantPartEntity is a plain [Serializable] class,
			// not a UnityEngine.Component, so the exact component types requested here
			// are data pointers that cannot be recovered. Left as a no-op so partEntity
			// keeps its serialized/assigned value.
		}

		protected override void Start()
		{
			base.Start();
			CardEntity card = CardEntity;
			if (card == null)
			{
				return;
			}
			// card.OnLevelUp (0xC0) += <Start>b__27_0
			card.OnLevelUp += _003CStart_003Eb__27_0;
			// if (CurrentLandEntity != null) CurrentLandEntity.ResetShowHealth();
			if (CurrentLandEntity != null)
			{
				CurrentLandEntity.ResetShowHealth();
			}
		}

		protected override void Update()
		{
			base.Update();
			if (partEntity == null)
			{
				return;
			}
			// only tick while not sleeping
			if (partEntity.isSleeping)
			{
				return;
			}
			PlantBaseAttr a = attr;
			if (a.attackIntervalTime > 0f)
			{
				a.attackIntervalTimer += Time.deltaTime;
				if (a.attackIntervalTimer >= a.attackIntervalTime)
				{
					a.attackIntervalTimer = 0f;
					if (CheckAttack())
					{
						Attack();
					}
				}
			}
			EyeUpdate();
			// param_1[0x1e] (isHasSpecialSkill 0xF0), param_1 + 0x1f (specialCooldownTimer 0xF8)
			if (isHasSpecialSkill && specialCooldownTimer > 0f)
			{
				specialCooldownTimer -= Time.deltaTime;
			}
		}

		protected override void UpdateSortingOrder()
		{
			// _rigidbody (0x80 = param_1[0x10])
			if (_rigidbody == null)
			{
				return;
			}
			Vector2 pos = _rigidbody.position;
			// _sortingGroup (0x98 = param_1[0x13])
			if (_sortingGroup != null)
			{
				// order = Mathf.RoundToInt(-pos.y * scale) + addSortingOrder
				int order = Mathf.RoundToInt(-pos.y * SortingOrderScale) + addSortingOrder;
				_sortingGroup.sortingOrder = order;
			}
		}

		// TODO: unresolved global constant used to convert world Y to sorting order.
		private const float SortingOrderScale = 100f; // TODO: reconstruct constant

		public override void SetFlipX(bool isFlipX)
		{
			// Flip the sign of localScale.x on transform (and on uiTransform at 0xB8 if set).
			Transform t = transform;
			if (t == null)
			{
				return;
			}
			float sx = Mathf.Abs(t.localScale.x);
			if (isFlipX)
			{
				sx = -sx;
			}
			Vector3 s = t.localScale;
			t.localScale = new Vector3(sx, s.y, s.z);
			// uiTransform (0xB8)
			if (uiTransform != null)
			{
				float usx = Mathf.Abs(uiTransform.localScale.x);
				if (isFlipX)
				{
					usx = -usx;
				}
				Vector3 us = uiTransform.localScale;
				uiTransform.localScale = new Vector3(usx, us.y, us.z);
			}
		}

		public override Vector2 GetPosition()
		{
			return transform.position;
		}

		public override int GetRow()
		{
			if (CurrentLandEntity == null)
			{
				return -1;
			}
			return CurrentLandEntity.rowId;
		}

		public override int GetColumn()
		{
			if (CurrentLandEntity == null)
			{
				return -1;
			}
			return CurrentLandEntity.columnId;
		}

		public override bool IsNotPick()
		{
			// attr.isNotPick1 (0x1A) || attr.isNotPick2 (0x1B)
			if (attr.isNotPick1)
			{
				return true;
			}
			return attr.isNotPick2;
		}

		public override bool IsNotPick0()
		{
			return false;
		}

		public override bool IsNotEat()
		{
			// attr.isNotEat (0x19)
			return attr.isNotEat;
		}

		public virtual BulletEntity CreateBullet(int index = 0)
		{
			// CreateBullet(index, transform.position)
			return CreateBullet(index, transform.position);
		}

		public virtual BulletEntity CreateBullet(int index, Vector2 startPosition)
		{
			// Compute muzzle offset from a global config, mirrored on flip.
			float offsetX;
			float offsetY;
			// TODO: _DAT_182e706b8 is a global config holder; the four floats at
			// 0x20/0x24/0x28/0x2c are the flipped / un-flipped muzzle offsets.
			if (!IsFlipX)
			{
				offsetY = MuzzleOffsetY;
				offsetX = MuzzleOffsetX;
			}
			else
			{
				offsetY = MuzzleOffsetFlipY;
				offsetX = MuzzleOffsetFlipX;
			}
			BulletManager manager = BulletManager.Instance;
			BulletAttr bulletAttr = bulletList[index];
			Vector2 spawn = new Vector2(startPosition.x + offsetX, startPosition.y + offsetY);
			BulletEntity bullet = manager.CreateBullet(this, bulletAttr, startPosition, spawn);
			if (bullet != null && attr != null && bullet.attr != null)
			{
				// bullet.attr.damage (BulletAttr.damage @0x10) = attr.attack (PlantBaseAttr.attack @0x20)
				bullet.attr.damage = attr.attack;
			}
			return bullet;
		}

		// TODO: unresolved muzzle-offset config globals.
		private const float MuzzleOffsetX = 0f; // TODO: reconstruct constant
		private const float MuzzleOffsetY = 0f; // TODO: reconstruct constant
		private const float MuzzleOffsetFlipX = 0f; // TODO: reconstruct constant
		private const float MuzzleOffsetFlipY = 0f; // TODO: reconstruct constant

		protected virtual bool CheckAttack()
		{
			// ICF-folded onto a stub that returns true; the real virtual base returns true.
			return true;
		}

		protected virtual void Attack()
		{
			// If attr and _animator exist, play the attack animation at a speed derived
			// from attackSpeed. The play/state target is an unresolved global.
			if (attr != null && _animator != null)
			{
				float speed = attr.attackSpeed * AttackSpeedFrameRate;
				// TODO: animation state name is a data pointer in the pseudocode.
				_animator.Play(PlantEntity.AttackAnimName);
				_animator.speed = speed;
			}
		}

		// TODO: unresolved attack animation state name.
		private const string AttackAnimName = "Attack"; // TODO: reconstruct literal

		public override void ChangeHealth(float value)
		{
			PlantBaseAttr a = attr;
			if (value > 0f)
			{
				// healing: clamp currentHealth up towards maxHealth
				if (a.currentHealth < a.maxHealth)
				{
					float target = value + a.currentHealth;
					if (target >= a.maxHealth)
					{
						target = a.maxHealth;
					}
					a.currentHealth = target;
				}
			}
			else
			{
				// damage: clamp currentHealth down to 0
				float target = value + a.currentHealth;
				if (target <= 0f)
				{
					target = 0f;
				}
				a.currentHealth = target;
			}
			if (attr.currentHealth <= 0f)
			{
				Death();
			}
			UpdateHealthTextField();
		}

		public override void ChangeMaxHealth(float value)
		{
			PlantBaseAttr a = attr;
			a.maxHealth += value;
			ChangeHealth(value);
		}

		public void ResetLandShowHealth()
		{
			if (CurrentLandEntity != null)
			{
				CurrentLandEntity.ResetShowHealth();
			}
		}

		public override void ResetShowHealth()
		{
			// _healthCom (0xC0 = param_1[0x18])
			if (_healthCom == null)
			{
				return;
			}
			// TODO: reconstruct - the pseudocode first gated on a global
			// "show health bar" toggle read from GameManager.Instance.LevelEntity,
			// a type/member that does not exist in the project; that gate (and its
			// hide-branch) is dropped here.
			// Show the health bar only on the land slot that matches this plant's placeType.
			int placeType = -1;
			if (CurrentLandEntity != null)
			{
				LandEntity land = CurrentLandEntity;
				if (land.shellPlant != null)
				{
					placeType = 1;
				}
				else if (land.floatPlant != null)
				{
					placeType = 3;
				}
				else if (land.masterPlant != null)
				{
					placeType = 0;
				}
				else if (land.basePlant != null)
				{
					placeType = 2;
				}
			}
			CardEntity card = CardEntity;
			if (card != null)
			{
				_healthCom.visible = ((int)card.placeType == placeType);
				UpdateHealthTextField();
			}
		}

		protected override void UpdateHealthTextField()
		{
			// TODO: reconstruct - the pseudocode also gated this on a global
			// "show health bar" toggle read from GameManager.Instance.LevelEntity,
			// a type/member that does not exist in the project; that gate is dropped.
			if (_healthTextField == null)
			{
				return;
			}
			// _healthTextField (0xC8 = param_1 + 200)
			if (attr != null)
			{
				_healthTextField.text = attr.currentHealth.ToString();
				// color green when full, red otherwise
				Color color = HealthTextColorLow;
				if (attr.maxHealth <= attr.currentHealth)
				{
					color = HealthTextColorFull;
				}
				_healthTextField.color = color;
			}
		}

		// TODO: unresolved health-text colors (Color structs stored as globals).
		private static readonly Color HealthTextColorFull = Color.green; // TODO: reconstruct color
		private static readonly Color HealthTextColorLow = Color.red; // TODO: reconstruct color

		public override bool Hit(float value, DamageTypeEntity damageType = null, BulletEntity sourceBullet = null)
		{
			if (damageType == null)
			{
				damageType = DamageTypeEntity.Common;
			}
			// invincible?
			if (attr.isInvincible)
			{
				return false;
			}
			if (damageType != null)
			{
				// isReward (0x1A) == 2 path in pseudocode compares damageType.damageType==2
				if ((int)damageType.damageType == 2)
				{
					// immuneBuffIdList (0x38 = param_1[7]) contains buff id 4 => immune
					if (immuneBuffIdList.Contains(4))
					{
						return false;
					}
					// attr.isNotPick2 (0x1B) also blocks this damage type
					if (attr.isNotPick2)
					{
						return false;
					}
				}
				// TODO: reconstruct - the pseudocode also gated this on a global
				// "damage disabled" flag read from GameManager.Instance.LevelEntity,
				// a type/member that does not exist in the project; that guard is
				// dropped here. The non-positive-damage guard below is preserved.
				if (value <= 0f)
				{
					return false;
				}
				// deathType (0x14) == 1 special handling
				if ((int)damageType.deathType == 1 && value >= attr.currentHealth)
				{
					// lethal instant-death: apply the instant-kill buff instead of damage
					if (_buffHandler != null)
					{
						// TODO: buff id (4) and duration constant taken from pseudocode.
						_buffHandler.AddBuff(4, null, InstantKillBuffDuration);
						return true;
					}
				}
				else
				{
					ChangeHealth(-value);
					Flicker();
					return true;
				}
			}
			return false;
		}

		// TODO: unresolved instant-kill buff duration constant.
		private const float InstantKillBuffDuration = 0f; // TODO: reconstruct constant

		public override void HitEat(float value, ZombieEntity zombieEntity)
		{
			// ICF-folded: forwards to the same damage entry-point. The pseudocode simply
			// invokes a virtual slot on this instance with the eaten value.
			// TODO: reconstruct — exact routed method (0x238) not resolvable from the dump.
			Hit(value, DamageTypeEntity.Common);
		}

		public override void Death()
		{
			DeathHandle();
			ClearLand();
			// Destroy(gameObject)
			UnityEngine.Object.Destroy(gameObject);
		}

		public override void DeathHandle()
		{
			// OnDeathAction (0xD8) invocation
			if (OnDeathAction != null)
			{
				OnDeathAction();
			}
		}

		public override void Clear()
		{
			// _lastDamageType (0xB0 = param_1[0x16]) = DamageTypeEntity.Clear; then Death()
			_lastDamageType = DamageTypeEntity.Clear;
			Death();
		}

		public override void Remove()
		{
			_lastDamageType = DamageTypeEntity.Remove;
			Death();
		}

		public void ClearLand()
		{
			if (CurrentLandEntity == null)
			{
				return;
			}
			LandEntity land = CurrentLandEntity;
			CardEntity card = CardEntity;
			// Detach this plant from the matching land slot based on placeType.
			switch ((int)card.placeType)
			{
				case 0:
					if (land.masterPlant == this)
					{
						land.masterPlant = null;
					}
					break;
				case 1:
					if (land.shellPlant == this)
					{
						land.shellPlant = null;
					}
					break;
				case 2:
					if (land.basePlant == this)
					{
						land.basePlant = null;
					}
					break;
				case 3:
					if (land.floatPlant == this)
					{
						land.floatPlant = null;
					}
					break;
			}
			// clear our own land reference and refresh the land's health display
			CurrentLandEntity = null;
			land.ResetShowHealth();
		}

		private void LevelUp(int level)
		{
			CardEntity card = CardEntity;
			if (card == null || card.cardStrengthenEntity == null)
			{
				return;
			}
			// OnLevelUp(cardStrengthenEntity.base) (0x10 field on strengthen entity)
			OnLevelUp(card.cardStrengthenEntity.level0);
			if (level == 1)
			{
				card = CardEntity;
				int idx = card.hasStrengthenDic[1];
				StrengthenEntity entity = card.cardStrengthenEntity.level1List[idx];
				entity.index = idx;
				OnLevelUp1(entity);
			}
			else if (level == 2)
			{
				card = CardEntity;
				int idx = card.hasStrengthenDic[2];
				StrengthenEntity entity = card.cardStrengthenEntity.level2List[idx];
				entity.index = idx;
				OnLevelUp2(entity);
			}
			else if (level == 3)
			{
				card = CardEntity;
				int idx = card.hasStrengthenDic[3];
				StrengthenEntity entity = card.cardStrengthenEntity.level3List[idx];
				entity.index = idx;
				OnLevelUp3(entity);
			}
		}

		protected virtual void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected virtual void OnLevelUp1(StrengthenEntity entity)
		{
		}

		protected virtual void OnLevelUp2(StrengthenEntity entity)
		{
		}

		protected virtual void OnLevelUp3(StrengthenEntity entity)
		{
		}

		public StrengthenEntity GetStrengthenEntity(int level, int index = -1)
		{
			CardEntity card = CardEntity;
			if (card == null)
			{
				return null;
			}
			// LevelUtils.GetCard(card.id) must exist
			if (LevelUtils.GetCard(card.id) == null)
			{
				return null;
			}
			card = CardEntity;
			int idx = card.hasStrengthenDic[level];
			if (index != -1 && idx != index)
			{
				return null;
			}
			List<StrengthenEntity> list;
			if (level == 1)
			{
				card = CardEntity;
				if (card.cardStrengthenEntity == null)
				{
					return null;
				}
				list = card.cardStrengthenEntity.level1List;
			}
			else if (level == 2)
			{
				card = CardEntity;
				if (card.cardStrengthenEntity == null)
				{
					return null;
				}
				list = card.cardStrengthenEntity.level2List;
			}
			else if (level == 3)
			{
				card = CardEntity;
				if (card.cardStrengthenEntity == null)
				{
					return null;
				}
				list = card.cardStrengthenEntity.level3List;
			}
			else
			{
				return null;
			}
			return list[idx];
		}

		public virtual void UsePower()
		{
			CardEntity card = CardEntity;
			if (card == null || card.hasStrengthenDic == null)
			{
				return;
			}
			int idx = card.hasStrengthenDic[3];
			if (idx == -1)
			{
				return;
			}
			card = CardEntity;
			// card.attr (0x70) is CardBaseAttr; isPowerCooldown (0x2C)
			if (card.attr.isPowerCooldown)
			{
				return;
			}
			card = CardEntity;
			card.attr.isPowerCooldown = true;
			// powerCooldownTimer (0x28) = powerCooldownTime (0x24)
			card.attr.powerCooldownTimer = card.attr.powerCooldownTime;
			if (partEntity == null)
			{
				return;
			}
			if (partEntity.isSleeping)
			{
				ChangeSleep(false);
			}
			card = CardEntity;
			if (card == null || card.cardStrengthenEntity == null)
			{
				return;
			}
			StrengthenEntity entity = card.cardStrengthenEntity.level3List[idx];
			entity.index = idx;
			if (idx == 0)
			{
				StartCoroutine(OnUsePower0(entity));
			}
			else if (idx == 1)
			{
				StartCoroutine(OnUsePower1(entity));
			}
			// TODO: reconstruct - the pseudocode then spawned a floating power text box
			// (via GameManager.Instance.PowerTextBoxLayer / a 3-arg PowerTextBoxEntity.Create)
			// and a power effect (via LevelAssetsManager.powerEffect + GameUtils.CreateEffect).
			// Those manager members / overloads do not exist in the project, so the visual
			// spawn is dropped here.
		}

		[IteratorStateMachine(typeof(_003COnUsePower0_003Ed__60))]
		protected virtual IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			return new _003COnUsePower0_003Ed__60(0);
		}

		[IteratorStateMachine(typeof(_003COnUsePower1_003Ed__61))]
		protected virtual IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			return new _003COnUsePower1_003Ed__61(0);
		}

		public override void OnTriggerBodyEnter(Collider2D col)
		{
		}

		public override void OnTriggerBodyExit(Collider2D col)
		{
		}

		public override void OnTriggerBodyStay(Collider2D col)
		{
		}

		public override void OnTriggerEatEnter(Collider2D col)
		{
		}

		public override void OnTriggerEatExit(Collider2D col)
		{
		}

		public override void OnTriggerEatStay(Collider2D col)
		{
		}

		public override void OnTriggerCustomEnter(Collider2D col, int index)
		{
		}

		public override void OnTriggerCustomExit(Collider2D col, int index)
		{
		}

		public override void OnTriggerCustomStay(Collider2D col, int index)
		{
		}

		public virtual void OnPlantClick()
		{
		}

		public virtual void OnPlantEnter()
		{
		}

		public virtual void OnPlantExit()
		{
		}

		public void SetMaxHealthAndShow(int value)
		{
			// ChangeMaxHealthAndShow(value - attr.maxHealth)
			ChangeMaxHealthAndShow((float)value - attr.maxHealth);
		}

		public override void ChangeMaxHealthAndShow(float value)
		{
			if (value == 0f)
			{
				return;
			}
			// If this plant is a shell block, delegate the display to the shell plant.
			if (IsShellBlock() && CurrentLandEntity != null && CurrentLandEntity.shellPlant != null)
			{
				CurrentLandEntity.shellPlant.ChangeMaxHealthAndShow(value);
				return;
			}
			ChangeMaxHealth(value);
			// TODO: reconstruct - the pseudocode then popped a floating value indicator
			// via GameManager.Instance.ValueBoxLayer and ValueBoxEntity.CreateGoodValue/
			// CreateBadValue. That manager member does not exist and those methods are
			// instance methods with a different signature, so the visual is dropped here.
		}

		// TODO: unresolved value-box label literals.
		private const string MaxHealthValueLabel = ""; // TODO: reconstruct literal
		private const string AttackValueLabel = ""; // TODO: reconstruct literal
		private const string MagicValueLabel = ""; // TODO: reconstruct literal
		private const string AttackSpeedValueLabel = ""; // TODO: reconstruct literal

		public override void ChangeAttackAndShow(int value)
		{
			if (value == 0)
			{
				return;
			}
			if (attr != null)
			{
				attr.attack += value;
				// TODO: reconstruct - value indicator popped via the non-existent
				// GameManager.Instance.ValueBoxLayer / ValueBoxEntity static calls; dropped.
			}
		}

		public override void ChangeMagicAndShow(int value)
		{
			if (value == 0)
			{
				return;
			}
			if (attr != null)
			{
				attr.magic += value;
				// TODO: reconstruct - value indicator popped via the non-existent
				// GameManager.Instance.ValueBoxLayer / ValueBoxEntity static calls; dropped.
			}
		}

		public override void ChangeAttackSpeedAndShow(float ratio)
		{
			if (ratio == 0f)
			{
				return;
			}
			if (attr != null && defaultAttr != null)
			{
				// attr.AttackSpeed = ratio * defaultAttr.attackSpeed + attr.attackSpeed
				attr.AttackSpeed = ratio * defaultAttr.attackSpeed + attr.attackSpeed;
				// TODO: reconstruct - value indicator popped via the non-existent
				// GameManager.Instance.ValueBoxLayer / ValueBoxEntity static calls; dropped.
			}
		}

		protected virtual void EyeUpdate()
		{
			if (partEntity == null)
			{
				return;
			}
			// Only blink when eye animation enabled and not sleeping.
			if (!partEntity.isEyeAnimation || partEntity.isSleeping)
			{
				return;
			}
			// partEntity.eyeBlinkTimer (0x1c) += deltaTime
			partEntity.blinkTimer += Time.deltaTime;
			// once timer reaches interval (0x18) -> blink and roll a new interval
			if (partEntity.blinkTimer < partEntity.blinkTime)
			{
				return;
			}
			EyeBlink();
			partEntity.blinkTimer = 0f;
			partEntity.blinkTime = UnityEngine.Random.Range(EyeBlinkMin, EyeBlinkMax);
		}

		public virtual void EyeBlink()
		{
			if (partEntity == null)
			{
				return;
			}
			// Don't blink while eyes are closed (isEyeClose at 0x16).
			if (partEntity.isCloseEye)
			{
				return;
			}
			if (_animator == null)
			{
				return;
			}
			AnimatorStateInfo state = _animator.GetCurrentAnimatorStateInfo(0);
			// Only trigger a blink if the current state carries the blink tag.
			if (state.IsTag(BlinkTag))
			{
				_animator.Play(EyeBlinkAnimName);
			}
		}

		public virtual void EyeOpen()
		{
			if (partEntity == null)
			{
				return;
			}
			// isEyeClose (0x16): only act if currently closed
			if (!partEntity.isCloseEye)
			{
				return;
			}
			partEntity.isCloseEye = false;
			if (_animator != null)
			{
				// Animator.Play(hash, layer, normalizedTime)
				// TODO: eye-open state name is a data pointer in the pseudocode.
				_animator.Play(Animator.StringToHash(EyeOpenAnimName), -1, EyeStateNormalizedTime);
			}
		}

		public virtual void EyeClose()
		{
			if (partEntity == null)
			{
				return;
			}
			if (partEntity.isCloseEye)
			{
				return;
			}
			partEntity.isCloseEye = true;
			if (_animator != null)
			{
				// TODO: eye-close state name is a data pointer in the pseudocode.
				_animator.Play(Animator.StringToHash(EyeCloseAnimName), -1, EyeStateNormalizedTime);
			}
		}

		// TODO: unresolved eye animation names / normalized time constant.
		private const string EyeOpenAnimName = "EyeOpen"; // TODO: reconstruct literal
		private const string EyeCloseAnimName = "EyeClose"; // TODO: reconstruct literal
		private const float EyeStateNormalizedTime = 0f; // TODO: reconstruct constant

		public void ChangeSleep(bool flag)
		{
			if (partEntity == null)
			{
				return;
			}
			if (partEntity.isSleeping != flag)
			{
				if (sleepObj != null)
				{
					sleepObj.SetActive(flag);
				}
				partEntity.isSleeping = flag;
				if (_sleepCoroutine != null)
				{
					StopCoroutine(_sleepCoroutine);
				}
				_sleepCoroutine = StartCoroutine(ChangeSleepStateCoroutine());
			}
		}

		[IteratorStateMachine(typeof(_003CChangeSleepStateCoroutine_003Ed__85))]
		protected virtual IEnumerator ChangeSleepStateCoroutine()
		{
			return new _003CChangeSleepStateCoroutine_003Ed__85(0)
			{
				_003C_003E4__this = this
			};
		}

		public virtual bool IsSpecialAvailable()
		{
			// isHasSpecialSkill (0xF0) && specialCooldownTimer (0xF8) <= 0
			if (!isHasSpecialSkill)
			{
				return false;
			}
			return specialCooldownTimer <= 0f;
		}

		public virtual void UseSpecialSkill()
		{
			// start cooldown
			specialCooldownTimer = specialCooldownTime;
			// TODO: reconstruct - the pseudocode then spawned a special effect via
			// LevelAssetsManager.powerEffect + GameUtils.CreateEffect; that manager
			// member does not exist and the CreateEffect overload expects an
			// EffectEntity (not a GameObject), so the effect spawn is dropped here.
		}

		protected void SpecialCooldownEnd()
		{
		}

		public void SpecialStartCooldown()
		{
			// specialCooldownTimer (0xF8) = specialCooldownTime (0xF4)
			specialCooldownTimer = specialCooldownTime;
		}

		protected bool IsNeedSleep()
		{
			// TODO: reconstruct - the pseudocode decided this from the level's day/night
			// state, read from GameManager.Instance.LevelEntity.isNight. Neither the
			// LevelEntity type nor that member exists in the project, so this cannot be
			// reconstructed and is stubbed to "never needs sleep".
			return false;
		}

		protected bool CheckIsFrontZombie(float distance = -1f)
		{
			// TODO: reconstruct - when called with the default distance sentinel the
			// pseudocode resolved the ray length from GameManager.Instance.LevelEntity's
			// zombieHouse / homeHouse. The LevelEntity type and those members do not exist
			// in the project, so the raycast cannot be set up faithfully; stubbed to false.
			return false;
		}

		// TODO: unresolved sentinel / layer-mask literals for CheckIsFrontZombie.
		private const float DefaultDistanceSentinel = -1f; // TODO: reconstruct constant
		private const string FrontZombieLayerName = "Zombie"; // TODO: reconstruct literal

		public virtual int GetHeadNumber()
		{
			// ICF-folded onto a stub returning 1; base returns a single head.
			return 1;
		}

		public virtual bool IsShellBlock()
		{
			CardEntity card = CardEntity;
			if (card == null)
			{
				return false;
			}
			// placeType (0x4C): shell (2) or master (0) blocks
			if ((int)card.placeType == 2)
			{
				return true;
			}
			card = CardEntity;
			return (int)card.placeType == 0;
		}

		[CompilerGenerated]
		private void _003CStart_003Eb__27_0()
		{
			// OnLevelUp handler registered in Start: re-applies the card's current level
			// strengthen effects. Mirrors the body of LevelUp for the card's level index.
			CardEntity card = CardEntity;
			if (card == null)
			{
				return;
			}
			int level = card.level;
			card = CardEntity;
			if (card == null || card.cardStrengthenEntity == null)
			{
				return;
			}
			OnLevelUp(card.cardStrengthenEntity.level0);
			if (level == 1)
			{
				card = CardEntity;
				int idx = card.hasStrengthenDic[1];
				StrengthenEntity entity = card.cardStrengthenEntity.level1List[idx];
				entity.index = idx;
				OnLevelUp1(entity);
			}
			else if (level == 2)
			{
				card = CardEntity;
				int idx = card.hasStrengthenDic[2];
				StrengthenEntity entity = card.cardStrengthenEntity.level2List[idx];
				entity.index = idx;
				OnLevelUp2(entity);
			}
			else if (level == 3)
			{
				card = CardEntity;
				int idx = card.hasStrengthenDic[3];
				StrengthenEntity entity = card.cardStrengthenEntity.level3List[idx];
				entity.index = idx;
				OnLevelUp3(entity);
			}
		}
	}
}
