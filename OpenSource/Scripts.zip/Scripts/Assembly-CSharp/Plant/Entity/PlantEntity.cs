using System;
using System.Collections;
using System.Collections.Generic;
using Bullet.Entity;
using Bullet.Manager;
using Common.Entity;
using FairyGUI;
using FGUI.Entity.UI;
using Game.Manager;
using Game.Util;
using Land.Entity;
using Level.Entity;
using Level.Manager;
using Level.Util;
using NoSLoofah.BuffSystem;
using Strengthen.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity
{
	public abstract class PlantEntity : BaseBody
	{

		private const string AwakeAnimName = "Awake";
		private const string AwakeIdleAnimName = "AwakeIdle";
		private const string SleepAnimName = "Sleep";
		private const string SleepIdleAnimName = "SleepIdle";
		private const string EyeBlinkAnimName = "EyeBlink";
		private const string BlinkTag = "Blink";

		[Tooltip("属性")]
		public PlantBaseAttr attr;

		[Tooltip("默认属性")]
		public PlantBaseAttr defaultAttr;

		[Tooltip("是否有大招")]
		public bool isHasSpecialSkill;

		[Tooltip("大招冷却时间")]
		public float specialCooldownTime;

		[HideInInspector]
		public float specialCooldownTimer;

		[HideInInspector]
		public PlantPartEntity partEntity;

		private CardEntity _cardEntity;

		private CardEntity _extraCardEntity;

		protected Coroutine _sleepCoroutine;

		public override LandEntity CurrentLandEntity
		{
			get
			{
				// currentLandList[0] (BaseBody field at 0x40)
				if (currentLandList.Count < 1)
				{
					return null;
				}
				return currentLandList[0];
			}
			set
			{
				// Replace the single element the plant tracks: clear then add.
				currentLandList.Clear();
				currentLandList.Add(value);
			}
		}

		public bool IsHasCardSlot
		{
			get
			{
				// CardEntity != null && LevelUtils.GetCard(CardEntity.id).xxx != null
				CardEntity card = CardEntity;
				// TODO: LevelUtils.GetCard returns a card definition whose first reference
				// field (offset 0x10) is compared for null. Exact member name unknown.
				CardEntity def = LevelUtils.GetCard(card.id);
				if (def == null)
				{
					return false;
				}
				return def.attr != null;
			}
		}

		public CardEntity CardEntity
		{
			get
			{
				// Lazily look up the card by id from the global card slot manager if the
				// backing field has not been assigned yet.
				if (_cardEntity != null)
				{
					return _cardEntity;
				}
				return CardSlotManager.Instance.GetCard(id);
			}
			set
			{
				_cardEntity = value;
			}
		}

		public CardEntity ExtraCardEntity
		{
			get
			{
				return _extraCardEntity;
			}
			set
			{
				_extraCardEntity = value;
			}
		}

		private bool IsPlaying
		{
			get
			{
				return false;
			}
		}

		public float defaultTransitionDuration
		{
			get
			{
				// attr (0xE0). If attackSpeed (0x28) > 0 return DefaultTransitionConst /
				// (attackSpeed * FrameRateConst) else 0.
				if (attr.attackSpeed > 0f)
				{
					return DefaultTransitionNumerator / (attr.attackSpeed * AttackSpeedFrameRate);
				}
				return 0f;
			}
		}

		// TODO: unresolved global constants used by defaultTransitionDuration / Attack.
		private const float DefaultTransitionNumerator = 1f;
		private const float AttackSpeedFrameRate = 30f;

		public override void Reset()
		{
			base.Reset();
			CardEntity card = CardEntity;
			if (ExtraCardEntity != null)
			{
				card = ExtraCardEntity;
			}
			title = card.title;
			defaultAttr = new PlantBaseAttr(card.plantAttr);
			priority = card.priority;
			if (partEntity != null)
			{
				// partEntity.sleepType (0x10) = card.sleepType (0x48)
				partEntity.sleepType = card.sleepType;
				// partEntity.isEyeAnimation (0x14) = card.isEyeAnimation (0x68)
				partEntity.isEyeAnimation = card.isEyeAnimation;
				// map card.placeType (0x4C) -> addSortingOrder ((longlong)param_1 + 0x74)
				switch ((int)card.placeType)
				{
					case 0:
						addSortingOrder = 0;
						break;
					case 1:
						addSortingOrder = 2;
						break;
					case 2:
						addSortingOrder = -1;
						break;
					case 3:
						addSortingOrder = 1;
						break;
				}
				// param_1[0x1c] (0xE0 attr) = new PlantBaseAttr(defaultAttr)
				attr = new PlantBaseAttr(defaultAttr);
				attr.Reset();
				CardEntity card2 = CardEntity;
				if (card2 != null && card2.plantAttr != null)
				{
					// attr.currentHealth (0x14) = card.plantAttr.currentHealth (0x14)
					attr.currentHealth = card2.plantAttr.currentHealth;
					// partEntity.blinkTimer (0x18) = Random.Range(min, max)
					partEntity.blinkTime = UnityEngine.Random.Range(EyeBlinkMin, EyeBlinkMax);
					partEntity.blinkTimer = 0f;
					partEntity.isSleeping = false;
					partEntity.isCloseEye = false;
					UpdateHealthTextField();
					if (attr.currentHealth <= 0f)
					{
						Clear();
					}
					ResetSleep();
				}
			}
		}

		// TODO: unresolved random-range bounds for eye blink interval.
		private const float EyeBlinkMin = 2f;
		private const float EyeBlinkMax = 6f;

		public virtual void ResetLevel()
		{
			CardEntity card = CardEntity;
			for (int i = 0; i < card.level; i++)
			{
				LevelUp(i + 1);
				card = CardEntity;
			}
		}

		public virtual void ResetSleep()
		{
			if (partEntity == null)
			{
				return;
			}
			// Whether this plant should currently be asleep depends on the level's
			// day/night state, resolved by IsNeedSleep().
			bool shouldSleep = IsNeedSleep();
			// partEntity.isSleep (0x15)
			if (partEntity.isSleeping != shouldSleep)
			{
				// sleepObj (0x58 = param_1[0xb])
				if (sleepObj != null)
				{
					sleepObj.SetActive(shouldSleep);
				}
				partEntity.isSleeping = shouldSleep;
				if (_sleepCoroutine != null)
				{
					StopCoroutine(_sleepCoroutine);
				}
				_sleepCoroutine = StartCoroutine(ChangeSleepStateCoroutine());
			}
		}

		protected override void Awake()
		{
		}

		protected override void Start()
		{
			base.Start();
			CardEntity card = CardEntity;
			if (card == null)
			{
				return;
			}
			// card.OnLevelUp (0xC0) += <Start>b__27_0
			card.OnLevelUp += OnCardLevelUp;
			// if (CurrentLandEntity != null) CurrentLandEntity.ResetShowHealth();
			if (CurrentLandEntity != null)
			{
				CurrentLandEntity.ResetShowHealth();
			}
		}

		protected override void Update()
		{
			base.Update();
			if (partEntity == null)
			{
				return;
			}
			// only tick while not sleeping
			if (partEntity.isSleeping)
			{
				return;
			}
			PlantBaseAttr a = attr;
			if (a.attackIntervalTime > 0f)
			{
				a.attackIntervalTimer += Time.deltaTime;
				if (a.attackIntervalTimer >= a.attackIntervalTime)
				{
					a.attackIntervalTimer = 0f;
					if (CheckAttack())
					{
						Attack();
					}
				}
			}
			EyeUpdate();
			// param_1[0x1e] (isHasSpecialSkill 0xF0), param_1 + 0x1f (specialCooldownTimer 0xF8)
			if (isHasSpecialSkill && specialCooldownTimer > 0f)
			{
				specialCooldownTimer -= Time.deltaTime;
			}
		}

		protected override void UpdateSortingOrder()
		{
			// _rigidbody (0x80 = param_1[0x10])
			if (_rigidbody == null)
			{
				return;
			}
			Vector2 pos = _rigidbody.position;
			// _sortingGroup (0x98 = param_1[0x13])
			if (_sortingGroup != null)
			{
				// order = Mathf.RoundToInt(-pos.y * scale) + addSortingOrder
				int order = Mathf.RoundToInt(-pos.y * SortingOrderScale) + addSortingOrder;
				_sortingGroup.sortingOrder = order;
			}
		}

		// TODO: unresolved global constant used to convert world Y to sorting order.
		private const float SortingOrderScale = 100f;

		public override void SetFlipX(bool isFlipX)
		{
			// Flip the sign of localScale.x on transform (and on uiTransform at 0xB8 if set).
			Transform t = transform;
			if (t == null)
			{
				return;
			}
			float sx = Mathf.Abs(t.localScale.x);
			if (isFlipX)
			{
				sx = -sx;
			}
			Vector3 s = t.localScale;
			t.localScale = new Vector3(sx, s.y, s.z);
			// uiTransform (0xB8)
			if (uiTransform != null)
			{
				float usx = Mathf.Abs(uiTransform.localScale.x);
				if (isFlipX)
				{
					usx = -usx;
				}
				Vector3 us = uiTransform.localScale;
				uiTransform.localScale = new Vector3(usx, us.y, us.z);
			}
		}

		public override Vector2 GetPosition()
		{
			return transform.position;
		}

		public override int GetRow()
		{
			if (CurrentLandEntity == null)
			{
				return -1;
			}
			return CurrentLandEntity.rowId;
		}

		public override int GetColumn()
		{
			if (CurrentLandEntity == null)
			{
				return -1;
			}
			return CurrentLandEntity.columnId;
		}

		public override bool IsNotPick()
		{
			// attr.isNotPick1 (0x1A) || attr.isNotPick2 (0x1B)
			if (attr.isNotPick1)
			{
				return true;
			}
			return attr.isNotPick2;
		}

		public override bool IsNotPick0()
		{
			return false;
		}

		public override bool IsNotEat()
		{
			// attr.isNotEat (0x19)
			return attr.isNotEat;
		}

		public virtual BulletEntity CreateBullet(int index = 0)
		{
			// CreateBullet(index, transform.position)
			return CreateBullet(index, transform.position);
		}

		public virtual BulletEntity CreateBullet(int index, Vector2 startPosition)
		{
			// Compute muzzle offset from a global config, mirrored on flip.
			float offsetX;
			float offsetY;
			if (!IsFlipX)
			{
				offsetY = MuzzleOffsetY;
				offsetX = MuzzleOffsetX;
			}
			else
			{
				offsetY = MuzzleOffsetFlipY;
				offsetX = MuzzleOffsetFlipX;
			}
			BulletManager manager = BulletManager.Instance;
			BulletAttr bulletAttr = bulletList[index];
			Vector2 spawn = new Vector2(startPosition.x + offsetX, startPosition.y + offsetY);
			BulletEntity bullet = manager.CreateBullet(this, bulletAttr, startPosition, spawn);
			if (bullet != null && attr != null && bullet.attr != null)
			{
				bullet.attr.damage = attr.attack;
			}
			return bullet;
		}

		// TODO: unresolved muzzle-offset config globals.
		private const float MuzzleOffsetX = 0f;
		private const float MuzzleOffsetY = 0f;
		private const float MuzzleOffsetFlipX = 0f;
		private const float MuzzleOffsetFlipY = 0f;

		protected virtual bool CheckAttack()
		{
			return true;
		}

		protected virtual void Attack()
		{
			// If attr and _animator exist, play the attack animation at a speed derived
			// from attackSpeed. The play/state target is an unresolved global.
			if (attr != null && _animator != null)
			{
				float speed = attr.attackSpeed * AttackSpeedFrameRate;
				_animator.Play(PlantEntity.AttackAnimName);
				_animator.speed = speed;
			}
		}

		// TODO: unresolved attack animation state name.
		private const string AttackAnimName = "Attack";

		public override void ChangeHealth(float value)
		{
			PlantBaseAttr a = attr;
			if (value > 0f)
			{
				// healing: clamp currentHealth up towards maxHealth
				if (a.currentHealth < a.maxHealth)
				{
					float target = value + a.currentHealth;
					if (target >= a.maxHealth)
					{
						target = a.maxHealth;
					}
					a.currentHealth = target;
				}
			}
			else
			{
				// damage: clamp currentHealth down to 0
				float target = value + a.currentHealth;
				if (target <= 0f)
				{
					target = 0f;
				}
				a.currentHealth = target;
			}
			if (attr.currentHealth <= 0f)
			{
				Death();
			}
			UpdateHealthTextField();
		}

		public override void ChangeMaxHealth(float value)
		{
			PlantBaseAttr a = attr;
			a.maxHealth += value;
			ChangeHealth(value);
		}

		public void ResetLandShowHealth()
		{
			if (CurrentLandEntity != null)
			{
				CurrentLandEntity.ResetShowHealth();
			}
		}

		public override void ResetShowHealth()
		{
			// _healthCom (0xC0 = param_1[0x18])
			if (_healthCom == null)
			{
				return;
			}
			int placeType = -1;
			if (CurrentLandEntity != null)
			{
				LandEntity land = CurrentLandEntity;
				if (land.shellPlant != null)
				{
					placeType = 1;
				}
				else if (land.floatPlant != null)
				{
					placeType = 3;
				}
				else if (land.masterPlant != null)
				{
					placeType = 0;
				}
				else if (land.basePlant != null)
				{
					placeType = 2;
				}
			}
			CardEntity card = CardEntity;
			if (card != null)
			{
				_healthCom.visible = ((int)card.placeType == placeType);
				UpdateHealthTextField();
			}
		}

		protected override void UpdateHealthTextField()
		{
			if (_healthTextField == null)
			{
				return;
			}
			// _healthTextField (0xC8 = param_1 + 200)
			if (attr != null)
			{
				_healthTextField.text = attr.currentHealth.ToString();
				// color green when full, red otherwise
				Color color = HealthTextColorLow;
				if (attr.maxHealth <= attr.currentHealth)
				{
					color = HealthTextColorFull;
				}
				_healthTextField.color = color;
			}
		}

		// TODO: unresolved health-text colors (Color structs stored as globals).
		private static readonly Color HealthTextColorFull = Color.green;
		private static readonly Color HealthTextColorLow = Color.red;

		public override bool Hit(float value, DamageTypeEntity damageType = null, BulletEntity sourceBullet = null)
		{
			if (damageType == null)
			{
				damageType = DamageTypeEntity.Common;
			}
			// invincible?
			if (attr.isInvincible)
			{
				return false;
			}
			if (damageType != null)
			{
				if ((int)damageType.damageType == 2)
				{
					// immuneBuffIdList (0x38 = param_1[7]) contains buff id 4 => immune
					if (immuneBuffIdList.Contains(4))
					{
						return false;
					}
					// attr.isNotPick2 (0x1B) also blocks this damage type
					if (attr.isNotPick2)
					{
						return false;
					}
				}
				if (value <= 0f)
				{
					return false;
				}
				// deathType (0x14) == 1 special handling
				if ((int)damageType.deathType == 1 && value >= attr.currentHealth)
				{
					// lethal instant-death: apply the instant-kill buff instead of damage
					if (_buffHandler != null)
					{
						_buffHandler.AddBuff(4, null, InstantKillBuffDuration);
						return true;
					}
				}
				else
				{
					ChangeHealth(-value);
					Flicker();
					return true;
				}
			}
			return false;
		}

		// TODO: unresolved instant-kill buff duration constant.
		private const float InstantKillBuffDuration = 0f;

		public override void HitEat(float value, ZombieEntity zombieEntity)
		{
			Hit(value, DamageTypeEntity.Common);
		}

		public override void Death()
		{
			DeathHandle();
			ClearLand();
			// Destroy(gameObject)
			UnityEngine.Object.Destroy(gameObject);
		}

		public override void DeathHandle()
		{
			// OnDeathAction (0xD8) invocation
			if (OnDeathAction != null)
			{
				OnDeathAction();
			}
		}

		public override void Clear()
		{
			// _lastDamageType (0xB0 = param_1[0x16]) = DamageTypeEntity.Clear; then Death()
			_lastDamageType = DamageTypeEntity.Clear;
			Death();
		}

		public override void Remove()
		{
			_lastDamageType = DamageTypeEntity.Remove;
			Death();
		}

		public void ClearLand()
		{
			if (CurrentLandEntity == null)
			{
				return;
			}
			LandEntity land = CurrentLandEntity;
			CardEntity card = CardEntity;
			// Detach this plant from the matching land slot based on placeType.
			switch ((int)card.placeType)
			{
				case 0:
					if (land.masterPlant == this)
					{
						land.masterPlant = null;
					}
					break;
				case 1:
					if (land.shellPlant == this)
					{
						land.shellPlant = null;
					}
					break;
				case 2:
					if (land.basePlant == this)
					{
						land.basePlant = null;
					}
					break;
				case 3:
					if (land.floatPlant == this)
					{
						land.floatPlant = null;
					}
					break;
			}
			// clear our own land reference and refresh the land's health display
			CurrentLandEntity = null;
			land.ResetShowHealth();
		}

		private void LevelUp(int level)
		{
			CardEntity card = CardEntity;
			if (card == null || card.cardStrengthenEntity == null)
			{
				return;
			}
			// OnLevelUp(cardStrengthenEntity.base) (0x10 field on strengthen entity)
			OnLevelUp(card.cardStrengthenEntity.level0);
			if (level == 1)
			{
				card = CardEntity;
				int idx = card.hasStrengthenDic[1];
				StrengthenEntity entity = card.cardStrengthenEntity.level1List[idx];
				entity.index = idx;
				OnLevelUp1(entity);
			}
			else if (level == 2)
			{
				card = CardEntity;
				int idx = card.hasStrengthenDic[2];
				StrengthenEntity entity = card.cardStrengthenEntity.level2List[idx];
				entity.index = idx;
				OnLevelUp2(entity);
			}
			else if (level == 3)
			{
				card = CardEntity;
				int idx = card.hasStrengthenDic[3];
				StrengthenEntity entity = card.cardStrengthenEntity.level3List[idx];
				entity.index = idx;
				OnLevelUp3(entity);
			}
		}

		protected virtual void OnLevelUp(StrengthenEntity entity)
		{
		}

		protected virtual void OnLevelUp1(StrengthenEntity entity)
		{
		}

		protected virtual void OnLevelUp2(StrengthenEntity entity)
		{
		}

		protected virtual void OnLevelUp3(StrengthenEntity entity)
		{
		}

		public StrengthenEntity GetStrengthenEntity(int level, int index = -1)
		{
			CardEntity card = CardEntity;
			if (card == null)
			{
				return null;
			}
			// LevelUtils.GetCard(card.id) must exist
			if (LevelUtils.GetCard(card.id) == null)
			{
				return null;
			}
			card = CardEntity;
			int idx = card.hasStrengthenDic[level];
			if (index != -1 && idx != index)
			{
				return null;
			}
			List<StrengthenEntity> list;
			if (level == 1)
			{
				card = CardEntity;
				if (card.cardStrengthenEntity == null)
				{
					return null;
				}
				list = card.cardStrengthenEntity.level1List;
			}
			else if (level == 2)
			{
				card = CardEntity;
				if (card.cardStrengthenEntity == null)
				{
					return null;
				}
				list = card.cardStrengthenEntity.level2List;
			}
			else if (level == 3)
			{
				card = CardEntity;
				if (card.cardStrengthenEntity == null)
				{
					return null;
				}
				list = card.cardStrengthenEntity.level3List;
			}
			else
			{
				return null;
			}
			return list[idx];
		}

		public virtual void UsePower()
		{
			CardEntity card = CardEntity;
			if (card == null || card.hasStrengthenDic == null)
			{
				return;
			}
			int idx = card.hasStrengthenDic[3];
			if (idx == -1)
			{
				return;
			}
			card = CardEntity;
			// card.attr (0x70) is CardBaseAttr; isPowerCooldown (0x2C)
			if (card.attr.isPowerCooldown)
			{
				return;
			}
			card = CardEntity;
			card.attr.isPowerCooldown = true;
			// powerCooldownTimer (0x28) = powerCooldownTime (0x24)
			card.attr.powerCooldownTimer = card.attr.powerCooldownTime;
			if (partEntity == null)
			{
				return;
			}
			if (partEntity.isSleeping)
			{
				ChangeSleep(false);
			}
			card = CardEntity;
			if (card == null || card.cardStrengthenEntity == null)
			{
				return;
			}
			StrengthenEntity entity = card.cardStrengthenEntity.level3List[idx];
			entity.index = idx;
			if (idx == 0)
			{
				StartCoroutine(OnUsePower0(entity));
			}
			else if (idx == 1)
			{
				StartCoroutine(OnUsePower1(entity));
			}
		}

		protected virtual IEnumerator OnUsePower0(StrengthenEntity entity)
		{
			// 大招0：等待一帧后由子类重写具体表现
			yield return null;
		}

		protected virtual IEnumerator OnUsePower1(StrengthenEntity entity)
		{
			// 大招1：等待一帧后由子类重写具体表现
			yield return null;
		}

		public override void OnTriggerBodyEnter(Collider2D col)
		{
		}

		public override void OnTriggerBodyExit(Collider2D col)
		{
		}

		public override void OnTriggerBodyStay(Collider2D col)
		{
		}

		public override void OnTriggerEatEnter(Collider2D col)
		{
		}

		public override void OnTriggerEatExit(Collider2D col)
		{
		}

		public override void OnTriggerEatStay(Collider2D col)
		{
		}

		public override void OnTriggerCustomEnter(Collider2D col, int index)
		{
		}

		public override void OnTriggerCustomExit(Collider2D col, int index)
		{
		}

		public override void OnTriggerCustomStay(Collider2D col, int index)
		{
		}

		public virtual void OnPlantClick()
		{
		}

		public virtual void OnPlantEnter()
		{
		}

		public virtual void OnPlantExit()
		{
		}

		public void SetMaxHealthAndShow(int value)
		{
			// ChangeMaxHealthAndShow(value - attr.maxHealth)
			ChangeMaxHealthAndShow((float)value - attr.maxHealth);
		}

		public override void ChangeMaxHealthAndShow(float value)
		{
			if (value == 0f)
			{
				return;
			}
			// If this plant is a shell block, delegate the display to the shell plant.
			if (IsShellBlock() && CurrentLandEntity != null && CurrentLandEntity.shellPlant != null)
			{
				CurrentLandEntity.shellPlant.ChangeMaxHealthAndShow(value);
				return;
			}
			ChangeMaxHealth(value);
		}

		// TODO: unresolved value-box label literals.
		private const string MaxHealthValueLabel = "";
		private const string AttackValueLabel = "";
		private const string MagicValueLabel = "";
		private const string AttackSpeedValueLabel = "";

		public override void ChangeAttackAndShow(int value)
		{
			if (value == 0)
			{
				return;
			}
			if (attr != null)
			{
				attr.attack += value;
			}
		}

		public override void ChangeMagicAndShow(int value)
		{
			if (value == 0)
			{
				return;
			}
			if (attr != null)
			{
				attr.magic += value;
			}
		}

		public override void ChangeAttackSpeedAndShow(float ratio)
		{
			if (ratio == 0f)
			{
				return;
			}
			if (attr != null && defaultAttr != null)
			{
				// attr.AttackSpeed = ratio * defaultAttr.attackSpeed + attr.attackSpeed
				attr.AttackSpeed = ratio * defaultAttr.attackSpeed + attr.attackSpeed;
			}
		}

		protected virtual void EyeUpdate()
		{
			if (partEntity == null)
			{
				return;
			}
			// Only blink when eye animation enabled and not sleeping.
			if (!partEntity.isEyeAnimation || partEntity.isSleeping)
			{
				return;
			}
			// partEntity.eyeBlinkTimer (0x1c) += deltaTime
			partEntity.blinkTimer += Time.deltaTime;
			// once timer reaches interval (0x18) -> blink and roll a new interval
			if (partEntity.blinkTimer < partEntity.blinkTime)
			{
				return;
			}
			EyeBlink();
			partEntity.blinkTimer = 0f;
			partEntity.blinkTime = UnityEngine.Random.Range(EyeBlinkMin, EyeBlinkMax);
		}

		public virtual void EyeBlink()
		{
			if (partEntity == null)
			{
				return;
			}
			// Don't blink while eyes are closed (isEyeClose at 0x16).
			if (partEntity.isCloseEye)
			{
				return;
			}
			if (_animator == null)
			{
				return;
			}
			AnimatorStateInfo state = _animator.GetCurrentAnimatorStateInfo(0);
			// Only trigger a blink if the current state carries the blink tag.
			if (state.IsTag(BlinkTag))
			{
				_animator.Play(EyeBlinkAnimName);
			}
		}

		public virtual void EyeOpen()
		{
			if (partEntity == null)
			{
				return;
			}
			// isEyeClose (0x16): only act if currently closed
			if (!partEntity.isCloseEye)
			{
				return;
			}
			partEntity.isCloseEye = false;
			if (_animator != null)
			{
				_animator.Play(Animator.StringToHash(EyeOpenAnimName), -1, EyeStateNormalizedTime);
			}
		}

		public virtual void EyeClose()
		{
			if (partEntity == null)
			{
				return;
			}
			if (partEntity.isCloseEye)
			{
				return;
			}
			partEntity.isCloseEye = true;
			if (_animator != null)
			{
				_animator.Play(Animator.StringToHash(EyeCloseAnimName), -1, EyeStateNormalizedTime);
			}
		}

		// TODO: unresolved eye animation names / normalized time constant.
		private const string EyeOpenAnimName = "EyeOpen";
		private const string EyeCloseAnimName = "EyeClose";
		private const float EyeStateNormalizedTime = 0f;

		public void ChangeSleep(bool flag)
		{
			if (partEntity == null)
			{
				return;
			}
			if (partEntity.isSleeping != flag)
			{
				if (sleepObj != null)
				{
					sleepObj.SetActive(flag);
				}
				partEntity.isSleeping = flag;
				if (_sleepCoroutine != null)
				{
					StopCoroutine(_sleepCoroutine);
				}
				_sleepCoroutine = StartCoroutine(ChangeSleepStateCoroutine());
			}
		}

		protected virtual IEnumerator ChangeSleepStateCoroutine()
		{
			// 等待一帧后再根据当前睡眠状态切换苏醒/睡眠动画
			yield return null;
			if (this != null && partEntity != null)
			{
				if (!partEntity.isSleeping)
				{
					if (_animator != null)
					{
						_animator.Play(AwakeAnimName);
						_animator.Play(AwakeIdleAnimName);
					}
				}
				else if (_animator != null)
				{
					_animator.Play(SleepAnimName);
					_animator.Play(SleepIdleAnimName);
				}
				_sleepCoroutine = null;
			}
		}

		public virtual bool IsSpecialAvailable()
		{
			// isHasSpecialSkill (0xF0) && specialCooldownTimer (0xF8) <= 0
			if (!isHasSpecialSkill)
			{
				return false;
			}
			return specialCooldownTimer <= 0f;
		}

		public virtual void UseSpecialSkill()
		{
			// start cooldown
			specialCooldownTimer = specialCooldownTime;
		}

		protected void SpecialCooldownEnd()
		{
		}

		public void SpecialStartCooldown()
		{
			// specialCooldownTimer (0xF8) = specialCooldownTime (0xF4)
			specialCooldownTimer = specialCooldownTime;
		}

		protected bool IsNeedSleep()
		{
			return false;
		}

		protected bool CheckIsFrontZombie(float distance = -1f)
		{
			return false;
		}

		// TODO: unresolved sentinel / layer-mask literals for CheckIsFrontZombie.
		private const float DefaultDistanceSentinel = -1f;
		private const string FrontZombieLayerName = "Zombie";

		public virtual int GetHeadNumber()
		{
			return 1;
		}

		public virtual bool IsShellBlock()
		{
			CardEntity card = CardEntity;
			if (card == null)
			{
				return false;
			}
			// placeType (0x4C): shell (2) or master (0) blocks
			if ((int)card.placeType == 2)
			{
				return true;
			}
			card = CardEntity;
			return (int)card.placeType == 0;
		}

		private void OnCardLevelUp()
		{
			// Start 中注册的升级回调：按卡片当前等级重新应用强化效果
			CardEntity card = CardEntity;
			if (card == null)
			{
				return;
			}
			int level = card.level;
			card = CardEntity;
			if (card == null || card.cardStrengthenEntity == null)
			{
				return;
			}
			OnLevelUp(card.cardStrengthenEntity.level0);
			if (level == 1)
			{
				card = CardEntity;
				int idx = card.hasStrengthenDic[1];
				StrengthenEntity entity = card.cardStrengthenEntity.level1List[idx];
				entity.index = idx;
				OnLevelUp1(entity);
			}
			else if (level == 2)
			{
				card = CardEntity;
				int idx = card.hasStrengthenDic[2];
				StrengthenEntity entity = card.cardStrengthenEntity.level2List[idx];
				entity.index = idx;
				OnLevelUp2(entity);
			}
			else if (level == 3)
			{
				card = CardEntity;
				int idx = card.hasStrengthenDic[3];
				StrengthenEntity entity = card.cardStrengthenEntity.level3List[idx];
				entity.index = idx;
				OnLevelUp3(entity);
			}
		}
	}
}
