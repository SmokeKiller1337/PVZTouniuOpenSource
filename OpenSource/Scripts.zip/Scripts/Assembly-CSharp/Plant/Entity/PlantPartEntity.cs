using System;
using Plant.Enum;
using UnityEngine;

namespace Plant.Entity
{
	[Serializable]
	public class PlantPartEntity
	{
		public SleepType sleepType;

		public bool isEyeAnimation;

		public bool isSleeping;

		public bool isCloseEye;

		public float blinkTime;

		public float blinkTimer;

		public void Reset()
		{
			blinkTime = UnityEngine.Random.Range(2f, 5f);
			blinkTimer = 0f;
			isSleeping = false;
			isCloseEye = false;
		}
	}
}
