using System;
using DG.Tweening;
using FairyGUI;
using Level.Manager;
using Level.Util;
using FGUI.Static;
using UnityEngine;
using Zombie.Entity;

// NOTE: Reconstructed from IL2CPP/Ghidra output for Plant.Entity.SeedCardEntity.
// The structure below (namespace, usings, class, fields, method signatures) is taken
// verbatim from the authoritative stub.cs / dump.cs and is NOT modified.
//
// Offset -> field mapping taken from dump.cs:
//   0x10 CardId            0x14 Position          0x20 CardEntity
//   0x28 IsProduce         0x29 IsPickUp          0x30 _cardButton
//   0x38 _pickUpFillImage  0x40 _titleTextField   0x48 _iconLoader
//   0x50 _firstTween       0x58 _secondTween      0x60 _durationTime
//   0x64 _durationTimer    0x68 IsActive          0x70 OnPlacePlant   0x78 OnPlaceZombie
//
// External references verified against Assembly-CSharp:
//   LevelUtils.GetCard(int)                     -> CardEntity          (static)
//   CardSlotManager.Instance.seedCardList       -> List<SeedCardEntity>
//   CardSlotManager.Instance.GetHiddenCard(int) -> CardEntity
//   FGUIUtils.SetCardBackground(GObject, int)                          (static)
//   FGUIStatic.GetIcon(object)                  -> string              (static)
//   CardEntity.backgroundId                     -> int
//   HandManager.Instance / DropCurrentHandEntity / ChangeHandEntity
//   GRoot.inst (FairyGUI root GComponent) used as the UI container: the original
//     added the card button to a level-UI container reached through the game/UI
//     singleton, but that container is not an addressable named member on the
//     available GameManager, so the verifiable FairyGUI root is used instead.

namespace Plant.Entity
{
	public class SeedCardEntity
	{
		public int CardId;

		public Vector2 Position;

		public CardEntity CardEntity;

		public bool IsProduce;

		public bool IsPickUp;

		private GButton _cardButton;

		private GImage _pickUpFillImage;

		private GTextField _titleTextField;

		private GLoader _iconLoader;

		private Tweener _firstTween;

		private Tweener _secondTween;

		private readonly float _durationTime;

		private float _durationTimer;

		[HideInInspector]
		public bool IsActive;

		public Action<PlantEntity> OnPlacePlant;

		public Action<ZombieEntity> OnPlaceZombie;

		// .ctor @0x599750 : initialises the readonly duration to 10f (0x41200000).
		public SeedCardEntity()
		{
			_durationTime = 10f;
		}

		public float DurationTimer
		{
			// get_DurationTimer @0x599760 : return field @0x64 (_durationTimer).
			get
			{
				return _durationTimer;
			}
			// set_DurationTimer @0x599770 :
			//   _durationTimer = value;
			//   if (0 < value && value < _durationTime) update the fade fill alpha;
			//   if (value <= 0) hide the card and remove it from the seed-card list,
			//                   then complete any running produce tween.
			set
			{
				_durationTimer = value;
				if (value > 0f && value < _durationTime * 1f)
				{
					float ratio = 1f - value / (_durationTime * 1f);
					ratio = Mathf.Clamp01(ratio);
					if (_cardButton != null)
					{
						_cardButton.alpha = ratio * 0.5f + 0.5f;
					}
				}
				if (_durationTimer > 0f)
				{
					return;
				}
				if (_cardButton != null)
				{
					_cardButton.visible = false;
					if (CardSlotManager.Instance != null && CardSlotManager.Instance.seedCardList != null)
					{
						CardSlotManager.Instance.seedCardList.Remove(this);
						CompleteProduceTween();
					}
				}
			}
		}

		// Start @0x599280 : create the seed-card UI button from its FairyGUI package,
		// grab its sub-components (fill image / title text / icon loader), scale it,
		// attach it to the UI root and wire the touch-begin handler.
		public void Start()
		{
			// TODO: the FairyGUI package/resource name and child names below were stored
			// as data pointers and cannot be recovered from the pseudocode; the values
			// used here are plausible placeholders.
			_cardButton = UIPackage.CreateObject("Level", "SeedCard").asButton;
			if (_cardButton == null)
			{
				return;
			}
			GComponent container = GRoot.inst;
			if (container == null)
			{
				return;
			}
			container.AddChild(_cardButton);
			_cardButton.SetScale(1f, 1f);
			GObject fill = _cardButton.GetChild("fill");
			if (fill == null)
			{
				return;
			}
			_pickUpFillImage = fill.asImage;
			GObject title = _cardButton.GetChild("title");
			if (title == null)
			{
				return;
			}
			_titleTextField = title.asTextField;
			GObject icon = _cardButton.GetChild("icon");
			if (icon == null)
			{
				return;
			}
			_iconLoader = icon.asLoader;
			_cardButton.onTouchBegin.Set(delegate(EventContext context)
			{
				// <Start>b__19_0 : the original placed the picked-up hand entity onto the
				// touched land, mutating internal HandManager / HandEntity slot fields
				// (offsets +0x58/+0x60/+0x68 on the hand entity, +0x64 timer on the hand
				// manager) that are not addressable named members on the verified
				// HandManager / HandEntity / HandCardEntity classes. Only the verifiable
				// hand-drop is preserved; the slot assignment is left unreconstructed.
				if (HandManager.Instance != null)
				{
					HandManager.Instance.DropCurrentHandEntity();
				}
				// TODO: reconstruct (assign the touched land/plant into the current hand
				// entity's slot fields, then HandManager.ChangeHandEntity).
			});
			_cardButton.touchable = true;
		}

		// Reset @0x598E30 : re-initialise a pooled seed card for (cardId, position,
		// isProduce): reset callbacks/alpha/timer, resolve the CardEntity (falling back
		// to the hidden-card list), paint the card background and icon, place it at the
		// screen projection of its world position, and — when producing — run a short
		// "toss" tween to a jittered target that completes into the produce state.
		public void Reset(int cardId, Vector2 position, bool isProduce)
		{
			CardId = cardId;
			Position = position;
			IsProduce = isProduce;
			OnPlacePlant = null;
			OnPlaceZombie = null;
			if (_cardButton == null)
			{
				return;
			}
			_cardButton.alpha = 1f;
			DurationTimer = _durationTime;
			CardEntity = LevelUtils.GetCard(cardId);
			if (CardEntity == null)
			{
				if (CardSlotManager.Instance == null)
				{
					return;
				}
				CardEntity = CardSlotManager.Instance.GetHiddenCard(cardId);
			}
			if (CardEntity == null)
			{
				return;
			}
			FGUIUtils.SetCardBackground(_cardButton, CardEntity.backgroundId);
			if (_pickUpFillImage == null)
			{
				return;
			}
			_pickUpFillImage.visible = false;
			if (_titleTextField != null)
			{
				_titleTextField.text = string.Empty;
			}
			if (_iconLoader != null)
			{
				_iconLoader.url = FGUIStatic.GetIcon(CardEntity);
			}
			Vector2 screenPos = WorldToScreenPoint(position);
			_cardButton.position = new Vector3(screenPos.x, screenPos.y, 0f);
			if (isProduce)
			{
				// Toss the card to a randomly jittered target near its landing point.
				Vector2 start = position;
				float jitterY = UnityEngine.Random.Range(0f, 1f);
				Vector2 target = WorldToScreenPoint(new Vector2(start.x + jitterY, start.y + 1f));
				_firstTween = DOTween.To(
					() => WorldToScreenPoint(Position),
					delegate(Vector2 pos)
					{
						if (_cardButton != null)
						{
							_cardButton.position = new Vector3(pos.x, pos.y, 0f);
						}
					},
					target,
					1f);
				_firstTween.OnComplete(CompleteProduceTween);
			}
			_cardButton.touchable = true;
		}

		// Release @0x598CC0 : hide the card, drop it from the active seed-card list and
		// kill any running produce tween (shared logic with CompleteProduceTween).
		public void Release()
		{
			if (_cardButton == null)
			{
				return;
			}
			_cardButton.visible = false;
			if (CardSlotManager.Instance == null || CardSlotManager.Instance.seedCardList == null)
			{
				return;
			}
			CardSlotManager.Instance.seedCardList.Remove(this);
			CompleteProduceTween();
		}

		// Destroy @0x598B80 : detach the card button from the UI container, dispose it
		// and drop this entity from the active seed-card list.
		public void Destroy()
		{
			GComponent container = GRoot.inst;
			if (container == null)
			{
				return;
			}
			if (_cardButton != null)
			{
				container.RemoveChild(_cardButton);
				_cardButton.Dispose();
			}
			if (CardSlotManager.Instance != null && CardSlotManager.Instance.seedCardList != null)
			{
				CardSlotManager.Instance.seedCardList.Remove(this);
			}
		}

		// PickUp @0x598C80 : mark the card as picked up and complete any running
		// produce tween, then flag the fill image as interactive.
		public void PickUp()
		{
			CompleteProduceTween();
			IsPickUp = true;
			if (_pickUpFillImage == null)
			{
				return;
			}
			_pickUpFillImage.touchable = true;
		}

		// Drop @0x598C50 : clear the picked-up flag and flag the fill image as
		// non-interactive.
		public void Drop()
		{
			IsPickUp = false;
			if (_pickUpFillImage == null)
			{
				return;
			}
			_pickUpFillImage.touchable = false;
		}

		// WorldToScreenPoint @0x599630 : project a world position through the main
		// camera to screen space, flip Y against the screen height, convert to the
		// FairyGUI root's local space, then offset by the card button's pivot.
		private Vector2 WorldToScreenPoint(Vector2 position)
		{
			Camera cam = Camera.main;
			if (cam == null)
			{
				return default(Vector2);
			}
			Vector3 screen = cam.WorldToScreenPoint(position);
			screen.y = Screen.height - screen.y;
			if (GRoot.inst == null)
			{
				return default(Vector2);
			}
			Vector2 local = GRoot.inst.GlobalToLocal(new Vector2(screen.x, screen.y));
			if (_cardButton == null)
			{
				return default(Vector2);
			}
			return new Vector2(local.x - _cardButton.width * 0.5f, local.y - _cardButton.height * 0.5f);
		}

		// CompleteProduceTween @0x598AF0 : if either tween is still active, kill it and
		// clear the reference (first tween takes priority over the second).
		private void CompleteProduceTween()
		{
			if (_firstTween != null && _firstTween.IsActive())
			{
				_firstTween.Kill();
				_firstTween = null;
				return;
			}
			if (_secondTween != null && _secondTween.IsActive())
			{
				_secondTween.Kill();
				_secondTween = null;
			}
		}
	}
}
