using System;
using DG.Tweening;
using FairyGUI;
using Level.Manager;
using Level.Util;
using FGUI.Static;
using UnityEngine;
using Zombie.Entity;

namespace Plant.Entity
{
	public class SeedCardEntity
	{
		public int CardId;

		public Vector2 Position;

		public CardEntity CardEntity;

		public bool IsProduce;

		public bool IsPickUp;

		private GButton _cardButton;

		private GImage _pickUpFillImage;

		private GTextField _titleTextField;

		private GLoader _iconLoader;

		private Tweener _firstTween;

		private Tweener _secondTween;

		private readonly float _durationTime;

		private float _durationTimer;

		[HideInInspector]
		public bool IsActive;

		public Action<PlantEntity> OnPlacePlant;

		public Action<ZombieEntity> OnPlaceZombie;

		public SeedCardEntity()
		{
			_durationTime = 10f;
		}

		public float DurationTimer
		{
			get
			{
				return _durationTimer;
			}
			set
			{
				_durationTimer = value;
				if (value > 0f && value < _durationTime * 1f)
				{
					float ratio = 1f - value / (_durationTime * 1f);
					ratio = Mathf.Clamp01(ratio);
					if (_cardButton != null)
					{
						_cardButton.alpha = ratio * 0.5f + 0.5f;
					}
				}
				if (_durationTimer > 0f)
				{
					return;
				}
				if (_cardButton != null)
				{
					_cardButton.visible = false;
					if (CardSlotManager.Instance != null && CardSlotManager.Instance.seedCardList != null)
					{
						CardSlotManager.Instance.seedCardList.Remove(this);
						CompleteProduceTween();
					}
				}
			}
		}

		public void Start()
		{
			_cardButton = UIPackage.CreateObject("Level", "SeedCard").asButton;
			if (_cardButton == null)
			{
				return;
			}
			GComponent container = GRoot.inst;
			if (container == null)
			{
				return;
			}
			container.AddChild(_cardButton);
			_cardButton.SetScale(1f, 1f);
			GObject fill = _cardButton.GetChild("fill");
			if (fill == null)
			{
				return;
			}
			_pickUpFillImage = fill.asImage;
			GObject title = _cardButton.GetChild("title");
			if (title == null)
			{
				return;
			}
			_titleTextField = title.asTextField;
			GObject icon = _cardButton.GetChild("icon");
			if (icon == null)
			{
				return;
			}
			_iconLoader = icon.asLoader;
			_cardButton.onTouchBegin.Set(delegate(EventContext context)
			{
				if (HandManager.Instance != null)
				{
					HandManager.Instance.DropCurrentHandEntity();
				}
			});
			_cardButton.touchable = true;
		}

		public void Reset(int cardId, Vector2 position, bool isProduce)
		{
			CardId = cardId;
			Position = position;
			IsProduce = isProduce;
			OnPlacePlant = null;
			OnPlaceZombie = null;
			if (_cardButton == null)
			{
				return;
			}
			_cardButton.alpha = 1f;
			DurationTimer = _durationTime;
			CardEntity = LevelUtils.GetCard(cardId);
			if (CardEntity == null)
			{
				if (CardSlotManager.Instance == null)
				{
					return;
				}
				CardEntity = CardSlotManager.Instance.GetHiddenCard(cardId);
			}
			if (CardEntity == null)
			{
				return;
			}
			FGUIUtils.SetCardBackground(_cardButton, CardEntity.backgroundId);
			if (_pickUpFillImage == null)
			{
				return;
			}
			_pickUpFillImage.visible = false;
			if (_titleTextField != null)
			{
				_titleTextField.text = string.Empty;
			}
			if (_iconLoader != null)
			{
				_iconLoader.url = FGUIStatic.GetIcon(CardEntity);
			}
			Vector2 screenPos = WorldToScreenPoint(position);
			_cardButton.position = new Vector3(screenPos.x, screenPos.y, 0f);
			if (isProduce)
			{
				// Toss the card to a randomly jittered target near its landing point.
				Vector2 start = position;
				float jitterY = UnityEngine.Random.Range(0f, 1f);
				Vector2 target = WorldToScreenPoint(new Vector2(start.x + jitterY, start.y + 1f));
				_firstTween = DOTween.To(
					() => WorldToScreenPoint(Position),
					delegate(Vector2 pos)
					{
						if (_cardButton != null)
						{
							_cardButton.position = new Vector3(pos.x, pos.y, 0f);
						}
					},
					target,
					1f);
				_firstTween.OnComplete(CompleteProduceTween);
			}
			_cardButton.touchable = true;
		}

		public void Release()
		{
			if (_cardButton == null)
			{
				return;
			}
			_cardButton.visible = false;
			if (CardSlotManager.Instance == null || CardSlotManager.Instance.seedCardList == null)
			{
				return;
			}
			CardSlotManager.Instance.seedCardList.Remove(this);
			CompleteProduceTween();
		}

		public void Destroy()
		{
			GComponent container = GRoot.inst;
			if (container == null)
			{
				return;
			}
			if (_cardButton != null)
			{
				container.RemoveChild(_cardButton);
				_cardButton.Dispose();
			}
			if (CardSlotManager.Instance != null && CardSlotManager.Instance.seedCardList != null)
			{
				CardSlotManager.Instance.seedCardList.Remove(this);
			}
		}

		public void PickUp()
		{
			CompleteProduceTween();
			IsPickUp = true;
			if (_pickUpFillImage == null)
			{
				return;
			}
			_pickUpFillImage.touchable = true;
		}

		public void Drop()
		{
			IsPickUp = false;
			if (_pickUpFillImage == null)
			{
				return;
			}
			_pickUpFillImage.touchable = false;
		}

		private Vector2 WorldToScreenPoint(Vector2 position)
		{
			Camera cam = Camera.main;
			if (cam == null)
			{
				return default(Vector2);
			}
			Vector3 screen = cam.WorldToScreenPoint(position);
			screen.y = Screen.height - screen.y;
			if (GRoot.inst == null)
			{
				return default(Vector2);
			}
			Vector2 local = GRoot.inst.GlobalToLocal(new Vector2(screen.x, screen.y));
			if (_cardButton == null)
			{
				return default(Vector2);
			}
			return new Vector2(local.x - _cardButton.width * 0.5f, local.y - _cardButton.height * 0.5f);
		}

		private void CompleteProduceTween()
		{
			if (_firstTween != null && _firstTween.IsActive())
			{
				_firstTween.Kill();
				_firstTween = null;
				return;
			}
			if (_secondTween != null && _secondTween.IsActive())
			{
				_secondTween.Kill();
				_secondTween = null;
			}
		}
	}
}
