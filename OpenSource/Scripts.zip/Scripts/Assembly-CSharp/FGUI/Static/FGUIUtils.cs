using FairyGUI;

namespace FGUI.Static
{
	public static class FGUIUtils
	{
		public static void SetOverText(GObject component, string title, string content)
		{
		}

		public static void SetOverText(GObject component, string content)
		{
		}

		public static void SetCardBackground(GObject component, int backgroundIndex)
		{
		}

		public static void SetAreaBackground(GObject component, int backgroundId)
		{
		}

		public static void SetPowerGem(GObject component, int gemIndex)
		{
		}

		public static void SetDifficultyMode0(GObject component, int difficulty, int touniuDifficulty)
		{
		}

		public static void SetDifficultyMode1(GObject component, int challengeDifficulty, int touniuDifficulty)
		{
		}

		public static void SetRank(GObject component, int rank)
		{
		}

		private static void SetRankItem(GComponent rankItem, int index)
		{
		}
	}
}
