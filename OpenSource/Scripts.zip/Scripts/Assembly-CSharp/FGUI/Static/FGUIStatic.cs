using System;
using System.Collections.Generic;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using FGUI.Entity;
using FairyGUI;
using Game.Util;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace FGUI.Static
{
	public static class FGUIStatic
	{
		private static bool _isLoad;

		public static Dictionary<string, FGUIComponentEntity> uiDic;

		public static Dictionary<Type, string> typeIconDic;

		public static void InitAwake()
		{
			// 字符串常量已从二进制 stringliteral 解出：包路径 "FGUI/Game"、内容缩放 1072x603、
			// 38 个 UI 名（"XxxBox"→FGUI.Entity.UI.XxxBoxEntity）。
			if (_isLoad)
			{
				return;
			}
			_isLoad = true;
			GRoot.inst.SetContentScaleFactor(1072, 603);
			// 主分支 FairyGUI(二进制原生)默认加载器已处理 _fui 后缀；资源在 Resources/fgui/(Resources.Load 大小写不敏感)。
			UIPackage.AddPackage("FGUI/Game");
			uiDic = new Dictionary<string, FGUIComponentEntity>();
			InitUIByName("TitleBox", typeof(FGUI.Entity.UI.TitleBoxEntity));
			InitUIByName("GameMainExtraBox", typeof(FGUI.Entity.UI.GameMainExtraBoxEntity));
			InitUIByName("AchievementBox", typeof(FGUI.Entity.UI.AchievementBoxEntity));
			InitUIByName("MapBox", typeof(FGUI.Entity.UI.MapBoxEntity));
			InitUIByName("GameMainBox", typeof(FGUI.Entity.UI.GameMainBoxEntity));
			InitUIByName("SelectLevelInfoBox", typeof(FGUI.Entity.UI.SelectLevelInfoBoxEntity));
			InitUIByName("GameOverBox", typeof(FGUI.Entity.UI.GameOverBoxEntity));
			InitUIByName("GameMenuBox", typeof(FGUI.Entity.UI.GameMenuBoxEntity));
			InitUIByName("GameTextBox", typeof(FGUI.Entity.UI.GameTextBoxEntity));
			InitUIByName("GameContinueBox", typeof(FGUI.Entity.UI.GameContinueBoxEntity));
			InitUIByName("WelcomeBox", typeof(FGUI.Entity.UI.WelcomeBoxEntity));
			InitUIByName("TextPopupBox", typeof(FGUI.Entity.UI.TextPopupBoxEntity));
			InitUIByName("ConveyorCardGroupBox", typeof(FGUI.Entity.UI.ConveyorCardGroupBoxEntity));
			InitUIByName("TouniuHandbookBox", typeof(FGUI.Entity.UI.TouniuHandbookBoxEntity));
			InitUIByName("PowerTextBox", typeof(FGUI.Entity.UI.PowerTextBoxEntity));
			InitUIByName("CardSlotBox", typeof(FGUI.Entity.UI.CardSlotBoxEntity));
			InitUIByName("PreparationBox", typeof(FGUI.Entity.UI.PreparationBoxEntity));
			InitUIByName("AttrPopupBox", typeof(FGUI.Entity.UI.AttrPopupBoxEntity));
			InitUIByName("PlantHandbookBox", typeof(FGUI.Entity.UI.PlantHandbookBoxEntity));
			InitUIByName("GameShortcutKeyBox", typeof(FGUI.Entity.UI.GameShortcutKeyBoxEntity));
			InitUIByName("StrengthenPopupBox", typeof(FGUI.Entity.UI.StrengthenPopupBoxEntity));
			InitUIByName("GoldLockBox", typeof(FGUI.Entity.UI.GoldLockBoxEntity));
			InitUIByName("HandbookBox", typeof(FGUI.Entity.UI.HandbookBoxEntity));
			InitUIByName("TeachBox", typeof(FGUI.Entity.UI.TeachBoxEntity));
			InitUIByName("ZombieHandbookBox", typeof(FGUI.Entity.UI.ZombieHandbookBoxEntity));
			InitUIByName("GameWinBox", typeof(FGUI.Entity.UI.GameWinBoxEntity));
			InitUIByName("TouniuSayBox", typeof(FGUI.Entity.UI.TouniuSayBoxEntity));
			InitUIByName("StatementBox", typeof(FGUI.Entity.UI.StatementBoxEntity));
			InitUIByName("GameSeedCardBox", typeof(FGUI.Entity.UI.GameSeedCardBoxEntity));
			InitUIByName("HelpBox", typeof(FGUI.Entity.UI.HelpBoxEntity));
			InitUIByName("SelectLevelBox", typeof(FGUI.Entity.UI.SelectLevelBoxEntity));
			InitUIByName("AttrBox", typeof(FGUI.Entity.UI.AttrBoxEntity));
			InitUIByName("LabelPopupBox", typeof(FGUI.Entity.UI.LabelPopupBoxEntity));
			InitUIByName("CardTextPopupBox", typeof(FGUI.Entity.UI.CardTextPopupBoxEntity));
			InitUIByName("WaveBox", typeof(FGUI.Entity.UI.WaveBoxEntity));
			InitUIByName("SelectStrengthenBox", typeof(FGUI.Entity.UI.SelectStrengthenBoxEntity));
			InitUIByName("ValueBox", typeof(FGUI.Entity.UI.ValueBoxEntity));
			InitUIByName("SelectPopupBox", typeof(FGUI.Entity.UI.SelectPopupBoxEntity));
		}

		public static void InitStart()
		{
			if (uiDic == null)
			{
				return;
			}
			foreach (string key in uiDic.Keys)
			{
				uiDic[key].Start();
			}
			string sceneName = SceneManager.GetActiveScene().name;
			GameUtils.InitSceneUI(sceneName);
		}

		public static void DestroyAllComponent()
		{
			GRoot inst = GRoot.inst;
			if (inst == null)
			{
				return;
			}
			GObject[] children = inst.GetChildren();
			if (children == null)
			{
				return;
			}
			for (int i = 0; i < children.Length; i++)
			{
				GRoot.inst.RemoveChild(children[i]);
			}
		}

		public static void CloseAll()
		{
			if (uiDic == null)
			{
				return;
			}
			foreach (string key in uiDic.Keys)
			{
				FGUIComponentEntity entity = uiDic[key];
				if (entity != null)
				{
					entity.Close();
				}
			}
		}

		public static void DestroyListChildren(GList list)
		{
			if (list == null)
			{
				return;
			}
			GObject[] children = list.GetChildren();
			if (children == null)
			{
				return;
			}
			for (int i = 0; i < children.Length; i++)
			{
				GObject child = children[i];
				list.RemoveChild(child);
				child.Dispose();
			}
		}

		public static TweenerCore<Vector3, Vector3, VectorOptions> ComponentMove(GObject com, Vector2 position, float time = 0.3f)
		{
			Vector3 startPosition = com.position;
			TweenerCore<Vector3, Vector3, VectorOptions> tweener = DOTween.To(() => startPosition, delegate(Vector3 pos)
			{
				com.SetPosition(pos.x, pos.y, pos.z);
			}, position, time);
			tweener.SetUpdate(true);
			return tweener;
		}

		public static TweenerCore<Vector3, Vector3, VectorOptions> ComponentMoveAndRotate(GObject com, Vector2 position, float rotate, float time = 0.3f)
		{
			DOTween.To(() => com.rotation, delegate(float value)
			{
				com.rotation = value;
			}, rotate, time).SetUpdate(true);
			Vector3 startPosition = com.position;
			TweenerCore<Vector3, Vector3, VectorOptions> tweener = DOTween.To(() => startPosition, delegate(Vector3 pos)
			{
				com.SetPosition(pos.x, pos.y, pos.z);
			}, position, time);
			tweener.SetUpdate(true);
			return tweener;
		}

		public static string GetIcon(object obj)
		{
			return null;
		}

		public static bool IsClickUI()
		{
			return Stage.inst.touchTarget != null && Stage.inst.touchTarget != Stage.inst;
		}

		private static void InitUIByName(string name, Type type)
		{
			// CreateObject 的包名常量已解出 = "Game"；FGUIConstant 静态字段名 == UI 名。
			GObject gObject = UIPackage.CreateObject("Game", name);
			if (gObject == null)
			{
				return;
			}
			GComponent com = gObject.asCom;
			FGUIComponentEntity entity = (FGUIComponentEntity)Activator.CreateInstance(type, com);
			com.name = name;
			GRoot.inst.AddChild(com);
			uiDic[name] = entity;
			System.Reflection.FieldInfo field = typeof(FGUI.FGUIConstant).GetField(name);
			if (field != null)
			{
				field.SetValue(null, entity);
			}
		}
	}
}
