using FGUI.Entity.UI;

namespace FGUI
{
	public class FGUIConstant
	{
		public static GameMenuBoxEntity GameMenuBox;

		public static GameMainBoxEntity GameMainBox;

		public static GameMainExtraBoxEntity GameMainExtraBox;

		public static GameSeedCardBoxEntity GameSeedCardBox;

		public static CardSlotBoxEntity CardSlotBox;

		public static ConveyorCardGroupBoxEntity ConveyorCardGroupBox;

		public static WaveBoxEntity WaveBox;

		public static GameTextBoxEntity GameTextBox;

		public static AttrBoxEntity AttrBox;

		public static SelectStrengthenBoxEntity SelectStrengthenBox;

		public static GameContinueBoxEntity GameContinueBox;

		public static GameWinBoxEntity GameWinBox;

		public static GameOverBoxEntity GameOverBox;

		public static ValueBoxEntity ValueBox;

		public static PowerTextBoxEntity PowerTextBox;

		public static PreparationBoxEntity PreparationBox;

		public static HandbookBoxEntity HandbookBox;

		public static AchievementBoxEntity AchievementBox;

		public static GoldLockBoxEntity GoldLockBox;

		public static TitleBoxEntity TitleBox;

		public static WelcomeBoxEntity WelcomeBox;

		public static SelectLevelBoxEntity SelectLevelBox;

		public static SelectLevelInfoBoxEntity SelectLevelInfoBox;

		public static StatementBoxEntity StatementBox;

		public static HelpBoxEntity HelpBox;

		public static MapBoxEntity MapBox;

		public static TouniuSayBoxEntity TouniuSayBox;

		public static TeachBoxEntity TeachBox;

		public static GameShortcutKeyBoxEntity GameShortcutKeyBox;

		public static TextPopupBoxEntity TextPopupBox;

		public static SelectPopupBoxEntity SelectPopupBox;

		public static CardTextPopupBoxEntity CardTextPopupBox;

		public static AttrPopupBoxEntity AttrPopupBox;

		public static StrengthenPopupBoxEntity StrengthenPopupBox;

		public static LabelPopupBoxEntity LabelPopupBox;
	}
}
