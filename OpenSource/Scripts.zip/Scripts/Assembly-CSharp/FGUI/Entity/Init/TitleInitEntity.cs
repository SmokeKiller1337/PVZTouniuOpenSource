using System.Reflection;
using Game.Constant;
using Game.Enum;
using Save.Constant;
using Save.Data;
using Save.Static;

namespace FGUI.Entity.Init
{
	public class TitleInitEntity : FGUISceneInitEntity
	{
		public override void Init()
		{
			// [还原] RVA 0x6bdf30：标题场景专属初始化。
			// ① 把 GameMode 复位为 Title；
			// ② 打开标题界面 TitleBox —— 这一步让标题真正显示出来（component.visible = true）；
			// ③ 版本校验通过后，反射遍历 SaveDataConstant 的存档字段，
			//    对开启了自动存档(isAutoSave)的存档调用 SaveDataStatic.Save 落盘。
			GameConstant.GameMode = GameMode.Title;
			if (FGUIConstant.TitleBox != null)
			{
				FGUIConstant.TitleBox.Open();
			}
			if (!SaveDataStatic.CheckVersion())
			{
				return;
			}
			FieldInfo[] fields = typeof(SaveDataConstant).GetFields();
			if (fields == null)
			{
				return;
			}
			for (int i = 0; i < fields.Length; i++)
			{
				FieldInfo field = fields[i];
				if (field == null)
				{
					continue;
				}
				if (field.GetValue(null) is SaveData saveData && saveData.isAutoSave)
				{
					SaveDataStatic.Save(saveData);
				}
			}
		}
	}
}
