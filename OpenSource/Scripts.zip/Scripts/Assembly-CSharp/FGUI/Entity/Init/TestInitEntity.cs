namespace FGUI.Entity.Init
{
	public class TestInitEntity : FGUISceneInitEntity
	{
		public override void Init()
		{
		}
	}
}
