namespace FGUI.Entity.Init
{
	public class LevelInitEntity : FGUISceneInitEntity
	{
		public override void Init()
		{
			// TODO: reconstruct
			// The decompiled body (RVA 0x6B80C0) reads through two unidentifiable
			// manager singletons and then walks a null-guarded chain of six UI-object
			// fields, invoking a virtual/delegate slot (native offset 0x1B8, data 0x1C0)
			// on each. Concretely the pseudocode does:
			//   - GameManager-like singleton (native _DAT_182e79ba0): when its Instance
			//     is non-null, call SetGameSpeed(0, 0). NOTE: in this build SetGameSpeed
			//     takes TWO arguments, which does not match GameManager.SetGameSpeed(int)
			//     in the project (RVA/signature mismatch => different build), so the call
			//     cannot be reproduced safely.
			//   - A second UI-holder singleton (native _DAT_182e73f40): read its Instance,
			//     then for object fields at offsets 0x08, 0x10, 0x38, 0x18, 0x68, 0x70
			//     invoke a virtual method (vtable slot 0x1B8) on each non-null field.
			// Neither manager type, the six field names, nor the invoked virtual method
			// could be resolved against Assembly-CSharp, and reconstructing them would
			// require fabricating members. Left as a stub rather than emitting code that
			// references non-existent members or fails to compile. (The reference
			// reconstruction of this same method is likewise empty.)
		}
	}
}
