namespace FGUI.Entity.Init
{
	public class LevelInitEntity : FGUISceneInitEntity
	{
		public override void Init()
		{
		}
	}
}
