using FairyGUI;
using FGUI.Static;

namespace FGUI.Entity
{
	public abstract class FGUIComponentEntity
	{
		public string name;

		public readonly GComponent component;

		public bool isOpen;

		public bool isOpenPause;

		protected Transition _t0;

		public FGUIComponentEntity(GComponent component)
		{
			this.component = component;
		}

		public abstract void Awake();

		public abstract void Start();

		public abstract void Update();

		public abstract void Reset();

		public virtual void Open()
		{
			if (isOpen)
			{
				return;
			}
			isOpen = true;
			if (_t0 == null)
			{
				component.visible = true;
			}
			else
			{
				_t0.Stop();
				component.visible = true;
				_t0.Play(delegate
				{
					OnOpenEnd();
				});
			}
			OnOpen();
			Update();
			if (_t0 == null)
			{
				OnOpenEnd();
			}
		}

		public virtual void Close()
		{
			if (!isOpen)
			{
				return;
			}
			isOpen = false;
			Stage.inst.CancelClick(0);
			if (_t0 == null)
			{
				component.visible = false;
			}
			else
			{
				_t0.Stop();
				_t0.PlayReverse(delegate
				{
					component.visible = false;
					OnCloseEnd();
				});
			}
			OnClose();
			if (_t0 == null)
			{
				OnCloseEnd();
			}
		}

		public virtual void Display()
		{
		}

		public virtual void Hide()
		{
		}

		public virtual void Destroy()
		{
			if (FGUIStatic.uiDic.ContainsKey(name))
			{
				FGUIStatic.uiDic.Remove(component.gameObjectName);
			}
			GRoot inst = GRoot.inst;
			if (inst != null)
			{
				inst.RemoveChild(component);
				component.Dispose();
			}
		}

		protected abstract void OnOpen();

		protected abstract void OnOpenEnd();

		protected abstract void OnClose();

		protected abstract void OnCloseEnd();
	}
}
