using FairyGUI;
using UnityEngine;
using UnityEngine.Pool;

namespace FGUI.Entity
{
	public class PoolComponentEntity : FGUIComponentEntity
	{
		protected GameObject poolUI;

		private IObjectPool<GameObject> pool;

		protected string itemComponentName;

		public PoolComponentEntity(GComponent component)
			: base(component)
		{
		}

		public override void Awake()
		{
		}

		public override void Start()
		{
		}

		public override void Update()
		{
		}

		public override void Reset()
		{
		}

		protected override void OnOpen()
		{
		}

		protected override void OnOpenEnd()
		{
		}

		protected override void OnClose()
		{
		}

		protected override void OnCloseEnd()
		{
		}

		protected GComponent Get(Vector2 position)
		{
			if (pool != null)
			{
				GameObject gameObject = pool.Get();
				if (gameObject != null)
				{
					Transform transform = gameObject.transform;
					if (transform != null)
					{
						transform.position = position;
						UIPanel uIPanel = gameObject.GetComponent<UIPanel>();
						if (uIPanel != null)
						{
							GComponent ui = uIPanel.ui;
							if (ui != null)
							{
								ui.SetPosition(0f - ui.x, 0f - ui.y, 0f);
								return ui;
							}
						}
					}
				}
			}
			return null;
		}

		public void Release(GComponent itemCom)
		{
			if (itemCom != null && itemCom.displayObject != null && itemCom.displayObject.gameObject != null)
			{
				UIPanel componentInParent = itemCom.displayObject.gameObject.GetComponentInParent<UIPanel>();
				if (componentInParent != null)
				{
					pool.Release(componentInParent.gameObject);
				}
			}
		}

		protected virtual GameObject OnCreateItem()
		{
			return null;
		}

		protected virtual void OnGetItem(GameObject item)
		{
			if (isOpen)
			{
				item.SetActive(true);
			}
		}

		protected virtual void OnReleaseItem(GameObject item)
		{
			item.SetActive(false);
		}

		protected virtual void OnDestroyItem(GameObject item)
		{
			if (item == null)
			{
				return;
			}
			UIPanel component = item.GetComponent<UIPanel>();
			if (component != null)
			{
				GComponent ui = component.ui;
				if (ui != null)
				{
					ui.Dispose();
				}
			}
			UnityEngine.Object.Destroy(item);
		}
	}
}
