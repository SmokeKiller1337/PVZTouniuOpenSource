using FairyGUI;
using UnityEngine;

namespace FGUI.Entity.UI
{
	public class PowerTextBoxEntity : PoolComponentEntity
	{
		public PowerTextBoxEntity(GComponent component)
			: base(component)
		{
			itemComponentName = "PowerTextItem";
		}

		public override void Start()
		{
		}

		public void Create(Vector2 position, string value)
		{
		}
	}
}
