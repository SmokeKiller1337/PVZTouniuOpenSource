using FairyGUI;
using UnityEngine;

namespace FGUI.Entity.UI
{
	public class PowerTextBoxEntity : PoolComponentEntity
	{
		public PowerTextBoxEntity(GComponent component)
			: base(component)
		{
			itemComponentName = "PowerTextItem";
		}

		public override void Start()
		{
		}

		public void Create(Vector2 position, string value)
		{
			// TODO: reconstruct
			// Original body gates on a manager/level state chain (unresolved singleton
			// with two boolean flags) and dispatches a captured lambda that releases the
			// pooled GameObject via a private base-class IObjectPool<GameObject> field
			// (not legally accessible from this subclass). Kept as a stub to avoid
			// referencing unverifiable members. Pattern is roughly:
			//   if (!isOpen) return;
			//   GComponent com = Get(position);
			//   com.GetChild("<text>").asTextField.text = value;
			//   com.GetTransition("showPowerText").Play(() => { /* release */ });
		}
	}
}
