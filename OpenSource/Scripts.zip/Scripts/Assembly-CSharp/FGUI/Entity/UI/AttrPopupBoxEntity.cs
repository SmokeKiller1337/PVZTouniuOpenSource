using FGUI.Entity.UI.GameMain.Entity;
using FairyGUI;
using Game.Util;

namespace FGUI.Entity.UI
{
	public class AttrPopupBoxEntity : DefaultComponentEntity
	{
		public AttrPopupBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
			// TODO: reconstruct - 绑定关闭按钮点击事件；子对象名称字面量与点击回调方法引用
			// 未能从元数据恢复（IL2CPP 字符串常量/委托目标丢失），保留桩以避免臆造成员。
		}

		public void OpenText(GObject com, AttrItemStruct attrItemStruct)
		{
			// TODO: reconstruct - 以下 GetChild / SetVar 的子对象名与变量名字面量未能从元数据恢复，
			// 使用占位字符串；核心数值格式化逻辑已按反编译还原。
			if (component == null)
			{
				return;
			}

			GObject titleObj = component.GetChild("title");
			GTextField titleField = titleObj != null ? titleObj.asTextField : null;
			if (titleField == null)
			{
				return;
			}
			titleField.text = attrItemStruct.title;

			GObject contentObj = component.GetChild("content");
			GTextField contentField = contentObj != null ? contentObj.asTextField : null;
			if (contentField == null)
			{
				return;
			}
			contentField.text = attrItemStruct.content;

			string decimalFormat = null;
			if (attrItemStruct.decimalNumber > 0)
			{
				decimalFormat = "F" + attrItemStruct.decimalNumber;
			}
			string valueStr = GameUtils.GetValueStr(attrItemStruct.value, attrItemStruct.isPercentage, decimalFormat);

			string defaultDecimalFormat = null;
			if (attrItemStruct.decimalNumber > 0)
			{
				defaultDecimalFormat = "F" + attrItemStruct.decimalNumber;
			}
			string defaultValueStr = GameUtils.GetValueStr(attrItemStruct.defaultValue, attrItemStruct.isPercentage, defaultDecimalFormat);

			// TODO: reconstruct - diffLabel（升/降颜色标签）与相等分支的占位文本字面量未能从元数据恢复，
			// 此处用空串占位；差值的正负号分支与格式化逻辑已按反编译还原。
			string diffLabel;
			string diffValueStr;
			if (UnityEngine.Mathf.Abs(attrItemStruct.value - attrItemStruct.defaultValue) < 1E-05f)
			{
				diffLabel = "";
				diffValueStr = "";
			}
			else
			{
				string diffFormat = null;
				float diff;
				if (attrItemStruct.value > attrItemStruct.defaultValue)
				{
					// 值上升：颜色标签受 isColorInversion 影响（升色/降色互换）
					diffLabel = "";
					diff = attrItemStruct.value - attrItemStruct.defaultValue;
				}
				else
				{
					// 值下降：颜色标签受 isColorInversion 影响
					diffLabel = "";
					diff = attrItemStruct.defaultValue - attrItemStruct.value;
				}
				if (attrItemStruct.decimalNumber > 0)
				{
					diffFormat = "F" + attrItemStruct.decimalNumber;
				}
				diffValueStr = GameUtils.GetValueStr(diff, attrItemStruct.isPercentage, diffFormat);
			}

			GObject valuePanel = component.GetChild("value");
			GTextField valueField = valuePanel != null ? valuePanel.asTextField : null;
			if (valueField == null)
			{
				return;
			}

			GTextField result = valueField
				.SetVar("title", attrItemStruct.title)
				.SetVar("value", valueStr)
				.SetVar("default", defaultValueStr)
				.SetVar("diff", diffValueStr)
				.SetVar("sign", diffLabel)
				.SetVar("label", diffLabel);
			if (result == null)
			{
				return;
			}
			result.FlushVars();

			Display();

			GRoot root = GRoot.inst;
			if (root != null)
			{
				root.ShowPopup(component, com);
			}
		}
	}
}
