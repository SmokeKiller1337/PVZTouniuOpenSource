using FairyGUI;

namespace FGUI.Entity.UI.GameMain.Entity
{
	public class CardSlotItemEntity
	{
		public GButton cardButton;

		public GImage fill;

		public GImage pickUpFill;

		public GImage cooldownFill;

		public Transition cooldownEndTransition;

		public GButton levelUpButton;

		public Transition showLevelUpTransition;

		public GComponent powerCom;

		public GImage powerFill;

		public GImage powerCooldownFill;

		public Transition powerCooldownEndTransition;
	}
}
