namespace FGUI.Entity.UI.GameMain.Entity
{
	public enum GameTextType
	{
		Room = 0,
		Ready = 1,
		BigWave = 2,
		LastWave = 3,
		BossAppear = 4,
		BossFlag = 5
	}
}
