using System;
using FairyGUI;
using UnityEngine;

namespace FGUI.Entity.UI.GameMain.Entity
{
	[Serializable]
	public class ConveyorCardComEntity
	{
		public GComponent com;

		public GComponent parentCom;

		public Vector2 position = new Vector2(500f, 400f);

		public void Remove()
		{
			if (com == null)
			{
				return;
			}
			if (parentCom != null)
			{
				parentCom.RemoveChild(com, false);
				com.Dispose();
				com = null;
			}
		}
	}
}
