using System;
using UnityEngine;

namespace FGUI.Entity.UI.GameMain.Entity
{
	[Serializable]
	public struct AttrItemStruct
	{
		[Tooltip("属性名")]
		public string title;

		[Tooltip("属性描述")]
		public string content;

		[Tooltip("当前值")]
		public float value;

		[Tooltip("默认值")]
		public float defaultValue;

		[Tooltip("是否颜色反转")]
		public bool isColorInversion;

		[Tooltip("是否为百分比")]
		public bool isPercentage;

		[Tooltip("小数位数")]
		public int decimalNumber;

		[Tooltip("图标")]
		public string icon;
	}
}
