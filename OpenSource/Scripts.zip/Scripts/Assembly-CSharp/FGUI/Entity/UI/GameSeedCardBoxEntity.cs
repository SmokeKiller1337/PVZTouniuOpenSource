using FairyGUI;

namespace FGUI.Entity.UI
{
	public class GameSeedCardBoxEntity : DefaultComponentEntity
	{
		public GameSeedCardBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
			// TODO: reconstruct
			// Decompile shows: base.Start(); then, when component != null,
			// component.SetPosition(0f, <field@0x8c>, <field@0x90>).
			// The exact source fields for the y/z arguments (raw IL2CPP offsets
			// 0x8C / 0x90 on GObject) cannot be mapped to real public members with
			// certainty, so the body is left as a stub rather than guess.
		}

		public override void Update()
		{
		}

		protected override void OnClose()
		{
			// TODO: reconstruct
			// Decompile shows: base.OnClose(); then, when component != null,
			// iterate component.GetChildren() invoking a virtual (vtable slot 0x298,
			// no args) on each child, followed by a second loop invoking another
			// virtual (vtable slot 0x358) over an unknown component collection
			// (field offset 0x1C8). These vtable slots / field offsets cannot be
			// resolved to real method/member names with certainty, so the body is
			// left as a stub rather than reference fabricated members.
		}
	}
}
