using FairyGUI;

namespace FGUI.Entity.UI
{
	public class GameSeedCardBoxEntity : DefaultComponentEntity
	{
		public GameSeedCardBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
		}

		public override void Update()
		{
		}

		protected override void OnClose()
		{
		}
	}
}
