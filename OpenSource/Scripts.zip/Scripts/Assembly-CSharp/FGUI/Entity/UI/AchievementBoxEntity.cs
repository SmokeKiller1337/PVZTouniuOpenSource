using System.Collections.Generic;
using FGUI.Entity.UI.Achievement;
using FairyGUI;
using Save.Data;

namespace FGUI.Entity.UI
{
	public class AchievementBoxEntity : DefaultComponentEntity
	{
		public AchievementBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
			// TODO: reconstruct
			// Original wires up a child button's onClick handler, but the button's
			// child name (a metadata string constant) and the click-target manager
			// (an unidentifiable singleton dispatched through an interface vtable)
			// could not be recovered reliably.
		}

		public override void Update()
		{
			// TODO: reconstruct
			// Original refreshes several GList/GLoader/GTextField children of the
			// component using GetTrophyNumber results, but every child lookup relies
			// on metadata string constants that could not be recovered from the
			// pseudocode. Reconstructing it would require fabricating those names.
		}

		private TrophyNumberEntity GetTrophyNumber(Dictionary<int, AreaData.AreaItemData> dictionary)
		{
			TrophyNumberEntity trophyNumberEntity = new TrophyNumberEntity();
			trophyNumberEntity.headNumberDic = new Dictionary<int, int>();
			trophyNumberEntity.bodyNumberDic = new Dictionary<int, int>();
			for (int i = 0; i < 6; i++)
			{
				trophyNumberEntity.headNumberDic.Add(i, 0);
				trophyNumberEntity.bodyNumberDic.Add(i, 0);
			}
			if (dictionary != null)
			{
				foreach (AreaData.AreaItemData value in dictionary.Values)
				{
					foreach (AreaData.LevelData level in value.levelList)
					{
						trophyNumberEntity.headNumberDic[level.touniuDifficulty]++;
						trophyNumberEntity.bodyNumberDic[level.difficulty]++;
						if (level.touniuDifficulty == 5)
						{
							trophyNumberEntity.headNumberDic[4]++;
						}
						if (level.difficulty == 5)
						{
							trophyNumberEntity.bodyNumberDic[4]++;
						}
					}
				}
			}
			return trophyNumberEntity;
		}
	}
}
