using FairyGUI;
using UnityEngine;

namespace FGUI.Entity.UI
{
	public class CardTextPopupBoxEntity : DefaultComponentEntity
	{
		public CardTextPopupBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
			if (component == null)
			{
				return;
			}
			// NOTE: child name string literal is unresolved in the pseudocode (global data ref);
			// "closeButton" is an inferred FairyGUI-conventional name for the close button.
			GObject child = component.GetChild("closeButton");
			if (child == null)
			{
				return;
			}
			GButton button = child.asButton;
			if (button != null)
			{
				// Standard popup close-button binding. Handler resolves to the base Close().
				button.onClick.Set(Close);
			}
		}

		public void OpenText(string title, string content)
		{
			Open();
			if (component == null)
			{
				return;
			}
			// NOTE: the child/variable name string literals are unresolved in the pseudocode
			// (global data refs). "text"/"title"/"content" are inferred FairyGUI-conventional names.
			GObject child = component.GetChild("text");
			if (child == null)
			{
				return;
			}
			GTextField textField = child.asTextField;
			if (textField == null)
			{
				return;
			}
			textField.SetVar("title", title).SetVar("content", content).FlushVars();
			GRoot inst = GRoot.inst;
			if (inst != null)
			{
				inst.ShowPopup(component);
			}
		}

		public void OpenCardText(GObject com, string title, string content)
		{
			// TODO: reconstruct
			// The layout math for this method relies on an unresolved numeric scale constant
			// (global float _DAT_18252cb64) that cannot be recovered from the pseudocode, so the
			// positioning cannot be faithfully reproduced. Left as a stub to avoid fabricating it.
		}

		public void OpenToolText(GObject com, string title, string content)
		{
			Open();
			if (component == null)
			{
				return;
			}
			// NOTE: the child/variable name string literals are unresolved in the pseudocode
			// (global data refs). "text"/"title"/"content" are inferred FairyGUI-conventional names.
			GObject child = component.GetChild("text");
			if (child == null)
			{
				return;
			}
			GTextField textField = child.asTextField;
			if (textField == null)
			{
				return;
			}
			textField.SetVar("title", title).SetVar("content", content).FlushVars();
			GRoot inst = GRoot.inst;
			if (inst == null)
			{
				return;
			}
			inst.ShowPopup(component);
			inst = GRoot.inst;
			if (com == null)
			{
				return;
			}
			Vector2 global = com.LocalToGlobal(Vector2.zero);
			Vector2 local = inst.GlobalToLocal(global);
			component.SetPosition(local.x, local.y + com.height, 0f);
		}
	}
}
