using System.Collections.Generic;
using System.Linq;
using FairyGUI;
using FGUI.Static;
using Level.Static;
using Zombie.Entity;

namespace FGUI.Entity.UI
{
	public class ZombieHandbookBoxEntity : DefaultComponentEntity
	{
		// ---- Reconstruction placeholders for unresolved FairyGUI string literals ----
		// The decompiled bodies reference the following names only as raw data pointers
		// (GComponent.GetChild names and the UIPackage package/resource names for the card
		// item). Their real string values live in the metadata string table and are not
		// present in the provided skeleton, so they are represented here as clearly marked
		// placeholder constants. The surrounding control flow is faithfully reconstructed.
		private const string TAB_LIST_NAME = "list_tab"; // TODO: real child name (data ptr 0x182e81c88)
		private const string CARD_LIST_NAME = "list_card"; // TODO: real child name (data ptr 0x182e423f0)
		private const string CARD_COM_NAME = "card"; // TODO: real child name (data ptr 0x182e66550)
		private const string CARD_ITEM_PACKAGE = "Handbook"; // TODO: real package name (data ptr 0x182e2c8e0)
		private const string CARD_ITEM_RESOURCE = "CardItem"; // TODO: real resource name (data ptr 0x182e359d0)

		// InitCardItem child names.
		private const string ITEM_BUTTON_NAME = "button"; // TODO: real child name (data ptr 0x182e6f598)
		private const string ITEM_COST_NAME = "cost"; // TODO: real child name (data ptr 0x182e7e8a8)
		private const string ITEM_ICON_NAME = "icon"; // TODO: real child name (data ptr 0x182e31ae0)
		private const string ITEM_HIDE1_NAME = "hide1"; // TODO: real child name (data ptr 0x182e223d0)
		private const string ITEM_HIDE2_NAME = "hide2"; // TODO: real child name (data ptr 0x182e5cdb8)
		private const string ITEM_HIDE3_NAME = "hide3"; // TODO: real child name (data ptr 0x182e774d8)

		private int _currentZombieId;

		private int _type;

		public ZombieHandbookBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
			base.Start();
			// Register this box on the parent handbook container (FGUIConstant.HandbookBox,
			// static field @0x80). Field zombieHandbookCom @0x38 is a public
			// ZombieHandbookBoxEntity on HandbookBoxEntity (verified against its offset dump).
			HandbookBoxEntity handbookBox = FGUIConstant.HandbookBox;
			if (handbookBox != null)
			{
				handbookBox.zombieHandbookCom = this;
			}
			if (component == null)
			{
				return;
			}
			GObject tabListObj = component.GetChild(TAB_LIST_NAME);
			if (tabListObj == null)
			{
				return;
			}
			GList tabList = tabListObj.asList;
			if (tabList == null)
			{
				return;
			}
			tabList.selectedIndex = 0;
			for (int i = 0; i < 3; i++)
			{
				GObject childAt = tabList.GetChildAt(i);
				if (childAt == null)
				{
					break;
				}
				GButton tabButton = childAt.asButton;
				if (tabButton == null)
				{
					break;
				}
				int index = i;
				// onClick uses the parameterless EventCallback0 overload; an explicit
				// () => lambda is required to disambiguate from the EventCallback1 overload.
				tabButton.onClick.Set(() =>
				{
					_type = index;
					Update();
				});
			}
		}

		protected override void OnOpen()
		{
			base.OnOpen();
			int key = ((_currentZombieId == 0) ? 10 : _currentZombieId);
			if (LevelStatic.zombieDic == null)
			{
				return;
			}
			ZombieEntity zombieEntity = LevelStatic.zombieDic[key];
			ShowZombie(zombieEntity);
		}

		private void InitCardItem(GComponent cardItem, ZombieEntity zombieEntity)
		{
			if (cardItem == null)
			{
				return;
			}
			GObject buttonObj = cardItem.GetChild(ITEM_BUTTON_NAME);
			if (buttonObj == null)
			{
				return;
			}
			GButton button = buttonObj.asButton;
			FGUIUtils.SetCardBackground(button, 0);
			if (button == null)
			{
				return;
			}
			button.touchable = true;
			GObject costObj = button.GetChild(ITEM_COST_NAME);
			if (costObj == null)
			{
				return;
			}
			GTextField costText = costObj.asTextField;
			if (zombieEntity == null || costText == null)
			{
				return;
			}
			costText.text = zombieEntity.sun.ToString();
			GObject iconObj = button.GetChild(ITEM_ICON_NAME);
			if (iconObj == null)
			{
				return;
			}
			GLoader iconLoader = iconObj.asLoader;
			string iconUrl = FGUIStatic.GetIcon(zombieEntity);
			if (iconLoader == null)
			{
				return;
			}
			// Decompile dispatches the virtual icon setter (vtable slot 0x288 == set_icon).
			iconLoader.icon = iconUrl;
			GObject hide1 = button.GetChild(ITEM_HIDE1_NAME);
			if (hide1 == null)
			{
				return;
			}
			hide1.visible = false;
			GObject hide2 = button.GetChild(ITEM_HIDE2_NAME);
			if (hide2 == null)
			{
				return;
			}
			hide2.visible = false;

			GObject hide3 = button.GetChild(ITEM_HIDE3_NAME);
			if (hide3 == null)
			{
				return;
			}
			// TODO: reconstruct — the decompiled tail does NOT set hide3.visible; it toggles a
			// bool member on this child (raw offset 0x16), invokes its virtual setter (vtable
			// slot 0x308), flags the parent's bounds as changed, and drives a Transition via
			// UpdateContext.OnBegin (System.Delegate.Combine). None of those members are named
			// in the provided skeleton, so the manipulation is left unreconstructed rather than
			// approximated with an unrelated member such as `visible`.
		}

		public override void Update()
		{
			if (component == null)
			{
				return;
			}
			GObject tabListObj = component.GetChild(TAB_LIST_NAME);
			if (tabListObj == null)
			{
				return;
			}
			GList tabList = tabListObj.asList;
			if (tabList == null)
			{
				return;
			}
			tabList.selectedIndex = _type;
			GObject cardListObj = component.GetChild(CARD_LIST_NAME);
			if (cardListObj == null)
			{
				return;
			}
			GList cardList = cardListObj.asList;
			if (cardList == null)
			{
				return;
			}
			cardList.RemoveChildrenToPool();
			if (LevelStatic.zombieDic == null)
			{
				return;
			}
			List<ZombieEntity> zombieList = LevelStatic.zombieDic.Values.ToList();
			if (zombieList == null)
			{
				return;
			}
			zombieList.Sort((ZombieEntity a, ZombieEntity b) => a.id.CompareTo(b.id));
			foreach (ZombieEntity zombieEntity in zombieList)
			{
				if (zombieEntity == null || (int)zombieEntity.type != _type)
				{
					continue;
				}
				string itemUrl = UIPackage.GetItemURL(CARD_ITEM_PACKAGE, CARD_ITEM_RESOURCE);
				GObject item = cardList.AddItemFromPool(itemUrl);
				if (item == null)
				{
					return;
				}
				GComponent cardCom = item.asCom;
				InitCardItem(cardCom, zombieEntity);
				if (cardCom == null)
				{
					return;
				}
				GObject buttonObj = cardCom.GetChild(ITEM_BUTTON_NAME);
				if (buttonObj == null)
				{
					return;
				}
				GButton button = buttonObj.asButton;
				if (button == null)
				{
					return;
				}
				ZombieEntity captured = zombieEntity;
				// onTouchBegin handler takes an EventContext (EventCallback1); the explicit
				// parameter disambiguates from the parameterless EventCallback0 overload.
				button.onTouchBegin.Set((EventContext context) =>
				{
					ShowZombie(captured);
				});
			}
		}

		private void ShowZombie(ZombieEntity zombieEntity)
		{
			if (zombieEntity == null)
			{
				return;
			}
			_currentZombieId = zombieEntity.id;
			AttrBoxEntity attrBox = FGUIConstant.AttrBox;
			if (component == null)
			{
				return;
			}
			GObject cardChild = component.GetChild(CARD_COM_NAME);
			if (cardChild == null)
			{
				return;
			}
			GComponent handbookItem = cardChild.asCom;
			if (attrBox == null)
			{
				return;
			}
			attrBox.OpenHandbookZombie(zombieEntity, handbookItem);
		}
	}
}
