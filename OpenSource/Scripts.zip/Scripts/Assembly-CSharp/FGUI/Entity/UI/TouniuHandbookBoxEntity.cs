using FGUI;
using FairyGUI;
using Level.Static;
using Touniu.Object;

namespace FGUI.Entity.UI
{
	public class TouniuHandbookBoxEntity : DefaultComponentEntity
	{
		private int _currentTouniuId;

		public TouniuHandbookBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
			base.Start();
			FGUIConstant.HandbookBox.touniuHandbookCom = this;
		}

		protected override void OnOpen()
		{
			base.OnOpen();
			ShowTouniu(LevelStatic.touniuDic[1]);
		}

		private void InitTouniuItem(GComponent cardItem, TouniuObject touniuObject)
		{
		}

		public override void Update()
		{
		}

		private void ShowTouniu(TouniuObject touniuObject)
		{
		}
	}
}
