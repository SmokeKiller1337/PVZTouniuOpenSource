using FairyGUI;

namespace FGUI.Entity.UI
{
	public class HandbookBoxEntity : DefaultComponentEntity
	{
		public PlantHandbookBoxEntity plantHandbookCom;

		public ZombieHandbookBoxEntity zombieHandbookCom;

		public TouniuHandbookBoxEntity touniuHandbookCom;

		public HandbookBoxEntity(GComponent component)
			: base(component)
		{
		}

		protected override void OnOpen()
		{
			base.OnOpen();
			InitShowButton();
		}

		public override void Start()
		{
		}

		private void InitShowButton()
		{
		}

		public override void Update()
		{
		}
	}
}
