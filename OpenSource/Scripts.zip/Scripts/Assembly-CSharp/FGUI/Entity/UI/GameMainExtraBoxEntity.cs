using FairyGUI;

namespace FGUI.Entity.UI
{
	public class GameMainExtraBoxEntity : DefaultComponentEntity
	{
		private GComponent _contentCom;

		public GComponent ContentCom
		{
			get
			{
				return _contentCom;
			}
			set
			{
				_contentCom = value;
			}
		}

		public GameMainExtraBoxEntity(GComponent component)
			: base(component)
		{
			// The IL2CPP ctor stores the incoming component into the base
			// readonly 'component' field directly. That field is readonly and
			// assigned through the base constructor chain, so no additional body
			// is reproducible in clean C#.
		}

		public override void Start()
		{
			// TODO: reconstruct
			// Original body hooks an onClick handler onto a named child button of
			// 'component'. The child name string constant and the handler method
			// target could not be resolved from the decompiled globals, so this is
			// left as a stub to avoid referencing non-existent members.
		}

		public override void Update()
		{
			// TODO: reconstruct
			// Original body rebuilds a FairyGUI content object each frame from a
			// manager's current wave/state (formatting a package resource name and
			// creating it via UIPackage.CreateObject). The source manager singleton
			// and the string/format/package constants could not be reliably
			// identified from the decompiled globals, so this is left as a stub.
		}
	}
}
