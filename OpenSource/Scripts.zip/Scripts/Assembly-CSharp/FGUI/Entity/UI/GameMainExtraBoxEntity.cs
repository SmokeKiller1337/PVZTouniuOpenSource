using FairyGUI;

namespace FGUI.Entity.UI
{
	public class GameMainExtraBoxEntity : DefaultComponentEntity
	{
		private GComponent _contentCom;

		public GComponent ContentCom
		{
			get
			{
				return _contentCom;
			}
			set
			{
				_contentCom = value;
			}
		}

		public GameMainExtraBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
		}

		public override void Update()
		{
		}
	}
}
