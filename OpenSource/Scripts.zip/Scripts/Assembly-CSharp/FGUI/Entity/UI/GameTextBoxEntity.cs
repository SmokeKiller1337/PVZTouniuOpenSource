using FGUI.Entity.UI.GameMain.Entity;
using FairyGUI;

namespace FGUI.Entity.UI
{
	public class GameTextBoxEntity : DefaultComponentEntity
	{
		private Transition _showRoomTransition;

		private Transition _showReadyTransition;

		private Transition _showBigWaveTransition;

		private Transition _showLastWaveTransition;

		private Transition _showBossAppearTransition;

		private Transition _showBossFlagTransition;

		public GameTextBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
			base.Start();
			if (component == null)
			{
				return;
			}
			_showRoomTransition = component.GetTransition("showRoom");
			_showReadyTransition = component.GetTransition("showReady");
			_showBigWaveTransition = component.GetTransition("showBigWave");
			_showLastWaveTransition = component.GetTransition("showLastWave");
			_showBossAppearTransition = component.GetTransition("showBossAppear");
			_showBossFlagTransition = component.GetTransition("showBossFlag");
			if (_showRoomTransition != null)
			{
				_showRoomTransition.ignoreEngineTimeScale = false;
			}
			if (_showReadyTransition != null)
			{
				_showReadyTransition.ignoreEngineTimeScale = false;
			}
			if (_showBigWaveTransition != null)
			{
				_showBigWaveTransition.ignoreEngineTimeScale = false;
			}
			if (_showLastWaveTransition != null)
			{
				_showLastWaveTransition.ignoreEngineTimeScale = false;
			}
			if (_showBossAppearTransition != null)
			{
				_showBossAppearTransition.ignoreEngineTimeScale = false;
			}
			if (_showBossFlagTransition != null)
			{
				_showBossFlagTransition.ignoreEngineTimeScale = false;
			}
		}

		protected override void OnOpen()
		{
		}

		protected override void OnClose()
		{
		}

		public override void Update()
		{
		}

		public void ShowText(GameTextType type)
		{
			Transition transition = null;
			switch (type)
			{
			case GameTextType.Room:
				transition = _showRoomTransition;
				break;
			case GameTextType.Ready:
				transition = _showReadyTransition;
				break;
			case GameTextType.BigWave:
				transition = _showBigWaveTransition;
				break;
			case GameTextType.LastWave:
				transition = _showLastWaveTransition;
				break;
			case GameTextType.BossAppear:
				transition = _showBossAppearTransition;
				break;
			case GameTextType.BossFlag:
				transition = _showBossFlagTransition;
				break;
			default:
				return;
			}
			if (transition != null)
			{
				transition.Play();
			}
		}
	}
}
