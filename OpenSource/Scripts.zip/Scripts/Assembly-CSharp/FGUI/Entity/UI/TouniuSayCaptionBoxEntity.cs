using FairyGUI;
using Touniu.Entity;
using Touniu.Enum;
using UnityEngine;

namespace FGUI.Entity.UI
{
	public class TouniuSayCaptionBoxEntity
	{
		private GTextField _textField;

		private GTextField _timeTextField;

		private GComponent _selectCom;

		private GButton _yesButton;

		private GButton _noButton;

		private GComponent _valueCom;

		private GButton _valueButton;

		private GButton _addValueButton;

		private GButton _subValueButton;

		private GComponent _shopCom;

		private GList _shopList;

		private GButton _confirmButton;

		private TouniuSayEntity _touniuSayEntity;

		private GGroup _aGroup;

		private GGroup _bGroup;

		public readonly GComponent component;

		public TouniuSayCaptionBoxEntity(GComponent com)
		{
			component = com;
		}

		public void Start()
		{
			// TODO: reconstruct
			// Original body resolves child GObjects from `component` via GetChild(<name>),
			// but the FairyGUI child-name string literals are unresolved obfuscated globals
			// in the decompilation, so the body cannot be faithfully rebuilt.
		}

		public void Open()
		{
			// TODO: reconstruct
			// Original body pulls the current TouniuSayEntity from an unidentified manager
			// singleton and wires up many child GObjects via GetChild(<name>); the required
			// string literals and manager type are unresolved, so this stays a stub.
		}

		public void Update()
		{
			if (_touniuSayEntity == null)
			{
				return;
			}
			TouniuSayData sayData = _touniuSayEntity.sayData;
			if (sayData != null && sayData.sayType == SayType.Select)
			{
				UpdateButtonTime();
			}
			sayData = _touniuSayEntity.sayData;
			if (sayData != null && sayData.sayType == SayType.Shop)
			{
				UpdateButtonTime();
			}
		}

		private void ProvideAddValue()
		{
			// TODO: reconstruct
			// Adjusts _touniuSayEntity.sayData.provideValue then writes it to a child text
			// field of _valueButton via GetChild(<name>) with a numeric format string; both
			// string literals are unresolved obfuscated globals, so this stays a stub.
		}

		private void ProvideSubValue()
		{
			// TODO: reconstruct
			// Mirror of ProvideAddValue (subtracts provideStepValue, clamps to provideMinValue);
			// blocked by the same unresolved child-name and format string literals.
		}

		private void SetTextColor(ColorType colorType)
		{
			// TODO: reconstruct
			// Selects an RGBA Color for _textField based on colorType; the concrete Color
			// constants are unresolved data globals, so the mapping cannot be rebuilt faithfully.
		}

		private void SetupSelectionButtons(TouniuSayData sayData)
		{
			// TODO: reconstruct
			// Populates the selection UI (option titles / provide value) and binds yes/no
			// touch handlers; depends on unresolved child-name and format string literals.
		}

		public void SetupShopButtons()
		{
			// TODO: reconstruct
			// Builds the shop item list from the say entity and binds the confirm handler,
			// but the loop reads shop-item collection members that are not present on the
			// declared TouniuSayEntity type, and it needs unresolved child-name/URL strings.
		}

		private void UpdateButtonTime()
		{
			if (_timeTextField == null)
			{
				return;
			}
			if (_touniuSayEntity != null)
			{
				int remaining = Mathf.CeilToInt(_touniuSayEntity.duration - _touniuSayEntity.currentDuration);
				_timeTextField.text = remaining.ToString();
			}
		}
	}
}
