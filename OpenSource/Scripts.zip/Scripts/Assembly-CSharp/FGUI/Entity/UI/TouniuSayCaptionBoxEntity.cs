using FairyGUI;
using Touniu.Entity;
using Touniu.Enum;
using UnityEngine;

namespace FGUI.Entity.UI
{
	public class TouniuSayCaptionBoxEntity
	{
		private GTextField _textField;

		private GTextField _timeTextField;

		private GComponent _selectCom;

		private GButton _yesButton;

		private GButton _noButton;

		private GComponent _valueCom;

		private GButton _valueButton;

		private GButton _addValueButton;

		private GButton _subValueButton;

		private GComponent _shopCom;

		private GList _shopList;

		private GButton _confirmButton;

		private TouniuSayEntity _touniuSayEntity;

		private GGroup _aGroup;

		private GGroup _bGroup;

		public readonly GComponent component;

		public TouniuSayCaptionBoxEntity(GComponent com)
		{
			component = com;
		}

		public void Start()
		{
		}

		public void Open()
		{
		}

		public void Update()
		{
			if (_touniuSayEntity == null)
			{
				return;
			}
			TouniuSayData sayData = _touniuSayEntity.sayData;
			if (sayData != null && sayData.sayType == SayType.Select)
			{
				UpdateButtonTime();
			}
			sayData = _touniuSayEntity.sayData;
			if (sayData != null && sayData.sayType == SayType.Shop)
			{
				UpdateButtonTime();
			}
		}

		private void ProvideAddValue()
		{
		}

		private void ProvideSubValue()
		{
		}

		private void SetTextColor(ColorType colorType)
		{
		}

		private void SetupSelectionButtons(TouniuSayData sayData)
		{
		}

		public void SetupShopButtons()
		{
		}

		private void UpdateButtonTime()
		{
			if (_timeTextField == null)
			{
				return;
			}
			if (_touniuSayEntity != null)
			{
				int remaining = Mathf.CeilToInt(_touniuSayEntity.duration - _touniuSayEntity.currentDuration);
				_timeTextField.text = remaining.ToString();
			}
		}
	}
}
