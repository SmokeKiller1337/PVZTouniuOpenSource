using System;
using FairyGUI;

namespace FGUI.Entity.UI
{
	public class SelectPopupBoxEntity : DefaultComponentEntity
	{
		public SelectPopupBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
		}

		public void OpenSelect(string title, string content, Action yesAction = null, Action noAction = null)
		{
			OpenSelect(null, title, content, yesAction, noAction);
		}

		public void OpenSelect(GObject com, string title, string content, Action yesAction = null, Action noAction = null)
		{
			GObject titleObj = component.GetChild("title");
			GTextField titleField = (titleObj != null) ? titleObj.asTextField : null;
			if (titleField != null)
			{
				titleField.text = title;
			}
			GObject contentObj = component.GetChild("content");
			GTextField contentField = (contentObj != null) ? contentObj.asTextField : null;
			if (contentField != null)
			{
				contentField.text = content;
			}
			GObject yesObj = component.GetChild("yesBtn");
			GButton yesButton = (yesObj != null) ? yesObj.asButton : null;
			if (yesButton != null)
			{
				yesButton.onClick.Set((EventCallback0)delegate
				{
					GRoot inst = GRoot.inst;
					if (component != null && inst != null)
					{
						inst.HidePopup(component);
						yesAction?.Invoke();
					}
				});
			}
			GObject noObj = component.GetChild("noBtn");
			GButton noButton = (noObj != null) ? noObj.asButton : null;
			if (noButton != null)
			{
				noButton.onClick.Set((EventCallback0)delegate
				{
					GRoot inst = GRoot.inst;
					if (component != null && inst != null)
					{
						inst.HidePopup(component);
						noAction?.Invoke();
					}
				});
			}
			GRoot root = GRoot.inst;
			if (root != null)
			{
				if (com == null)
				{
					root.ShowPopup(component);
				}
				else
				{
					root.ShowPopup(component, com);
				}
			}
		}
	}
}
