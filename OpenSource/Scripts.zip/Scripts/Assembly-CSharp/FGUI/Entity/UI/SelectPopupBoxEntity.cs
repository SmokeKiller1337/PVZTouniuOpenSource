using System;
using FairyGUI;

namespace FGUI.Entity.UI
{
	public class SelectPopupBoxEntity : DefaultComponentEntity
	{
		public SelectPopupBoxEntity(GComponent component)
			: base(component)
		{
			// NOTE: base field `component` is readonly and set by the base ctor;
			// the derived ctor cannot reassign it in C#. Body left as stub.
			// TODO: reconstruct
		}

		public override void Start()
		{
			// Decompile binds a folded delegate (unidentifiable method token) to a
			// child button's onClick; target method cannot be reliably recovered.
			// TODO: reconstruct
		}

		public void OpenSelect(string title, string content, Action yesAction = null, Action noAction = null)
		{
			OpenSelect(null, title, content, yesAction, noAction);
		}

		public void OpenSelect(GObject com, string title, string content, Action yesAction = null, Action noAction = null)
		{
			GObject titleObj = component.GetChild("title");
			GTextField titleField = (titleObj != null) ? titleObj.asTextField : null;
			if (titleField != null)
			{
				titleField.text = title;
			}
			GObject contentObj = component.GetChild("content");
			GTextField contentField = (contentObj != null) ? contentObj.asTextField : null;
			if (contentField != null)
			{
				contentField.text = content;
			}
			GObject yesObj = component.GetChild("yesBtn");
			GButton yesButton = (yesObj != null) ? yesObj.asButton : null;
			if (yesButton != null)
			{
				yesButton.onClick.Set((EventCallback0)delegate
				{
					GRoot inst = GRoot.inst;
					if (component != null && inst != null)
					{
						inst.HidePopup(component);
						yesAction?.Invoke();
					}
				});
			}
			GObject noObj = component.GetChild("noBtn");
			GButton noButton = (noObj != null) ? noObj.asButton : null;
			if (noButton != null)
			{
				noButton.onClick.Set((EventCallback0)delegate
				{
					GRoot inst = GRoot.inst;
					if (component != null && inst != null)
					{
						inst.HidePopup(component);
						noAction?.Invoke();
					}
				});
			}
			GRoot root = GRoot.inst;
			if (root != null)
			{
				if (com == null)
				{
					root.ShowPopup(component);
				}
				else
				{
					root.ShowPopup(component, com);
				}
			}
		}
	}
}
