using System;
using System.Collections.Generic;
using FairyGUI;
using Level.Enum;
using Level.Object;
using Level.Static;
using Save.Data;
using cfg;

namespace FGUI.Entity.UI
{
	public class SelectLevelBoxEntity : DefaultComponentEntity
	{
		public int currentPage;

		public int totalPage;

		public GComponent mode0Com;

		public GComponent mode1Com;

		public GComponent mode2Com;

		public AreaEntity areaEntity;

		public List<LevelObject> levelObjectList;

		private int _miniType;

		private readonly List<string> _miniTypeTitleList;

		public SelectLevelBoxEntity(GComponent component)
			: base(component)
		{
			currentPage = 1;
			_miniTypeTitleList = new List<string>();
		}

		public override void Open()
		{
		}

		public override void Awake()
		{
		}

		public override void Start()
		{
		}

		protected override void OnOpen()
		{
		}

		public override void Update()
		{
		}

		private int GetAreaTotalPage()
		{
			return LubanUtils.Tables.Area.DataList.Count;
		}

		private GComponent GetModeCom()
		{
			switch (AreaStatic.Mode)
			{
			case 0:
				return mode0Com;
			case 1:
				return mode1Com;
			case 2:
				return mode2Com;
			default:
				throw new ArgumentOutOfRangeException();
			}
		}

		private int GetMiniSuccessCount(MiniType type)
		{
			int num = 0;
			foreach (LevelObject levelObject in LevelStatic.mode2LevelObjectList)
			{
				if (levelObject.miniType == type)
				{
					AreaData.LevelData levelData = LevelStatic.GetLevelData(2, levelObject);
					if (levelData != null && levelData.difficulty + levelData.touniuDifficulty > 1)
					{
						num++;
					}
				}
			}
			return num;
		}

		private int GetMiniCount(MiniType type)
		{
			int num = 0;
			foreach (LevelObject levelObject in LevelStatic.mode2LevelObjectList)
			{
				if (levelObject.miniType == type)
				{
					num++;
				}
			}
			return num;
		}
	}
}
