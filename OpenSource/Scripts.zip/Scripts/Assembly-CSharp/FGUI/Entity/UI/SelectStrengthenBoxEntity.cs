using FGUI.Static;
using FairyGUI;
using Game.Manager;
using Level.Manager;
using Plant.Entity;
using Strengthen.Entity;

namespace FGUI.Entity.UI
{
	public class SelectStrengthenBoxEntity : DefaultComponentEntity
	{
		public SelectStrengthenBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
			base.Start();
			if (component == null)
			{
				return;
			}
			// Wire the "revoke" (cancel) button: clicking it deselects the current
			// strengthen choice and closes this box.
			GObject revoke = component.GetChild("revoke");
			if (revoke == null)
			{
				return;
			}
			revoke.onClick.Set((EventCallback0)delegate
			{
				SelectStrengthenEntity sse = CardSlotManager.Instance.selectStrengthenEntity;
				if (sse == null || !sse.isSelected)
				{
					return;
				}
				sse.isSelected = false;
				FGUIConstant.SelectStrengthenBox.Close();
			});
		}

		protected override void OnOpen()
		{
			// Opening the strengthen selection pauses the game (guarded by isOpenPause).
			if (!isOpenPause)
			{
				return;
			}
			GameManager.Instance.Pause(this);
		}

		protected override void OnClose()
		{
		}

		public override void Update()
		{
			if (component == null)
			{
				return;
			}
			GObject listObj = component.GetChild("list");
			if (listObj == null)
			{
				return;
			}
			GList list = listObj.asList;
			if (list == null)
			{
				return;
			}
			list.RemoveChildrenToPool();

			for (int i = 0; ; i++)
			{
				SelectStrengthenEntity sse = CardSlotManager.Instance.selectStrengthenEntity;
				if (sse == null || sse.strengthenList == null || i >= sse.strengthenList.Count)
				{
					return;
				}
				StrengthenEntity strengthen = sse.strengthenList[i];
				CardEntity cardEntity = sse.cardEntity;
				if (cardEntity == null)
				{
					return;
				}

				string url = UIPackage.GetItemURL("Game", "StrengthenButton");
				GObject item = list.AddItemFromPool(url);
				if (item == null)
				{
					return;
				}
				GButton button = item.asButton;
				if (button == null)
				{
					return;
				}

				SetStrengthenButtonBackground(button, cardEntity.level);

				GObject backgroundObj = button.GetChild("background");
				if (backgroundObj == null)
				{
					return;
				}
				FGUIUtils.SetAreaBackground(backgroundObj.asCom, cardEntity.backgroundId);

				GObject gemObj = button.GetChild("gem");
				if (gemObj == null)
				{
					return;
				}
				FGUIUtils.SetPowerGem(gemObj.asCom, i);

				GObject titleObj = button.GetChild("title");
				if (titleObj == null)
				{
					return;
				}
				GTextField titleField = titleObj.asTextField;
				if (titleField == null)
				{
					return;
				}
				titleField.text = strengthen.title;

				GObject contentObj = button.GetChild("content");
				if (contentObj == null)
				{
					return;
				}
				GTextField contentField = contentObj.asTextField;
				if (contentField == null)
				{
					return;
				}
				contentField.text = strengthen.GetDesc(cardEntity);

				GObject cooldownObj = button.GetChild("cooldown");
				if (cooldownObj == null)
				{
					return;
				}
				GTextField cooldownField = cooldownObj.asTextField;
				if (cooldownField == null)
				{
					return;
				}
				cooldownField.SetVar("value", strengthen.cooldownTime.ToString("F0")).FlushVars();

				GObject cooldownVisObj = button.GetChild("cooldown");
				if (cooldownVisObj == null)
				{
					return;
				}
				cooldownVisObj.visible = strengthen.cooldownTime > 0f;

				GObject cooldownIconObj = button.GetChild("cooldownIcon");
				if (cooldownIconObj == null)
				{
					return;
				}
				cooldownIconObj.visible = strengthen.cooldownTime > 0f;

				GObject iconObj = button.GetChild("icon");
				if (iconObj == null)
				{
					return;
				}
				GLoader iconLoader = iconObj.asLoader;
				if (iconLoader == null)
				{
					return;
				}
				iconLoader.url = FGUIStatic.GetIcon(cardEntity);

				// Confirm handler: capture the option index and, if the player can afford
				// the level-up cost, spend the diamonds, level up the card and close the box.
				int index = i;
				button.onClick.Set((EventCallback0)delegate
				{
					SelectStrengthenEntity selectEntity = CardSlotManager.Instance.selectStrengthenEntity;
					if (selectEntity == null || !selectEntity.isSelected)
					{
						return;
					}
					if (selectEntity.strengthenList == null || index >= selectEntity.strengthenList.Count)
					{
						return;
					}
					CardEntity card = selectEntity.cardEntity;
					if (card == null)
					{
						return;
					}
					CardSlotManager manager = CardSlotManager.Instance;
					float cost = manager.GetLevelUpCost(card.level);
					if (manager.DiamondValue < cost)
					{
						FGUIConstant.CardSlotBox.DiamondNotEnough();
						selectEntity.isSelected = false;
					}
					else
					{
						selectEntity.isSelected = false;
						manager.DiamondValue -= cost;
						FGUIConstant.CardSlotBox.UpdateDiamondNumber();
						FGUIConstant.CardSlotBox.UpdateLevelUpButton();
						card.LevelUp(index);
					}
					FGUIConstant.SelectStrengthenBox.Close();
					FGUIConstant.CardSlotBox.UpdateLevelUpButton();
				});
				button.grayed = false;
			}
		}

		private void SetStrengthenButtonBackground(GButton button, int level)
		{
			if (button == null)
			{
				return;
			}
			for (int i = 0; i <= 2; i++)
			{
				GObject groupObj = button.GetChild("n" + i);
				if (groupObj == null)
				{
					return;
				}
				GComponent group = groupObj.asCom;
				if (group == null)
				{
					return;
				}
				for (int j = 1; j < 4; j++)
				{
					GObject frame = group.GetChild("n" + j);
					if (frame == null)
					{
						return;
					}
					frame.visible = false;
				}
				GObject active = group.GetChild("n" + (level + 1));
				if (active != null)
				{
					active.visible = true;
				}
			}
		}
	}
}
