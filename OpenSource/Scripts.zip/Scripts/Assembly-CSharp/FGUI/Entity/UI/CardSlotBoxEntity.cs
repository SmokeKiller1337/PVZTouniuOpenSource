using System.Collections.Generic;
using FGUI.Entity.UI.GameMain.Entity;
using FairyGUI;
using Plant.Entity;
using UnityEngine;

namespace FGUI.Entity.UI
{
	public class CardSlotBoxEntity : DefaultComponentEntity
	{
		private GComponent _cardSlotACom;

		private GComponent _cardSlotBCom;

		private Dictionary<int, CardSlotItemEntity> _cardSlotDic;

		private CardSlotItemEntity _extraCardSlot;

		private CardEntity _currentOverTextCard;

		public Animator beltAnimator;

		private GComponent _conveyorCom;

		private Dictionary<CardEntity, ConveyorCardComEntity> _conveyorCardDic;

		private Dictionary<CardEntity, CardSlotItemEntity> _conveyorSlotDic;

		public Dictionary<int, CardSlotItemEntity> CardSlotDic
		{
			get
			{
				return _cardSlotDic;
			}
			set
			{
				_cardSlotDic = value;
			}
		}

		public CardSlotItemEntity ExtraCardSlot
		{
			get
			{
				return _extraCardSlot;
			}
			set
			{
				_extraCardSlot = value;
			}
		}

		public CardSlotBoxEntity(GComponent component)
			: base(component)
		{
			_cardSlotDic = new Dictionary<int, CardSlotItemEntity>();
		}

		public override void Start()
		{
		}

		public override void Update()
		{
		}

		public void UpdateCardCooldown(CardEntity cardEntity)
		{
		}

		public void UpdateCard(CardEntity cardEntity)
		{
		}

		public void CardCooldownEnd(CardEntity cardEntity)
		{
			if (cardEntity == null)
			{
				return;
			}
			CardSlotItemEntity cardSlotItemEntity = GetCardSlotItemEntity(cardEntity);
			if (cardSlotItemEntity == null)
			{
				return;
			}
			cardSlotItemEntity.cooldownEndTransition.Stop();
			cardSlotItemEntity.cooldownEndTransition.Play();
			if (_currentOverTextCard == cardEntity)
			{
				OpenCardText(cardSlotItemEntity.cardButton, cardEntity);
			}
		}

		public void CardPowerCooldownEnd(CardEntity cardEntity)
		{
			CardSlotItemEntity cardSlotItemEntity = GetCardSlotItemEntity(cardEntity);
			if (cardSlotItemEntity != null)
			{
				cardSlotItemEntity.powerCooldownEndTransition.Play(1, 0f, null);
			}
		}

		public void UpdateSunNumber()
		{
		}

		public GComponent GetCurrentCardSlot()
		{
			return null;
		}

		public void SunNotEnough()
		{
		}

		public void DiamondNotEnough()
		{
		}

		public void HammerNotEnough()
		{
		}

		public void UpdateTool()
		{
		}

		public void RefreshCardSlot()
		{
		}

		public void AddCard(CardEntity cardEntity)
		{
		}

		public void UpdateExtraCard()
		{
		}

		private void InitCardItem(GComponent com, CardEntity cardEntity)
		{
		}

		private string GetCurrentCardItemType()
		{
			return null;
		}

		private void SetCardOverText(GObject com, CardEntity cardEntity)
		{
		}

		private void SetCardOverText(GObject com, string title, string content)
		{
		}

		private void OpenCardText(GObject com, CardEntity cardEntity)
		{
		}

		public void PickUpCard(CardEntity cardEntity)
		{
		}

		public void DropCard(CardEntity cardEntity)
		{
		}

		public void UpdateDiamondNumber()
		{
		}

		public void UpdateLevelUpButton()
		{
		}

		private void SetLevelUpButtonBackground(GButton button, int level)
		{
		}

		private CardSlotItemEntity GetCardSlotItemEntity(CardEntity cardEntity)
		{
			return null;
		}

		public void RefreshConveyor()
		{
		}

		public void JoinConveyorCard(CardEntity cardEntity, ConveyorCardComEntity comEntity = null)
		{
		}

		public void LeaveConveyorCard(CardEntity cardEntity)
		{
		}

		public void UpdateConveyorCard(CardEntity cardEntity)
		{
		}

		public void UpdateConveyorSpeed()
		{
		}

		public void PickUpConveyorCard(CardEntity cardEntity)
		{
		}

		public void DropConveyorCard(CardEntity cardEntity)
		{
		}

		private void InitConveyorCardItem(GComponent com, CardEntity cardEntity)
		{
		}

		private void UpdateConveyorLevelUpButton(CardEntity entity)
		{
		}

		public void UpdateFocusTime()
		{
		}
	}
}
