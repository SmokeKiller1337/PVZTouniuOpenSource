using System.Collections.Generic;
using FGUI.Entity.UI.GameMain.Entity;
using FairyGUI;
using Plant.Entity;
using UnityEngine;

namespace FGUI.Entity.UI
{
	public class CardSlotBoxEntity : DefaultComponentEntity
	{
		private GComponent _cardSlotACom;

		private GComponent _cardSlotBCom;

		private Dictionary<int, CardSlotItemEntity> _cardSlotDic;

		private CardSlotItemEntity _extraCardSlot;

		private CardEntity _currentOverTextCard;

		public Animator beltAnimator;

		private GComponent _conveyorCom;

		private Dictionary<CardEntity, ConveyorCardComEntity> _conveyorCardDic;

		private Dictionary<CardEntity, CardSlotItemEntity> _conveyorSlotDic;

		public Dictionary<int, CardSlotItemEntity> CardSlotDic
		{
			get
			{
				return _cardSlotDic;
			}
			set
			{
				_cardSlotDic = value;
			}
		}

		public CardSlotItemEntity ExtraCardSlot
		{
			get
			{
				return _extraCardSlot;
			}
			set
			{
				_extraCardSlot = value;
			}
		}

		public CardSlotBoxEntity(GComponent component)
			: base(component)
		{
			_cardSlotDic = new Dictionary<int, CardSlotItemEntity>();
		}

		public override void Start()
		{
			// TODO: reconstruct
		}

		public override void Update()
		{
			// TODO: reconstruct
		}

		public void UpdateCardCooldown(CardEntity cardEntity)
		{
			// TODO: reconstruct
		}

		public void UpdateCard(CardEntity cardEntity)
		{
			// TODO: reconstruct
		}

		public void CardCooldownEnd(CardEntity cardEntity)
		{
			if (cardEntity == null)
			{
				return;
			}
			CardSlotItemEntity cardSlotItemEntity = GetCardSlotItemEntity(cardEntity);
			if (cardSlotItemEntity == null)
			{
				return;
			}
			cardSlotItemEntity.cooldownEndTransition.Stop();
			cardSlotItemEntity.cooldownEndTransition.Play();
			if (_currentOverTextCard == cardEntity)
			{
				OpenCardText(cardSlotItemEntity.cardButton, cardEntity);
			}
		}

		public void CardPowerCooldownEnd(CardEntity cardEntity)
		{
			CardSlotItemEntity cardSlotItemEntity = GetCardSlotItemEntity(cardEntity);
			if (cardSlotItemEntity != null)
			{
				cardSlotItemEntity.powerCooldownEndTransition.Play(1, 0f, null);
			}
		}

		public void UpdateSunNumber()
		{
			// TODO: reconstruct
		}

		public GComponent GetCurrentCardSlot()
		{
			// TODO: reconstruct
			return null;
		}

		public void SunNotEnough()
		{
			// TODO: reconstruct
		}

		public void DiamondNotEnough()
		{
			// TODO: reconstruct
		}

		public void HammerNotEnough()
		{
			// TODO: reconstruct
		}

		public void UpdateTool()
		{
			// TODO: reconstruct
		}

		public void RefreshCardSlot()
		{
			// TODO: reconstruct
		}

		public void AddCard(CardEntity cardEntity)
		{
			// TODO: reconstruct
		}

		public void UpdateExtraCard()
		{
			// TODO: reconstruct
		}

		private void InitCardItem(GComponent com, CardEntity cardEntity)
		{
			// TODO: reconstruct
		}

		private string GetCurrentCardItemType()
		{
			// TODO: reconstruct
			return null;
		}

		private void SetCardOverText(GObject com, CardEntity cardEntity)
		{
			// TODO: reconstruct
		}

		private void SetCardOverText(GObject com, string title, string content)
		{
			// TODO: reconstruct
		}

		private void OpenCardText(GObject com, CardEntity cardEntity)
		{
			// TODO: reconstruct
		}

		public void PickUpCard(CardEntity cardEntity)
		{
			// TODO: reconstruct
		}

		public void DropCard(CardEntity cardEntity)
		{
			// TODO: reconstruct
		}

		public void UpdateDiamondNumber()
		{
			// TODO: reconstruct
		}

		public void UpdateLevelUpButton()
		{
			// TODO: reconstruct
		}

		private void SetLevelUpButtonBackground(GButton button, int level)
		{
			// TODO: reconstruct
		}

		private CardSlotItemEntity GetCardSlotItemEntity(CardEntity cardEntity)
		{
			// TODO: reconstruct
			return null;
		}

		public void RefreshConveyor()
		{
			// TODO: reconstruct
		}

		public void JoinConveyorCard(CardEntity cardEntity, ConveyorCardComEntity comEntity = null)
		{
			// TODO: reconstruct
		}

		public void LeaveConveyorCard(CardEntity cardEntity)
		{
			// TODO: reconstruct
		}

		public void UpdateConveyorCard(CardEntity cardEntity)
		{
			// TODO: reconstruct
		}

		public void UpdateConveyorSpeed()
		{
			// TODO: reconstruct
		}

		public void PickUpConveyorCard(CardEntity cardEntity)
		{
			// TODO: reconstruct
		}

		public void DropConveyorCard(CardEntity cardEntity)
		{
			// TODO: reconstruct
		}

		private void InitConveyorCardItem(GComponent com, CardEntity cardEntity)
		{
			// TODO: reconstruct
		}

		private void UpdateConveyorLevelUpButton(CardEntity entity)
		{
			// TODO: reconstruct
		}

		public void UpdateFocusTime()
		{
			// TODO: reconstruct
		}
	}
}
