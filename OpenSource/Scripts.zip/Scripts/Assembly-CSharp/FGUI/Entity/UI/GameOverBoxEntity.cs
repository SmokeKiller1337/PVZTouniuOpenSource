using FairyGUI;
using Game.Manager;

namespace FGUI.Entity.UI
{
	public class GameOverBoxEntity : DefaultComponentEntity
	{
		public GameOverBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
			// TODO: reconstruct
			// The decompiled body creates a <>c__DisplayClass1_0 closure, marks this
			// entity as pause-capable, calls base.Start(), then wires three child
			// button onClick handlers (<Start>b__1_0, <Start>b__1, <Start>b__1_2).
			// The button child names and the exact delegate wiring depend on opaque
			// string constants (DAT_182e65728 / DAT_182e71570 / DAT_182e7ee48) that
			// could not be recovered from the folded pseudocode, so the body is left
			// as a stub rather than fabricating GetChild("...") names / handler logic.
		}

		protected override void OnOpen()
		{
			// Guard: only participate in the pause set when the box is flagged as a
			// pausing box (base flag at native offset 0x21 == isOpenPause).
			if (!isOpenPause)
			{
				return;
			}
			// The folded body is byte-identical to GameManager.Pause(object): it adds
			// this entity to the pause look-up list and, when it becomes the first
			// pauser, pauses the game and refreshes the main-box pause text. Expressed
			// via the verified public accessor rather than inlining the private list.
			GameManager.Instance.Pause(this);
		}

		protected override void OnClose()
		{
			// Decompiles to an empty body (RVA 0x386160 folds onto a no-op .ctor).
		}

		public override void Update()
		{
			// TODO: reconstruct
			// The decompiled body fetches a child button by an opaque string name
			// (DAT_182e71570) via component.GetChild(...).asButton and toggles its
			// enabled/grayed state from IsDifficulty1() / a Tilemaps.StartUp-style
			// check, then flushes FairyGUI relation/bounds updates through raw vtable
			// offsets. The child name and the button state member being written could
			// not be resolved reliably, so the body is left as a stub rather than
			// guessing GetChild("...") / the FairyGUI property involved.
		}

		public bool IsDifficulty1()
		{
			// TODO: reconstruct
			// The decompiled body reads the game/level manager singletons and compares
			// two flags at native offsets 0x20/0x24 of the first level record to 1
			// (a "difficulty == 1" style check). The concrete manager type behind
			// DAT_182e507b0 and the meaning of those offsets could not be verified
			// against the project, so the original false-returning stub is preserved.
			return false;
		}
	}
}
