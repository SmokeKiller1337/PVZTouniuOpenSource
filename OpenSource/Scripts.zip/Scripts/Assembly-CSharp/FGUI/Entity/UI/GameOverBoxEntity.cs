using FairyGUI;
using Game.Manager;

namespace FGUI.Entity.UI
{
	public class GameOverBoxEntity : DefaultComponentEntity
	{
		public GameOverBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
		}

		protected override void OnOpen()
		{
			if (!isOpenPause)
			{
				return;
			}
			GameManager.Instance.Pause(this);
		}

		protected override void OnClose()
		{
		}

		public override void Update()
		{
		}

		public bool IsDifficulty1()
		{
			return false;
		}
	}
}
