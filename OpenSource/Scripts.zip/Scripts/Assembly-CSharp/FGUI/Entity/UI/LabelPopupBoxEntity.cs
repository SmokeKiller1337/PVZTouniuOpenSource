using FairyGUI;

namespace FGUI.Entity.UI
{
	public class LabelPopupBoxEntity : DefaultComponentEntity
	{
		public LabelPopupBoxEntity(GComponent component)
			: base(component)
		{
			// Decompiled ctor stores 'component' at the base 'component' field offset,
			// but that field is declared 'readonly' in FGUIComponentEntity and is set
			// via the base constructor. The authoritative stub base call is ': base(null)'
			// and the body carries no additional reconstructable logic.
		}

		public override void Start()
		{
			// TODO: reconstruct
			// Binds a click handler on a child button (child name is an opaque IL2CPP
			// string constant) to an entity method (target is an unresolved metadata
			// token). Left as stub to avoid inventing member/string references.
		}

		public void OpenText(string title, string content)
		{
			// TODO: reconstruct
			// Opens the box, sets two child GTextField texts (title/content), then
			// GRoot.inst.ShowPopup(component). The child field names are opaque IL2CPP
			// string constants and the leading virtual-slot call is unconfirmed, so this
			// is left as a stub rather than guessing the child names.
		}

		public void OpenText(GObject com, string title, string content)
		{
			// TODO: reconstruct
			// As above, but ShowPopup(component, com). Same unresolved child-name string
			// constants; left as a stub.
		}
	}
}
