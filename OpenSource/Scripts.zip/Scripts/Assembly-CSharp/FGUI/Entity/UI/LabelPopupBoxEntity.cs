using FairyGUI;

namespace FGUI.Entity.UI
{
	public class LabelPopupBoxEntity : DefaultComponentEntity
	{
		public LabelPopupBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
		}

		public void OpenText(string title, string content)
		{
		}

		public void OpenText(GObject com, string title, string content)
		{
		}
	}
}
