using System.Collections.Generic;
using FairyGUI;
using Plant.Entity;
using UnityEngine;

namespace FGUI.Entity.UI
{
	public class ConveyorCardGroupBoxEntity : DefaultComponentEntity
	{
		private List<CardEntity> _conveyorPreviewCardList;

		[HideInInspector]
		public GList conveyorCardList;

		public ConveyorCardGroupBoxEntity(GComponent component)
			: base(component)
		{
			_conveyorPreviewCardList = new List<CardEntity>();
		}

		public override void Awake()
		{
			base.Awake();
		}

		public override void Start()
		{
			base.Start();
			isOpenPause = true;
		}

		public override void Close()
		{
			base.Close();
			if (_conveyorPreviewCardList == null)
			{
				return;
			}
			// Destroy every previewed card's GameObject, then clear the list.
			foreach (CardEntity cardEntity in _conveyorPreviewCardList)
			{
				if (cardEntity != null)
				{
					Object.Destroy(cardEntity.gameObject);
				}
			}
			_conveyorPreviewCardList.Clear();
		}

		public override void Update()
		{
		}

		private void InitCardItem(GComponent cardItem, CardEntity cardEntity)
		{
		}

		private static void SetOverText(GObject component, string title, string content)
		{
		}
	}
}
