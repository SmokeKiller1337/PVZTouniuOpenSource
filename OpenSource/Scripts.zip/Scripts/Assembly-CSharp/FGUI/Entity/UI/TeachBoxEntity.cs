using System.Collections.Generic;
using FairyGUI;
using cfg;

namespace FGUI.Entity.UI
{
	public class TeachBoxEntity : DefaultComponentEntity
	{
		private List<int> _teachList;

		public TeachBoxEntity(GComponent component)
			: base(component)
		{
			_teachList = new List<int>();
		}

		public override void Start()
		{
		}

		public void OpenTeach(TeachEntity teachEntity)
		{
		}

		public void TryOpenTeach(int id)
		{
		}

		protected override void OnCloseEnd()
		{
			base.OnCloseEnd();
			if (_teachList != null && _teachList.Count > 0)
			{
				int id = _teachList[0];
				_teachList.RemoveAt(0);
				TryOpenTeach(id);
			}
		}

		public void OpenTeachList()
		{
		}

		private void UpdateTeach(TeachEntity teachEntity)
		{
		}
	}
}
