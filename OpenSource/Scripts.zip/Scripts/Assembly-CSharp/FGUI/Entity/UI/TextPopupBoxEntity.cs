using FairyGUI;

namespace FGUI.Entity.UI
{
	public class TextPopupBoxEntity : DefaultComponentEntity
	{
		public TextPopupBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
		}

		public void OpenText(string title, string content)
		{
			Open();
			if (component == null)
			{
				return;
			}
			GObject titleChild = component.GetChild("title");
			if (titleChild == null)
			{
				return;
			}
			GTextField titleField = titleChild.asTextField;
			if (titleField == null)
			{
				return;
			}
			titleField.text = title;
			GObject contentChild = component.GetChild("content");
			if (contentChild == null)
			{
				return;
			}
			GTextField contentField = contentChild.asTextField;
			if (contentField == null)
			{
				return;
			}
			contentField.text = content;
			GRoot inst = GRoot.inst;
			if (inst != null)
			{
				inst.ShowPopup(component);
			}
		}

		public void OpenText(GObject com, string title, string content)
		{
			Open();
			if (component == null)
			{
				return;
			}
			GObject titleChild = component.GetChild("title");
			if (titleChild == null)
			{
				return;
			}
			GTextField titleField = titleChild.asTextField;
			if (titleField == null)
			{
				return;
			}
			titleField.text = title;
			GObject contentChild = component.GetChild("content");
			if (contentChild == null)
			{
				return;
			}
			GTextField contentField = contentChild.asTextField;
			if (contentField == null)
			{
				return;
			}
			contentField.text = content;
			GRoot inst = GRoot.inst;
			if (inst != null)
			{
				inst.ShowPopup(component, com);
			}
		}
	}
}
