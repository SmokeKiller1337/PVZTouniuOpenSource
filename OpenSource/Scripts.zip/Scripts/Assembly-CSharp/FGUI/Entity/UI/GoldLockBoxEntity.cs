using System.Collections.Generic;
using BirdCommon.Manager;
using FGUI.Entity.UI.Achievement;
using FGUI.Static;
using FairyGUI;
using Save.Constant;

namespace FGUI.Entity.UI
{
	public class GoldLockBoxEntity : DefaultComponentEntity
	{
		public List<GoldLockItemEntity> goldLockItemList;

		private GList _unLockList;

		public GoldLockBoxEntity(GComponent component)
			: base(component)
		{
			goldLockItemList = new List<GoldLockItemEntity>();
		}

		public override void Start()
		{
			base.Start();
			goldLockItemList.Add(new GoldLockItemEntity
			{
				goldNumber = 100,
				cardId = 420
			});
			goldLockItemList.Add(new GoldLockItemEntity
			{
				goldNumber = 200,
				cardId = 470
			});
			_unLockList = component.GetChild("unLockList").asList;
		}

		public override void Update()
		{
			if (component == null)
			{
				return;
			}
			GTextField valueText = component.GetChild("valueText").asTextField;
			valueText.text = SaveDataConstant.ValueShopData.Value.ToString();
			if (_unLockList == null)
			{
				return;
			}
			_unLockList.RemoveChildrenToPool();
			foreach (GoldLockItemEntity item in goldLockItemList)
			{
				GComponent itemCom = _unLockList.AddItemFromPool(UIPackage.GetItemURL("Common", "GoldLockItem")).asCom;
				itemCom.GetChild("numberText").asTextField.text = item.goldNumber.ToString();
				SetCardButton(itemCom.GetChild("cardButton").asButton, item.cardId);
			}
			ValueShopManager.Instance.UpdateLockReward();
		}

		private void SetCardButton(GObject gObject, int cardId)
		{
			if (gObject == null)
			{
				return;
			}
			GButton button = gObject.asButton;
			FGUIUtils.SetCardBackground(button, 0);
			if (button == null)
			{
				return;
			}
			button.touchable = true;
			button.GetChild("numberText").asTextField.text = string.Empty;
			button.GetChild("icon").asLoader.url = string.Empty;
			button.GetChild("select").visible = false;
			button.GetChild("effect").visible = false;
			button.GetChild("lock").visible = false;
			// TODO: reconstruct card-reward lookup — the decompiled body reads a
			// Dictionary<int, ...> keyed by cardId off ValueShopManager.Instance and
			// updates the number text + icon (FGUIStatic.GetIcon) from it, but no such
			// member exists on the restored ValueShopManager, so this branch is omitted.
		}
	}
}
