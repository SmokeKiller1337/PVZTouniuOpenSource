using System.Collections.Generic;
using FairyGUI;
using Plant.Entity;
using UnityEngine;

namespace FGUI.Entity.UI
{
	public class PreparationBoxEntity : DefaultComponentEntity
	{
		public GComponent cardSlotCom;

		public GComponent selectCardCom;

		public GList cardSlotListCom;

		public GList preparationCardListCom;

		public GList cardSlotConveyorCardListCom;

		public GImage preparationCardLockImage;

		private int _cardDownCount;

		private int _cardUpCount;

		private GButton _selectCardDescButton;

		public Dictionary<int, GComponent> _preparationCardDic;

		private Dictionary<int, GComponent> _cardSlotDic;

		private List<CardEntity> _conveyorPreviewCardList;

		public PreparationBoxEntity(GComponent component)
			: base(component)
		{
			_preparationCardDic = new Dictionary<int, GComponent>();
		}

		public override void Awake()
		{
			base.Awake();
		}

		public override void Start()
		{
		}

		public override void Update()
		{
		}

		protected override void OnOpen()
		{
		}

		public void ResetCardSlot()
		{
		}

		public void ResetSelectCard()
		{
		}

		private GComponent CreateCardItem(int cardId)
		{
			return null;
		}

		private void AddCardSlot(CardEntity cardEntity)
		{
		}

		private void InitCardItem(GComponent cardItem, CardEntity cardEntity)
		{
		}

		private void SetCardDisable(GComponent com, bool flag)
		{
		}

		private void CreateMoveCardItem(int cardId, Vector2 startPosition, Vector2 endPosition)
		{
		}

		private void CardSlotPreMove(int startIndex)
		{
		}

		private void LoadCardList(List<int> cardIdList)
		{
		}

		private static void SetOverText(GObject component, string title, string content)
		{
		}

		public void EndLevelPreparation()
		{
			if (_conveyorPreviewCardList == null)
			{
				return;
			}
			foreach (CardEntity cardEntity in _conveyorPreviewCardList)
			{
				if (cardEntity != null)
				{
					Object.Destroy(cardEntity.gameObject);
				}
			}
			_conveyorPreviewCardList.Clear();
		}
	}
}
