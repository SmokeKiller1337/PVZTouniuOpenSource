using System.Collections.Generic;
using FairyGUI;
using Level.Entity;

namespace FGUI.Entity.UI
{
	public class MapBoxEntity : DefaultComponentEntity
	{
		private List<ZombieWaveEntity> _waveRouteList;

		private List<GComponent> _contentComList;

		private GComponent _contentCom;

		private GList _typeList;

		private GComponent _parentContentCom;

		public MapBoxEntity(GComponent component)
			: base(component)
		{
			_waveRouteList = new List<ZombieWaveEntity>();
		}

		public override void Start()
		{
		}

		protected override void OnOpen()
		{
		}

		protected override void OnClose()
		{
		}

		public override void Update()
		{
		}

		private void UpdateRoute(int index)
		{
			GComponent oldContentCom = _contentCom;
			if (_typeList == null)
			{
				return;
			}
			_typeList.selectedIndex = index;
			int i = 0;
			while (_contentComList != null)
			{
				if (_contentComList.Count <= i)
				{
					// Finished toggling: keep the newly selected route scrolled to the
					// same horizontal position the previous one was at.
					if (oldContentCom != null && _contentCom != null)
					{
						ScrollPane oldScroll = oldContentCom.scrollPane;
						ScrollPane newScroll = _contentCom.scrollPane;
						if (oldScroll == null || newScroll == null)
						{
							break;
						}
						newScroll.SetPosX(oldScroll.posX, false);
					}
					return;
				}
				if (i == index)
				{
					GComponent com = _contentComList[i];
					if (com == null)
					{
						break;
					}
					com.visible = true;
					if (_contentComList == null)
					{
						break;
					}
					_contentCom = _contentComList[i];
				}
				else
				{
					GComponent com = _contentComList[i];
					if (com == null)
					{
						break;
					}
					com.visible = false;
				}
				i++;
			}
		}

		private void ToRoutePosition(GComponent oldContentCom, GComponent contentCom)
		{
			if (oldContentCom == null || contentCom == null)
			{
				return;
			}
			ScrollPane oldScroll = oldContentCom.scrollPane;
			ScrollPane newScroll = contentCom.scrollPane;
			if (oldScroll == null || newScroll == null)
			{
				return;
			}
			newScroll.SetPosX(oldScroll.posX, false);
		}

		private void ToTimePosition(float time)
		{
		}
	}
}
