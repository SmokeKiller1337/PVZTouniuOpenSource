using System.Text;
using FairyGUI;
using Game.Util;
using Save.Constant;
using Save.Data;
using UnityEngine;

namespace FGUI.Entity.UI
{
	public class ValueBoxEntity : PoolComponentEntity
	{
		public ValueBoxEntity(GComponent component)
			: base(component)
		{
			// The ctor stores the pooled item's FairyGUI component name into the
			// inherited itemComponentName field (native offset 0x40). The exact
			// string constant could not be decoded textually from global metadata;
			// "ValueBoxItem" is a best guess and only affects which pooled UI
			// component is fetched at runtime.
			// TODO: verify pooled item component name string (native _DAT_182e25ab8).
			itemComponentName = "ValueBoxItem";
		}

		public override void Start()
		{
		}

		public void CreateDamage(Vector2 position, int value)
		{
			// Only spawn floating damage numbers while the box is open, and only
			// when the "low graphics" mode (lowMode2, native offset 0x3a) is off and
			// the "show damage" toggle (native offset 0x49) is on.
			if (!isOpen)
			{
				return;
			}
			GameMenuData menuData = SaveDataConstant.GameMenuData;
			if (menuData == null || menuData.lowMode2 || !menuData.showDamage)
			{
				return;
			}
			GComponent component = Get(position);
			if (component == null)
			{
				return;
			}
			// TODO: verify pooled child object name ("text") — recovered from a
			//       global-metadata string literal that could not be decoded textually.
			GObject child = component.GetChild("text");
			if (child == null)
			{
				return;
			}
			GTextField textField = child.asTextField;
			if (textField == null)
			{
				return;
			}
			textField.color = Color.white;
			textField.text = value.ToString();
			// TODO: verify transition-name prefix ("t") — recovered from a
			//       global-metadata string literal that could not be decoded textually.
			Transition transition = component.GetTransition("t" + Random.Range(0, 2).ToString());
			if (transition != null)
			{
				transition.Play(delegate
				{
					Release(component);
				});
			}
		}

		public void CreateText(Vector2 position, string text, Color color)
		{
			GComponent component = Get(position);
			if (component == null)
			{
				return;
			}
			// TODO: verify pooled child object name ("text") — recovered from a
			//       global-metadata string literal that could not be decoded textually.
			GObject child = component.GetChild("text");
			if (child == null)
			{
				return;
			}
			GTextField textField = child.asTextField;
			if (textField == null)
			{
				return;
			}
			textField.color = color;
			textField.text = text;
			// TODO: verify transition name ("t0") — recovered from a
			//       global-metadata string literal that could not be decoded textually.
			Transition transition = component.GetTransition("t0");
			if (transition != null)
			{
				transition.Play(delegate
				{
					Release(component);
				});
			}
		}

		public void CreateGoodValue(Vector2 position, string attrStr, float value, bool isPercentage = false, string format = null)
		{
			// Only when open, low-graphics mode (lowMode2, native offset 0x3a) is off
			// and the "show event value" toggle (native offset 0x4b) is on.
			if (!isOpen)
			{
				return;
			}
			GameMenuData menuData = SaveDataConstant.GameMenuData;
			if (menuData == null || menuData.lowMode2 || !menuData.showEventValue)
			{
				return;
			}
			// For "good" values a non-negative amount is shown in the positive colour.
			// TODO: verify sign-prefix string literals ("+" / "-") — recovered from
			//       global-metadata string literals that could not be decoded textually.
			string signStr = ((double)value >= 0.0) ? "+" : "-";
			StringBuilder sb = new StringBuilder();
			if (!string.IsNullOrEmpty(attrStr))
			{
				sb.Append(GameUtils.AttrStrFormat(attrStr, null));
			}
			sb.Append(signStr);
			sb.Append(GameUtils.GetValueStr(value, isPercentage, format));
			// TODO: verify colour literal (green) — recovered from a global-metadata
			//       constant that could not be decoded textually.
			CreateText(position, sb.ToString(), Color.green);
		}

		public void CreateBadValue(Vector2 position, string attrStr, float value, bool isPercentage = false, string format = null)
		{
			// Only when open, low-graphics mode (lowMode2, native offset 0x3a) is off
			// and the "show event value" toggle (native offset 0x4b) is on.
			if (!isOpen)
			{
				return;
			}
			GameMenuData menuData = SaveDataConstant.GameMenuData;
			if (menuData == null || menuData.lowMode2 || !menuData.showEventValue)
			{
				return;
			}
			// For "bad" values a strictly positive amount is shown in the positive colour.
			// TODO: verify sign-prefix string literals ("+" / "-") — recovered from
			//       global-metadata string literals that could not be decoded textually.
			string signStr = ((double)value > 0.0) ? "+" : "-";
			StringBuilder sb = new StringBuilder();
			if (!string.IsNullOrEmpty(attrStr))
			{
				sb.Append(GameUtils.AttrStrFormat(attrStr, null));
			}
			sb.Append(signStr);
			sb.Append(GameUtils.GetValueStr(value, isPercentage, format));
			// TODO: verify colour literal (red) — recovered from a global-metadata
			//       constant that could not be decoded textually.
			CreateText(position, sb.ToString(), Color.red);
		}
	}
}
