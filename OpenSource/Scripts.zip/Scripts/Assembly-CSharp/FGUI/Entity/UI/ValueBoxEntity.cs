using System.Text;
using FairyGUI;
using Game.Util;
using Save.Constant;
using Save.Data;
using UnityEngine;

namespace FGUI.Entity.UI
{
	public class ValueBoxEntity : PoolComponentEntity
	{
		public ValueBoxEntity(GComponent component)
			: base(component)
		{
			itemComponentName = "ValueBoxItem";
		}

		public override void Start()
		{
		}

		public void CreateDamage(Vector2 position, int value)
		{
			if (!isOpen)
			{
				return;
			}
			GameMenuData menuData = SaveDataConstant.GameMenuData;
			if (menuData == null || menuData.lowMode2 || !menuData.showDamage)
			{
				return;
			}
			GComponent component = Get(position);
			if (component == null)
			{
				return;
			}
			GObject child = component.GetChild("text");
			if (child == null)
			{
				return;
			}
			GTextField textField = child.asTextField;
			if (textField == null)
			{
				return;
			}
			textField.color = Color.white;
			textField.text = value.ToString();
			Transition transition = component.GetTransition("t" + Random.Range(0, 2).ToString());
			if (transition != null)
			{
				transition.Play(delegate
				{
					Release(component);
				});
			}
		}

		public void CreateText(Vector2 position, string text, Color color)
		{
			GComponent component = Get(position);
			if (component == null)
			{
				return;
			}
			GObject child = component.GetChild("text");
			if (child == null)
			{
				return;
			}
			GTextField textField = child.asTextField;
			if (textField == null)
			{
				return;
			}
			textField.color = color;
			textField.text = text;
			Transition transition = component.GetTransition("t0");
			if (transition != null)
			{
				transition.Play(delegate
				{
					Release(component);
				});
			}
		}

		public void CreateGoodValue(Vector2 position, string attrStr, float value, bool isPercentage = false, string format = null)
		{
			if (!isOpen)
			{
				return;
			}
			GameMenuData menuData = SaveDataConstant.GameMenuData;
			if (menuData == null || menuData.lowMode2 || !menuData.showEventValue)
			{
				return;
			}
			string signStr = ((double)value >= 0.0) ? "+" : "-";
			StringBuilder sb = new StringBuilder();
			if (!string.IsNullOrEmpty(attrStr))
			{
				sb.Append(GameUtils.AttrStrFormat(attrStr, null));
			}
			sb.Append(signStr);
			sb.Append(GameUtils.GetValueStr(value, isPercentage, format));
			CreateText(position, sb.ToString(), Color.green);
		}

		public void CreateBadValue(Vector2 position, string attrStr, float value, bool isPercentage = false, string format = null)
		{
			if (!isOpen)
			{
				return;
			}
			GameMenuData menuData = SaveDataConstant.GameMenuData;
			if (menuData == null || menuData.lowMode2 || !menuData.showEventValue)
			{
				return;
			}
			string signStr = ((double)value > 0.0) ? "+" : "-";
			StringBuilder sb = new StringBuilder();
			if (!string.IsNullOrEmpty(attrStr))
			{
				sb.Append(GameUtils.AttrStrFormat(attrStr, null));
			}
			sb.Append(signStr);
			sb.Append(GameUtils.GetValueStr(value, isPercentage, format));
			CreateText(position, sb.ToString(), Color.red);
		}
	}
}
