using FairyGUI;
using Touniu.Entity;
using Touniu.Entity.Body;
using Touniu.Enum;
using UnityEngine;

namespace FGUI.Entity.UI
{
	public class TouniuSayDialogBoxEntity
	{
		private GTextField _textField;

		private GTextField _buttonTime;

		private GImage _invalidStunImage;

		private GImage _fogImage;

		private GComponent _dialogCom;

		private GImage _upImage;

		private GImage _downImage;

		private GImage _arrowImage;

		private GComponent _selectCom;

		private GButton _yesButton;

		private GButton _noButton;

		private GComponent _valueCom;

		private GButton _valueButton;

		private GButton _addValueButton;

		private GButton _subValueButton;

		private GComponent _shopCom;

		private GList _shopList;

		private GButton _confirmButton;

		private TouniuSayEntity _touniuSayEntity;

		private Transform _touniuTransform;

		private Camera _mainCamera;

		private GGroup _aGroup;

		private GGroup _bGroup;

		private GComponent _dialogACom;

		private GComponent _dialogBCom;

		private GComponent _selectACom;

		private GComponent _selectBCom;

		private GComponent _valueACom;

		private GComponent _valueBCom;

		private GComponent _shopACom;

		private GComponent _shopBCom;

		private GList _shopAList;

		private GList _shopBList;

		private int _dialogPositionIndex;

		private readonly float _minX;

		private readonly float _maxX;

		private readonly float _minY;

		private readonly float _maxY;

		private readonly float _arrowX;

		private readonly float _arrowMinX;

		private readonly float _arrowMaxX;

		public readonly GComponent component;

		public Transform TouniuTransform
		{
			get
			{
				return _touniuTransform;
			}
			set
			{
				_touniuTransform = value;
			}
		}

		public TouniuSayDialogBoxEntity(GComponent com)
		{
			_minX = -8.8f;
			_maxX = 2.9f;
			_minY = -2.05f;
			_maxY = 4.9f;
			_arrowX = 90f;
			_arrowMinX = -1.2f;
			_arrowMaxX = 3.3f;
			component = com;
		}

		public void Start()
		{
		}

		public void Open()
		{
		}

		public void Update()
		{
			if (_touniuSayEntity == null)
			{
				return;
			}
			UpdatePosition();
			TouniuSayData sayData = _touniuSayEntity.sayData;
			if (sayData == null)
			{
				return;
			}
			if (sayData.sayType == SayType.Select)
			{
				UpdateButtonTime();
			}
			if (sayData.sayType == SayType.Shop)
			{
				UpdateButtonTime();
			}
			TouniuBaseBody touniuBaseBody = _touniuSayEntity.TouniuBaseBody;
			if (touniuBaseBody != null && _invalidStunImage != null)
			{
				_invalidStunImage.visible = touniuBaseBody.IsInvalidStun;
			}
		}

		private void ProvideAddValue()
		{
		}

		private void ProvideSubValue()
		{
		}

		public void ClearFogSay()
		{
		}

		private void SetTextColor(ColorType colorType)
		{
		}

		private void SetupSelectionButtons(TouniuSayData sayData)
		{
		}

		public void SetupShopButtons()
		{
		}

		private void UpdatePosition()
		{
		}

		private void UpdateButtonTime()
		{
			if (_touniuSayEntity == null)
			{
				return;
			}
			int remaining = Mathf.CeilToInt(_touniuSayEntity.duration - _touniuSayEntity.currentDuration);
			if (_buttonTime != null)
			{
				_buttonTime.text = remaining.ToString();
			}
		}
	}
}
