using FairyGUI;
using Touniu.Entity;
using Touniu.Entity.Body;
using Touniu.Enum;
using UnityEngine;

namespace FGUI.Entity.UI
{
	public class TouniuSayDialogBoxEntity
	{
		private GTextField _textField;

		private GTextField _buttonTime;

		private GImage _invalidStunImage;

		private GImage _fogImage;

		private GComponent _dialogCom;

		private GImage _upImage;

		private GImage _downImage;

		private GImage _arrowImage;

		private GComponent _selectCom;

		private GButton _yesButton;

		private GButton _noButton;

		private GComponent _valueCom;

		private GButton _valueButton;

		private GButton _addValueButton;

		private GButton _subValueButton;

		private GComponent _shopCom;

		private GList _shopList;

		private GButton _confirmButton;

		private TouniuSayEntity _touniuSayEntity;

		private Transform _touniuTransform;

		private Camera _mainCamera;

		private GGroup _aGroup;

		private GGroup _bGroup;

		private GComponent _dialogACom;

		private GComponent _dialogBCom;

		private GComponent _selectACom;

		private GComponent _selectBCom;

		private GComponent _valueACom;

		private GComponent _valueBCom;

		private GComponent _shopACom;

		private GComponent _shopBCom;

		private GList _shopAList;

		private GList _shopBList;

		private int _dialogPositionIndex;

		private readonly float _minX;

		private readonly float _maxX;

		private readonly float _minY;

		private readonly float _maxY;

		private readonly float _arrowX;

		private readonly float _arrowMinX;

		private readonly float _arrowMaxX;

		public readonly GComponent component;

		public Transform TouniuTransform
		{
			get
			{
				return _touniuTransform;
			}
			set
			{
				_touniuTransform = value;
			}
		}

		public TouniuSayDialogBoxEntity(GComponent com)
		{
			_minX = -8.8f;
			_maxX = 2.9f;
			_minY = -2.05f;
			_maxY = 4.9f;
			_arrowX = 90f;
			_arrowMinX = -1.2f;
			_arrowMaxX = 3.3f;
			component = com;
		}

		public void Start()
		{
			// TODO: reconstruct - original resolved the dialog text field via
			// component.GetChild("<name>").asTextField and cached it into _textField,
			// but the FairyGUI child-name string literals were not recoverable from the
			// decompiled pseudocode, so reproducing this faithfully would require fabricating them.
		}

		public void Open()
		{
			// TODO: reconstruct - original wired up the whole dialog (a/b groups, dialog/select/value/shop
			// components, yes/no/value/confirm buttons and their event handlers) by resolving many
			// FairyGUI children by name and reading a game-manager singleton. The child-name string
			// literals and the singleton type/members were not recoverable from the pseudocode, so a
			// faithful reconstruction cannot be produced without fabricating members.
		}

		public void Update()
		{
			if (_touniuSayEntity == null)
			{
				return;
			}
			UpdatePosition();
			TouniuSayData sayData = _touniuSayEntity.sayData;
			if (sayData == null)
			{
				return;
			}
			if (sayData.sayType == SayType.Select)
			{
				UpdateButtonTime();
			}
			if (sayData.sayType == SayType.Shop)
			{
				UpdateButtonTime();
			}
			TouniuBaseBody touniuBaseBody = _touniuSayEntity.TouniuBaseBody;
			if (touniuBaseBody != null && _invalidStunImage != null)
			{
				_invalidStunImage.visible = touniuBaseBody.IsInvalidStun;
			}
		}

		private void ProvideAddValue()
		{
			// TODO: reconstruct - original clamped _touniuSayEntity.sayData.provideValue up by
			// provideStepValue (capped at provideMaxValue) and wrote it into the value button's child
			// text field. The clamp maps cleanly to public fields, but the text field was resolved via
			// _valueButton.GetChild("<name>").asTextField using a child-name string literal that was not
			// recoverable, so the method is left as a stub rather than fabricating the missing name.
		}

		private void ProvideSubValue()
		{
			// TODO: reconstruct - original clamped _touniuSayEntity.sayData.provideValue down by
			// provideStepValue (floored at provideMinValue) and wrote it into the value button's child
			// text field. The text field was resolved via _valueButton.GetChild("<name>").asTextField
			// using an unrecoverable child-name string literal, so the method is left as a stub.
		}

		public void ClearFogSay()
		{
			// TODO: reconstruct - original faded _fogImage out via _fogImage.TweenFade(0f, <duration>)
			// when _touniuSayEntity was present. The tween duration constant was not recoverable from the
			// pseudocode, so the method is left as a stub rather than fabricating the value.
		}

		private void SetTextColor(ColorType colorType)
		{
			// TODO: reconstruct - original switched on colorType and assigned a Color to _textField.color.
			// The per-ColorType Color constants live in read-only data that was not recoverable from the
			// pseudocode, so the mapping cannot be reproduced faithfully and the method is left as a stub.
		}

		private void SetupSelectionButtons(TouniuSayData sayData)
		{
			// TODO: reconstruct - original populated either the value component or the yes/no selection
			// buttons (titles, visibility and touch handlers) depending on sayData.isProvideValue. It
			// resolved several FairyGUI children by name; those child-name string literals were not
			// recoverable from the pseudocode, so the method is left as a stub.
		}

		public void SetupShopButtons()
		{
			// TODO: reconstruct - original showed the shop component/list, wired the confirm button and
			// rebuilt the shop item list from a shop-data collection, resolving many FairyGUI children by
			// name and reading CardSlotManager. The item-data element type, the child-name string literals
			// and item-URL resources were not recoverable from the pseudocode, so the method is left a stub.
		}

		private void UpdatePosition()
		{
			// TODO: reconstruct - original projected _touniuTransform's world position through the main
			// camera to screen space, converted it to GRoot-local space and repositioned the dialog and
			// arrow within clamped bounds. The reconstruction depends on several unrecoverable magic
			// offset/scale constants baked into read-only data, so the method is left as a stub.
		}

		private void UpdateButtonTime()
		{
			if (_touniuSayEntity == null)
			{
				return;
			}
			int remaining = Mathf.CeilToInt(_touniuSayEntity.duration - _touniuSayEntity.currentDuration);
			if (_buttonTime != null)
			{
				_buttonTime.text = remaining.ToString();
			}
		}
	}
}
