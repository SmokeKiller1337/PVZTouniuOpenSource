using System.Collections.Generic;
using FairyGUI;
using Plant.Entity;

namespace FGUI.Entity.UI
{
	public class GameWinBoxEntity : DefaultComponentEntity
	{
		public List<int> cardIdList;

		public int addGoldValue;

		public GameWinBoxEntity(GComponent component)
			: base(component)
		{
			cardIdList = new List<int>();
		}

		public override void Start()
		{
			base.Start();
		}

		protected override void OnOpen()
		{
		}

		protected override void OnClose()
		{
		}

		public override void Update()
		{
		}

		private void InitCardItem(GComponent cardItem, CardEntity cardEntity)
		{
		}

		private static string GetDifficultyStr(int mode, int difficulty, int touniuDifficulty, int challengeDifficulty)
		{
			return null;
		}
	}
}
