using FairyGUI;
using Touniu.Manager;
using UnityEngine;

namespace FGUI.Entity.UI
{
	public class TouniuSayBoxEntity : DefaultComponentEntity
	{
		private Vector2 _leftUpPosition;

		private Vector2 _rightDownPosition;

		private int _sayBoxType;

		public TouniuSayDialogBoxEntity dialogBox;

		public TouniuSayCaptionBoxEntity captionBox;

		public TouniuSayBoxEntity(GComponent component)
			: base(component)
		{
			_leftUpPosition = new Vector2(-9.6f, 5.6f);
			_rightDownPosition = new Vector2(9.8f, -6f);
		}

		public override void Awake()
		{
			base.Awake();
			if (component != null)
			{
				component.SetPosition(0f, component.x, component.y);
			}
		}

		public override void Start()
		{
			// TODO: reconstruct
		}

		public override void Open()
		{
			if (isOpen)
			{
				return;
			}
			if (dialogBox != null && dialogBox.component != null)
			{
				dialogBox.component.alpha = 0f;
			}
			if (captionBox != null && captionBox.component != null)
			{
				captionBox.component.alpha = 0f;
			}
			isOpen = true;
			if (_t0 != null)
			{
				_t0.Play();
			}
			TouniuSayManager.Instance.OpenSayBox();
		}

		public void Open1()
		{
			if (!isOpen)
			{
				return;
			}
			if (component == null)
			{
				return;
			}
			component.visible = true;
			UpdateSayBoxType();
			if (dialogBox != null)
			{
				dialogBox.Open();
			}
			if (captionBox != null)
			{
				captionBox.Open();
			}
		}

		public override void Close()
		{
			base.Close();
			if (isOpen)
			{
				isOpen = false;
				if (_t0 != null)
				{
					_t0.PlayReverse();
				}
			}
		}

		public override void Update()
		{
			UpdateSayBoxType();
			if (dialogBox != null)
			{
				dialogBox.Update();
			}
			if (captionBox != null)
			{
				captionBox.Update();
			}
		}

		private void UpdateSayBoxType()
		{
			// TODO: reconstruct
		}

		public void UpdateShopItem()
		{
			if (dialogBox != null)
			{
				dialogBox.SetupShopButtons();
			}
			if (captionBox != null)
			{
				captionBox.SetupShopButtons();
			}
		}
	}
}
