using FairyGUI;

namespace FGUI.Entity.UI
{
	public class HelpBoxEntity : DefaultComponentEntity
	{
		public HelpBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
		}

		public override void Update()
		{
		}
	}
}
