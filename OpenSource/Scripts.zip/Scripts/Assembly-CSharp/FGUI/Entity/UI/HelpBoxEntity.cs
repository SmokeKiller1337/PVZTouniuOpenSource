using FairyGUI;

namespace FGUI.Entity.UI
{
	public class HelpBoxEntity : DefaultComponentEntity
	{
		public HelpBoxEntity(GComponent component)
			: base(component)
		{
			// The constructor stores 'component' into the (readonly) base
			// FGUIComponentEntity.component field. That assignment cannot be
			// expressed from a derived constructor in legal C#, and the
			// authoritative stub calls base(null) with an empty body, so this
			// is left as the stub.
			// TODO: reconstruct
		}

		public override void Start()
		{
			// Decompiled body wires the OK/close button's onClick to a
			// compiler-generated lambda (<>c.<Start>b__1_0). That lambda pulls
			// data from a UI manager singleton and a Luban config table
			// (LubanUtils.Tables) using child names and row fields that cannot
			// be recovered without the string-literal metadata, so it cannot be
			// reconstructed without inventing members. Left as the stub.
			// TODO: reconstruct
		}

		public override void Update()
		{
			// Decompiled body is empty (return;). Nothing to do per frame.
		}
	}
}
