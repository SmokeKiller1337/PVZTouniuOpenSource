using FairyGUI;
using Game.Manager;

namespace FGUI.Entity.UI
{
	public class GameMainBoxEntity : DefaultComponentEntity
	{
		private GTextField _timeText;

		private GTextField _pauseText;

		private GTextField _focusText;

		public GameMainBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
		}

		public void DisplayPauseText()
		{
			// Mirror the game's paused state onto the pause text field's visibility.
			if (GameManager.Instance != null && _pauseText != null)
			{
				_pauseText.visible = GameManager.Instance.IsPaused();
			}
		}

		public void DisplayFocusText()
		{
		}

		protected override void OnOpen()
		{
			// Only "pausing" boxes participate in the global pause bookkeeping.
			if (!isOpenPause)
			{
				return;
			}
			// Register this box as a pause source; GameManager.Pause de-dupes the
			// source, freezes the game when it becomes the first pauser, and refreshes
			// the pause text on the main box.
			if (GameManager.Instance != null)
			{
				GameManager.Instance.Pause(this);
			}
		}

		protected override void OnClose()
		{
		}

		public override void Update()
		{
		}

		public void UpdateDebugTool()
		{
		}

		public void UpdateTime()
		{
		}

		public void UpdateFocusTime()
		{
		}
	}
}
