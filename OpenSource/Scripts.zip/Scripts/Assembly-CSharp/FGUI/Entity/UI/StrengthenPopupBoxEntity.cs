using FairyGUI;
using Plant.Entity;

namespace FGUI.Entity.UI
{
	public class StrengthenPopupBoxEntity : DefaultComponentEntity
	{
		public StrengthenPopupBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
		}

		public void OpenText(GObject com, CardEntity cardEntity, int level)
		{
			// Public entry for a card-only context: forwards to the shared private
			// implementation with no plant entity.
			OpenText(com, cardEntity, null, level);
		}

		public void OpenText(GObject com, PlantEntity plantEntity, int level)
		{
			// Public entry for a plant context: forwards to the shared private
			// implementation with no explicit card entity (the private method derives the
			// card from the plant).
			OpenText(com, null, plantEntity, level);
		}

		private void OpenText(GObject com, CardEntity cardEntity, PlantEntity plantEntity, int level)
		{
			// --- Reliably recovered prologue (references only verified members) ---
			// Guard: at least one source entity is required.
			if (cardEntity == null && plantEntity == null)
			{
				return;
			}
			// When a plant entity is supplied it takes precedence; the card is read from it
			// (PlantEntity.CardEntity is a verified property returning CardEntity).
			if (plantEntity != null)
			{
				cardEntity = plantEntity.CardEntity;
			}

		}

		private void SetStrengthenButtonBackground(GButton button, int level)
		{
		}
	}
}
