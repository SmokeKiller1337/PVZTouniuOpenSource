using FairyGUI;
using Plant.Entity;

namespace FGUI.Entity.UI
{
	public class StrengthenPopupBoxEntity : DefaultComponentEntity
	{
		public StrengthenPopupBoxEntity(GComponent component)
			: base(component)
		{
			// The readonly `component` field is assigned by the FGUIComponentEntity base
			// constructor; the pseudocode ctor body only performs that base store, so no
			// additional work is required here.
		}

		public override void Start()
		{
			// The pseudocode looks up a child button on `component` by a name stored as an
			// IL2CPP data pointer (unrecoverable) and binds its onClick to a
			// compiler-generated lambda (<Start>b__...). Both the child name and the
			// handler target could not be resolved from the available inputs, so a faithful
			// binding would require inventing a child name / handler. Left as a stub rather
			// than fabricating those values.
			// TODO: reconstruct (bind the popup button's onClick handler).
		}

		public void OpenText(GObject com, CardEntity cardEntity, int level)
		{
			// Public entry for a card-only context: forwards to the shared private
			// implementation with no plant entity.
			OpenText(com, cardEntity, null, level);
		}

		public void OpenText(GObject com, PlantEntity plantEntity, int level)
		{
			// Public entry for a plant context: forwards to the shared private
			// implementation with no explicit card entity (the private method derives the
			// card from the plant).
			OpenText(com, null, plantEntity, level);
		}

		private void OpenText(GObject com, CardEntity cardEntity, PlantEntity plantEntity, int level)
		{
			// --- Reliably recovered prologue (references only verified members) ---
			// Guard: at least one source entity is required.
			if (cardEntity == null && plantEntity == null)
			{
				return;
			}
			// When a plant entity is supplied it takes precedence; the card is read from it
			// (PlantEntity.CardEntity is a verified property returning CardEntity).
			if (plantEntity != null)
			{
				cardEntity = plantEntity.CardEntity;
			}

			// --- Remainder left as a stub (TODO: reconstruct) ---
			// The rest of this method selects the strengthen-option list for the requested
			// level from cardEntity.cardStrengthenEntity (level 0 -> level1List,
			// 1 -> level2List, 2 -> level3List), rebuilds the popup's FairyGUI GList by
			// pulling pooled item components and filling each one's background, power gem,
			// title, description, cooldown text, icon and per-item click handler, then shows
			// the popup via GRoot.inst.ShowPopup(component, com).
			//
			// It is deliberately not reconstructed because a faithful translation would
			// require members/values that cannot be verified from the available inputs:
			//   * ~10 FairyGUI child/variable-name string constants (the list name and the
			//     per-item title/desc/cooldown/icon/gem field names) stored as IL2CPP data
			//     pointers, unrecoverable from the pseudocode.
			//   * A global manager singleton lookup (Ghidra FUN_180417960 -> field @+0xd8 ->
			//     @+0x20) used to override the card background id; the owning singleton/member
			//     could not be identified.
			//   * The per-item onClick handler, a compiler-generated lambda whose selection
			//     body is not present in the binary.
			// Reconstructing these would violate the "only reference real, verified members"
			// rule, so the remainder is preserved as a stub.
			// TODO: reconstruct (rebuild the strengthen option list UI and show popup).
		}

		private void SetStrengthenButtonBackground(GButton button, int level)
		{
			// The pseudocode walks GetChild(prefix + index) on `button` (a GComponent),
			// hiding four state children per group and revealing the one matching
			// (level + 1). Every child lookup is keyed by a string prefix stored as an
			// IL2CPP data pointer (unrecoverable), so a faithful body cannot be produced
			// without fabricating those child names. Left as a stub.
			// TODO: reconstruct (show the button background matching the given level).
		}
	}
}
