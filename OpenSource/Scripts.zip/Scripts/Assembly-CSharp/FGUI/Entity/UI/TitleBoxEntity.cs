using FairyGUI;

namespace FGUI.Entity.UI
{
	public class TitleBoxEntity : DefaultComponentEntity
	{
		public TitleBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
		}

		public override void Update()
		{
			TryOpenWelcomeBox();
		}

		private void TryOpenWelcomeBox()
		{
		}
	}
}
