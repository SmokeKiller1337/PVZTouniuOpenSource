using FairyGUI;

namespace FGUI.Entity.UI
{
	public class TitleBoxEntity : DefaultComponentEntity
	{
		public TitleBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
			// TODO: reconstruct
			// The decompiled Start() gets FairyGUI children from `component` and wires
			// their buttons via GetChild(...).asButton.onClick.Set(<lambda>), loops 3
			// plant-select buttons, loads a random splash art into GLoader children, sets
			// a version GTextField from Application.version, and checks
			// Save.Static.SaveDataStatic.CheckVersion(). The button click handlers are
			// compiler-generated closures (<>c / <>c__DisplayClass1_0) whose bodies invoke
			// manager methods through ICF-folded indirect vtable/delegate calls; those
			// target identities are not recoverable from the pseudocode. Reconstructing the
			// wiring would require inventing the handler methods, so the body is left as a
			// stub rather than emit code that references non-existent members.
		}

		public override void Update()
		{
			// Update (RVA 0x6BDE40) is ICF-folded to the exact same native body as
			// TryOpenWelcomeBox (identical RVA), i.e. the original Update simply delegated
			// to this class's own TryOpenWelcomeBox() and was folded after inlining.
			TryOpenWelcomeBox();
		}

		private void TryOpenWelcomeBox()
		{
			// TODO: reconstruct
			// The decompiled body reads an unidentified static manager singleton's nested
			// dictionary (ContainsKey(1) / get_Item(1)) and, when the flag is unset, invokes
			// a cached delegate via an indirect call to open the welcome box. The owning
			// manager type, the dictionary field, and the delegate target could not be
			// resolved from the pseudocode, so the body is left as a stub to avoid
			// fabricating members.
		}
	}
}
