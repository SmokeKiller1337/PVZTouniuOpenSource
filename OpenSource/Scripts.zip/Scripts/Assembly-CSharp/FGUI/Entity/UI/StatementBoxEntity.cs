using FairyGUI;

namespace FGUI.Entity.UI
{
	public class StatementBoxEntity : DefaultComponentEntity
	{
		public StatementBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
		}

		public override void Update()
		{
		}
	}
}
