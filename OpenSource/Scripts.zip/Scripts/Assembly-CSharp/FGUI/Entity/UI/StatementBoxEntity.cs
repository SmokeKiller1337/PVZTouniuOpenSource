using FairyGUI;

namespace FGUI.Entity.UI
{
	public class StatementBoxEntity : DefaultComponentEntity
	{
		public StatementBoxEntity(GComponent component)
			: base(component)
		{
			// TODO: reconstruct
			// The decompiled body stores the component into the inherited field at
			// offset 0x18 (FGUIComponentEntity.component). That field is declared
			// `readonly` in the base class, so a derived constructor cannot legally
			// assign it in C#. Left as a stub to keep the output compilable.
		}

		public override void Start()
		{
			// TODO: reconstruct
			// The decompiled body wires an onClick handler:
			//   this.component.GetChild(<unresolved child name>)?.asButton?.onClick.Set(<callback>)
			// Both the child-name string literal and the click-callback method are
			// unresolvable data references, and no such callback method is declared on
			// this class. Reconstructing would reference non-existent members, so this
			// method is left as a stub.
		}

		public override void Update()
		{
		}
	}
}
