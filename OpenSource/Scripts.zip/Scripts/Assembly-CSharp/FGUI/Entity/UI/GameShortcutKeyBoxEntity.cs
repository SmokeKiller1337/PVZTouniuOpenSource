using FairyGUI;

namespace FGUI.Entity.UI
{
	public class GameShortcutKeyBoxEntity : DefaultComponentEntity
	{
		public GameShortcutKeyBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
		}

		public override void Update()
		{
		}
	}
}
