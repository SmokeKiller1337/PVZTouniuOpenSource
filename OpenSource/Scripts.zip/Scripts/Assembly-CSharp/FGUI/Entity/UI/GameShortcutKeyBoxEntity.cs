using FairyGUI;

namespace FGUI.Entity.UI
{
	public class GameShortcutKeyBoxEntity : DefaultComponentEntity
	{
		public GameShortcutKeyBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
			// TODO: reconstruct
			// Decompiled body wires up a click handler on a named child button of
			// `component` (GComponent.GetChild(<name>).asButton.onClick.Set(<handler>)),
			// but the child-name string constant is unresolvable and the target click
			// handler method is not a declared member of this class. Left as a stub to
			// avoid referencing a nonexistent member / guessing a literal.
		}

		public override void Update()
		{
		}
	}
}
