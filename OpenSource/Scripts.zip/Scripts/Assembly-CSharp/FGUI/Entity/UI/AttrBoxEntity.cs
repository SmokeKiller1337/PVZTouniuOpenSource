using System;
using System.Collections.Generic;
using Common.Entity;
using FGUI.Entity.UI.GameMain.Entity;
using FairyGUI;
using Plant.Entity;
using Plant.Entity.Card;
using Touniu.Entity.Body;
using Touniu.Object;
using UnityEngine;
using Zombie.Entity;

namespace FGUI.Entity.UI
{
	public class AttrBoxEntity : DefaultComponentEntity
	{
		private CardEntity _cardEntity;

		private CardZombieEntity _cardZombieEntity;

		private PlantEntity _plantEntity;

		private CardBaseAttr _cardAttr;

		private CardBaseAttr _cardDefaultAttr;

		private PlantBaseAttr _plantAttr;

		private PlantBaseAttr _plantDefaultAttr;

		private ZombieEntity _zombieEntity;

		private ZombieBaseAttr _zombieAttr;

		private ZombieBaseAttr _zombieDefaultAttr;

		private GComponent _plantAttrCom;

		private GComponent _zombieAttrCom;

		private GComponent _touniuAttrCom;

		private TouniuBaseBody _touniuBaseBody;

		private TouniuObject _touniuObject;

		private TouniuBaseAttr _touniuAttr;

		private TouniuBaseAttr _touniuDefaultAttr;

		private bool _isShowPlant;

		private bool _isShowZombie;

		private bool _isShowTouniu;

		private GProgressBar _cachedPlantHealthBar;

		private GProgressBar _cachedZombieHealthBar;

		private GProgressBar _cachedArm1HealthBar;

		private GProgressBar _cachedArm2HealthBar;

		private GProgressBar _cachedTouniuHealthBar;

		private GImage _cachedTouniuHammerInvalidImage;

		private GButton _cachedCardAttrButton1;

		private GButton _cachedCardAttrButton2;

		private GButton _cachedCardAttrButton3;

		private GButton _cachedCardZombieAttrButton1;

		private GButton _cachedCardZombieAttrButton2;

		private GButton _cachedPlantAttrButton1;

		private GButton _cachedPlantAttrButton2;

		private GButton _cachedPlantAttrButton3;

		private GButton _cachedPlantExtraAttrButton1;

		private GButton _cachedPlantExtraAttrButton2;

		private GButton _cachedPlantExtraAttrButton3;

		private GButton _cachedZombieAttrButton1;

		private GButton _cachedZombieAttrButton2;

		private GButton _cachedZombieAttrButton3;

		private GButton _cachedZombieAttrButton4;

		private GButton _cachedZombieExtraAttrButton1;

		private GButton _cachedZombieExtraAttrButton2;

		private GButton _cachedZombieExtraAttrButton3;

		private GButton _cachedTouniuAttrButton1;

		private GButton _cachedTouniuAttrButton2;

		private GButton _cachedTouniuAttrButton3;

		private GButton _cachedTouniuExtraAttrButton1;

		private GButton _cachedTouniuExtraAttrButton2;

		private GButton _cachedTouniuExtraAttrButton3;

		private GList _cachedPlantLabelList;

		private GList _cachedZombieLabelList;

		private GList _cachedTouniuLabelList;

		private int _cardAttrListVersion;

		private int _plantAttrListVersion;

		private int _plantExtraAttrListVersion;

		private int _plantLabelListVersion;

		private int _zombieAttrListVersion;

		private int _zombieExtraAttrListVersion;

		private int _zombieLabelListVersion;

		private int _touniuAttrListVersion;

		private int _touniuExtraAttrListVersion;

		private int _touniuLabelListVersion;

		public AttrBoxEntity(GComponent component)
			: base(component)
		{
			// The .ctor pseudocode initializes all ten list-version fields to -1 via five
			// 8-byte (0xFFFFFFFFFFFFFFFF) stores over the contiguous int block at
			// offsets 0x1C8..0x1EC, and stores the incoming component through the base
			// chain. The version fields default to 0 in C#, so seed them to -1 so the
			// first UpdateAttrList/UpdateLabelList pass always refreshes.
			_cardAttrListVersion = -1;
			_plantAttrListVersion = -1;
			_plantExtraAttrListVersion = -1;
			_plantLabelListVersion = -1;
			_zombieAttrListVersion = -1;
			_zombieExtraAttrListVersion = -1;
			_zombieLabelListVersion = -1;
			_touniuAttrListVersion = -1;
			_touniuExtraAttrListVersion = -1;
			_touniuLabelListVersion = -1;
		}

		public override void Start()
		{
			base.Start();
			CacheComponents();
			// TODO: reconstruct — the Start RVA body was ICF-folded onto CacheComponents
			// (obfuscated FairyGUI child-name string constants that cannot be recovered).
		}

		private void CacheComponents()
		{
			// TODO: reconstruct — resolves dozens of FairyGUI children by name and caches
			// them into the _cached* fields, wires onRemovedFromStage handlers, and drives
			// GRoot ShowPopup/HidePopup. Every GetChild(...) argument is an obfuscated
			// interned string constant (_DAT_182e...) that is not recoverable from the
			// pseudocode, so a faithful body cannot be produced without inventing names.
		}

		public override void Update()
		{
			if (_isShowPlant)
			{
				UpdatePlant();
			}
			if (_isShowZombie)
			{
				UpdateZombie();
			}
			if (_isShowTouniu)
			{
				UpdateTouniu();
			}
		}

		public void Show(int type)
		{
			if (_plantAttrCom != null)
			{
				_plantAttrCom.visible = false;
			}
			if (_zombieAttrCom != null)
			{
				_zombieAttrCom.visible = false;
			}
			if (_touniuAttrCom != null)
			{
				_touniuAttrCom.visible = false;
			}
			switch (type)
			{
			case 1:
				ShowPlant();
				break;
			case 2:
				ShowZombie();
				break;
			case 3:
				ShowTouniu();
				break;
			}
		}

		private void ShowPlant(GComponent handbookItem = null)
		{
			// TODO: reconstruct — builds the plant attribute panel by resolving many
			// FairyGUI children (obfuscated string names), setting text/loaders and
			// progress bars, and calling InitCardAttrList / InitPlantAttrList /
			// InitPlantExtraAttrList. The child-name constants and localized strings are
			// not recoverable, so a faithful, compilable body cannot be produced.
		}

		private void InitLevelUpButton(GButton button, int level)
		{
			// TODO: reconstruct — toggles level-up sub-buttons by building child names via
			// string concatenation with an obfuscated prefix constant that cannot be
			// recovered, then calls SetOverStrengthenText. Left as a stub.
		}

		private void SetLevelUpButtonBackground(GButton button, int level)
		{
			// TODO: reconstruct — same obfuscated child-name concatenation pattern as
			// InitLevelUpButton; the name-prefix string constant is unrecoverable.
		}

		private void AddLabelList(GList list, List<AttrLabelEntity> attrLabelList)
		{
			// TODO: reconstruct — populates a GList from the label list using
			// UIPackage.GetItemURL with obfuscated package/item id constants and interned
			// format strings that cannot be recovered. Left as a stub.
		}

		private void InitAttrItem(GButton button, AttrItemStruct attrItemStruct)
		{
			// TODO: reconstruct — writes AttrItemStruct fields into the button's child
			// text/icon objects using obfuscated child-name constants. Left as a stub.
		}

		private void UpdatePlant()
		{
			// TODO: reconstruct — updates the plant health bar and re-inits the plant
			// attribute/label lists. The per-frame init actions are compiler-generated
			// lambdas (<UpdatePlant>b__73_*) that construct AttrItemStruct values from
			// unrecoverable interned title/desc/icon string constants, so the body cannot
			// be reconstructed without fabricating those literals.
		}

		private void ShowZombie(GComponent handbookItem = null)
		{
			// TODO: reconstruct — zombie counterpart of ShowPlant; depends on the same
			// unrecoverable obfuscated FairyGUI child-name and localized string constants.
		}

		private void JoinPlantIcon(GGraph icon)
		{
			// TODO: reconstruct — attaches the plant icon graphic; body relies on
			// obfuscated resource/child constants that cannot be recovered.
		}

		private void JoinZombieIcon(GGraph icon)
		{
			// TODO: reconstruct — attaches the zombie icon graphic; body relies on
			// obfuscated resource/child constants that cannot be recovered.
		}

		private void JoinTouniuIcon(GGraph icon)
		{
			// TODO: reconstruct — attaches the touniu icon graphic; body relies on
			// obfuscated resource/child constants that cannot be recovered.
		}

		private void UpdateZombie()
		{
			// TODO: reconstruct — updates zombie/armor health bars and re-inits the zombie
			// attribute/label lists via compiler-generated lambdas that build AttrItemStruct
			// values from unrecoverable interned string constants. Left as a stub.
		}

		private void ClearData()
		{
			_cardEntity = null;
		}

		public void OpenCard(CardEntity cardEntity)
		{
			// TODO: reconstruct — null-checks cardEntity, calls ClearData, copies
			// CardBaseAttr/PlantBaseAttr references off CardEntity by raw offset
			// (fields whose exact identity on CardEntity is not verifiable from this
			// class's dump), then Show(1) + GRoot.ShowPopup + SetXY. Left as a stub to
			// avoid referencing unconfirmed foreign fields.
		}

		public void OpenPlant(PlantEntity plantEntity)
		{
			// TODO: reconstruct — resolves the backing CardEntity and copies PlantBaseAttr
			// references, then Show(1) + ShowPopup. Depends on foreign field offsets that
			// cannot be confirmed against a dump. Left as a stub.
		}

		public void OpenZombie(ZombieEntity zombieEntity)
		{
			// TODO: reconstruct — copies ZombieBaseAttr references off ZombieEntity by raw
			// offset and calls Show(2) + ShowPopup. Foreign field identity unverifiable;
			// left as a stub.
		}

		public void OpenCardZombie(CardZombieEntity cardEntity)
		{
			// TODO: reconstruct — looks a ZombieEntity up in a global manager dictionary
			// (obfuscated singleton + generic-key constants) then copies attributes and
			// calls Show(2). Unrecoverable dependencies; left as a stub.
		}

		public void OpenPreparationCard(CardEntity cardEntity)
		{
			// TODO: reconstruct — builds a fresh PlantBaseAttr from CardEntity data and
			// calls Show(1). Depends on foreign field offsets and a constructor whose
			// identity cannot be confirmed here; left as a stub.
		}

		public void OpenPreparationZombie(ZombieEntity zombieEntity)
		{
			// TODO: reconstruct — builds a fresh ZombieBaseAttr and calls Show(2).
			// Depends on unverifiable foreign field offsets; left as a stub.
		}

		public void OpenHandbookCard(CardEntity cardEntity, GComponent handbookItem)
		{
			// TODO: reconstruct — like OpenPreparationCard but dispatches to
			// ShowPlant(handbookItem). Depends on unverifiable foreign field offsets and
			// the (stubbed) ShowPlant; left as a stub.
		}

		public void OpenHandbookZombie(ZombieEntity zombieEntity, GComponent handbookItem)
		{
			// TODO: reconstruct — like OpenPreparationZombie but dispatches to
			// ShowZombie(handbookItem). Depends on unverifiable foreign field offsets and
			// the (stubbed) ShowZombie; left as a stub.
		}

		private int GetCurrentListVersion()
		{
			// TODO: reconstruct — the RVA for this method was ICF-folded onto an unrelated
			// engine helper, so its real body is not present in the pseudocode.
			return 0;
		}

		private void UpdateAttrList(int listVersion, Action initAction)
		{
			if (listVersion != Time.frameCount)
			{
				initAction();
			}
		}

		private void UpdateLabelList(GList list, int listVersion, List<AttrLabelEntity> attrLabelList)
		{
			if (attrLabelList == null)
			{
				return;
			}
			int total = 0;
			foreach (AttrLabelEntity label in attrLabelList)
			{
				total += label.layer + 1;
			}
			if (total > 0)
			{
				if (listVersion != total)
				{
					list.RemoveChildrenToPool();
					AddLabelList(list, attrLabelList);
					// NOTE: the decompiled body writes this specific version field
					// unconditionally (an ICF/inlining artifact of the plant-list call
					// site); reproduced verbatim to match the original binary.
					_plantLabelListVersion = total;
				}
				return;
			}
			list.RemoveChildrenToPool();
		}

		private void InitCardAttrList(GComponent handbookItem = null)
		{
			// TODO: reconstruct — fills the card attribute GList; every item/child name is
			// an unrecoverable obfuscated string constant. Left as a stub.
		}

		private void InitPlantAttrList(GComponent handbookItem = null)
		{
			// TODO: reconstruct — fills the plant attribute GList; obfuscated string
			// constants unrecoverable. Left as a stub.
		}

		private void InitPlantExtraAttrList(GComponent handbookItem = null)
		{
			// TODO: reconstruct — fills the plant extra-attribute GList; obfuscated string
			// constants unrecoverable. Left as a stub.
		}

		private void InitZombieAttrList(GComponent handbookItem = null)
		{
			// TODO: reconstruct — fills the zombie attribute GList; obfuscated string
			// constants unrecoverable. Left as a stub.
		}

		private void InitZombieExtraAttrList(GComponent handbookItem = null)
		{
			// TODO: reconstruct — fills the zombie extra-attribute GList; obfuscated string
			// constants unrecoverable. Left as a stub.
		}

		public void OpenTouniu(TouniuBaseBody touniuBaseBody)
		{
			// TODO: reconstruct — stores the TouniuBaseBody, copies TouniuBaseAttr
			// references and calls Show(3). Depends on unverifiable foreign field offsets;
			// left as a stub.
		}

		public void OpenHandbookTouniu(TouniuObject touniuObject, GComponent handbookItem)
		{
			// TODO: reconstruct — sets up the touniu handbook view and dispatches to
			// ShowTouniu(handbookItem). Depends on unverifiable foreign field offsets and
			// the (stubbed) ShowTouniu; left as a stub.
		}

		private void ShowTouniu(GComponent handbookItem = null)
		{
			// TODO: reconstruct — builds the touniu attribute panel; relies on unrecoverable
			// obfuscated FairyGUI child-name and localized string constants, IsTouniuUnlock
			// and GetTouniuContentLockText. Left as a stub.
		}

		private bool IsTouniuUnlock(TouniuObject touniuObject)
		{
			// TODO: reconstruct — evaluates unlock conditions against a global save/unlock
			// manager (obfuscated singleton + generic dictionary key constants) and reads
			// TouniuObject fields by unverifiable offsets. Left as a stub.
			return false;
		}

		private string GetTouniuContentLockText(TouniuObject touniuObject)
		{
			// TODO: reconstruct — composes the lock-reason text from unrecoverable interned
			// string constants and manager lookups. Left as a stub.
			return null;
		}

		private void UpdateTouniu()
		{
			// TODO: reconstruct — updates the touniu health bar / hammer-invalid image and
			// re-inits the touniu lists via compiler-generated lambdas that build
			// AttrItemStruct values from unrecoverable interned string constants. Left as a
			// stub.
		}

		private void InitTouniuAttrList(GComponent handbookItem = null)
		{
			// TODO: reconstruct — fills the touniu attribute GList; obfuscated string
			// constants unrecoverable. Left as a stub.
		}

		private void InitTouniuExtraAttrList(GComponent handbookItem = null)
		{
			// TODO: reconstruct — fills the touniu extra-attribute GList; obfuscated string
			// constants unrecoverable. Left as a stub.
		}

		private static void SetOverLabelText(GObject component, AttrLabelEntity labelEntity)
		{
			// TODO: reconstruct — registers a hover/tooltip callback carrying the label's
			// localized description; body captures obfuscated event/string constants that
			// cannot be recovered. Left as a stub.
		}

		private static void SetOverAttrText(GObject component, AttrItemStruct attrItemStruct)
		{
			// TODO: reconstruct — registers a hover/tooltip callback for an attribute item;
			// depends on unrecoverable interned string constants. Left as a stub.
		}

		private static void SetOverStrengthenText(GObject component, CardEntity cardEntity, int level)
		{
			// TODO: reconstruct — registers a hover/tooltip callback describing a card
			// strengthen level; depends on unrecoverable interned string constants and
			// foreign field offsets. Left as a stub.
		}

		private static void SetOverStrengthenText(GObject component, PlantEntity plantEntity, int level)
		{
			// TODO: reconstruct — plant overload of the strengthen tooltip callback; depends
			// on unrecoverable interned string constants and foreign field offsets. Left as
			// a stub.
		}
	}
}
