using System;
using System.Collections.Generic;
using Common.Entity;
using FGUI.Entity.UI.GameMain.Entity;
using FairyGUI;
using Plant.Entity;
using Plant.Entity.Card;
using Touniu.Entity.Body;
using Touniu.Object;
using UnityEngine;
using Zombie.Entity;

namespace FGUI.Entity.UI
{
	public class AttrBoxEntity : DefaultComponentEntity
	{
		private CardEntity _cardEntity;

		private CardZombieEntity _cardZombieEntity;

		private PlantEntity _plantEntity;

		private CardBaseAttr _cardAttr;

		private CardBaseAttr _cardDefaultAttr;

		private PlantBaseAttr _plantAttr;

		private PlantBaseAttr _plantDefaultAttr;

		private ZombieEntity _zombieEntity;

		private ZombieBaseAttr _zombieAttr;

		private ZombieBaseAttr _zombieDefaultAttr;

		private GComponent _plantAttrCom;

		private GComponent _zombieAttrCom;

		private GComponent _touniuAttrCom;

		private TouniuBaseBody _touniuBaseBody;

		private TouniuObject _touniuObject;

		private TouniuBaseAttr _touniuAttr;

		private TouniuBaseAttr _touniuDefaultAttr;

		private bool _isShowPlant;

		private bool _isShowZombie;

		private bool _isShowTouniu;

		private GProgressBar _cachedPlantHealthBar;

		private GProgressBar _cachedZombieHealthBar;

		private GProgressBar _cachedArm1HealthBar;

		private GProgressBar _cachedArm2HealthBar;

		private GProgressBar _cachedTouniuHealthBar;

		private GImage _cachedTouniuHammerInvalidImage;

		private GButton _cachedCardAttrButton1;

		private GButton _cachedCardAttrButton2;

		private GButton _cachedCardAttrButton3;

		private GButton _cachedCardZombieAttrButton1;

		private GButton _cachedCardZombieAttrButton2;

		private GButton _cachedPlantAttrButton1;

		private GButton _cachedPlantAttrButton2;

		private GButton _cachedPlantAttrButton3;

		private GButton _cachedPlantExtraAttrButton1;

		private GButton _cachedPlantExtraAttrButton2;

		private GButton _cachedPlantExtraAttrButton3;

		private GButton _cachedZombieAttrButton1;

		private GButton _cachedZombieAttrButton2;

		private GButton _cachedZombieAttrButton3;

		private GButton _cachedZombieAttrButton4;

		private GButton _cachedZombieExtraAttrButton1;

		private GButton _cachedZombieExtraAttrButton2;

		private GButton _cachedZombieExtraAttrButton3;

		private GButton _cachedTouniuAttrButton1;

		private GButton _cachedTouniuAttrButton2;

		private GButton _cachedTouniuAttrButton3;

		private GButton _cachedTouniuExtraAttrButton1;

		private GButton _cachedTouniuExtraAttrButton2;

		private GButton _cachedTouniuExtraAttrButton3;

		private GList _cachedPlantLabelList;

		private GList _cachedZombieLabelList;

		private GList _cachedTouniuLabelList;

		private int _cardAttrListVersion;

		private int _plantAttrListVersion;

		private int _plantExtraAttrListVersion;

		private int _plantLabelListVersion;

		private int _zombieAttrListVersion;

		private int _zombieExtraAttrListVersion;

		private int _zombieLabelListVersion;

		private int _touniuAttrListVersion;

		private int _touniuExtraAttrListVersion;

		private int _touniuLabelListVersion;

		public AttrBoxEntity(GComponent component)
			: base(component)
		{
			_cardAttrListVersion = -1;
			_plantAttrListVersion = -1;
			_plantExtraAttrListVersion = -1;
			_plantLabelListVersion = -1;
			_zombieAttrListVersion = -1;
			_zombieExtraAttrListVersion = -1;
			_zombieLabelListVersion = -1;
			_touniuAttrListVersion = -1;
			_touniuExtraAttrListVersion = -1;
			_touniuLabelListVersion = -1;
		}

		public override void Start()
		{
			base.Start();
			CacheComponents();
		}

		private void CacheComponents()
		{
		}

		public override void Update()
		{
			if (_isShowPlant)
			{
				UpdatePlant();
			}
			if (_isShowZombie)
			{
				UpdateZombie();
			}
			if (_isShowTouniu)
			{
				UpdateTouniu();
			}
		}

		public void Show(int type)
		{
			if (_plantAttrCom != null)
			{
				_plantAttrCom.visible = false;
			}
			if (_zombieAttrCom != null)
			{
				_zombieAttrCom.visible = false;
			}
			if (_touniuAttrCom != null)
			{
				_touniuAttrCom.visible = false;
			}
			switch (type)
			{
			case 1:
				ShowPlant();
				break;
			case 2:
				ShowZombie();
				break;
			case 3:
				ShowTouniu();
				break;
			}
		}

		private void ShowPlant(GComponent handbookItem = null)
		{
		}

		private void InitLevelUpButton(GButton button, int level)
		{
		}

		private void SetLevelUpButtonBackground(GButton button, int level)
		{
		}

		private void AddLabelList(GList list, List<AttrLabelEntity> attrLabelList)
		{
		}

		private void InitAttrItem(GButton button, AttrItemStruct attrItemStruct)
		{
		}

		private void UpdatePlant()
		{
		}

		private void ShowZombie(GComponent handbookItem = null)
		{
		}

		private void JoinPlantIcon(GGraph icon)
		{
		}

		private void JoinZombieIcon(GGraph icon)
		{
		}

		private void JoinTouniuIcon(GGraph icon)
		{
		}

		private void UpdateZombie()
		{
		}

		private void ClearData()
		{
			_cardEntity = null;
		}

		public void OpenCard(CardEntity cardEntity)
		{
		}

		public void OpenPlant(PlantEntity plantEntity)
		{
		}

		public void OpenZombie(ZombieEntity zombieEntity)
		{
		}

		public void OpenCardZombie(CardZombieEntity cardEntity)
		{
		}

		public void OpenPreparationCard(CardEntity cardEntity)
		{
		}

		public void OpenPreparationZombie(ZombieEntity zombieEntity)
		{
		}

		public void OpenHandbookCard(CardEntity cardEntity, GComponent handbookItem)
		{
		}

		public void OpenHandbookZombie(ZombieEntity zombieEntity, GComponent handbookItem)
		{
		}

		private int GetCurrentListVersion()
		{
			return 0;
		}

		private void UpdateAttrList(int listVersion, Action initAction)
		{
			if (listVersion != Time.frameCount)
			{
				initAction();
			}
		}

		private void UpdateLabelList(GList list, int listVersion, List<AttrLabelEntity> attrLabelList)
		{
			if (attrLabelList == null)
			{
				return;
			}
			int total = 0;
			foreach (AttrLabelEntity label in attrLabelList)
			{
				total += label.layer + 1;
			}
			if (total > 0)
			{
				if (listVersion != total)
				{
					list.RemoveChildrenToPool();
					AddLabelList(list, attrLabelList);
					_plantLabelListVersion = total;
				}
				return;
			}
			list.RemoveChildrenToPool();
		}

		private void InitCardAttrList(GComponent handbookItem = null)
		{
		}

		private void InitPlantAttrList(GComponent handbookItem = null)
		{
		}

		private void InitPlantExtraAttrList(GComponent handbookItem = null)
		{
		}

		private void InitZombieAttrList(GComponent handbookItem = null)
		{
		}

		private void InitZombieExtraAttrList(GComponent handbookItem = null)
		{
		}

		public void OpenTouniu(TouniuBaseBody touniuBaseBody)
		{
		}

		public void OpenHandbookTouniu(TouniuObject touniuObject, GComponent handbookItem)
		{
		}

		private void ShowTouniu(GComponent handbookItem = null)
		{
		}

		private bool IsTouniuUnlock(TouniuObject touniuObject)
		{
			return false;
		}

		private string GetTouniuContentLockText(TouniuObject touniuObject)
		{
			return null;
		}

		private void UpdateTouniu()
		{
		}

		private void InitTouniuAttrList(GComponent handbookItem = null)
		{
		}

		private void InitTouniuExtraAttrList(GComponent handbookItem = null)
		{
		}

		private static void SetOverLabelText(GObject component, AttrLabelEntity labelEntity)
		{
		}

		private static void SetOverAttrText(GObject component, AttrItemStruct attrItemStruct)
		{
		}

		private static void SetOverStrengthenText(GObject component, CardEntity cardEntity, int level)
		{
		}

		private static void SetOverStrengthenText(GObject component, PlantEntity plantEntity, int level)
		{
		}
	}
}
