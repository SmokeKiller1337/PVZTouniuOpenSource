using FairyGUI;

namespace FGUI.Entity.UI
{
	public class GameContinueBoxEntity : DefaultComponentEntity
	{
		public GameContinueBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
		}

		protected override void OnOpen()
		{
		}

		protected override void OnClose()
		{
		}

		public override void Update()
		{
		}

		public bool IsDifficulty4()
		{
			return false;
		}
	}
}
