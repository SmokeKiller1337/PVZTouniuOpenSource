using FairyGUI;

namespace FGUI.Entity.UI
{
	public class GameContinueBoxEntity : DefaultComponentEntity
	{
		public GameContinueBoxEntity(GComponent component)
			: base(component)
		{
			// Authoritative body per stub: the base FGUIComponentEntity ctor takes the
			// component (its `component` field is readonly). The stub pins the base call to
			// `base(null)`, so the body is intentionally empty.
		}

		public override void Start()
		{
			// TODO: reconstruct - original wired four child GButtons (via component.GetChild(...).asButton.onClick)
			// to click handlers that ultimately drive LevelAssetsManager.Instance.StartLevel(1/2/3) and a
			// return-to-menu path (DG.Tweening.DOTween.KillAll + FGUI.Static.FGUIStatic.CloseAll +
			// UnityEngine.SceneManagement.SceneManager.LoadScene). The four FairyGUI child NAME strings and the
			// exact StartLevel type-per-button mapping cannot be recovered without global-metadata, and two of the
			// handlers read through unidentified game-flow/difficulty singletons (native _DAT_182e47708 /
			// _DAT_182e507b0). Left as a stub rather than fabricating child names or member access.
		}

		protected override void OnOpen()
		{
			// TODO: reconstruct - original pushed this box onto a pause-stack singleton (native _DAT_182e79ba0)
			// and, when it became the first pause source, set GameManager pause state (Game.Manager.GameManager
			// IsPause is private/inaccessible from here) and called FGUI.FGUIConstant.GameMainBox.DisplayPauseText().
			// The pause-stack singleton type could not be resolved and the pause setter is not accessible, so the
			// body is left as a stub rather than referencing non-existent/inaccessible members.
		}

		protected override void OnClose()
		{
			// Authentic empty override: RVA 0x386160 is the shared ICF-folded empty method
			// (dump.cs lists OnClose at RVA 0x386160, Slot 15). No body in the binary.
		}

		public override void Update()
		{
			// TODO: reconstruct - original refreshed two child GButtons each frame:
			//   component.GetChild(<fast-start button>).asButton.enabled = ES3.KeyExists("CardSave", AreaStatic.GetRecordSettings());
			//   component.GetChild(<continue button>).asButton.grayed   = !ES3.KeyExists("FrameSave", AreaStatic.GetRecordSettings());
			// The ES3 keys ("CardSave"/"FrameSave") are recoverable, but the two FairyGUI child NAME strings are
			// not recoverable without global-metadata. Left as a stub rather than fabricating child names.
		}

		public bool IsDifficulty4()
		{
			// TODO: reconstruct - original returned whether the current level's difficulty (adventure or touniu)
			// equals 4, reading through two unidentified singletons (native _DAT_182e47708 and _DAT_182e507b0)
			// and comparing int fields at offsets 0x20/0x24 against 4. The concrete singleton types and the field
			// mapping (likely AreaData.LevelData.difficulty / .touniuDifficulty) could not be confirmed, so the
			// method is left as a stub returning the default rather than referencing unverified members.
			return false;
		}
	}
}
