namespace FGUI.Entity.UI.Achievement
{
	public class GoldLockItemEntity
	{
		public int goldNumber;

		public int cardId;
	}
}
