using System.Collections.Generic;

namespace FGUI.Entity.UI.Achievement
{
	public class TrophyNumberEntity
	{
		public Dictionary<int, int> headNumberDic;

		public Dictionary<int, int> bodyNumberDic;

		public TrophyNumberEntity()
		{
			headNumberDic = new Dictionary<int, int>();
			bodyNumberDic = new Dictionary<int, int>();
		}
	}
}
