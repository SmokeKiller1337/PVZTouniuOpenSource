using System;
using FairyGUI;
using Level.Static;

namespace FGUI.Entity.UI
{
	public class SelectLevelInfoBoxEntity : DefaultComponentEntity
	{
		public GComponent mode0Com;

		public GComponent mode1Com;

		public GComponent mode2Com;

		public GComponent currentModeCom;

		public SelectLevelInfoBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Open()
		{
		}

		public override void Awake()
		{
		}

		public override void Start()
		{
		}

		public override void Update()
		{
		}

		private void UpdateAssetsNumber()
		{
		}

		private void ResetDifficultyItem()
		{
		}

		private GComponent GetModeCom()
		{
			int mode = AreaStatic.Mode;
			if (mode == 0)
			{
				return mode0Com;
			}
			if (mode == 1)
			{
				return mode1Com;
			}
			if (mode == 2)
			{
				return mode2Com;
			}
			throw new Exception("Invalid mode");
		}
	}
}
