using FairyGUI;

namespace FGUI.Entity.UI
{
	public class WelcomeBoxEntity : DefaultComponentEntity
	{
		public WelcomeBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
			base.Start();
			// TODO: reconstruct
			// The decompiled body wires up onClick handlers on two child GButtons
			// obtained via component.GetChild(<name>).asButton. The child name string
			// literals and the delegate target handler methods are not recoverable from
			// the pseudocode (unresolved global string constants and ICF-folded delegate
			// targets that are not declared members of this class), so faithfully
			// restoring this method would require inventing members. Left as a stub.
		}

		public override void Update()
		{
		}
	}
}
