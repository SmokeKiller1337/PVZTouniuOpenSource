using FairyGUI;

namespace FGUI.Entity.UI
{
	public class WelcomeBoxEntity : DefaultComponentEntity
	{
		public WelcomeBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
			base.Start();
		}

		public override void Update()
		{
		}
	}
}
