using FairyGUI;
using UnityEngine.Events;

namespace FGUI.Entity.UI
{
	public class GameMenuBoxEntity : DefaultComponentEntity
	{
		public UnityAction UpdateGameDataAction;

		public GComponent menu0Com;

		public GComponent menu1Com;

		public GameMenuBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
		}

		public override void Update()
		{
		}

		private void InitAudioSlider(string name)
		{
		}

		private void UpdateGameData()
		{
		}

		private void DebugButton(int type)
		{
		}
	}
}
