using FairyGUI;
using Plant.Entity;

// NOTE: Reconstructed from IL2CPP/Ghidra output for FGUI.Entity.UI.PlantHandbookBoxEntity.
// The structure below (namespace, usings, class/base, fields, method signatures) is taken
// verbatim from the authoritative stub.cs / dump.cs and is not modified.
//
// Every non-constructor method of this class drives the FairyGUI view by resolving named
// children via GComponent.GetChild("<childName>") and, in Update(), by building item URLs
// via UIPackage.GetItemURL("<pkg>", "<res>"). In the IL2CPP binary those child names,
// package names and resource names are string-literal *data pointers* (uRam.../DAT_...) whose
// literal text cannot be recovered from the available pseudocode. Because reproducing these
// method bodies faithfully would require passing invented string arguments to real APIs
// (GetChild / GetItemURL), and inventing those strings would be fabrication, the affected
// bodies are deliberately left as stubs with a description of their intended behaviour.
//
// Verified facts used while analysing (kept for future reconstruction once the string
// table is available):
//   * base type FGUI.Entity.DefaultComponentEntity : FGUIComponentEntity, which exposes
//     'public readonly GComponent component;' (offset 0x18) — the root of all GetChild calls.
//   * _currentCardId is field @0x30, _type is field @0x34.
//   * Plant.Entity.CardEntity: id @0x20 (int), type @0x44 (CardType), attr @0x70 (CardBaseAttr).
//     Plant.Entity.CardBaseAttr: sun @0x10 (int).
//   * Level.Static.LevelStatic.cardDic : static readonly Dictionary<int, CardEntity>.
//   * FGUI.FGUIConstant.AttrBox : static AttrBoxEntity, exposing
//     'public void OpenHandbookCard(CardEntity cardEntity, GComponent handbookItem)'.
//   * FGUI.Static.FGUIStatic.GetIcon(object) : string;
//     FGUI.Static.FGUIUtils.SetCardBackground(GObject, int).

namespace FGUI.Entity.UI
{
	public class PlantHandbookBoxEntity : DefaultComponentEntity
	{
		private int _currentCardId;

		private int _type;

		public PlantHandbookBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
			// Intended behaviour (from pseudocode):
			//   base.Start();
			//   var tabList = component.GetChild("<tabListName>").asList;
			//   tabList.selectedIndex = 0;
			//   for (int i = 0; i < 3; i++)
			//   {
			//       var btn = tabList.GetChildAt(i).asButton;
			//       // closure <>c__DisplayClass3_0 captures (this, i); onClick sets
			//       // this._type = i; this.Update();
			//       btn.onClick.Set(() => { _type = i; Update(); });
			//   }
			// Blocked: the tab-list child name is an unrecoverable string literal.
			// TODO: reconstruct (needs FairyGUI child-name string constant).
		}

		protected override void OnOpen()
		{
			// Intended behaviour (from pseudocode):
			//   base.OnOpen();
			//   int id = _currentCardId != 0 ? _currentCardId : 10;
			//   CardEntity card = LevelStatic.cardDic[id];
			//   if (card == null) return;
			//   _currentCardId = card.id;
			//   var handbookItem = component.GetChild("<handbookItemName>").asCom;
			//   FGUIConstant.AttrBox.OpenHandbookCard(card, handbookItem);
			// Blocked: the handbook-item child name is an unrecoverable string literal, so
			// the terminal OpenHandbookCard call cannot be issued with a real argument.
			// TODO: reconstruct (needs FairyGUI child-name string constant).
		}

		private void InitCardItem(GComponent cardItem, CardEntity cardEntity)
		{
			// Intended behaviour (from pseudocode):
			//   var button = cardItem.GetChild("<cardButtonName>").asButton;
			//   FGUIUtils.SetCardBackground(button, 0);
			//   button.touchable = true;
			//   button.GetChild("<costTextName>").asTextField.text = cardEntity.attr.sun.ToString();
			//   button.GetChild("<iconLoaderName>").asLoader.url = FGUIStatic.GetIcon(cardEntity);
			//   button.GetChild("<name1>").visible = false;
			//   button.GetChild("<name2>").visible = false;
			//   button.GetChild("<name3>").visible = false; // grayed/selected marker cleared
			// Blocked: all of the child names above are unrecoverable string literals.
			// TODO: reconstruct (needs FairyGUI child-name string constants).
		}

		public override void Update()
		{
			// Intended behaviour (from pseudocode):
			//   var tabList = component.GetChild("<tabListName>").asList;
			//   tabList.selectedIndex = _type;
			//   var cardList = component.GetChild("<cardListName>").asList;
			//   cardList.RemoveChildrenToPool();
			//   var cards = LevelStatic.cardDic.Values.ToList();
			//   cards.Sort(<priority comparer>);
			//   foreach (CardEntity card in cards)
			//   {
			//       if ((int)card.type != _type) continue;
			//       var item = cardList.AddItemFromPool(UIPackage.GetItemURL("<pkg>", "<res>")).asCom;
			//       InitCardItem(item, card);
			//       // closure <>c__DisplayClass6_0 captures (this, card); onTouchBegin -> ShowCard(card)
			//       item.GetChild("<cardButtonName>").asButton.onTouchBegin.Set(ctx => ShowCard(card));
			//   }
			// Blocked: multiple unrecoverable child-name string literals plus the
			// UIPackage.GetItemURL package/resource name literals.
			// TODO: reconstruct (needs FairyGUI child-name and package/resource string constants).
		}

		private void ShowCard(CardEntity cardEntity)
		{
			// Intended behaviour (from pseudocode):
			//   if (cardEntity == null) return;               // UnityEngine.Object == null check
			//   _currentCardId = cardEntity.id;
			//   var handbookItem = component.GetChild("<handbookItemName>").asCom;
			//   FGUIConstant.AttrBox.OpenHandbookCard(cardEntity, handbookItem);
			// Blocked: the handbook-item child name is an unrecoverable string literal, so
			// the terminal OpenHandbookCard call cannot be issued with a real argument.
			// TODO: reconstruct (needs FairyGUI child-name string constant).
		}
	}
}
