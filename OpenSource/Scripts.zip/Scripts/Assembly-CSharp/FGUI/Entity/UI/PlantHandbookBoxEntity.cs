using FairyGUI;
using Plant.Entity;

namespace FGUI.Entity.UI
{
	public class PlantHandbookBoxEntity : DefaultComponentEntity
	{
		private int _currentCardId;

		private int _type;

		public PlantHandbookBoxEntity(GComponent component)
			: base(component)
		{
		}

		public override void Start()
		{
		}

		protected override void OnOpen()
		{
		}

		private void InitCardItem(GComponent cardItem, CardEntity cardEntity)
		{
		}

		public override void Update()
		{
		}

		private void ShowCard(CardEntity cardEntity)
		{
		}
	}
}
