using System.Reflection;
using UnityEngine;

namespace FGUI.Entity
{
	public abstract class FGUISceneInitEntity : MonoBehaviour
	{
		public bool isInit;

		public abstract void Init();

		private void Update()
		{
			// 挂载后首帧驱动一次——先 Reset 所有已建 UI，再执行本场景 Init。
			if (isInit)
			{
				return;
			}
			isInit = true;
			ExecReset();
			Init();
		}

		private void ExecReset()
		{
			// 反射遍历 FGUIConstant 的静态 UI 字段，对每个非空实体调用 Reset()。
			FieldInfo[] fields = typeof(FGUIConstant).GetFields();
			if (fields == null)
			{
				return;
			}
			for (int i = 0; i < fields.Length; i++)
			{
				FieldInfo field = fields[i];
				if (field == null)
				{
					continue;
				}
				if (field.GetValue(null) is FGUIComponentEntity entity)
				{
					entity.Reset();
				}
			}
		}
	}
}
