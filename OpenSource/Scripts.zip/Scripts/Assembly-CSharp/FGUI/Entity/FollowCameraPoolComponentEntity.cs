using FairyGUI;
using UnityEngine;
using UnityEngine.Pool;

namespace FGUI.Entity
{
	public class FollowCameraPoolComponentEntity : FGUIComponentEntity
	{
		private IObjectPool<GComponent> pool;

		protected string itemComponentName;

		public FollowCameraPoolComponentEntity(GComponent component)
			: base(component)
		{
		}

		public override void Awake()
		{
			if (component != null)
			{
				component.visible = false;
			}
		}

		public override void Start()
		{
		}

		public override void Update()
		{
		}

		public override void Reset()
		{
			if (pool == null)
			{
				pool = new ObjectPool<GComponent>(OnCreateItem, OnGetItem, OnReleaseItem, OnDestroyItem, true, 10, 10000);
			}
		}

		protected override void OnOpen()
		{
		}

		protected override void OnOpenEnd()
		{
		}

		protected override void OnClose()
		{
		}

		protected override void OnCloseEnd()
		{
		}

		protected GComponent Get(Vector2 position)
		{
			GComponent gComponent = pool.Get();
			Camera main = Camera.main;
			if (main != null)
			{
				Vector3 vector = main.WorldToScreenPoint(position);
				vector.y = (float)Screen.height - vector.y;
				GRoot inst = GRoot.inst;
				if (inst != null)
				{
					Vector2 vector2 = inst.GlobalToLocal(new Vector2(vector.x, vector.y));
					if (gComponent != null)
					{
						gComponent.SetPosition(vector2.x - gComponent.width * GRoot.contentScaleFactor, vector2.y, 0f);
						return gComponent;
					}
				}
			}
			return gComponent;
		}

		public void Release(GComponent itemCom)
		{
			pool.Release(itemCom);
		}

		protected virtual GComponent OnCreateItem()
		{
			// Decompiled body calls UIPackage.CreateObject(<pkgName>, itemComponentName).asCom,
			// then component.AddChild(...) and sets visible = false. The package-name argument is a
			// folded string constant that cannot be recovered from the pseudocode, so the create
			// call cannot be reconstructed faithfully.
			// TODO: reconstruct
			return null;
		}

		protected virtual void OnGetItem(GComponent itemCom)
		{
			if (!isOpen)
			{
				return;
			}
			if (itemCom != null)
			{
				itemCom.visible = true;
			}
		}

		protected virtual void OnReleaseItem(GComponent itemCom)
		{
			if (itemCom != null)
			{
				itemCom.visible = false;
			}
		}

		protected virtual void OnDestroyItem(GComponent itemCom)
		{
			if (itemCom != null)
			{
				itemCom.Dispose();
			}
		}
	}
}
