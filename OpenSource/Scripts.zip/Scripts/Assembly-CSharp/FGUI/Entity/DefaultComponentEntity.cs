using FairyGUI;
using Game.Manager;

namespace FGUI.Entity
{
	public class DefaultComponentEntity : FGUIComponentEntity
	{
		public DefaultComponentEntity(GComponent component)
			: base(component)
		{
			// the base constructor stores the component reference.
		}

		public override void Awake()
		{
			if (component == null)
			{
				return;
			}
			// Start hidden until opened.
			component.visible = false;
			GRoot inst = GRoot.inst;
			if (inst != null)
			{
				// Center the component horizontally within the root, preserving its
				// current vertical position.
				component.SetPosition((inst.width - component.width) * 0.5f, component.y, component.z);
			}
		}

		public override void Start()
		{
		}

		public override void Update()
		{
		}

		public override void Reset()
		{
		}

		protected override void OnOpen()
		{
			if (!isOpenPause)
			{
				return;
			}
			// Opening a pause-style component registers it as a pause source on the
			// game manager; the manager pauses the game the first time a source is added.
			if (GameManager.Instance != null)
			{
				GameManager.Instance.Pause(this);
			}
		}

		protected override void OnOpenEnd()
		{
		}

		protected override void OnClose()
		{
		}

		protected override void OnCloseEnd()
		{
			if (!isOpenPause)
			{
				return;
			}
			// Closing a pause-style component releases its pause registration; the
			// manager resumes the game once the last source is removed.
			if (GameManager.Instance != null)
			{
				GameManager.Instance.UnPause(this);
			}
		}
	}
}
