using FairyGUI;
using Game.Manager;

namespace FGUI.Entity
{
	public class DefaultComponentEntity : FGUIComponentEntity
	{
		public DefaultComponentEntity(GComponent component)
			: base(component)
		{
			// RVA: 0x6702A0 — the base constructor stores the component reference.
		}

		public override void Awake()
		{
			// RVA: 0x67E240
			if (component == null)
			{
				return;
			}
			// Start hidden until opened.
			component.visible = false;
			GRoot inst = GRoot.inst;
			if (inst != null)
			{
				// Center the component horizontally within the root, preserving its
				// current vertical position.
				component.SetPosition((inst.width - component.width) * 0.5f, component.y, component.z);
			}
		}

		public override void Start()
		{
			// RVA: 0x67E380
			// The original body fetches a child of the component by a string constant
			// (unrecoverable from the pseudocode) via GComponent.GetChild, takes its
			// .asButton, and wires .onClick to a compiler-generated handler
			// (<Start>b__2_0, RVA 0x67E450). That handler is itself an unrecovered
			// indirect (jump-table) virtual call through this instance's vtable with a
			// field argument, whose target could not be resolved. Both the child name
			// and the handler target are unknown, so the method is left as a stub
			// rather than fabricating a child name / member call.
			// TODO: reconstruct
		}

		public override void Update()
		{
			// RVA: 0x381980 — empty in the decompiled binary.
		}

		public override void Reset()
		{
			// RVA: 0x381980 — empty in the decompiled binary.
		}

		protected override void OnOpen()
		{
			// RVA: 0x67E320
			if (!isOpenPause)
			{
				return;
			}
			// Opening a pause-style component registers it as a pause source on the
			// game manager; the manager pauses the game the first time a source is added.
			if (GameManager.Instance != null)
			{
				GameManager.Instance.Pause(this);
			}
		}

		protected override void OnOpenEnd()
		{
			// RVA: 0x381980 — empty in the decompiled binary.
		}

		protected override void OnClose()
		{
			// RVA: 0x381980 — empty in the decompiled binary.
		}

		protected override void OnCloseEnd()
		{
			// RVA: 0x67E2C0
			if (!isOpenPause)
			{
				return;
			}
			// Closing a pause-style component releases its pause registration; the
			// manager resumes the game once the last source is removed.
			if (GameManager.Instance != null)
			{
				GameManager.Instance.UnPause(this);
			}
		}
	}
}
