public delegate void LoadErrorCallback(string error);
