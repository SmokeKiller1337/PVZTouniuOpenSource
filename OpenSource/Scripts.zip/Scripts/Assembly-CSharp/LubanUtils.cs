using System;
using System.IO;
using Luban;
using UnityEngine;
using UnityEngine.Networking;
using cfg;

public class LubanUtils
{
	public static bool isInitLoad;

	private static string GAME_CONF_DIR;

	[SerializeField]
	private static Tables tables;

	public static Tables Tables
	{
		get
		{
			if (tables == null)
			{
				Debug.LogWarning("Tables not loaded yet, loading now.");
				InitLoad();
			}
			return tables;
		}
		set
		{
			tables = value;
		}
	}

	static LubanUtils()
	{
		isInitLoad = true;
		// NOTE: exact string literal is not recoverable from the IL2CPP pseudocode;
		// this is the Luban byte-config directory prefix used by the loader below.
		GAME_CONF_DIR = "GameConf";
	}

	public static void InitLoad()
	{
		LoadTable();
	}

	private static void LoadTable()
	{
		tables = new Tables(delegate(string file)
		{
			byte[] bytes;
			if (Application.platform == RuntimePlatform.Android)
			{
				string uri = GAME_CONF_DIR + "/" + file + ".bytes";
				UnityWebRequest request = UnityWebRequest.Get(uri);
				request.SendWebRequest();
				while (!request.isDone)
				{
				}
				if (request.result != UnityWebRequest.Result.Success)
				{
					Debug.LogError("Load table error: " + request.error);
					return null;
				}
				bytes = request.downloadHandler.data;
			}
			else
			{
				string path = GAME_CONF_DIR + "/" + file + ".bytes";
				if (!File.Exists(path))
				{
					Debug.LogError("Table file not found: " + path);
					return null;
				}
				bytes = File.ReadAllBytes(path);
			}
			if (bytes == null || bytes.Length == 0)
			{
				Debug.LogError("Table file is empty.");
				return null;
			}
			return new ByteBuf(bytes);
		});
	}
}
