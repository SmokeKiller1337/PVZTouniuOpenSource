using System.Collections.Generic;
using Common.Entity;
using UnityEngine;

namespace Reanim2UnityAnim
{
	public class UniqueMaterialController : MonoBehaviour
	{
		[Range(0f, 1f)]
		[Tooltip("整体色相")]
		public float hueValue;

		[HideInInspector]
		public GameObject spriteObj;

		[HideInInspector]
		public GameObject listObj;

		[HideInInspector]
		public GameObject previewSpriteObj;

		private static int sortingOrderIncrement;

		public List<SpriteRenderer> spriteRenderers;

		private BaseBody _baseBody;

		private void Awake()
		{
		}

		private void Start()
		{
		}

		public void Retrieve()
		{
		}

		public void Release()
		{
		}

		private void DisplaySprite(bool flag)
		{
		}
	}
}
