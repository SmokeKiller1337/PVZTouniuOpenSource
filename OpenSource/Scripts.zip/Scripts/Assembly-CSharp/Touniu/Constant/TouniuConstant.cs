using System.Collections.Generic;
using Touniu.Enum;

namespace Touniu.Constant
{
	public static class TouniuConstant
	{
		public const string TouniuSayNamespace = "Touniu.Entity.Say.";

		public const string AudioRootDir = "Audio/Touniu/";

		public const string AudioAIRootDir = "Audio/TouniuAI/";

		public const string Select = "Select";

		public const string Fixed = "Fixed";

		public const string Shop = "Shop";

		public static Dictionary<SayType, string> sayTypeNameDic;

		public const string TouniuHandleNamespace = "Touniu.Entity.Handle.";

		public const string HandlePackageName = "Data";

		static TouniuConstant()
		{
			sayTypeNameDic = new Dictionary<SayType, string>
			{
				{ SayType.Select, Select },
				{ SayType.Fixed, Fixed },
				{ SayType.Shop, Shop }
			};
		}
	}
}
