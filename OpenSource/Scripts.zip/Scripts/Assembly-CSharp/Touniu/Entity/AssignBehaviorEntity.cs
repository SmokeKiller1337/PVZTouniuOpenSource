using System;
using UnityEngine;

namespace Touniu.Entity
{
	[Serializable]
	public class AssignBehaviorEntity
	{
		[Tooltip("持续时间")]
		public float minTime;

		public float maxTime;
	}
}
