using System;
using Touniu.Enum;

namespace Touniu.Entity.Fixed.Mini.Level5
{
	[Serializable]
	public class Mini5SelectSayEntity
	{
		public int id;

		public SayType sayType;

		public string originalText;

		public string simpleText;

		public bool isSelected;

		public Mini5SelectSayEntity()
		{
			// Constructor sets offset 0x28 (isSelected, bool) = 1
			this.isSelected = true;
		}
	}
}
