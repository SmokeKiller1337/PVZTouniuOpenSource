using System;
using System.Collections;
using System.Collections.Generic;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle111002 : TouniuHandleEntity
	{
		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// 空协程：当前无特效逻辑。
			yield break;
		}
	}
}
