using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Land.Entity;
using Plant.Entity;
using Touniu.Manager;
using UnityEngine;
using Zombie.Entity;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle15002 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__3 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle15002 _003C_003E4__this;

			private ZombieEntity _003CzombieEntity_003E5__2;

			private int _003CspeedCount_003E5__3;

			private int _003Ci_003E5__4;

			private CardEntity _003CcardEntity_003E5__5;

			private LandEntity _003ClandEntity_003E5__6;

			private Vector2 _003ClandPosition_003E5__7;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__3(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x503C00. Long 14-state cutscene: gate on Level15DataManager.Instance (set flag
				// +0x38), Move the touniu body and Talk lines 0x3A9F / 0x3AA0 / 0x3AA1 (SayType 4) with
				// WaitForCompletion, FindObjectOfType a component and GetComponent it, then draw a card
				// (LevelUtils.GetCard(-1)) onto an empty land (LevelUtils.GetEmptyLand): SetHandLongSprite,
				// Move to the card/land position, LandEntity.IsPlaceable + LandManager.AddPlant, with the
				// per-iteration WaitForSeconds scaled by the difficulty selector (static _DAT_182e507b0 ->
				// +0xB8 -> member +0x24, values 1/2/3/4) and a DOVirtual.DelayedCall onto the
				// compiler-generated <Effect>b__3_0 callback, finally Move back and End(). The body is
				// left as a stub: the difficulty singleton cannot be mapped from raw offsets, every wait
				// / position constant (_DAT_18252cb28/cb64/cd00/ccfc/ce84/ced0/cb8c/cb94, _UNK_18252cb7c)
				// is unrecovered, and <Effect>b__3_0 is a compiler-generated method that is NOT declared
				// in the authoritative skeleton (which must not be modified).
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded). Caches TouniuManager.Instance.touniuBaseBody into _touniuBaseBody.
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		public override void OnEnd()
		{
			// TODO: reconstruct
			// RVA 0x4FC370 (ICF-folded to TouniuHandle102003.OnEnd). Restores the touniu hand sprite
			// renderer (_touniuBaseBody field +0x140) through an unrecovered indirect call. Left as a
			// stub: the target renderer member and the invoked method cannot be confirmed from offsets.
		}

		protected override void Start()
		{
			// RVA 0x4FC3A0. Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__3))]
		private IEnumerator Effect()
		{
			// RVA 0x4FC300. Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__3(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
