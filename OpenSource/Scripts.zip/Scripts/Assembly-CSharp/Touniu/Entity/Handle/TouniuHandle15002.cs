using System;
using System.Collections;
using System.Collections.Generic;
using Land.Entity;
using Plant.Entity;
using Touniu.Manager;
using UnityEngine;
using Zombie.Entity;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle15002 : TouniuHandleEntity
	{
		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		public override void OnEnd()
		{
		}

		protected override void Start()
		{
			// Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			yield break;
		}
	}
}
