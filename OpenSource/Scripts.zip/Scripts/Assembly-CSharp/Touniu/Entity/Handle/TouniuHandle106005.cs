using System.Collections;
using System.Collections.Generic;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle106005 : TouniuHandleEntity
	{
		[Tooltip("播报")]
		public List<AudioClip> soundList;

		[Tooltip("锤子预制体")]
		public GameObject hammerPrefab;

		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			yield break;
		}

		private IEnumerator RotateHammer(GameObject o)
		{
			yield break;
		}
	}
}
