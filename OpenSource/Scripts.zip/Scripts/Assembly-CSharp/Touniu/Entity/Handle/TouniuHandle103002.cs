using System;
using System.Collections;
using System.Collections.Generic;
using Land.Entity;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle103002 : TouniuHandleEntity
	{
		[Tooltip("植物图")]
		public Sprite plant125Sprite;

		[Tooltip("钻石铲图")]
		public Sprite shovelSprite;

		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		public override void OnEnd()
		{
		}

		protected override void Start()
		{
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			yield break;
		}

		private float GetSpeedRatio()
		{
			return 0f;
		}
	}
}
