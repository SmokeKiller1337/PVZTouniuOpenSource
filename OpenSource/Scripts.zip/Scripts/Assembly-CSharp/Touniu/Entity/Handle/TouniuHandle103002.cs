using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Land.Entity;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle103002 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__5 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle103002 _003C_003E4__this;

			private int _003Cj_003E5__2;

			private int _003CplantNumber_003E5__3;

			private int _003CshovelNumber_003E5__4;

			private int _003CzombieNumber_003E5__5;

			private int _003Ci_003E5__6;

			private float _003CwaitTime_003E5__7;

			private LandEntity _003ClandEntity_003E5__8;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__5(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x575120. Long multi-state Mini3 "cheat board" sequence: spawns an effect at the touniu
				// body, adds buff 3 to the level manager, seeds a difficulty-scaled grid of tombstones
				// (LevelUtils.GetLandBuildingList filtered/shuffled, BuildingManager.AddTombstone), then loops
				// up to 1000 times planting card 125 (LandManager.AddPlant), shovelling plants and spawning
				// zombies (ZombieManager.CreateZombie) at random lands, driving the touniu hand to each target
				// (TouniuBaseBody.Move) at a speed derived from GetSpeedRatio(), with AudioManager.PlayUI cues
				// and per-step WaitForSeconds. Left as a stub on two independent counts: the land/plant/zombie
				// filtering predicates live in compiler-generated `<>c` display classes
				// (<Effect>b__5_0/_1/_2) that are NOT declared in the authoritative skeleton (which must not be
				// modified), and the Mini3 data-manager members, the difficulty singleton (_DAT_182e507b0),
				// the audio/clip singletons and every WaitForSeconds / colour / scale constant cannot be
				// confirmed from raw offsets without guessing.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("植物图")]
		public Sprite plant125Sprite;

		[Tooltip("钻石铲图")]
		public Sprite shovelSprite;

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded). Caches TouniuManager.Instance.touniuBaseBody into _touniuBaseBody.
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		public override void OnEnd()
		{
			// TODO: reconstruct
			// RVA 0x567ED0 (ICF-folded, shared with several sibling handlers). Restores the touniu hand sprite
			// renderer (_touniuBaseBody field +0x140) through an unrecovered indirect call. Left as a stub: the
			// target renderer member and the invoked method cannot be confirmed from the offsets.
		}

		protected override void Start()
		{
			// RVA 0x568480. Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__5))]
		private IEnumerator Effect()
		{
			// RVA 0x568270. Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__5(0)
			{
				_003C_003E4__this = this
			};
		}

		private float GetSpeedRatio()
		{
			// TODO: reconstruct
			// RVA 0x5682E0. Computes the per-step move duration for the Effect sequence from the current
			// land-building count (LevelUtils.GetLandBuildingList), the Mini3 data manager state
			// (LevelMini3DataManager.Instance members +0x28/+0x38), whether the level manager has buff 3
			// (BuffHandler.HasBuff), and the area difficulty (_DAT_182e507b0 -> +0x24 mode multiplier). Left as
			// a stub: every threshold/weight is an unrecovered float constant (_DAT_18252cb28 / ce80 / cd08 /
			// cd00 / ce84 / cb64 / ce30 / cf3c) and the manager members cannot be confirmed from raw offsets.
			return 0f;
		}
	}
}
