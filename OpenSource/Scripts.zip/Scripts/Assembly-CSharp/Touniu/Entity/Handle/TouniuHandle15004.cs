using System;
using System.Collections;
using System.Collections.Generic;
using Bullet.Entity;
using Land.Entity;
using Plant.Entity;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle15004 : TouniuHandleEntity
	{
		[Tooltip("豌豆子弹")]
		public BulletAttr bulletAttr;

		[Tooltip("拿樱桃炸弹时音效")]
		public AudioClip plant30Sound;

		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		public override void OnEnd()
		{
		}

		protected override void Start()
		{
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// 该关卡无额外效果逻辑
			yield break;
		}
	}
}
