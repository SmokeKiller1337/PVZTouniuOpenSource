using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Bullet.Entity;
using Land.Entity;
using Plant.Entity;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle15004 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__5 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle15004 _003C_003E4__this;

			private int _003CerrorCount_003E5__2;

			private int _003CspeedCount_003E5__3;

			private int _003Ci_003E5__4;

			private CardEntity _003CcardEntity_003E5__5;

			private LandEntity _003ClandEntity_003E5__6;

			private Vector2 _003ClandPosition_003E5__7;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__5(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x508770. Large 10-state auto-play loop (bounded to 500 iterations, tracking an
				// error count and a speed count): each pass draws a card (LevelUtils.GetCard), and on the
				// hardest difficulty (static _DAT_182e507b0 -> +0xB8 -> member +0x24 > 3, with enough
				// zombies/plants on the board) fires the pea bullet (bulletAttr, field +0x60) at the
				// nearest zombie via BulletManager.CreateBullet using a camera-relative offset
				// (unidentified camera singleton _DAT_182e70d90); otherwise it walks the touniu to an
				// empty land (LevelUtils.GetEmptyLand), SetHandLongSprite/Move, LandEntity.IsPlaceable +
				// LandManager.AddPlant, plays audio (AudioManager.PlayVoice with plant30Sound (+0x68) for
				// the cherry bomb id 0x1E, and AudioManager.PlayUI), with per-iteration WaitForSeconds
				// scaled by the difficulty selector and Level15DataManager.Instance (+0x39), then End().
				// The body is left as a stub: the difficulty and camera singletons cannot be mapped from
				// raw offsets, and the numerous wait/scale constants (_DAT_18252cb28/cb64/cd00/ccfc,
				// _UNK_18252cf28/cb7c, etc.) are unrecovered, so a faithful reconstruction would require
				// fabricating member accesses.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("豌豆子弹")]
		public BulletAttr bulletAttr;

		[Tooltip("拿樱桃炸弹时音效")]
		public AudioClip plant30Sound;

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded). Caches TouniuManager.Instance.touniuBaseBody into _touniuBaseBody.
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		public override void OnEnd()
		{
			// TODO: reconstruct
			// RVA 0x4FC370 (ICF-folded to TouniuHandle102003.OnEnd). Restores the touniu hand sprite
			// renderer (_touniuBaseBody field +0x140) through an unrecovered indirect call. Left as a
			// stub: the target renderer member and the invoked method cannot be confirmed from offsets.
		}

		protected override void Start()
		{
			// RVA 0x4FC5E0. Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__5))]
		private IEnumerator Effect()
		{
			// RVA 0x4FC570. Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__5(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
