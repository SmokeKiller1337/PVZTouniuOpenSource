using System;
using System.Collections;
using System.Collections.Generic;
using Level.Manager.Data.Mini;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle112001 : TouniuHandleEntity
	{
		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// 先执行基类逻辑，再启动效果协程
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// 若关卡数据管理器存在，初始化首个花盆槽位，随后结束行为
			if (LevelMini12DataManager.Instance != null)
			{
				LevelMini12DataManager.Instance.InitPot(0);
			}
			End();
			yield break;
		}
	}
}
