using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle15003 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__2 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle15003 _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__2(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x503360. Seven-state farewell sequence: Move the touniu body through a series of
				// positions (states 0-3) with WaitForSeconds pauses, then branch on the difficulty
				// selector (static _DAT_182e507b0 -> +0xB8 -> member +0x24): if < 3, Talk line 0x3AA3
				// (SayType 4) with WaitForCompletion, otherwise TouniuBehaviorUtils.Talk(0x3AA4, 4, true);
				// then RewardManager.CreateTrophy at the touniu's world position, Move it toward a
				// camera-relative point (unidentified camera singleton _DAT_182e70d90 -> +0xB8, members
				// +0x3c/+0x40), schedule a DOVirtual.DelayedCall onto the compiler-generated
				// <Effect>b__2_0 callback, and finally End(). The body is left as a stub: the difficulty
				// and camera singletons cannot be mapped from raw offsets, the position/duration
				// constants (_UNK_18252ced8/ceec/cef4/cf48, _DAT_18252cb28/ce84/cb98/ce38/cb6c) are
				// unrecovered, and <Effect>b__2_0 is a compiler-generated method not declared in the
				// authoritative skeleton (which must not be modified).
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded). Caches TouniuManager.Instance.touniuBaseBody into _touniuBaseBody.
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// RVA 0x4FC4C0. Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__2))]
		private IEnumerator Effect()
		{
			// RVA 0x4FC450. Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__2(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
