using System.Collections;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle110001 : TouniuHandleEntity
	{
		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// 该处理器暂无特效逻辑
			yield break;
		}
	}
}
