using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle102001 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__2 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle102001 _003C_003E4__this;

			private bool _003CisBlue_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__2(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x557420. Toggles the touniu between two color variants. Reads
				// LevelMini2DataManager.Instance (flipping its bool field at +0x28 into the local
				// `isBlue`), then Moves the touniu body up (TouniuBaseBody.Move) and waits; on the
				// second pass calls TouniuManager.Instance.ChangeTouniu(2 or 3) depending on isBlue,
				// assigns the touniu body's two sprite fields (+0x28 / +0x38) to the matching
				// variant sprites, Moves the body back down and waits, then End(). Left as a stub:
				// the four variant-sprite constants (_182e43fb0 / _182e3d748 / _182e3c368 /
				// _182e3d410), the _touniuBaseBody sprite members (+0x28 / +0x38), the Move target
				// vector (_UNK_18252ce94) and the WaitForSeconds duration (_DAT_18252cb64) cannot be
				// confirmed from raw offsets without guessing.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded). Caches TouniuManager.Instance.touniuBaseBody into _touniuBaseBody.
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// RVA 0x552C40. Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__2))]
		private IEnumerator Effect()
		{
			// RVA 0x552BD0. Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__2(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
