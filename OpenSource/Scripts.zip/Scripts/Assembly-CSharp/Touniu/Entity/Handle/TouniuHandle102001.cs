using System.Collections;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle102001 : TouniuHandleEntity
	{
		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			yield break;
		}
	}
}
