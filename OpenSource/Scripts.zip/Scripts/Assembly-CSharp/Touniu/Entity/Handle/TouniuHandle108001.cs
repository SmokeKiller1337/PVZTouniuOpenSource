using System;
using System.Collections;
using System.Collections.Generic;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle108001 : TouniuHandleEntity
	{
		[Tooltip("图片1")]
		public GameObject image1Prefab;

		[Tooltip("图片2")]
		public GameObject image2Prefab;

		private GameObject _image1Obj;

		private GameObject _image2Obj;

		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		public override void OnEnd()
		{
			// Destroys the two spawned image objects if they are still alive.
			if (_image1Obj != null)
			{
				UnityEngine.Object.Destroy(_image1Obj);
			}
			if (_image2Obj != null)
			{
				UnityEngine.Object.Destroy(_image2Obj);
			}
		}

		protected override void Start()
		{
			// Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// 该特效当前无任何分步逻辑，直接结束。
			yield break;
		}
	}
}
