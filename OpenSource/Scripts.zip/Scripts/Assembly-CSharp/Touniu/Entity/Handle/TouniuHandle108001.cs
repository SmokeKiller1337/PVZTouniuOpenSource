using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle108001 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__7 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle108001 _003C_003E4__this;

			private TouniuSayEntity _003CtouniuSayEntity_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__7(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x5777C0. Eight-state Mini8 image sequence: speaks narrator lines
				// (_touniuBaseBody.Talk 0x1a5e1..0x1a5e4) each awaited via WaitForCompletion, spawns
				// image1Prefab/image2Prefab (Instantiate) into _image1Obj/_image2Obj at spawn transforms taken
				// from an unidentified singleton (_DAT_182e46360 -> +0xb8), recolours a child SpriteRenderer and
				// drives DG.Tweening DOMove/DOColor tweens over unrecovered data-segment constants
				// (_DAT_18252c* / _DAT_18252d* family) with WaitForSeconds yields, destroying each object when
				// finished. The spawn-transform singleton and the tween/yield constants cannot be resolved to
				// confirmed members, so the body is left as a stub.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("图片1")]
		public GameObject image1Prefab;

		[Tooltip("图片2")]
		public GameObject image2Prefab;

		private GameObject _image1Obj;

		private GameObject _image2Obj;

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded). Caches TouniuManager.Instance.touniuBaseBody into _touniuBaseBody,
			// matching the base TouniuBehaviorEntity.Awake body.
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		public override void OnEnd()
		{
			// RVA 0x5691A0. Destroys the two spawned image objects if they are still alive.
			if (_image1Obj != null)
			{
				UnityEngine.Object.Destroy(_image1Obj);
			}
			if (_image2Obj != null)
			{
				UnityEngine.Object.Destroy(_image2Obj);
			}
		}

		protected override void Start()
		{
			// RVA 0x569280. Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__7))]
		private IEnumerator Effect()
		{
			// Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__7(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
