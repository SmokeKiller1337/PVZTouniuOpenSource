using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Plant.Entity;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle1002 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass5_0
		{
			public PlantEntity plantEntity;

			internal void _003CEffect_003Eb__0()
			{
				// TODO: reconstruct
				// RVA 0x5785B0. Delayed-call callback: if plantEntity != null, calls
				// BaseBody.Highlight(plantEntity, <bool>). Left as a stub: the Highlight overload
				// and its argument cannot be confirmed from the offsets without guessing.
			}
		}

		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__5 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle1002 _003C_003E4__this;

			private _003C_003Ec__DisplayClass5_0 _003C_003E8__1;

			private int _003Ci_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__5(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x576B00. Sell-plant loop repeated `number` times. For each of `number`
				// iterations it: creates a display-class closure holding a random planted PlantEntity
				// (LevelUtils.GetLandPlant), swaps the touniu hand sprite to sellSprite, plays a UI
				// sound via AudioManager.PlayUI(<sound key at manager +0x88/+0xA0>), moves the touniu
				// body toward the plant (TouniuBaseBody.Move), highlights the plant through a
				// DOVirtual.DelayedCall, then spawns sun via RewardManager.CreateSun at the plant's
				// position using the plant's card sun value, with several WaitForSeconds gaps.
				// End() once all iterations complete. Left as a stub: the AudioManager sound keys
				// (manager singleton _DAT_182e65730 members +0x88/+0xA0), the RewardManager singleton,
				// TouniuBaseBody.Move / CreateSun argument constants (_DAT_18252cb28 / cb64 / cd08 /
				// ce20 / cb70) and the DelayedCall delay cannot be confirmed from raw offsets.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("卖数量")]
		public int number;

		[Tooltip("卖图片")]
		public Sprite sellSprite;

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded). Caches TouniuManager.Instance.touniuBaseBody into _touniuBaseBody.
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		public override void OnEnd()
		{
			// TODO: reconstruct
			// RVA 0x567ED0. Restores the touniu hand sprite renderer (_touniuBaseBody field +0x140)
			// through an unrecovered indirect call. Left as a stub: the target renderer member and
			// the invoked method cannot be confirmed from the offsets.
		}

		protected override void Start()
		{
			// RVA 0x567F10. Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__5))]
		private IEnumerator Effect()
		{
			// RVA 0x567E60. Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__5(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
