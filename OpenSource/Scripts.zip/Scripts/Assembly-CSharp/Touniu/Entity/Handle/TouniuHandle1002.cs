using System;
using System.Collections;
using System.Collections.Generic;
using Plant.Entity;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle1002 : TouniuHandleEntity
	{
		[Tooltip("卖数量")]
		public int number;

		[Tooltip("卖图片")]
		public Sprite sellSprite;

		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		public override void OnEnd()
		{
		}

		protected override void Start()
		{
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// 当前无特效逻辑
			yield break;
		}
	}
}
