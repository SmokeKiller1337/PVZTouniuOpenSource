using System;
using System.Collections;
using System.Collections.Generic;
using Plant.Entity;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle111001 : TouniuHandleEntity
	{
		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// 该头牛暂无额外特效逻辑
			yield break;
		}
	}
}
