using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Plant.Entity;
using Plant.Entity.Plant;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle16002 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass13_0
		{
			public PlantEntity plantEntity;

			internal void _003CEffect_003Eb__0(PlantEntity plant)
			{
				// RVA 0x3FF620. Captures the placed plant into the display-class field so the
				// coroutine can reference it after PlacePlant completes.
				plantEntity = plant;
			}
		}

		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__13 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle16002 _003C_003E4__this;

			private _003C_003Ec__DisplayClass13_0 _003C_003E8__1;

			private TouniuSayEntity _003CtouniuSayEntity_003E5__2;

			private Plant60Entity _003Cplant60Entity_003E5__3;

			private float _003Ctimer_003E5__4;

			private Vector3 _003Cposition_003E5__5;

			private bool _003CisHit_003E5__6;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__13(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x4FFAB0. A 16-state Level-16 sequence: places a plant via
				// _touniuBaseBody.handle.PlacePlant(PlacePlantParam), moves/talks the touniu
				// (Talk(0x3E81/0x3E82/0x3E83/0x3E84, SayType.Fixed)), plays hand-long sprite frames with
				// AudioManager.PlayOneShot and DOPunchPosition, runs a Physics2D.OverlapCircleAll bullet-hit
				// loop that spawns GameUtils.CreateEffect and BulletEntity.DestroySelf, tweaks the touniu's
				// SpriteRenderer material, and finally End().
				// Left as a stub because nearly every step depends on unresolved data-segment constants: the
				// WaitForSeconds durations (_DAT_18252cb* / _UNK_18252cd* / _UNK_18252cf* family), a camera/
				// position singleton (_DAT_182e70d90) read at many raw offsets, material property-name statics
				// (_DAT_182e4d898 / _DAT_182e4d938), and raw vtable slots (+0x408/+0x410). These cannot be
				// mapped to confirmed members without guessing, so a faithful reconstruction is not possible.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		public Sprite peaSprite;

		public Sprite peaHeadSprite;

		public Sprite bucketSprite;

		public Sprite milkSprite;

		public Sprite meatSprite;

		public AudioClip bucketSound;

		public AudioClip milkSound;

		public AudioClip milkSound1;

		public AudioClip meatSound;

		public AudioClip loseHeadSound;

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded onto the shared Handle.Awake body). Caches the shared touniu body
			// from the TouniuManager singleton into the base-class _touniuBaseBody field
			// (TouniuManager.Instance.touniuBaseBody).
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		public override void OnEnd()
		{
			// TODO: reconstruct
			// RVA 0x4FC8B0. Restores the touniu after the Level-16 effect: SetHandLongSprite(null), then
			// iterates _touniuBaseBody.GetComponentsInChildren<SpriteRenderer>(true) resetting each
			// material's hit color and flash amount, and finally resets the body Animator's speed.
			// Left as a stub because the material property-name statics (_DAT_182e4d898 / _DAT_182e4d938)
			// are unresolved native globals whose string keys could not be recovered from the exported
			// assembly, so the SetColor/SetFloat calls cannot be reconstructed without inventing them.
		}

		protected override void Start()
		{
			// RVA 0x4FCA10. Chains to the base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__13))]
		private IEnumerator Effect()
		{
			// RVA 0x4FC840. Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__13(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
