using System.Collections;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle16002 : TouniuHandleEntity
	{
		public Sprite peaSprite;

		public Sprite peaHeadSprite;

		public Sprite bucketSprite;

		public Sprite milkSprite;

		public Sprite meatSprite;

		public AudioClip bucketSound;

		public AudioClip milkSound;

		public AudioClip milkSound1;

		public AudioClip meatSound;

		public AudioClip loseHeadSound;

		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		public override void OnEnd()
		{
		}

		protected override void Start()
		{
			// Chains to the base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// 本关卡无额外表现逻辑，协程直接结束。
			yield break;
		}
	}
}
