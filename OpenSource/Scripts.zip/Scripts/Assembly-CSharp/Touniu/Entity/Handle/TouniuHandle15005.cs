using System;
using System.Collections;
using System.Collections.Generic;
using Plant.Entity;
using Plant.Entity.Plant;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle15005 : TouniuHandleEntity
	{
		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// 先执行基类初始化，再启动特效协程。
			base.Start();
			StartCoroutine(Effect());
		}

		public override void OnEnd()
		{
		}

		private IEnumerator Effect()
		{
			// 当前无特效逻辑，占位空协程。
			yield break;
		}
	}
}
