using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Plant.Entity;
using Plant.Entity.Plant;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle15005 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__3 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle15005 _003C_003E4__this;

			private PlantEntity _003CplantEntity_003E5__2;

			private Plant50Entity _003Cplant50Entity_003E5__3;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__3(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x504860. Level-15 (id-50 melon-pult / 巨型玉米？) boss dialogue sequence. Its
				// confirmable pieces are: on state 0 _touniuBaseBody.Talk(0x3AAE, SayType.Fixed);
				// on state 1 LevelUtils.GetLandPlant(3, 1) cast to Plant50Entity, and when its id is 50
				// _touniuBaseBody.Move(plant.transform.position, ...) followed by Talk(0x3AAB, SayType.Fixed);
				// on state 2 a plant-side flag write then, when plant.IsPreparation is true,
				// StartCoroutine(plant.PreparationEnd()); on state 3 StartCoroutine(plant.Explosion()) and a
				// wave-state branch that either _touniuBaseBody.Stun() + sets a Level15DataManager.Instance flag
				// or _touniuBaseBody.Dying(), then End().
				// Left as a stub because every yield uses an unrecovered WaitForSeconds duration constant
				// (_DAT_18252cb90 / _DAT_18252cb88 / _DAT_18252cb28), and the sequence dereferences several
				// unidentified singleton/field offsets on the plant and on the current-wave object (raw +0xe0 /
				// +0x18 / +0x24 accesses) that cannot be mapped to confirmed members without guessing.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded onto the shared Handle.Awake body). Caches the shared touniu body
			// from the TouniuManager singleton into the base-class _touniuBaseBody field
			// (TouniuManager.Instance.touniuBaseBody).
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// RVA 0x4FC6D0. Chains to the base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		public override void OnEnd()
		{
			// Confirmed empty: RVA 0x386160 is the shared empty-method thunk.
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__3))]
		private IEnumerator Effect()
		{
			// RVA 0x4FC660. Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__3(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
