using System;
using System.Collections;
using System.Collections.Generic;
using Level.Manager.Data.Mini;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle108003 : TouniuHandleEntity
	{
		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// Mini8 关卡开场：若数据管理器存在则启动谜题流程，随后结束该行为。
			if (LevelMini8DataManager.Instance != null)
			{
				LevelMini8DataManager.Instance.RiddleStart();
			}
			End();
			yield break;
		}
	}
}
