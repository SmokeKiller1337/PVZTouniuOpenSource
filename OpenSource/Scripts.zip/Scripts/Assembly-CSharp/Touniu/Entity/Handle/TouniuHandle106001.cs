using System.Collections;
using System.Collections.Generic;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle106001 : TouniuHandleEntity
	{
		[Tooltip("开局播报")]
		public List<AudioClip> soundList;

		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			base.Start();
			StartCoroutine(Effect());
		}

		// 开局特效协程，当前无播报逻辑
		private IEnumerator Effect()
		{
			yield break;
		}
	}
}
