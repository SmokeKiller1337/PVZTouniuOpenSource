using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle106001 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__3 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle106001 _003C_003E4__this;

			private TouniuSayEntity _003CtouniuSayEntity_003E5__2;

			private int _003Ci_003E5__3;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__3(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x570D80. A ~17-state black-screen opening "报幕" sequence for the Mini6 level. At each
				// state it invokes a virtual method on LevelMini6DataManager.Instance's sub-object (raw member
				// +0x70, dispatched through vtable slot +0x268 with unrecovered localization-key statics
				// _DAT_182e40d18 / _182e42238 / _182e4aab8 / _182e3d228 / _182e3d0e0), interleaved with
				// AudioManager.PlayVoice(soundList[i]) / AudioManager.PlayOneShot on unidentified singletons
				// (FUN_1804177e0 / FUN_1804178e0), _touniuBaseBody.Talk(0x19e11..0x19e15, SayType.Fixed) awaited
				// via WaitForCompletion, and LevelMini6DataManager.EnterBlack/OutCard/ExitBlack, finishing with
				// TouniuBehaviorUtils.ClearQueue() and End(). Every yield uses an unrecovered WaitForSeconds
				// float constant (_DAT_18252c* family). The +0x70 dispatch target, its localization argument
				// statics and the wait constants cannot be resolved to confirmed members without guessing, so
				// the body is left as a stub.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("开局播报")]
		public List<AudioClip> soundList;

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded). Caches TouniuManager.Instance.touniuBaseBody into _touniuBaseBody.
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// RVA 0x568660. Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__3))]
		private IEnumerator Effect()
		{
			// RVA 0x5685F0. Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__3(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
