using System;
using System.Collections;
using System.Collections.Generic;
using Level.Manager.Data.Mini;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle113002 : TouniuHandleEntity
	{
		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// 一次性效果：若第13关昼夜数据管理器存在，则切换到夜晚，随后结束行为。
			if (LevelMini13DataManager.Instance != null)
			{
				LevelMini13DataManager.Instance.EnterNight();
			}
			End();
			yield break;
		}
	}
}
