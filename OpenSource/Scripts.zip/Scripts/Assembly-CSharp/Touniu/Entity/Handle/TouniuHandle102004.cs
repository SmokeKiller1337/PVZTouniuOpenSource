using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Game.Entity;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle102004 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__6 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle102004 _003C_003E4__this;

			private SpriteRenderer[] _003Crenderers_003E5__2;

			private float _003CintervalTime_003E5__3;

			private float _003CintervalTimer_003E5__4;

			private float _003Ctime_003E5__5;

			private float _003Ctimer_003E5__6;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__6(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x5772A0. Six-state "purge board" magic sequence: spawns magicEffect at the touniu's
				// staff sub-object (_touniuBaseBody member +0x88) position, fades every SpriteRenderer under
				// _touniuBaseBody (GetComponentsInChildren) to transparent via DOTween DOColor, plays a UI
				// sound (AudioManager.PlayUI on unidentified singletons FUN_1804177e0 / FUN_1804178e0), then
				// over a difficulty-scaled duration (LevelAreaManager singleton _DAT_182e507b0 -> +0x24 mode)
				// repeatedly calls _touniuBaseBody.handle.ShovelPlant() before fading the sprites back to their
				// normal colour and End()ing. Left as a stub: the +0x88 staff member, the audio singletons and
				// their clip members, every DOColor colour constant (_DAT_18252cba0 family), the difficulty
				// mode field and all WaitForSeconds / scale constants cannot be confirmed from raw offsets
				// without guessing.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("符咒特效")]
		public EffectEntity magicEffect;

		[Tooltip("贴图")]
		public Sprite itemSprite;

		[Tooltip("铲子贴图")]
		public Sprite shovelSprite;

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded). Caches TouniuManager.Instance.touniuBaseBody into _touniuBaseBody.
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		public override void OnEnd()
		{
			// TODO: reconstruct
			// RVA 0x568000. Clears the touniu hand sprite renderer (_touniuBaseBody field +0x140) to null and
			// resets every SpriteRenderer under _touniuBaseBody (GetComponentsInChildren) back to its normal
			// colour. Left as a stub: the reset colour is an unrecovered constant (_DAT_18252cba0 family) and
			// the +0x140 renderer member cannot be confirmed from the offset alone.
		}

		protected override void Start()
		{
			// RVA 0x5680D0. Chains to base Start, then launches the Effect coroutine. The original also assigns
			// the touniu hand sprite renderer (_touniuBaseBody field +0x140) = itemSprite before starting the
			// coroutine; that assignment is omitted because the specific renderer member (short vs long hand)
			// cannot be confirmed from the offset alone.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__6))]
		private IEnumerator Effect()
		{
			// RVA 0x567F90. Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__6(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
