using System;
using System.Collections;
using System.Collections.Generic;
using Game.Entity;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle102004 : TouniuHandleEntity
	{
		[Tooltip("符咒特效")]
		public EffectEntity magicEffect;

		[Tooltip("贴图")]
		public Sprite itemSprite;

		[Tooltip("铲子贴图")]
		public Sprite shovelSprite;

		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		public override void OnEnd()
		{
		}

		protected override void Start()
		{
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			yield break;
		}
	}
}
