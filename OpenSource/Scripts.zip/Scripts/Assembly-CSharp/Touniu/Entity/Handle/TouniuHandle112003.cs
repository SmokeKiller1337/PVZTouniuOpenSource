using System;
using System.Collections;
using System.Collections.Generic;
using Level.Manager.Data.Mini;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle112003 : TouniuHandleEntity
	{
		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// 先执行基类初始化，再启动效果协程
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// 初始化第三个花盆槽位后结束行为
			if (LevelMini12DataManager.Instance != null)
			{
				LevelMini12DataManager.Instance.InitPot(2);
			}
			End();
			yield break;
		}
	}
}
