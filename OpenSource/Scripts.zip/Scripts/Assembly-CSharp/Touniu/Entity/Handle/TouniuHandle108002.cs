using System.Collections;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle108002 : TouniuHandleEntity
	{
		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// 当前无特效逻辑，直接结束。
			yield break;
		}
	}
}
