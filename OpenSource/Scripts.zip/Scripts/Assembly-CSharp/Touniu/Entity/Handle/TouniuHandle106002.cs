using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle106002 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__4 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle106002 _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__4(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x574120. Eight-state tutorial dialogue: pauses game time via
				// LevelAssetsManager.set_IsPauseTime on an unidentified manager singleton (FUN_180417960),
				// flags a bool at +0x31 on another singleton (FUN_180417a20), moves the touniu body toward the
				// current mouse-click position (TouniuBaseBody.Move), then walks a chain of
				// _touniuBaseBody.Talk(0x19e16 / 0x19e17 / 0x19e18 / 0x19e1b / 0x19e29, SayType.Fixed) lines
				// awaited via WaitForCompletion, clears the touniu hand sprite renderer (+0x140) to null, and
				// (depending on a count field +0x18 < 10 on FUN_1804178a0's +0x20 sub-object) plays one more
				// line before TouniuBehaviorUtils.Talk(0x19e11, SayType.Select) and End(). Left as a stub: the
				// pause/flag manager singletons, the mouse-click-position source, the +0x140 renderer member
				// and every WaitForSeconds duration constant cannot be confirmed from raw offsets without
				// guessing.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("图标")]
		public Sprite itemSprite;

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded). Caches TouniuManager.Instance.touniuBaseBody into _touniuBaseBody.
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		public override void OnEnd()
		{
			// TODO: reconstruct
			// RVA 0x567ED0 (ICF-folded, shared with several sibling handlers). Restores the touniu hand sprite
			// renderer (_touniuBaseBody field +0x140) through an unrecovered indirect call. Left as a stub: the
			// target renderer member and the invoked method cannot be confirmed from the offsets.
		}

		protected override void Start()
		{
			// RVA 0x568750. Chains to base Start, then launches the Effect coroutine. The original also assigns
			// the touniu hand sprite renderer (_touniuBaseBody field +0x140) = itemSprite before starting the
			// coroutine; that assignment is omitted because the specific renderer member (short vs long hand)
			// cannot be confirmed from the offset alone.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__4))]
		private IEnumerator Effect()
		{
			// RVA 0x5686E0. Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__4(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
