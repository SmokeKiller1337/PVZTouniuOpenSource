using System;
using System.Collections;
using System.Collections.Generic;
using Land.Entity;
using Level.Util;
using Plant.Entity;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle1001 : TouniuHandleEntity
	{
		[Tooltip("换位数量")]
		public int number;

		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		public override void OnEnd()
		{
		}

		protected override void Start()
		{
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// 按 number 次，将随机一株已种植的植物换位到一块空地（无空地则任取一块），逐次执行换位动画后结束。
			for (int i = 0; i < number; i++)
			{
				PlantEntity landPlant = LevelUtils.GetLandPlant();
				if (landPlant == null)
				{
					continue;
				}
				LandEntity landEntity = LevelUtils.GetEmptyLand();
				if (landEntity == null)
				{
					landEntity = LevelUtils.GetLand();
				}
				yield return _touniuBaseBody.handle.SwapPlant(landPlant.CurrentLandEntity, landEntity, 1f);
			}
			End();
		}
	}
}
