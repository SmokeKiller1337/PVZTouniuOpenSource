using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Land.Entity;
using Level.Util;
using Plant.Entity;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle1001 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__4 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle1001 _003C_003E4__this;

			private int _003Ci_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__4(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// RVA 0x573CF0. Repeatedly swaps a random planted lawn plant onto a free lane,
				// `number` times. For each iteration: grab a random planted PlantEntity via
				// LevelUtils.GetLandPlant(); skip the slot if none; otherwise pick an empty land
				// (falling back to any land), then yield the _touniuBaseBody.handle.SwapPlant swap
				// coroutine before advancing. End() once `number` swaps have been attempted.
				int num = _003C_003E1__state;
				TouniuHandle1001 touniuHandle = _003C_003E4__this;
				switch (num)
				{
				default:
					return false;
				case 0:
					_003C_003E1__state = -1;
					_003Ci_003E5__2 = 0;
					break;
				case 1:
					_003C_003E1__state = -1;
					_003Ci_003E5__2++;
					break;
				}
				while (_003Ci_003E5__2 < touniuHandle.number)
				{
					PlantEntity landPlant = LevelUtils.GetLandPlant();
					if (landPlant == null)
					{
						_003Ci_003E5__2++;
						continue;
					}
					LandEntity landEntity = LevelUtils.GetEmptyLand();
					if (landEntity == null)
					{
						landEntity = LevelUtils.GetLand();
					}
					_003C_003E2__current = touniuHandle._touniuBaseBody.handle.SwapPlant(landPlant.CurrentLandEntity, landEntity, 1f);
					_003C_003E1__state = 1;
					return true;
				}
				touniuHandle.End();
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("换位数量")]
		public int number;

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded). Caches TouniuManager.Instance.touniuBaseBody into _touniuBaseBody.
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		public override void OnEnd()
		{
			// Confirmed empty: RVA 0x386160 is a shared empty-method thunk.
		}

		protected override void Start()
		{
			// RVA 0x567DE0. Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__4))]
		private IEnumerator Effect()
		{
			// RVA 0x567D70. Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__4(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
