using System;
using System.Collections;
using System.Collections.Generic;
using Game.Entity;
using Plant.Entity;
using Touniu.Manager;
using UnityEngine;
using Zombie.Entity;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle102003 : TouniuHandleEntity
	{
		[Tooltip("符咒特效")]
		public EffectEntity magicEffect;

		[Tooltip("贴图")]
		public Sprite itemSprite;

		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		public override void OnEnd()
		{
		}

		protected override void Start()
		{
			base.Start();
			StartCoroutine(Effect());
		}

		// 符咒特效协程：当前无处理逻辑，立即结束
		private IEnumerator Effect()
		{
			yield break;
		}
	}
}
