using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Game.Entity;
using Plant.Entity;
using Touniu.Manager;
using UnityEngine;
using Zombie.Entity;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle102003 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__5 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle102003 _003C_003E4__this;

			private TouniuSayEntity _003CtouniuSayEntity_003E5__2;

			private int _003CaddHealth_003E5__3;

			private int _003Cvalue_003E5__4;

			private int _003Ci_003E5__5;

			private PlantEntity _003CplantEntity_003E5__6;

			private ZombieEntity _003CzombieEntity_003E5__7;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__5(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x562950. Long 11-state "magic charm" sequence: Move the touniu body,
				// ChangeTouniu(1), AudioManager.PlayOneShot(<clip at _touniuBaseBody +0x60>),
				// Move back, Talk(0x18E85, SayType) -> WaitForCompletion, SetHandLongSprite(itemSprite),
				// spawn magicEffect at the hand position, then two reward loops (up to 3 plants and up
				// to 3 zombies): pick a random entry from LevelUtils.GetLandPlantList / GetLandZombieList,
				// spawn a floating UI effect (GameUtils.CreateEffectUI) that DOMoves toward the touniu,
				// heal/buff by a difficulty-scaled amount (500/5000/2000/1000 by manager +0x24 mode),
				// destroy the UI effect, and finally End(). Left as a stub: every WaitForSeconds
				// duration constant, the Talk say-key semantics, the difficulty manager singleton
				// (_DAT_182e507b0) and its mode field +0x24, the DOMove target offsets
				// (_DAT_182e70d90 members, _DAT_18252cb24), the reward-application virtual call
				// (vtable +0x1F8) and multiple _touniuBaseBody members cannot be confirmed from raw
				// offsets without guessing.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("符咒特效")]
		public EffectEntity magicEffect;

		[Tooltip("贴图")]
		public Sprite itemSprite;

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded). Caches TouniuManager.Instance.touniuBaseBody into _touniuBaseBody.
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		public override void OnEnd()
		{
			// TODO: reconstruct
			// RVA 0x4FC370. Restores the touniu hand sprite renderer (_touniuBaseBody field +0x140)
			// through an unrecovered indirect call. Left as a stub: the target renderer member and
			// the invoked method cannot be confirmed from the offsets.
		}

		protected override void Start()
		{
			// RVA 0x552E20. Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__5))]
		private IEnumerator Effect()
		{
			// RVA 0x552DB0. Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__5(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
