using System;
using System.Collections;
using System.Collections.Generic;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle113004 : TouniuHandleEntity
	{
		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			base.Start();
			StartCoroutine(Effect());
		}

		// 特效协程：当前无逻辑
		private IEnumerator Effect()
		{
			yield break;
		}
	}
}
