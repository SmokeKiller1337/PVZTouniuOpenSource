using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle113005 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__2 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle113005 _003C_003E4__this;

			private float _003Ctime_003E5__2;

			private float _003Ctimer_003E5__3;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__2(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x56DC90. Timed polling loop: while `timer < time` (time set to 10.0 when the
				// Level-Mini-13 data manager is alive) it advances `timer` by an unrecovered increment
				// constant (_DAT_18252cb64) and `yield return new WaitForSeconds(_DAT_18252cb64)`,
				// bailing out early when a boolean flag on LevelMini13DataManager.Instance (member +0x70)
				// becomes set, in which case it fires TouniuBehaviorUtils.Talk(0x1B975, 4, 1). It then
				// ends. Both the per-frame WaitForSeconds duration and the LevelMini13 +0x70 flag are
				// unrecovered/unidentified, so the body is left as a stub rather than fabricate those.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded). Caches TouniuManager.Instance.touniuBaseBody into _touniuBaseBody.
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// RVA 0x56A6C0. Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__2))]
		private IEnumerator Effect()
		{
			// RVA 0x56A650. Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__2(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
