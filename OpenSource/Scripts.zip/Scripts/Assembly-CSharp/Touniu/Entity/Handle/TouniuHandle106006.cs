using System;
using System.Collections;
using System.Collections.Generic;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle106006 : TouniuHandleEntity
	{
		[Tooltip("播报")]
		public List<AudioClip> soundList;

		public GameObject role1Prefab;

		public GameObject role2Prefab;

		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			yield break;
		}
	}
}
