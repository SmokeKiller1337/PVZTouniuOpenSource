using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle106006 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass5_0
		{
			public GameObject roleObj;

			internal void _003CEffect_003Eb__0()
			{
				// RVA 0x578520. Captured cleanup lambda: destroys the spawned role GameObject if it is still alive.
				if (roleObj != null)
				{
					UnityEngine.Object.Destroy(roleObj);
				}
			}
		}

		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__5 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle106006 _003C_003E4__this;

			private _003C_003Ec__DisplayClass5_0 _003C_003E8__1;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__5(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x574720. Mini6 role-intro sequence: instantiates role1Prefab/role2Prefab (Instantiate with a
				// parent transform taken from an unidentified singleton at _DAT_182e46360 -> +0xb8), captures the
				// spawn in the display class, plays voice lines from soundList and schedules the b__0 cleanup lambda,
				// interleaved with WaitForSeconds yields whose durations are unrecovered float constants
				// (_DAT_18252c* family). The spawn parent and yield constants cannot be resolved to confirmed
				// members, so a faithful reconstruction is not possible; left as a stub.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("播报")]
		public List<AudioClip> soundList;

		public GameObject role1Prefab;

		public GameObject role2Prefab;

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded). Caches TouniuManager.Instance.touniuBaseBody into _touniuBaseBody,
			// matching the base TouniuBehaviorEntity.Awake body.
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// RVA 0x568C10. Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__5))]
		private IEnumerator Effect()
		{
			// Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__5(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
