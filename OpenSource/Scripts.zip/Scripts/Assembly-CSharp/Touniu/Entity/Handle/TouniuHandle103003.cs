using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle103003 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__2 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle103003 _003C_003E4__this;

			private int _003Cnumber_003E5__2;

			private int _003Ci_003E5__3;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__2(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x56D060. Spawns `number` tombstone-zombies at random land-buildings: `number` starts
				// at 5 and is overridden by the current area difficulty (LevelAreaManager singleton
				// _DAT_182e507b0 -> +0x24 mode => 3/3/7/9). Each of `number` iterations pulls
				// LevelUtils.GetLandBuildingList(), filters it via a LINQ Where using the cached predicate
				// TouniuHandle103003.<>c.<Effect>b__2_0 (only tombstones whose zombie-count field +0x24 > 2),
				// picks a random survivor, yields _touniuBaseBody.handle.BadLine(target.transform.position),
				// then DOVirtual.DelayedCall(..., <>c__DisplayClass2_0.<Effect>b__1) to CreateZombie on it,
				// with WaitForSeconds gaps. End() when done. Left as a stub: the filtering/callback logic
				// lives in compiler-generated `<>c` / `<>c__DisplayClass2_0` display classes that are NOT
				// declared in the authoritative skeleton (which must not be modified), and the difficulty
				// singleton member and the WaitForSeconds constants (_DAT_18252cb64 / cb80) cannot be
				// confirmed from raw offsets.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded). Caches TouniuManager.Instance.touniuBaseBody into _touniuBaseBody.
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// RVA 0x568570. Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__2))]
		private IEnumerator Effect()
		{
			// RVA 0x568500. Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__2(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
