using System;
using System.Collections;
using System.Collections.Generic;
using Level.Manager.Data.Mini;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle102002 : TouniuHandleEntity
	{
		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// 调用基类 Start 后启动效果协程。
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// 切换偷牛的无效眩晕标记，然后结束处理。
			if (LevelMini2DataManager.Instance != null)
			{
				LevelMini2DataManager.Instance.SetTouniuInvalidStun(!_touniuBaseBody.IsInvalidStun);
			}
			End();
			yield break;
		}
	}
}
