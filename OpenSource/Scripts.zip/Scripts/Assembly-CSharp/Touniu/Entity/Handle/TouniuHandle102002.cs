using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Level.Manager.Data.Mini;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle102002 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__2 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle102002 _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__2(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// RVA 0x556C70. Toggles the touniu's invalid-stun flag on the Mini-2 data manager.
				int num = _003C_003E1__state;
				TouniuHandle102002 touniuHandle = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					if (LevelMini2DataManager.Instance != null)
					{
						LevelMini2DataManager.Instance.SetTouniuInvalidStun(!touniuHandle._touniuBaseBody.IsInvalidStun);
					}
					touniuHandle.End();
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded). Caches TouniuManager.Instance.touniuBaseBody into _touniuBaseBody.
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// RVA 0x552D30. Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__2))]
		private IEnumerator Effect()
		{
			// RVA 0x552CC0. Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__2(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
