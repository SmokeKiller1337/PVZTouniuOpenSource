using System;
using System.Collections;
using System.Collections.Generic;
using Level.Manager.Data.Mini;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle113001 : TouniuHandleEntity
	{
		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// 若小游戏13（昼夜）数据管理器存在，则切换为白天，然后结束该行为。
			if (LevelMini13DataManager.Instance != null)
			{
				LevelMini13DataManager.Instance.EnterDay();
			}
			End();
			yield break;
		}
	}
}
