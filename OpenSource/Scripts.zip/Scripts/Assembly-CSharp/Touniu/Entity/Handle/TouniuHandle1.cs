using System.Collections;
using Building.Entity;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle1 : TouniuHandleEntity
	{
		[Tooltip("水池预制体")]
		public GameObject waterPrefab;

		public Sprite item1;

		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// 发放额外卡片并结束当前行为
			Level.Util.LevelUtils.SetExtraCard(315);
			End();
			yield break;
		}

		private IEnumerator A(TombstoneEntity tombstone)
		{
			yield break;
		}

		private void SetToWaterType(int row)
		{
		}
	}
}
