using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Building.Entity;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle1 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CA_003Ed__5 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TombstoneEntity tombstone;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CA_003Ed__5(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x56BA60. Three-step sequence acting on `tombstone`: spawn an effect from a
				// manager singleton (an EffectEntity read at member +0x58, then +0x60 of an
				// unidentified manager singleton at static +0xB8/+0x38) via
				// GameUtils.CreateEffect(effect, tombstone.transform.position, <unrecovered rotation>),
				// each followed by a `yield return new WaitForSeconds(<unrecovered constant>)`
				// (_UNK_18252ce78 / _UNK_18252ce74), and finally tombstone.CreateZombie(). Left as a
				// stub: the manager-singleton identity, the two effect members, the rotation source
				// and both WaitForSeconds duration constants cannot be confirmed from offsets alone.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__4 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle1 _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__4(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// RVA 0x5736E0. Grants extra card 0x13B (315) then ends the behavior.
				int num = _003C_003E1__state;
				TouniuHandle1 touniuHandle = _003C_003E4__this;
				if (num == 0)
				{
					_003C_003E1__state = -1;
					Level.Util.LevelUtils.SetExtraCard(315);
					touniuHandle.End();
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("水池预制体")]
		public GameObject waterPrefab;

		public Sprite item1;

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded). Caches TouniuManager.Instance.touniuBaseBody into _touniuBaseBody.
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// RVA 0x56AC90. Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__4))]
		private IEnumerator Effect()
		{
			// RVA 0x56A8A0. Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__4(0)
			{
				_003C_003E4__this = this
			};
		}

		[IteratorStateMachine(typeof(_003CA_003Ed__5))]
		private IEnumerator A(TombstoneEntity tombstone)
		{
			// RVA 0x56A830. Compiler-generated factory that instantiates the A state machine.
			return new _003CA_003Ed__5(0)
			{
				tombstone = tombstone
			};
		}

		private void SetToWaterType(int row)
		{
			// TODO: reconstruct
			// RVA 0x56A910. Looks up `row` in a manager singleton's soil/lane dictionary
			// (Dictionary<int, ...> reached through static +0xB8 -> +0x28 -> +0x20), marks the
			// entry's field +0x24 = 1, then iterates a List at entry +0x28 setting each item's
			// field +0x28 = 1 and spawning GameUtils.CreateEffect(effect, item.transform.position, ...)
			// from a renderer at item +0x30. Left as a stub: the manager-singleton identity, the
			// dictionary element type and its fields, and the effect member cannot be confirmed from
			// raw offsets without guessing.
		}
	}
}
