using System;
using System.Collections;
using System.Collections.Generic;
using Level.Manager.Data.Mini;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle112002 : TouniuHandleEntity
	{
		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// 初始化第二个花盆槽位，然后结束当前行为
			if (LevelMini12DataManager.Instance != null)
			{
				LevelMini12DataManager.Instance.InitPot(1);
			}
			End();
			yield break;
		}
	}
}
