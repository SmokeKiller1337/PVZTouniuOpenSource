using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle106004 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__3 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle106004 _003C_003E4__this;

			private int _003Ci_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__3(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x570AC0. Mini6 day-end dialogue: reads LevelMini6DataManager.Instance.GetDayResult() and
				// branches to a different _touniuBaseBody.Talk(id, index) line per result, each awaited via
				// WaitForCompletion. Reconstruction is blocked because the sequence first pauses time through
				// LevelAssetsManager.set_IsPauseTime on an unidentified manager singleton (_DAT_182e2bc20 -> +0xb8)
				// accessed by raw offset, which cannot be resolved to a confirmed member; left as a stub rather than
				// fabricate that singleton access.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded). Caches TouniuManager.Instance.touniuBaseBody into _touniuBaseBody,
			// matching the base TouniuBehaviorEntity.Awake body.
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		public override void OnEnd()
		{
			// TODO: reconstruct
			// RVA 0x568960. Reads an unidentified manager singleton (_DAT_182e2bc20 -> +0xb8) and, when
			// Level.Static.AreaStatic.IsRandomMode() is false, clears a bool member at +0x28 on that object. The
			// singleton and its +0x28 member cannot be resolved to confirmed members from the offsets alone, so the
			// body is left as a stub rather than fabricate the access.
		}

		protected override void Start()
		{
			// RVA 0x5689C0. Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__3))]
		private IEnumerator Effect()
		{
			// Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__3(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
