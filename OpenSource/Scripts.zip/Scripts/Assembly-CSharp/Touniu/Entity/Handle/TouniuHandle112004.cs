using System;
using System.Collections;
using System.Collections.Generic;
using Level.Manager.Data.Mini;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle112004 : TouniuHandleEntity
	{
		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// 若关卡花盆数据管理器存在，则初始化第 3 个花盆，随后结束行为
			if (LevelMini12DataManager.Instance != null)
			{
				LevelMini12DataManager.Instance.InitPot(3);
			}
			End();
			yield break;
		}
	}
}
