using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle108004 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__5 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle108004 _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__5(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x5768A0. Three-state Mini8 hint: gates on LevelMini8DataManager.Instance and a difficulty
				// value from an unidentified singleton (_DAT_182e507b0 -> +0xb8 -> +0x24), speaks a narrator
				// line (_touniuBaseBody.Talk(0x1a5e6, 4)) awaited via WaitForCompletion, then instantiates
				// textPrefab into _textObj at a spawn transform read from another unidentified singleton
				// (_DAT_182e46360 -> +0xb8) and yields a WaitForSeconds on an unrecovered float constant
				// (_DAT_18252cb94) before ending. The two singleton accesses and the yield constant cannot be
				// resolved to confirmed members, so the body is left as a stub.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("提示预制体")]
		public GameObject textPrefab;

		private GameObject _textObj;

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded). Caches TouniuManager.Instance.touniuBaseBody into _touniuBaseBody,
			// matching the base TouniuBehaviorEntity.Awake body.
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		public override void OnEnd()
		{
			// RVA 0x569550. Destroys the spawned hint object if it is still alive.
			if (_textObj != null)
			{
				UnityEngine.Object.Destroy(_textObj);
			}
		}

		protected override void Start()
		{
			// RVA 0x5695E0. Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__5))]
		private IEnumerator Effect()
		{
			// Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__5(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
