using System;
using System.Collections;
using System.Collections.Generic;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle108004 : TouniuHandleEntity
	{
		[Tooltip("提示预制体")]
		public GameObject textPrefab;

		private GameObject _textObj;

		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		public override void OnEnd()
		{
			// 若提示对象还存在则销毁
			if (_textObj != null)
			{
				UnityEngine.Object.Destroy(_textObj);
			}
		}

		protected override void Start()
		{
			// 调用基类初始化并启动特效协程
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// 当前无特效逻辑，协程直接结束
			yield break;
		}
	}
}
