using System.Collections;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle110002 : TouniuHandleEntity
	{
		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// 该处理器无额外特效逻辑，协程直接结束。
			yield break;
		}
	}
}
