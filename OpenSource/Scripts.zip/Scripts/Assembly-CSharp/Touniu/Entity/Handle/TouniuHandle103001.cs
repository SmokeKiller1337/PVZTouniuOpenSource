using System;
using System.Collections;
using System.Collections.Generic;
using Level.Static;
using Level.Util;
using Plant.Entity;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle103001 : TouniuHandleEntity
	{
		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// 调用基类 Start 后启动 Effect 协程。
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// 非随机模式下，把豌豆射手（卡片 120）和向日葵（卡片 30）的冷却清零并将阳光消耗刷为 0，然后结束行为。
			if (!AreaStatic.IsRandomMode())
			{
				CardEntity card = LevelUtils.GetCard(120);
				CardEntity card2 = LevelUtils.GetCard(30);
				if (card != null)
				{
					card.attr.cooldownTime = 0f;
					card.attr.cooldownTimer = 0f;
					card.attr.isCooldown = false;
					card.SetSunAndShow(0);
				}
				if (card2 != null)
				{
					card2.attr.cooldownTime = 0f;
					card2.attr.cooldownTimer = 0f;
					card2.attr.isCooldown = false;
					card2.SetSunAndShow(0);
				}
			}
			End();
			yield break;
		}
	}
}
