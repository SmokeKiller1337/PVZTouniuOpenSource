using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Level.Static;
using Level.Util;
using Plant.Entity;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle103001 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__2 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle103001 _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__2(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// RVA 0x56C6D0. Outside random mode, zeroes the cooldown on the peashooter (card id 120)
				// and sunflower (card id 30) cards and refreshes their sun cost to 0, then ends the behavior.
				TouniuHandle103001 touniuHandle = _003C_003E4__this;
				if (_003C_003E1__state != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (!AreaStatic.IsRandomMode())
				{
					CardEntity card = LevelUtils.GetCard(120);
					CardEntity card2 = LevelUtils.GetCard(30);
					if (card != null)
					{
						card.attr.cooldownTime = 0f;
						card.attr.cooldownTimer = 0f;
						card.attr.isCooldown = false;
						card.SetSunAndShow(0);
					}
					if (card2 != null)
					{
						card2.attr.cooldownTime = 0f;
						card2.attr.cooldownTimer = 0f;
						card2.attr.isCooldown = false;
						card2.SetSunAndShow(0);
					}
				}
				touniuHandle.End();
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded). Caches TouniuManager.Instance.touniuBaseBody into _touniuBaseBody.
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// RVA 0x5681F0. Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__2))]
		private IEnumerator Effect()
		{
			// RVA 0x568180. Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__2(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
