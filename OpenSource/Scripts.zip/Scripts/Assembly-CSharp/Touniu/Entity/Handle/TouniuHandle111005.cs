using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle111005 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__2 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle111005 _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__2(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x56E240. When LevelMini11DataManager.Instance is alive it calls
				// _touniuBaseBody.ChangeTouniu(6), _touniuBaseBody.Move(...), yields a WaitForSeconds, then
				// yields _touniuBaseBody.Handle(0x1B199).WaitForCompletion() before ending. The Move offset
				// arguments and the WaitForSeconds duration are unrecovered float constants
				// (_DAT_18252cb70 / _DAT_18252cb64 / _DAT_18252cb28), so a faithful reconstruction is not
				// possible without inventing them; the body is left as a stub.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded). Caches TouniuManager.Instance.touniuBaseBody into _touniuBaseBody.
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// RVA 0x569C70. Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__2))]
		private IEnumerator Effect()
		{
			// RVA 0x569C00. Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__2(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
