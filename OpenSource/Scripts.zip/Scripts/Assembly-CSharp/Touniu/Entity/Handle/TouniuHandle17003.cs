using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Level.Manager.Data.Area;
using Touniu.Enum;
using Touniu.Manager;
using Touniu.Util;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle17003 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__2 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle17003 _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__2(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// RVA 0x502530. Single-state, no yields: if the Level-17 data manager exists and the
				// player borrowed sun at the start of the level, the touniu says its fixed line, then the
				// behavior ends.
				TouniuHandle17003 touniuHandle = _003C_003E4__this;
				if (_003C_003E1__state == 0)
				{
					_003C_003E1__state = -1;
					if (Level17DataManager.Instance != null && Level17DataManager.Instance.isStartSun)
					{
						TouniuBehaviorUtils.Talk(0x4273, SayType.Fixed, 1);
					}
					touniuHandle.End();
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded onto the shared Handle.Awake body). Caches the shared touniu body
			// from the TouniuManager singleton into the base-class _touniuBaseBody field
			// (TouniuManager.Instance.touniuBaseBody).
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// RVA 0x4FCDD0. Chains to the base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__2))]
		private IEnumerator Effect()
		{
			// RVA 0x4FCD60. Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__2(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
