using System;
using System.Collections;
using System.Collections.Generic;
using Level.Manager.Data.Area;
using Touniu.Enum;
using Touniu.Manager;
using Touniu.Util;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle17003 : TouniuHandleEntity
	{
		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// 第 17 关且开局借用阳光时，投牛说固定台词，随后结束本次行为
			if (Level17DataManager.Instance != null && Level17DataManager.Instance.isStartSun)
			{
				TouniuBehaviorUtils.Talk(0x4273, SayType.Fixed, 1);
			}
			End();
			yield break;
		}
	}
}
