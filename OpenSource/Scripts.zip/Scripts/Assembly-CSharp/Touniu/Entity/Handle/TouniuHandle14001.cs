using System;
using System.Collections;
using System.Collections.Generic;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle14001 : TouniuHandleEntity
	{
		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			base.Start();
			StartCoroutine(Effect());
		}

		// 该处理器暂无特效表现，协程直接结束。
		private IEnumerator Effect()
		{
			yield break;
		}
	}
}
