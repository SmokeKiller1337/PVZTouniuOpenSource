using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle14001 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__2 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle14001 _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__2(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x501050. Multi-state auto-draw sequence gated on TWO unidentified manager
				// singletons: a level/state manager (static _DAT_182e2bc20 -> +0xB8 -> mode field +0x20
				// checked against 2, plus an object member +0x40 null-checked and a nested float at
				// +0x118 -> +0x14) and the difficulty selector (static _DAT_182e507b0 -> +0xB8 ->
				// member +0x24, values 1/3/4 scaling the loop wait). The confirmable pieces are
				// LevelUtils.GetCard(-1), _touniuBaseBody.handle.PlacePlant(card.id, -1, -1),
				// _touniuBaseBody.SetHandLongSprite / Move(TouniuUtils.GetRandomPosition(), ...),
				// WaitForSeconds and End(). The body is left as a stub: neither manager singleton can
				// be mapped from raw offsets, and the wait/threshold constants (_DAT_18252cb28,
				// _DAT_18252cb6c, _DAT_18252cb94/ccb8, _DAT_18252cb64, _DAT_18252ce84) are unrecovered,
				// so reconstructing it would require fabricating member accesses.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded). Caches TouniuManager.Instance.touniuBaseBody into _touniuBaseBody.
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// RVA 0x4FC190. Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__2))]
		private IEnumerator Effect()
		{
			// RVA 0x4FC120. Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__2(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
