using System;
using System.Collections;
using System.Collections.Generic;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle17002 : TouniuHandleEntity
	{
		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// Chains to the base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// 该处理器无额外特效逻辑
			yield break;
		}
	}
}
