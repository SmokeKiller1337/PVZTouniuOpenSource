using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle17002 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__2 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle17002 _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__2(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x501880. Level-17 sequence: reads the current board/wave-mode singleton
				// (native global _DAT_182e507b0.Instance, int member at +0x24) to compute a normalized
				// factor (0.3/0.5/0.4/0.2 depending on the mode value), takes LevelUtils.GetLandPlantList(-1, -1)
				// filtered by a cached Func predicate, then for each result spawns a hit/flash effect via
				// GameUtils.CreateEffectUI and animates it toward the touniu with DOTween DOMove, yielding a
				// single WaitForSeconds before End().
				// Left as a stub because it depends on several unresolved data-segment constants and native
				// singletons: the WaitForSeconds duration and the tween factor (_DAT_18252cb64 / _DAT_18252cb28),
				// the board/wave-mode singleton (_DAT_182e507b0), and two further effect/anchor singletons
				// (_DAT_182e65730 / _DAT_182e46360) read at raw offsets. None of these can be mapped to
				// confirmed members without guessing, so a faithful reconstruction is not possible.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded onto the shared Handle.Awake body). Caches the shared touniu body
			// from the TouniuManager singleton into the base-class _touniuBaseBody field
			// (TouniuManager.Instance.touniuBaseBody).
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// RVA 0x4FCCE0. Chains to the base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__2))]
		private IEnumerator Effect()
		{
			// RVA 0x4FCC70. Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__2(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
