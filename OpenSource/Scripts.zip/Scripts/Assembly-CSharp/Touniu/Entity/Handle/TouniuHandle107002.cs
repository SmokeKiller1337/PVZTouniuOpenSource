using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle107002 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CColorTarget_003Ed__5 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle107002 _003C_003E4__this;

			private int _003Ci_003E5__2;

			private List<SpriteRenderer>.Enumerator _003C_003E7__wrap2;

			private SpriteRenderer _003CspriteRenderer_003E5__4;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CColorTarget_003Ed__5(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x56BD80. Loops (up to 10 passes) over a List<SpriteRenderer> obtained from a level
				// sub-object and, for each renderer, tweens its material via DG.Tweening DOFloat and sets a
				// material colour (Material.SetColor) over unrecovered data-segment constants
				// (_DAT_18252c* / _DAT_18252d* families) with WaitForSeconds yields. The material property id,
				// tween/colour constants and the sub-object list source do not resolve to confirmed members, so
				// the body is left as a stub.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			private void _003C_003Em__Finally1()
			{
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__3 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle107002 _003C_003E4__this;

			private Coroutine _003Ccoroutine1_003E5__2;

			private Coroutine _003Ccoroutine2_003E5__3;

			private TouniuSayEntity _003CtouniuSayEntity_003E5__4;

			private float _003CwaitTime_003E5__5;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__3(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x56FA30. Thirteen-state Mini7 finale: gates on LevelMini7DataManager.EndCheckGood, plays
				// AudioManager.PlayOneShot(effectSound), starts the RotateTarget and ColorTarget sub-coroutines,
				// speaks several narrator lines (_touniuBaseBody.Talk / TouniuBehaviorUtils.Talk) awaited via
				// WaitForCompletion, drives a camera-control singleton (_DAT_182e73f40 -> +0xb8 -> +0xd0, virtual
				// slot +0x1c8) by raw offset, calls TouniuCommonHandle.UseMilk, stops the sub-coroutines and
				// resets child renderers (GetComponentsInChildren -> DOFloat/eulerAngles) — all interleaved with
				// WaitForSeconds on unrecovered float constants (_DAT_18252c* family). The camera-singleton
				// dispatch and the yield constants do not resolve to confirmed members, so the body is left as a
				// stub.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CRotateTarget_003Ed__4 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle107002 _003C_003E4__this;

			private float _003Ctimer_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CRotateTarget_003Ed__4(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x578040. Per-frame loop that rotates LevelMini7DataManager.Instance's target transform
				// (eulerAngles) using Time.deltaTime and Game.Util.GameUtils.Map over unrecovered data-segment
				// float constants (_DAT_18252c* family: the timer bound and the map input/output range), yielding
				// null each frame. The loop bound and the mapping constants do not resolve to confirmed members,
				// so the body is left as a stub.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("旋转音效")]
		public AudioClip effectSound;

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded). Caches TouniuManager.Instance.touniuBaseBody into _touniuBaseBody,
			// matching the base TouniuBehaviorEntity.Awake body.
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// RVA 0x5690B0. Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__3))]
		private IEnumerator Effect()
		{
			// Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__3(0)
			{
				_003C_003E4__this = this
			};
		}

		[IteratorStateMachine(typeof(_003CRotateTarget_003Ed__4))]
		private IEnumerator RotateTarget()
		{
			// Compiler-generated factory that instantiates the RotateTarget state machine.
			return new _003CRotateTarget_003Ed__4(0)
			{
				_003C_003E4__this = this
			};
		}

		[IteratorStateMachine(typeof(_003CColorTarget_003Ed__5))]
		private IEnumerator ColorTarget()
		{
			// Compiler-generated factory that instantiates the ColorTarget state machine.
			return new _003CColorTarget_003Ed__5(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
