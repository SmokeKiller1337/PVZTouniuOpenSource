using System;
using System.Collections;
using System.Collections.Generic;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle107002 : TouniuHandleEntity
	{
		[Tooltip("旋转音效")]
		public AudioClip effectSound;

		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			yield break;
		}

		private IEnumerator RotateTarget()
		{
			yield break;
		}

		private IEnumerator ColorTarget()
		{
			yield break;
		}
	}
}
