using System.Collections;
using System.Collections.Generic;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle106003 : TouniuHandleEntity
	{
		[Tooltip("播报")]
		public List<AudioClip> soundList;

		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// 该处理器不产生额外的特效流程
			yield break;
		}
	}
}
