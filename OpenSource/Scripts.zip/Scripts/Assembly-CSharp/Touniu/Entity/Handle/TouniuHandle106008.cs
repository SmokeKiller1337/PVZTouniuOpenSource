using System;
using System.Collections;
using System.Collections.Generic;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle106008 : TouniuHandleEntity
	{
		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// 先执行基类初始化，再启动特效协程。
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// 该处理器无特效逻辑，协程直接结束。
			yield break;
		}
	}
}
