using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Touniu.Manager;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle106008 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__2 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle106008 _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__2(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x56C5B0. Single-shot Mini6 end check: when LevelMini6DataManager.Instance is alive and a
				// lawn-mower still survives (Level.Util.LevelUtils.GetLawnMowerList), it triggers a narrator Talk
				// line, then ends. The Talk id and the survival gate are computed from an unidentified manager
				// singleton (_DAT_182e507b0 -> +0xb8 -> +0x24) and a LevelMini6DataManager sub-object read by raw
				// offset (+0x80 -> +0x18/+0x48), none of which resolve to confirmed members, so a faithful
				// reconstruction is not possible without guessing; left as a stub.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded). Caches TouniuManager.Instance.touniuBaseBody into _touniuBaseBody,
			// matching the base TouniuBehaviorEntity.Awake body.
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// RVA 0x568DF0. Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__2))]
		private IEnumerator Effect()
		{
			// Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__2(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
