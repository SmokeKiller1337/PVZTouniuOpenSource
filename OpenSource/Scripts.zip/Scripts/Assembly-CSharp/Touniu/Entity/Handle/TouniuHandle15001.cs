using System;
using System.Collections;
using System.Collections.Generic;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle15001 : TouniuHandleEntity
	{
		public GameObject winCheckPrefab;

		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		public override void OnEnd()
		{
		}

		protected override void Start()
		{
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			// 当前无特效逻辑
			yield break;
		}
	}
}
