using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle15001 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__4 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle15001 _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__4(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x507B80. Single-shot effect: Instantiate(winCheckPrefab) at a spawn position
				// pulled from an unidentified manager singleton (static _DAT_182e46360 -> +0xB8, first
				// two 8-byte members read as the position) with an unrecovered rotation constant
				// (_UNK_18252cec8) and an unidentified parent Transform, then FindObjectOfType<T>() for
				// an unidentified component type, disable it (Behaviour.enabled = false) if found, and
				// End(). The body is left as a stub: the spawn-position manager singleton, the
				// FindObjectOfType target type and the rotation constant cannot be mapped from raw
				// offsets/tokens without guessing. (winCheckPrefab at field +0x60 is confirmed.)
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		public GameObject winCheckPrefab;

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded). Caches TouniuManager.Instance.touniuBaseBody into _touniuBaseBody.
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		public override void OnEnd()
		{
			// Confirmed empty: RVA 0x386160 is a shared empty-method thunk.
		}

		protected override void Start()
		{
			// RVA 0x4FC280. Chains to base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__4))]
		private IEnumerator Effect()
		{
			// RVA 0x4FC210. Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__4(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
