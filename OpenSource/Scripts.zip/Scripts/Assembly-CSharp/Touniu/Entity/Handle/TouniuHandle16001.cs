using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle16001 : TouniuHandleEntity
	{
		[CompilerGenerated]
		private sealed class _003CEffect_003Ed__3 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuHandle16001 _003C_003E4__this;

			private int _003Cnumber_003E5__2;

			private int _003Ci_003E5__3;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEffect_003Ed__3(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// RVA 0x504DF0. Level-16 "eat plants" sequence: it reads the current board/wave-mode
				// singleton (native global _DAT_182e507b0.Instance, int member at +0x24) to choose how many
				// plants to eat (number = 1 / 2 / 3 depending on the mode value), then loops i from 0 while
				// i < number calling _touniuBaseBody.handle.EatPlant() (TouniuCommonHandle.EatPlant) and
				// yielding on its coroutine, finally End().
				// Left as a stub because the board/wave-mode singleton (_DAT_182e507b0) is an unresolved
				// native global that could not be mapped to a confirmed member in the exported assembly, and
				// it is exactly what drives the loop count, so a faithful reconstruction is not possible.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		public AudioClip meatSound;

		protected override void Awake()
		{
			// RVA 0x4FC110 (ICF-folded onto the shared Handle.Awake body). Caches the shared touniu body
			// from the TouniuManager singleton into the base-class _touniuBaseBody field
			// (TouniuManager.Instance.touniuBaseBody).
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// RVA 0x4FC7C0. Chains to the base Start, then launches the Effect coroutine.
			base.Start();
			StartCoroutine(Effect());
		}

		[IteratorStateMachine(typeof(_003CEffect_003Ed__3))]
		private IEnumerator Effect()
		{
			// RVA 0x4FC750. Compiler-generated factory that instantiates the Effect state machine.
			return new _003CEffect_003Ed__3(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
