using System;
using System.Collections;
using System.Collections.Generic;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Handle
{
	public class TouniuHandle16001 : TouniuHandleEntity
	{
		public AudioClip meatSound;

		protected override void Awake()
		{
			_touniuBaseBody = TouniuManager.Instance.touniuBaseBody;
		}

		protected override void Start()
		{
			// 先执行基类初始化，再启动特效协程
			base.Start();
			StartCoroutine(Effect());
		}

		private IEnumerator Effect()
		{
			yield break;
		}
	}
}
