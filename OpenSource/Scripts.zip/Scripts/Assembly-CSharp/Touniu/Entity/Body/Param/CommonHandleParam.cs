using System.Collections.Generic;
using Game.Util;
using Land.Entity;
using Level.Manager;
using Level.Util;
using Plant.Enum;

namespace Touniu.Entity.Body.Param
{
	public class CommonHandleParam
	{
		public int row;

		public int column;

		public int startRow;

		public int endRow;

		public int startColumn;

		public int endColumn;

		public PlaceType placeType;

		public float speedRatio;

		public CommonHandleParam()
		{
			// 伪代码: +0x10/+0x18/+0x20 各写入 0xffffffffffffffff（两个 int -1），
			// +0x2c 写入 0x3f800000 (=1.0f)。即所有行列范围字段默认 -1，速度倍率默认 1。
			row = -1;
			column = -1;
			startRow = -1;
			endRow = -1;
			startColumn = -1;
			endColumn = -1;
			speedRatio = 1f;
		}

		public virtual LandEntity GetLand()
		{
			// 伪代码: 调用本类虚方法 GetLandList()（vtable +0x188），
			// 若返回列表非空且 Count >= 1 则返回第 0 个元素，否则返回 null。
			List<LandEntity> landList = GetLandList();
			if (landList == null || landList.Count < 1)
			{
				return null;
			}
			return landList[0];
		}

		public virtual List<LandEntity> GetLandList()
		{
			// 结果列表
			List<LandEntity> result = new List<LandEntity>();

			// 取全部地皮（row=-1, column=-1 表示不过滤）
			List<LandEntity> allLands = LevelUtils.GetLandList(-1, -1);
			if (allLands == null || allLands.Count == 0)
			{
				return result;
			}

			// 网格最大行/列来自地皮管理器单例。
			// 伪代码通过全局管理器单例 (->0xb8 的 Instance) 的子对象读取 +0x30/+0x34，
			// 语义即网格的最大行数/最大列数，对应 LandManager 的公开字段 rowNumber/columnNumber。
			LandManager landManager = LandManager.Instance;
			if (landManager == null)
			{
				return result;
			}
			int maxRow = landManager.rowNumber;
			int maxColumn = landManager.columnNumber;

			// 计算行范围 [rowStart, rowEnd]
			int rowStart;
			int rowEnd;
			if (row == -1)
			{
				rowStart = (startRow == -1) ? 1 : startRow;
				rowEnd = (endRow == -1) ? maxRow : endRow;
			}
			else
			{
				rowStart = row;
				rowEnd = row;
			}

			// 计算列范围 [colStart, colEnd]
			int colStart;
			int colEnd;
			if (column == -1)
			{
				colStart = (startColumn == -1) ? 1 : startColumn;
				colEnd = (endColumn == -1) ? maxColumn : endColumn;
			}
			else
			{
				colStart = column;
				colEnd = column;
			}

			// 逐个夹取到 [1, max]（伪代码: if (v<1) v=1; else if (max<v) v=max;）
			if (rowStart < 1) { rowStart = 1; } else if (maxRow < rowStart) { rowStart = maxRow; }
			if (rowEnd < 1) { rowEnd = 1; } else if (maxRow < rowEnd) { rowEnd = maxRow; }
			if (colStart < 1) { colStart = 1; } else if (maxColumn < colStart) { colStart = maxColumn; }
			if (colEnd < 1) { colEnd = 1; } else if (maxColumn < colEnd) { colEnd = maxColumn; }

			// 遍历全部地皮，收集落在行列范围内的地皮
			foreach (LandEntity land in allLands)
			{
				if (land == null)
				{
					continue;
				}
				if (land.rowId >= rowStart && land.rowId <= rowEnd &&
					land.columnId >= colStart && land.columnId <= colEnd)
				{
					result.Add(land);
				}
			}

			// 特殊分支: column == 0 或 (startColumn == 0 且 endColumn == 0)。
			// 此时清空上面收集的结果，改为每一行取列 0 的地皮（GetLand(row, 0)），非空则加入。
			if (column == 0 || (startColumn == 0 && endColumn == 0))
			{
				result.Clear();
				for (int r = rowStart; r <= rowEnd; r++)
				{
					LandEntity land = LevelUtils.GetLand(r, 0);
					if (land != null)
					{
						result.Add(land);
					}
				}
			}

			// 打乱后返回
			GameUtils.ShuffleList(result);
			return result;
		}
	}
}
