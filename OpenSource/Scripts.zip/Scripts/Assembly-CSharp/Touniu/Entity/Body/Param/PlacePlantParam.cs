using System;
using System.Collections.Generic;
using System.Linq;
using Land.Entity;
using Level.Static;
using Level.Util;
using Plant.Entity;

namespace Touniu.Entity.Body.Param
{
	public class PlacePlantParam : CommonHandleParam
	{
		// .ctor (RVA 0x57DA10): cardId @0x30 = -1, isPickUpCardSlot @0x34 = true.
		// (Offsets 0x2c/0x10/0x18/0x20 belong to the CommonHandleParam base and are
		// initialised by the base constructor, so they are not touched here.)
		public int cardId = -1;

		public bool isPickUpCardSlot = true;

		public ExistBodyEnum existBodyEnum;

		public Action<PlantEntity> OnPlaceAction;

		// RVA: 0x57D7E0 — override GetLand.
		// Fetch all candidate lands from the base virtual GetLandList(), resolve this
		// param's card (falling back to the static card dictionary when the live lookup
		// misses), keep only lands the card may be placed on, and return the first one.
		public override LandEntity GetLand()
		{
			List<LandEntity> landList = GetLandList();
			if (landList == null || landList.Count < 1)
			{
				return null;
			}

			CardEntity card = LevelUtils.GetCard(cardId);
			if (card == null)
			{
				// Fallback: look the card up in the shared static card dictionary.
				card = LevelStatic.cardDic[cardId];
			}
			if (card == null)
			{
				return null;
			}

			List<LandEntity> placeableList = landList.Where(land => card.IsPlaceable(land)).ToList();
			if (placeableList.Count == 0)
			{
				return null;
			}
			return placeableList[0];
		}

		// RVA: 0x57D640 — filter the supplied land list down to the lands on which this
		// param's card may be placed. Same card-resolution flow as GetLand().
		private List<LandEntity> GetEmptyLandList(List<LandEntity> landList)
		{
			CardEntity card = LevelUtils.GetCard(cardId);
			if (card == null)
			{
				// Fallback: look the card up in the shared static card dictionary.
				card = LevelStatic.cardDic[cardId];
			}
			if (card == null)
			{
				return null;
			}

			return landList.Where(land => card.IsPlaceable(land)).ToList();
		}
	}
}
