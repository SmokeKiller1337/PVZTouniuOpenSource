using System;
using System.Collections.Generic;
using System.Linq;
using Land.Entity;
using Level.Static;
using Level.Util;
using Plant.Entity;

namespace Touniu.Entity.Body.Param
{
	public class PlacePlantParam : CommonHandleParam
	{
		public int cardId = -1;

		public bool isPickUpCardSlot = true;

		public ExistBodyEnum existBodyEnum;

		public Action<PlantEntity> OnPlaceAction;

		// override GetLand.
		// Fetch all candidate lands from the base virtual GetLandList(), resolve this
		// param's card (falling back to the static card dictionary when the live lookup
		// misses), keep only lands the card may be placed on, and return the first one.
		public override LandEntity GetLand()
		{
			List<LandEntity> landList = GetLandList();
			if (landList == null || landList.Count < 1)
			{
				return null;
			}

			CardEntity card = LevelUtils.GetCard(cardId);
			if (card == null)
			{
				// Fallback: look the card up in the shared static card dictionary.
				card = LevelStatic.cardDic[cardId];
			}
			if (card == null)
			{
				return null;
			}

			List<LandEntity> placeableList = landList.Where(land => card.IsPlaceable(land)).ToList();
			if (placeableList.Count == 0)
			{
				return null;
			}
			return placeableList[0];
		}

		// filter the supplied land list down to the lands on which this
		// param's card may be placed. Same card-resolution flow as GetLand().
		private List<LandEntity> GetEmptyLandList(List<LandEntity> landList)
		{
			CardEntity card = LevelUtils.GetCard(cardId);
			if (card == null)
			{
				// Fallback: look the card up in the shared static card dictionary.
				card = LevelStatic.cardDic[cardId];
			}
			if (card == null)
			{
				return null;
			}

			return landList.Where(land => card.IsPlaceable(land)).ToList();
		}
	}
}
