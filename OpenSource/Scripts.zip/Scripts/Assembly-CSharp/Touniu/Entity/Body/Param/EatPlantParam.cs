using System;
using System.Collections.Generic;
using System.Linq;
using Land.Entity;
using Plant.Entity;
using Plant.Enum;

namespace Touniu.Entity.Body.Param
{
	public class EatPlantParam : CommonHandleParam
	{
		public bool isPenetrateShell;

		public bool isShovelHypnosisPlant;

		public bool isFirstHypnosisPlant;

		public Action OnEatHypnosisPlantAction;

		public override LandEntity GetLand()
		{
			return null;
		}

		public override List<LandEntity> GetLandList()
		{
			return base.GetLandList().Where(delegate(LandEntity landEntity)
			{
				if (placeType != PlaceType.Master)
				{
					return false;
				}
				if (landEntity.masterPlant == null)
				{
					return false;
				}
				return landEntity.masterPlant.GetHeadNumber() > 0;
			}).ToList();
		}

		public PlantEntity GetPlant(LandEntity landEntity = null)
		{
			// landEntity 为空则取 this.GetLand()；仍为空返回 null。
			if (landEntity == null)
			{
				landEntity = GetLand();
			}
			if (landEntity == null)
			{
				return null;
			}

			// 依据 placeType(0x28) 选层。
			// 字段偏移(据 LandEntity 声明序): master=0x30, shell=0x38, base=0x40, float=0x48。
			PlantEntity plant = null;
			switch (placeType)
			{
				case PlaceType.All:
					if (landEntity.floatPlant != null)
					{
						plant = landEntity.floatPlant;
					}
					if (landEntity.masterPlant != null)
					{
						plant = landEntity.masterPlant;
					}
					if (landEntity.shellPlant != null)
					{
						plant = landEntity.shellPlant;
					}
					if (landEntity.basePlant != null)
					{
						plant = landEntity.basePlant;
					}
					break;
				case PlaceType.Master:
					plant = landEntity.masterPlant;
					break;
				case PlaceType.Shell:
					plant = landEntity.shellPlant;
					break;
				case PlaceType.Base:
					plant = landEntity.basePlant;
					break;
				case PlaceType.Float:
					plant = landEntity.floatPlant;
					break;
			}

			if (plant == null)
			{
				return null;
			}

			// 未开启“穿壳”(isPenetrateShell, 0x30==false) 时，若选中植物本身是壳块(IsShellBlock)，
			// 则改为返回其所在地皮的外壳植物(shellPlant)。
			// 该分支模式与 PlantEntity.ChangeMaxHealthAndShow (PlantEntity.cs:1178) 完全一致：
			//   IsShellBlock() && CurrentLandEntity != null && CurrentLandEntity.shellPlant != null
			if (!isPenetrateShell)
			{
				if (plant.IsShellBlock())
				{
					LandEntity land = plant.CurrentLandEntity;
					if (land != null && land.shellPlant != null)
					{
						plant = land.shellPlant;
					}
				}
			}

			return plant;
		}
	}
}
