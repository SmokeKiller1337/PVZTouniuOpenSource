using System;
using System.Collections.Generic;
using System.Linq;
using Land.Entity;
using Plant.Entity;
using Plant.Enum;

namespace Touniu.Entity.Body.Param
{
	public class EatPlantParam : CommonHandleParam
	{
		public bool isPenetrateShell;

		public bool isShovelHypnosisPlant;

		public bool isFirstHypnosisPlant;

		public Action OnEatHypnosisPlantAction;

		public override LandEntity GetLand()
		{
			// TODO: reconstruct
			// 伪代码: GetLandList().Where(<GetLand>b__4_0).ToList()，若非空且 isFirstHypnosisPlant(0x32)
			// 为真则用比较器 <GetLand>b__4_1 排序，最后返回 list[0]；否则 null。
			// 无法可靠还原原因：
			//  1) 排序比较器 <GetLand>b__4_1 里对 masterPlant 做 `is <某类型>` 判定，该类型
			//     (全局符号 182e40ba0) 在导出工程中无法匹配到确切的类，臆造类型会产出错误逻辑。
			//  2) 过滤谓词 <GetLand>b__4_0 末尾比较植物 +0x10 处的引用是否非空，而 PlantEntity+0x10
			//     实为 int id（值类型），偏移解读因 IL2CPP ICF/布局折叠而不可靠。
			// 按“宁可留桩”原则整体退桩，避免产出错误的过滤/排序行为。
			return null;
		}

		public override List<LandEntity> GetLandList()
		{
			// base.GetLandList() 结果做 Where 过滤后 ToList。
			// 谓词 <GetLandList>b__5_0:
			//   this.placeType == Master(0) && landEntity.masterPlant != null
			//   && landEntity.masterPlant.<vtable +0x548>() > 0
			// +0x548 为 PlantEntity 上返回 int 的虚方法；已核实相邻槽 (+0x558) 确为 IsShellBlock，
			// 结合本类语义(EatPlant=吃有“头”的植物)判定该 int 方法为 GetHeadNumber()（公开 virtual int，
			// 见 PlantEntity.cs:1410）。GetHeadNumber 为真实成员，此处仅存在“同类相邻虚槽”识别风险。
			return base.GetLandList().Where(delegate(LandEntity landEntity)
			{
				if (placeType != PlaceType.Master)
				{
					return false;
				}
				if (landEntity.masterPlant == null)
				{
					return false;
				}
				return landEntity.masterPlant.GetHeadNumber() > 0; // TODO: verify vtable +0x548 == GetHeadNumber
			}).ToList();
		}

		public PlantEntity GetPlant(LandEntity landEntity = null)
		{
			// landEntity 为空则取 this.GetLand()；仍为空返回 null。
			if (landEntity == null)
			{
				landEntity = GetLand();
			}
			if (landEntity == null)
			{
				return null;
			}

			// 依据 placeType(0x28) 选层。
			// 字段偏移(据 LandEntity 声明序): master=0x30, shell=0x38, base=0x40, float=0x48。
			PlantEntity plant = null;
			switch (placeType)
			{
				case PlaceType.All:
					// 伪代码检查顺序 0x48,0x30,0x38,0x40，非空覆盖赋值 => 优先级 float<master<shell<base，
					// 即按此顺序最后一个非空者胜出（base 优先级最高）。
					if (landEntity.floatPlant != null)
					{
						plant = landEntity.floatPlant;
					}
					if (landEntity.masterPlant != null)
					{
						plant = landEntity.masterPlant;
					}
					if (landEntity.shellPlant != null)
					{
						plant = landEntity.shellPlant;
					}
					if (landEntity.basePlant != null)
					{
						plant = landEntity.basePlant;
					}
					break;
				case PlaceType.Master:
					plant = landEntity.masterPlant;
					break;
				case PlaceType.Shell:
					plant = landEntity.shellPlant;
					break;
				case PlaceType.Base:
					plant = landEntity.basePlant;
					break;
				case PlaceType.Float:
					plant = landEntity.floatPlant;
					break;
			}

			if (plant == null)
			{
				return null;
			}

			// 未开启“穿壳”(isPenetrateShell, 0x30==false) 时，若选中植物本身是壳块(IsShellBlock)，
			// 则改为返回其所在地皮的外壳植物(shellPlant)。
			// 该分支模式与 PlantEntity.ChangeMaxHealthAndShow (PlantEntity.cs:1178) 完全一致：
			//   IsShellBlock() && CurrentLandEntity != null && CurrentLandEntity.shellPlant != null
			if (!isPenetrateShell)
			{
				if (plant.IsShellBlock())
				{
					LandEntity land = plant.CurrentLandEntity;
					if (land != null && land.shellPlant != null)
					{
						plant = land.shellPlant;
					}
				}
			}

			return plant;
		}
	}
}
