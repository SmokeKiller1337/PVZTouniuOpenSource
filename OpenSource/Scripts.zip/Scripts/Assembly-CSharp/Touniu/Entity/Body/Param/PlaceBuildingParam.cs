using System;
using System.Collections.Generic;
using System.Linq;
using Building.Entity;
using Land.Entity;
using UnityEngine;

namespace Touniu.Entity.Body.Param
{
	public class PlaceBuildingParam : CommonHandleParam
	{
		public int buildingId;

		public bool isPickUpCardSlot;

		public Sprite buildingSprite;

		public ExistBodyEnum existBodyEnum;

		public Action<BuildingEntity> OnPlaceAction;

		private const string BuildingSpritePathFormat = "Sprites/Building/{0}";

		public PlaceBuildingParam()
		{
			row = -1;
			column = -1;
			startRow = -1;
			endRow = -1;
			startColumn = -1;
			endColumn = -1;
			speedRatio = 1f;
			buildingId = -1;
		}

		public Sprite BuildingSprite
		{
			get
			{
				if (buildingSprite != null)
				{
					return buildingSprite;
				}
				return Resources.Load<Sprite>(string.Format(BuildingSpritePathFormat, buildingId));
			}
			set
			{
				buildingSprite = value;
			}
		}

		public override LandEntity GetLand()
		{
			List<LandEntity> landList = GetLandList();
			if (landList == null || landList.Count < 1)
			{
				return null;
			}
			List<LandEntity> emptyList = landList.Where(land => land.masterBuilding == null).ToList();
			if (emptyList.Count > 0)
			{
				return emptyList[0];
			}
			return landList[0];
		}

		private List<LandEntity> GetEmptyLandList(List<LandEntity> landList)
		{
			return landList.Where(land => land.masterBuilding == null).ToList();
		}
	}
}
