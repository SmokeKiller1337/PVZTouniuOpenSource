using System;
using System.Collections.Generic;
using System.Linq;
using Building.Entity;
using Land.Entity;
using UnityEngine;

namespace Touniu.Entity.Body.Param
{
	public class PlaceBuildingParam : CommonHandleParam
	{
		public int buildingId;

		public bool isPickUpCardSlot;

		public Sprite buildingSprite;

		public ExistBodyEnum existBodyEnum;

		public Action<BuildingEntity> OnPlaceAction;

		// TODO: 原始 get_BuildingSprite 用一个全局格式字符串常量拼出 Resources 路径
		//       （_DAT_182e22c60 是 "{0}" 型格式串，_DAT_182e40b20 是 string.Format 的宿主）。
		//       该字面量无法从伪代码恢复，参照 PotEntity 的约定用占位常量，实际前缀需还原。
		private const string BuildingSpritePathFormat = "Sprites/Building/{0}";

		public PlaceBuildingParam()
		{
			// .ctor @0x57d540：把基类的行列范围字段全部初始化为 -1，速度倍率初始化为 1，
			// 本类 buildingId 初始化为 -1。
			// 偏移映射：0x10=row,0x14=column,0x18=startRow,0x1c=endRow,
			//           0x20=startColumn,0x24=endColumn,0x2c=speedRatio,0x30=buildingId
			row = -1;
			column = -1;
			startRow = -1;
			endRow = -1;
			startColumn = -1;
			endColumn = -1;
			speedRatio = 1f;
			buildingId = -1;
		}

		public Sprite BuildingSprite
		{
			get
			{
				// 伪代码 get_BuildingSprite @0x57d570：
				//   若已缓存的 buildingSprite (0x38) 非空(Unity null 判断)则直接返回；
				//   否则用 buildingId (0x30) 格式化出资源路径并 Resources.Load<Sprite>。
				if (buildingSprite != null)
				{
					return buildingSprite;
				}
				return Resources.Load<Sprite>(string.Format(BuildingSpritePathFormat, buildingId));
			}
			set
			{
				// 伪代码 set_BuildingSprite @0x4116e0：仅写入 0x38 字段。
				buildingSprite = value;
			}
		}

		public override LandEntity GetLand()
		{
			// 伪代码 GetLand @0x57d390：
			//   取候选地皮列表(基类虚方法 GetLandList，vtable +0x188)，为空或 Count<1 时返回 null；
			//   否则用与 GetEmptyLandList 相同的“无建筑”谓词过滤，取结果的第一块地。
			List<LandEntity> landList = GetLandList();
			if (landList == null || landList.Count < 1)
			{
				return null;
			}
			List<LandEntity> emptyList = landList.Where(land => land.masterBuilding == null).ToList();
			if (emptyList.Count > 0)
			{
				return emptyList[0];
			}
			// 过滤后为空时，伪代码回退到原始列表的第一块（此时 Count>=1 已由上面保证）。
			return landList[0];
		}

		private List<LandEntity> GetEmptyLandList(List<LandEntity> landList)
		{
			// 伪代码 GetEmptyLandList @0x57d260 与嵌套 lambda b__9_0：
			//   过滤出没有建筑(masterBuilding==null，Unity null 判断，LandEntity+0x50)的地皮。
			return landList.Where(land => land.masterBuilding == null).ToList();
		}
	}
}
