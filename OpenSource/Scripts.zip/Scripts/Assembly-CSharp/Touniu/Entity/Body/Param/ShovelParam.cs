using System.Collections.Generic;
using System.Linq;
using Land.Entity;
using Plant.Entity;
using Plant.Enum;
using UnityEngine;

namespace Touniu.Entity.Body.Param
{
	public class ShovelParam : CommonHandleParam
	{
		public bool isPenetrateShell;

		public bool isUsePlayerShovel;

		public bool isShovelExpensive;

		public Sprite shovelSprite;

		public ShovelParam()
		{
			row = -1;
			column = -1;
			startRow = -1;
			endRow = -1;
			startColumn = -1;
			endColumn = -1;
			speedRatio = 1f;
		}

		public Sprite ShovelSprite
		{
			get
			{
				if (shovelSprite != null)
				{
					return shovelSprite;
				}
				return shovelSprite;
			}
			set
			{
				shovelSprite = value;
			}
		}

		public override LandEntity GetLand()
		{
			// GetLand: pick a target land from the candidate land list.
			// The candidates are filtered by which plant layer is occupied, trying the
			// layers in the fixed order Master -> Shell -> Float -> Base. The first layer
			// that yields any occupied land wins, and this.placeType is set to that layer.
			// When isShovelExpensive is set, the surviving lands are sorted so the most
			// expensive plant (highest CardEntity.attr.sun) comes first, and that land is
			// returned; otherwise the first land in the filtered list is returned.
			List<LandEntity> landList = GetLandList();

			placeType = PlaceType.Master;
			List<LandEntity> filtered = landList.Where(land => land.masterPlant != null).ToList();

			if (filtered.Count < 1)
			{
				placeType = PlaceType.Shell;
				filtered = landList.Where(land => land.shellPlant != null).ToList();

				if (filtered.Count < 1)
				{
					placeType = PlaceType.Float;
					filtered = landList.Where(land => land.floatPlant != null).ToList();

					if (filtered.Count < 1)
					{
						placeType = PlaceType.Base;
						filtered = landList.Where(land => land.basePlant != null).ToList();

						if (filtered.Count < 1)
						{
							return null;
						}
					}
				}
			}

			if (isShovelExpensive)
			{
				// <GetLand>b__7_4: descending compare by the plant's sun cost
				// for the currently selected placeType. Inlined here as the sort comparer.
				filtered.Sort((landEntity1, landEntity2) =>
				{
					PlantEntity plant1 = landEntity1.GetPlaceTypePlant(placeType);
					PlantEntity plant2 = landEntity2.GetPlaceTypePlant(placeType);
					return plant2.CardEntity.attr.sun.CompareTo(plant1.CardEntity.attr.sun);
				});
			}

			return filtered[0];
		}

		public PlantEntity GetPlant(LandEntity landEntity = null)
		{
			// GetPlant: resolve the plant this shovel action targets.
			// If no land was supplied, resolve it via GetLand(). Then pick the plant on the
			// layer indicated by this.placeType. Finally, unless isPenetrateShell is set,
			// if the picked plant is a shell block, redirect to the shell plant sitting on
			// that plant's current land (so the shovel hits the shell, not what it guards).
			if (landEntity == null)
			{
				landEntity = GetLand();
			}
			if (landEntity == null)
			{
				return null;
			}

			PlantEntity plant = null;
			switch (placeType)
			{
				case PlaceType.All:
					// Last non-null wins, in the order float -> master -> shell -> base,
					// giving effective priority base > shell > master > float.
					if (landEntity.floatPlant != null)
					{
						plant = landEntity.floatPlant;
					}
					if (landEntity.masterPlant != null)
					{
						plant = landEntity.masterPlant;
					}
					if (landEntity.shellPlant != null)
					{
						plant = landEntity.shellPlant;
					}
					if (landEntity.basePlant != null)
					{
						plant = landEntity.basePlant;
					}
					break;
				case PlaceType.Master:
					plant = landEntity.masterPlant;
					break;
				case PlaceType.Shell:
					plant = landEntity.shellPlant;
					break;
				case PlaceType.Base:
					plant = landEntity.basePlant;
					break;
				case PlaceType.Float:
					plant = landEntity.floatPlant;
					break;
			}

			if (plant == null)
			{
				return null;
			}

			if (!isPenetrateShell)
			{
				if (plant.IsShellBlock())
				{
					LandEntity plantLand = plant.CurrentLandEntity;
					if (plantLand != null && plantLand.shellPlant != null)
					{
						plant = plant.CurrentLandEntity.shellPlant;
					}
				}
			}

			return plant;
		}
	}
}
