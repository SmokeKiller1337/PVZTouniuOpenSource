using System.Collections.Generic;
using System.Linq;
using Land.Entity;
using Plant.Entity;
using Plant.Enum;
using UnityEngine;

namespace Touniu.Entity.Body.Param
{
	public class ShovelParam : CommonHandleParam
	{
		public bool isPenetrateShell;

		public bool isUsePlayerShovel;

		public bool isShovelExpensive;

		public Sprite shovelSprite;

		public ShovelParam()
		{
			// .ctor (RVA 0x57A450): initialize the inherited CommonHandleParam range fields
			// to -1 (unset) and the speed ratio to 1.0f.
			//   +0x10 row = -1, +0x14 column = -1  (single 8-byte -1 write)
			//   +0x18 startRow = -1, +0x1c endRow = -1
			//   +0x20 startColumn = -1, +0x24 endColumn = -1
			//   +0x2c speedRatio = 1.0f (0x3f800000)
			row = -1;
			column = -1;
			startRow = -1;
			endRow = -1;
			startColumn = -1;
			endColumn = -1;
			speedRatio = 1f;
		}

		public Sprite ShovelSprite
		{
			get
			{
				// get_ShovelSprite (RVA 0x57FFC0): return the configured sprite when set,
				// otherwise fall back to a default provided by a global manager singleton.
				// The fallback chain (_DAT_182e7d978 -> +0xb8 -> +0x28 -> +0x48 -> delegate)
				// could not be resolved to a concrete manager/API, so only the confirmed
				// field-backed path is reconstructed here.
				if (shovelSprite != null)
				{
					return shovelSprite;
				}
				// TODO: reconstruct default-sprite fallback from the unresolved global singleton.
				return shovelSprite;
			}
			set
			{
				// set_ShovelSprite (RVA 0x4116E0): store into the backing field at +0x38.
				shovelSprite = value;
			}
		}

		public override LandEntity GetLand()
		{
			// GetLand (RVA 0x57F720): pick a target land from the candidate land list.
			// The candidates are filtered by which plant layer is occupied, trying the
			// layers in the fixed order Master -> Shell -> Float -> Base. The first layer
			// that yields any occupied land wins, and this.placeType is set to that layer.
			// When isShovelExpensive is set, the surviving lands are sorted so the most
			// expensive plant (highest CardEntity.attr.sun) comes first, and that land is
			// returned; otherwise the first land in the filtered list is returned.
			List<LandEntity> landList = GetLandList();

			placeType = PlaceType.Master;
			List<LandEntity> filtered = landList.Where(land => land.masterPlant != null).ToList();

			if (filtered.Count < 1)
			{
				placeType = PlaceType.Shell;
				filtered = landList.Where(land => land.shellPlant != null).ToList();

				if (filtered.Count < 1)
				{
					placeType = PlaceType.Float;
					filtered = landList.Where(land => land.floatPlant != null).ToList();

					if (filtered.Count < 1)
					{
						placeType = PlaceType.Base;
						filtered = landList.Where(land => land.basePlant != null).ToList();

						if (filtered.Count < 1)
						{
							return null;
						}
					}
				}
			}

			if (isShovelExpensive)
			{
				// <GetLand>b__7_4 (RVA 0x57FE90): descending compare by the plant's sun cost
				// for the currently selected placeType. Inlined here as the sort comparer.
				filtered.Sort((landEntity1, landEntity2) =>
				{
					PlantEntity plant1 = landEntity1.GetPlaceTypePlant(placeType);
					PlantEntity plant2 = landEntity2.GetPlaceTypePlant(placeType);
					return plant2.CardEntity.attr.sun.CompareTo(plant1.CardEntity.attr.sun);
				});
			}

			return filtered[0];
		}

		public PlantEntity GetPlant(LandEntity landEntity = null)
		{
			// GetPlant (RVA 0x57FBD0): resolve the plant this shovel action targets.
			// If no land was supplied, resolve it via GetLand(). Then pick the plant on the
			// layer indicated by this.placeType. Finally, unless isPenetrateShell is set,
			// if the picked plant is a shell block, redirect to the shell plant sitting on
			// that plant's current land (so the shovel hits the shell, not what it guards).
			if (landEntity == null)
			{
				landEntity = GetLand();
			}
			if (landEntity == null)
			{
				return null;
			}

			PlantEntity plant = null;
			switch (placeType)
			{
				case PlaceType.All:
					// Last non-null wins, in the order float -> master -> shell -> base,
					// giving effective priority base > shell > master > float.
					if (landEntity.floatPlant != null)
					{
						plant = landEntity.floatPlant;
					}
					if (landEntity.masterPlant != null)
					{
						plant = landEntity.masterPlant;
					}
					if (landEntity.shellPlant != null)
					{
						plant = landEntity.shellPlant;
					}
					if (landEntity.basePlant != null)
					{
						plant = landEntity.basePlant;
					}
					break;
				case PlaceType.Master:
					plant = landEntity.masterPlant;
					break;
				case PlaceType.Shell:
					plant = landEntity.shellPlant;
					break;
				case PlaceType.Base:
					plant = landEntity.basePlant;
					break;
				case PlaceType.Float:
					plant = landEntity.floatPlant;
					break;
			}

			if (plant == null)
			{
				return null;
			}

			if (!isPenetrateShell)
			{
				// TODO: verify the two virtual slots (+0x558 -> IsShellBlock, +0x178 ->
				// CurrentLandEntity). Both members exist on PlantEntity and match the
				// observed layout, but the exact vtable mapping is inferred.
				if (plant.IsShellBlock())
				{
					LandEntity plantLand = plant.CurrentLandEntity;
					if (plantLand != null && plantLand.shellPlant != null)
					{
						plant = plant.CurrentLandEntity.shellPlant;
					}
				}
			}

			return plant;
		}
	}
}
