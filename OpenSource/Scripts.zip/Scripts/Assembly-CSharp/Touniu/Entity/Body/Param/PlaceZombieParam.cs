using System;
using System.Collections.Generic;
using System.Linq;
using Land.Entity;
using Level.Static;
using Zombie.Entity;

namespace Touniu.Entity.Body.Param
{
	public class PlaceZombieParam : CommonHandleParam
	{
		public int zombieId;

		public bool isPickUpCardSlot;

		public bool isHypnosis;

		public Action<ZombieEntity> OnPlaceAction;

		public override LandEntity GetLand()
		{
			List<LandEntity> landList = GetLandList();
			if (landList == null || landList.Count <= 0)
			{
				return null;
			}
			ZombieEntity zombie = LevelStatic.zombieDic[zombieId];
			List<LandEntity> placeableList = landList.Where((LandEntity land) => zombie.IsPlaceable(land)).ToList();
			if (placeableList.Count > 0)
			{
				landList = placeableList;
			}
			if (landList.Count == 0)
			{
				return null;
			}
			return landList[0];
		}

		private List<LandEntity> GetEmptyLandList(List<LandEntity> landList)
		{
			ZombieEntity zombie = LevelStatic.zombieDic[zombieId];
			return landList.Where((LandEntity land) => zombie.IsPlaceable(land)).ToList();
		}
	}
}
