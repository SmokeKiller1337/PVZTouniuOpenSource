using System.Collections.Generic;
using Touniu.Manager;
using UnityEngine;

namespace Touniu.Entity.Body
{
	public class TouniuGhostEntity : MonoBehaviour
	{
		[Tooltip("步")]
		public int ghostStep;

		[Tooltip("间隔时间")]
		public float ghostTime = 0.1f;

		private float _currentTime;

		private readonly List<Vector2> _ghostPosList = new List<Vector2>();

		private SpriteRenderer _spriteRenderer;

		public void Reset()
		{
			// Snap this ghost to the head-cow's current position and clear the
			// recorded position trail.
			GameObject touniuObj = TouniuManager.Instance?.touniuObj;
			if (touniuObj == null)
			{
				return;
			}
			if (_ghostPosList != null)
			{
				_ghostPosList.Clear();
				transform.position = touniuObj.transform.position;
			}
		}

		private void Awake()
		{
			_spriteRenderer = GetComponent<SpriteRenderer>();
		}

		private void Update()
		{
			// Every ghostTime seconds, sample the head-cow's position into a
			// fixed-length (ghostStep) FIFO trail, then move this ghost to the
			// oldest sampled position and flip its sprite to face the travel
			// direction. TouniuManager.Instance.touniuObj is the head-cow object
			// (native field at manager offset 0x20).
			GameObject touniuObj = TouniuManager.Instance?.touniuObj;
			if (touniuObj == null)
			{
				return;
			}

			_currentTime += Time.deltaTime;
			if (_currentTime <= ghostTime)
			{
				return;
			}
			_currentTime = 0f;

			if (_ghostPosList == null)
			{
				return;
			}

			if (_ghostPosList.Count < ghostStep)
			{
				// Trail not yet full: append the head-cow's current position.
				GameObject sampleObj = TouniuManager.Instance?.touniuObj;
				if (sampleObj == null)
				{
					return;
				}
				Transform sampleTransform = sampleObj.transform;
				if (sampleTransform == null)
				{
					return;
				}
				_ghostPosList.Add(sampleTransform.position);
			}
			else
			{
				// Trail full: shift every element down by one (dropping the oldest
				// at index 0) and write the head-cow's current position into the
				// last slot.
				for (int i = 0; i < _ghostPosList.Count; i++)
				{
					Vector2 value;
					if (i == _ghostPosList.Count - 1)
					{
						GameObject sampleObj = TouniuManager.Instance?.touniuObj;
						if (sampleObj == null)
						{
							break;
						}
						Transform sampleTransform = sampleObj.transform;
						if (sampleTransform == null)
						{
							break;
						}
						value = sampleTransform.position;
					}
					else
					{
						value = _ghostPosList[i + 1];
					}
					_ghostPosList[i] = value;
				}
			}

			// Move this ghost to the oldest recorded position (index 0) and set
			// the sprite facing based on horizontal travel direction.
			if (_ghostPosList == null)
			{
				return;
			}
			float targetX = _ghostPosList[0].x;
			Transform selfTransform = transform;
			if (selfTransform == null)
			{
				return;
			}
			float currentX = selfTransform.position.x;
			selfTransform = transform;
			if (_ghostPosList == null || selfTransform == null)
			{
				return;
			}
			Vector2 target = _ghostPosList[0];
			selfTransform.position = new Vector3(target.x, target.y, 0f);
			if (_spriteRenderer != null)
			{
				_spriteRenderer.flipX = targetX - currentX < 0f;
			}
		}
	}
}
