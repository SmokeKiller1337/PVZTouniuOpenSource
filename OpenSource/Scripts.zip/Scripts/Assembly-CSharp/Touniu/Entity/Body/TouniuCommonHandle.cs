using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Building.Entity;
using Game.Entity;
using Land.Entity;
using Level.Util;
using Plant.Entity;
using Touniu.Entity.Body.Param;
using UnityEngine;
using Zombie.Entity;

namespace Touniu.Entity.Body
{
	public class TouniuCommonHandle : MonoBehaviour
	{
		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass10_0
		{
			public PlantEntity oldPlantEntity;

			internal void _003CPlacePlantCoroutine_003Eb__0()
			{
				// TODO: reconstruct
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass12_0
		{
			public PlantEntity plantEntity;

			internal void _003CShovelPlantCoroutine_003Eb__0()
			{
				// TODO: reconstruct
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass17_0
		{
			public PlantEntity plantEntity;

			internal void _003CEatPlantCoroutine_003Eb__0()
			{
				// TODO: reconstruct
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass28_0
		{
			public GameObject sunObj;

			internal void _003CReduceSunCoroutine_003Eb__0()
			{
				// TODO: reconstruct
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass30_0
		{
			public GameObject diamondObj;

			internal void _003CReduceDiamondCoroutine_003Eb__0()
			{
				// TODO: reconstruct
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass32_0
		{
			public GameObject hammerObj;

			internal void _003CReduceHammerCoroutine_003Eb__0()
			{
				// TODO: reconstruct
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass47_0
		{
			public Animator animator;

			public GameObject curtainObj;

			internal void _003CCreateCurtainCoroutine_003Eb__0()
			{
				// TODO: reconstruct
			}

			internal void _003CCreateCurtainCoroutine_003Eb__1()
			{
				// TODO: reconstruct
			}
		}

		[CompilerGenerated]
		private sealed class _003CBadLineCoroutine_003Ed__24 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuCommonHandle _003C_003E4__this;

			public Vector2 targetPosition;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CBadLineCoroutine_003Ed__24(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CCreateCurtainCoroutine_003Ed__47 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public float scale;

			public TouniuCommonHandle _003C_003E4__this;

			public Vector2 position;

			private _003C_003Ec__DisplayClass47_0 _003C_003E8__1;

			public float hue;

			public float duration;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CCreateCurtainCoroutine_003Ed__47(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CEatPlantCoroutine_003Ed__17 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public EatPlantParam param;

			public TouniuCommonHandle _003C_003E4__this;

			private _003C_003Ec__DisplayClass17_0 _003C_003E8__1;

			private List<int> _003CplantIdList_003E5__2;

			private float _003CspeedRatio_003E5__3;

			private Vector2 _003Cposition_003E5__4;

			private float _003CeatTime_003E5__5;

			private int _003CeatEffectNumber_003E5__6;

			private int _003Ci_003E5__7;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CEatPlantCoroutine_003Ed__17(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CGoodLineCoroutine_003Ed__22 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuCommonHandle _003C_003E4__this;

			public Vector2 targetPosition;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CGoodLineCoroutine_003Ed__22(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CPlaceBuildingCoroutine_003Ed__26 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public PlaceBuildingParam param;

			public TouniuCommonHandle _003C_003E4__this;

			private float _003CspeedRatio_003E5__2;

			private LandEntity _003ClandEntity_003E5__3;

			private Sprite _003CbuildingSprite_003E5__4;

			private Vector3 _003CtargetPosition_003E5__5;

			private int _003Ci_003E5__6;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CPlaceBuildingCoroutine_003Ed__26(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CPlacePlantCoroutine_003Ed__10 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public PlacePlantParam param;

			public TouniuCommonHandle _003C_003E4__this;

			private _003C_003Ec__DisplayClass10_0 _003C_003E8__1;

			private int _003Cid_003E5__2;

			private float _003CspeedRatio_003E5__3;

			private CardEntity _003CcardEntity_003E5__4;

			private LandEntity _003ClandEntity_003E5__5;

			private Vector2 _003ClandPosition_003E5__6;

			private Sprite _003CplantSprite_003E5__7;

			private int _003Ci_003E5__8;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CPlacePlantCoroutine_003Ed__10(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CPlaceZombieCoroutine_003Ed__20 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public PlaceZombieParam param;

			public TouniuCommonHandle _003C_003E4__this;

			private int _003Cid_003E5__2;

			private float _003CspeedRatio_003E5__3;

			private LandEntity _003ClandEntity_003E5__4;

			private Vector3 _003CtargetPosition_003E5__5;

			private Sprite _003CzombieSprite_003E5__6;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CPlaceZombieCoroutine_003Ed__20(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CReduceDiamondCoroutine_003Ed__30 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public int value;

			public TouniuCommonHandle _003C_003E4__this;

			private _003C_003Ec__DisplayClass30_0 _003C_003E8__1;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CReduceDiamondCoroutine_003Ed__30(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CReduceHammerCoroutine_003Ed__32 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public int value;

			public TouniuCommonHandle _003C_003E4__this;

			private _003C_003Ec__DisplayClass32_0 _003C_003E8__1;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CReduceHammerCoroutine_003Ed__32(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CReduceSunCoroutine_003Ed__28 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public int value;

			public TouniuCommonHandle _003C_003E4__this;

			private _003C_003Ec__DisplayClass28_0 _003C_003E8__1;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CReduceSunCoroutine_003Ed__28(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CShovelPlantCoroutine_003Ed__12 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public ShovelParam param;

			public TouniuCommonHandle _003C_003E4__this;

			private _003C_003Ec__DisplayClass12_0 _003C_003E8__1;

			private float _003CspeedRatio_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CShovelPlantCoroutine_003Ed__12(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CSwapPlantCoroutine_003Ed__14 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public LandEntity landEntity1;

			public LandEntity landEntity2;

			public float speedRatio;

			public TouniuCommonHandle _003C_003E4__this;

			private float _003Ctime_003E5__2;

			private PlantEntity _003Cland1Plant_003E5__3;

			private BuildingEntity _003Cland1Building_003E5__4;

			private PlantEntity _003Cland2Plant_003E5__5;

			private BuildingEntity _003Cland2Building_003E5__6;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CSwapPlantCoroutine_003Ed__14(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CUseBeefCoroutine_003Ed__40 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuCommonHandle _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CUseBeefCoroutine_003Ed__40(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CUseHypnosisMushroomCoroutine_003Ed__44 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuCommonHandle _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CUseHypnosisMushroomCoroutine_003Ed__44(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CUseMilkCoroutine_003Ed__36 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuCommonHandle _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CUseMilkCoroutine_003Ed__36(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		private TouniuBaseBody _touniuBaseBody;

		private Coroutine _currentCoroutine;

		private bool _isPickUpPlayerShovel;

		private PlantEntity _swapCurrentPlant;

		private BuildingEntity _swapCurrentBuilding;

		[Tooltip("吃特效")]
		public EffectEntity eatPlantEffect;

		[Tooltip("牛奶贴图")]
		public Sprite milkSprite;

		[Tooltip("牛奶音效")]
		public AudioClip milkSound;

		[Tooltip("牛肉贴图")]
		public Sprite beefSprite;

		[Tooltip("牛肉音效")]
		public AudioClip beefSound;

		[Tooltip("魅惑菇贴图")]
		public Sprite hypnosisMushroomSprite;

		[Tooltip("魅惑特效")]
		public EffectEntity hypnosisMushroomEffect;

		[Tooltip("幕帘预制体")]
		public GameObject curtainPrefab;

		private void Awake()
		{
			_touniuBaseBody = GetComponent<TouniuBaseBody>();
		}

		private void Update()
		{
		}

		public void KillCoroutine()
		{
			// TODO: reconstruct
		}

		public Coroutine PlacePlant(PlacePlantParam param)
		{
			if (param == null)
			{
				param = new PlacePlantParam
				{
					cardId = -1,
					isPickUpCardSlot = true,
					row = -1,
					column = -1,
					startRow = -1,
					endRow = -1,
					startColumn = -1,
					endColumn = -1,
					speedRatio = 1f
				};
			}
			if (param.cardId == -1)
			{
				param.cardId = 10;
				CardEntity card = LevelUtils.GetCard();
				if (card != null)
				{
					param.cardId = card.id;
				}
			}
			_currentCoroutine = StartCoroutine(PlacePlantCoroutine(param));
			return _currentCoroutine;
		}

		public Coroutine PlacePlant(int id = -1, int row = -1, int column = -1)
		{
			PlacePlantParam param = new PlacePlantParam
			{
				cardId = -1,
				isPickUpCardSlot = true,
				row = -1,
				column = -1,
				startRow = -1,
				endRow = -1,
				startColumn = -1,
				endColumn = -1,
				speedRatio = 1f
			};
			param.cardId = id;
			param.row = row;
			param.column = column;
			if (param.cardId == -1)
			{
				param.cardId = 10;
				CardEntity card = LevelUtils.GetCard();
				if (card != null)
				{
					param.cardId = card.id;
				}
			}
			_currentCoroutine = StartCoroutine(PlacePlantCoroutine(param));
			return _currentCoroutine;
		}

		[IteratorStateMachine(typeof(_003CPlacePlantCoroutine_003Ed__10))]
		private IEnumerator PlacePlantCoroutine(PlacePlantParam param)
		{
			// TODO: reconstruct
			return null;
		}

		public Coroutine ShovelPlant(ShovelParam param = null)
		{
			if (param == null)
			{
				param = new ShovelParam
				{
					row = -1,
					column = -1,
					startRow = -1,
					endRow = -1,
					startColumn = -1,
					endColumn = -1,
					speedRatio = 1f
				};
			}
			_currentCoroutine = StartCoroutine(ShovelPlantCoroutine(param));
			return _currentCoroutine;
		}

		[IteratorStateMachine(typeof(_003CShovelPlantCoroutine_003Ed__12))]
		private IEnumerator ShovelPlantCoroutine(ShovelParam param)
		{
			// TODO: reconstruct
			return null;
		}

		public Coroutine SwapPlant(LandEntity landEntity1 = null, LandEntity landEntity2 = null, float speedRatio = 1f)
		{
			_currentCoroutine = StartCoroutine(SwapPlantCoroutine(landEntity1, landEntity2, speedRatio));
			return _currentCoroutine;
		}

		[IteratorStateMachine(typeof(_003CSwapPlantCoroutine_003Ed__14))]
		private IEnumerator SwapPlantCoroutine(LandEntity landEntity1, LandEntity landEntity2, float speedRatio)
		{
			// TODO: reconstruct
			return null;
		}

		public Coroutine EatPlant(EatPlantParam param = null)
		{
			if (param == null)
			{
				param = new EatPlantParam
				{
					isShovelHypnosisPlant = true,
					row = -1,
					column = -1,
					startRow = -1,
					endRow = -1,
					startColumn = -1,
					endColumn = -1,
					speedRatio = 1f
				};
			}
			_currentCoroutine = StartCoroutine(EatPlantCoroutine(param));
			return _currentCoroutine;
		}

		[IteratorStateMachine(typeof(_003CEatPlantCoroutine_003Ed__17))]
		private IEnumerator EatPlantCoroutine(EatPlantParam param)
		{
			// TODO: reconstruct
			return null;
		}

		public Coroutine PlaceZombie(PlaceZombieParam param)
		{
			if (param == null)
			{
				param = new PlaceZombieParam
				{
					zombieId = -1,
					isPickUpCardSlot = true,
					row = -1,
					column = -1,
					startRow = -1,
					endRow = -1,
					startColumn = 6,
					endColumn = 9,
					speedRatio = 1f
				};
			}
			if (param.zombieId == -1)
			{
				param.zombieId = 10;
				List<ZombieEntity> zombieList = LevelUtils.GetLevelZombieList(false);
				if (zombieList.Count > 0)
				{
					ZombieEntity zombie = zombieList[UnityEngine.Random.Range(0, zombieList.Count)];
					param.zombieId = zombie.id;
				}
			}
			_currentCoroutine = StartCoroutine(PlaceZombieCoroutine(param));
			return _currentCoroutine;
		}

		public Coroutine PlaceZombie(int id = -1)
		{
			PlaceZombieParam param = new PlaceZombieParam
			{
				zombieId = -1,
				isPickUpCardSlot = true,
				row = -1,
				column = -1,
				startRow = -1,
				endRow = -1,
				startColumn = 6,
				endColumn = 9,
				speedRatio = 1f
			};
			param.zombieId = id;
			if (param.zombieId == -1)
			{
				param.zombieId = 10;
				List<ZombieEntity> zombieList = LevelUtils.GetLevelZombieList(false);
				if (zombieList.Count > 0)
				{
					ZombieEntity zombie = zombieList[UnityEngine.Random.Range(0, zombieList.Count)];
					param.zombieId = zombie.id;
				}
			}
			_currentCoroutine = StartCoroutine(PlaceZombieCoroutine(param));
			return _currentCoroutine;
		}

		[IteratorStateMachine(typeof(_003CPlaceZombieCoroutine_003Ed__20))]
		private IEnumerator PlaceZombieCoroutine(PlaceZombieParam param)
		{
			// TODO: reconstruct
			return null;
		}

		public Coroutine GoodLine(Vector2 targetPosition)
		{
			_currentCoroutine = StartCoroutine(GoodLineCoroutine(targetPosition));
			return _currentCoroutine;
		}

		[IteratorStateMachine(typeof(_003CGoodLineCoroutine_003Ed__22))]
		private IEnumerator GoodLineCoroutine(Vector2 targetPosition)
		{
			// TODO: reconstruct
			return null;
		}

		public Coroutine BadLine(Vector2 targetPosition)
		{
			_currentCoroutine = StartCoroutine(BadLineCoroutine(targetPosition));
			return _currentCoroutine;
		}

		[IteratorStateMachine(typeof(_003CBadLineCoroutine_003Ed__24))]
		private IEnumerator BadLineCoroutine(Vector2 targetPosition)
		{
			// TODO: reconstruct
			return null;
		}

		public Coroutine PlaceBuilding(PlaceBuildingParam param)
		{
			if (param == null)
			{
				param = new PlaceBuildingParam
				{
					buildingId = -1,
					row = -1,
					column = -1,
					startRow = -1,
					endRow = -1,
					startColumn = -1,
					endColumn = -1,
					speedRatio = 1f
				};
			}
			_currentCoroutine = StartCoroutine(PlaceBuildingCoroutine(param));
			return _currentCoroutine;
		}

		[IteratorStateMachine(typeof(_003CPlaceBuildingCoroutine_003Ed__26))]
		private IEnumerator PlaceBuildingCoroutine(PlaceBuildingParam param)
		{
			// TODO: reconstruct
			return null;
		}

		public Coroutine ReduceSun(int value)
		{
			_currentCoroutine = StartCoroutine(ReduceSunCoroutine(value));
			return _currentCoroutine;
		}

		[IteratorStateMachine(typeof(_003CReduceSunCoroutine_003Ed__28))]
		private IEnumerator ReduceSunCoroutine(int value)
		{
			// TODO: reconstruct
			return null;
		}

		public Coroutine ReduceDiamond(int value)
		{
			_currentCoroutine = StartCoroutine(ReduceDiamondCoroutine(value));
			return _currentCoroutine;
		}

		[IteratorStateMachine(typeof(_003CReduceDiamondCoroutine_003Ed__30))]
		private IEnumerator ReduceDiamondCoroutine(int value)
		{
			// TODO: reconstruct
			return null;
		}

		public Coroutine ReduceHammer(int value)
		{
			_currentCoroutine = StartCoroutine(ReduceHammerCoroutine(value));
			return _currentCoroutine;
		}

		[IteratorStateMachine(typeof(_003CReduceHammerCoroutine_003Ed__32))]
		private IEnumerator ReduceHammerCoroutine(int value)
		{
			// TODO: reconstruct
			return null;
		}

		public Coroutine UseMilk()
		{
			_currentCoroutine = StartCoroutine(UseMilkCoroutine());
			return _currentCoroutine;
		}

		[IteratorStateMachine(typeof(_003CUseMilkCoroutine_003Ed__36))]
		private IEnumerator UseMilkCoroutine()
		{
			// TODO: reconstruct
			return null;
		}

		public Coroutine UseBeef()
		{
			_currentCoroutine = StartCoroutine(UseBeefCoroutine());
			return _currentCoroutine;
		}

		[IteratorStateMachine(typeof(_003CUseBeefCoroutine_003Ed__40))]
		private IEnumerator UseBeefCoroutine()
		{
			// TODO: reconstruct
			return null;
		}

		public Coroutine UseHypnosisMushroom()
		{
			_currentCoroutine = StartCoroutine(UseHypnosisMushroomCoroutine());
			return _currentCoroutine;
		}

		[IteratorStateMachine(typeof(_003CUseHypnosisMushroomCoroutine_003Ed__44))]
		private IEnumerator UseHypnosisMushroomCoroutine()
		{
			// TODO: reconstruct
			return null;
		}

		public Coroutine CreateCurtain(Vector2 position, float scale = 1f, float duration = 1.5f, float hue = 0f)
		{
			_currentCoroutine = StartCoroutine(CreateCurtainCoroutine(position, scale, duration, hue));
			return _currentCoroutine;
		}

		[IteratorStateMachine(typeof(_003CCreateCurtainCoroutine_003Ed__47))]
		private IEnumerator CreateCurtainCoroutine(Vector2 position, float scale, float duration, float hue)
		{
			// TODO: reconstruct
			return null;
		}
	}
}
