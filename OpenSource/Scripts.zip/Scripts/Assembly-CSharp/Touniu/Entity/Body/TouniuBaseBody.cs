using System;
using System.Collections;
using System.Collections.Generic;
using Audio.Manager;
using Common.Entity;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using Game.Entity;
using Game.Util;
using Level.Static;
using NoSLoofah.BuffSystem;
using Touniu.Entity.Say.Shop;
using Touniu.Enum;
using Touniu.Manager;
using Touniu.Util;
using UnityEngine;
using UnityEngine.Rendering;

namespace Touniu.Entity.Body
{
	public class TouniuBaseBody : MonoBehaviour
	{
		[Tooltip("编号")]
		public int id;

		[Tooltip("名称")]
		public string title;

		[Tooltip("特性")]
		public string cardTitle;

		[TextArea]
		[Tooltip("描述")]
		public string content;

		[Tooltip("属性")]
		public TouniuBaseAttr attr;

		[Tooltip("默认属性")]
		public TouniuBaseAttr defaultAttr;

		[Tooltip("直接行为集合")]
		public List<TouniuBehaviorEntity> directBehaviorList;

		[Tooltip("濒死音效")]
		public AudioClip dyingSound;

		[Tooltip("濒死长音效")]
		public AudioClip dyingSound1;

		[Tooltip("击中时再次砸音效")]
		public AudioClip dyingSound2;

		[Tooltip("哎哟喂字音效")]
		public List<AudioClip> dyingSoundList;

		[Tooltip("主体")]
		public Transform mainBodyTransform;

		[Tooltip("身体")]
		public Transform touniuRootTransform;

		[Tooltip("手部")]
		public Transform handTransform;

		[Tooltip("防具")]
		public Transform armTransform;

		[Tooltip("阴影")]
		public SpriteRenderer shadowSpriteRenderer;

		[Tooltip("免疫击晕渲染器")]
		public SpriteRenderer invalidStunSpriteRenderer;

		[Tooltip("头盔预制体")]
		public GameObject helmetPrefab;

		[HideInInspector]
		public SpriteRenderer helmetSpriteRenderer;

		private GameObject _helmetObj;

		private Tween _helmetDelayedCall;

		[Tooltip("头盔贴图集合")]
		public List<Sprite> helmetSpriteList;

		[Tooltip("深蓝头羊眼镜")]
		public SpriteRenderer deepBlueRenderer;

		[Tooltip("深蓝头羊特效")]
		public EffectEntity deepBlueEffect;

		[Tooltip("深蓝驱散迷雾预制体")]
		public GameObject deepBlueDispelFogPrefab;

		private GameObject _deepBlueDispelFogObj;

		[HideInInspector]
		public bool isSpecialPattern;

		[HideInInspector]
		public TouniuCommonHandle handle;

		public TweenerCore<Vector3, Vector3, VectorOptions> moveTweenerCore;

		private List<SpriteRenderer> _spriteRendererList;

		private Animator _animator;

		private Collider2D _collider;

		private Rigidbody2D _rigidbody;

		private BuffHandler _buffHandler;

		private SortingGroup _sortingGroup;

		private SpriteRenderer _handShortSpriteRenderer;

		private SpriteRenderer _handLongSpriteRenderer;

		private Dictionary<int, GameObject> _skinObjDic;

		private bool _isHighlight;

		private bool _isFlicker;

		private bool _isStun;

		private int _invalidStunValue;

		private bool _isHelmet;

		private bool _isDying;

		private bool _isDeath;

		private int _stunFirstFrameCount;

		private Coroutine _stunCoroutine;

		[HideInInspector]
		public int stunCount;

		[HideInInspector]
		public int stunInvalidCount;

		public Action OnBeforeStun;

		public Action OnAfterStun;

		[Tooltip("索引")]
		public int index;

		public List<SpriteRenderer> SpriteRendererList
		{
			get
			{
				return _spriteRendererList;
			}
			set
			{
				_spriteRendererList = value;
			}
		}

		public SpriteRenderer SpriteRenderer => _animator.transform.Find(id.ToString())?.GetComponent<SpriteRenderer>();

		public Animator Animator
		{
			get
			{
				return _animator;
			}
			set
			{
				_animator = value;
			}
		}

		public Collider2D Collider
		{
			get
			{
				return _collider;
			}
			set
			{
				_collider = value;
			}
		}

		public Rigidbody2D Rigidbody
		{
			get
			{
				return _rigidbody;
			}
			set
			{
				_rigidbody = value;
			}
		}

		public SortingGroup SortingGroup
		{
			get
			{
				return _sortingGroup;
			}
			set
			{
				_sortingGroup = value;
			}
		}

		public BuffHandler BuffHandler
		{
			get
			{
				return _buffHandler;
			}
			set
			{
				_buffHandler = value;
			}
		}

		public bool IsInvalidStun => _invalidStunValue > 0;

		public bool IsFlipX => base.transform.localScale.x < 0f;

		public bool IsStun
		{
			get
			{
				return _isStun;
			}
			set
			{
				_isStun = value;
			}
		}

		public bool IsRage
		{
			get
			{
				foreach (global::NoSLoofah.BuffSystem.Buff buff in _buffHandler.GetBuffs)
				{
					if (buff.ID == 3)
					{
						return true;
					}
				}
				return false;
			}
		}

		public bool IsHypnosis
		{
			get
			{
				foreach (global::NoSLoofah.BuffSystem.Buff buff in _buffHandler.GetBuffs)
				{
					if (buff.ID == 7)
					{
						return true;
					}
				}
				return false;
			}
		}

		public bool IsHelmet => _isHelmet;

		public bool IsDying
		{
			get
			{
				return _isDying;
			}
			set
			{
				_isDying = value;
			}
		}

		public bool IsDeath
		{
			get
			{
				return _isDeath;
			}
			set
			{
				_isDeath = value;
			}
		}

		public bool IsAvailable
		{
			get
			{
				if (!_isStun && !_isDying)
				{
					return !_isDeath;
				}
				return false;
			}
		}

		protected void Awake()
		{
			handle = GetComponent<TouniuCommonHandle>();
			_animator = GetComponentInChildren<Animator>();
			_collider = GetComponent<Collider2D>();
			_rigidbody = GetComponent<Rigidbody2D>();
			_buffHandler = GetComponent<BuffHandler>();
			_spriteRendererList = new List<SpriteRenderer>(touniuRootTransform.GetComponentsInChildren<SpriteRenderer>(true));
			_handShortSpriteRenderer = handTransform.Find("HandShort").GetComponent<SpriteRenderer>();
			_handLongSpriteRenderer = handTransform.Find("HandLong").GetComponent<SpriteRenderer>();
			_sortingGroup = mainBodyTransform.GetComponent<SortingGroup>();
			for (int i = 1; i < 100; i++)
			{
				Transform transform = _animator.transform.Find(i.ToString());
				if (transform == null)
				{
					break;
				}
				_skinObjDic.Add(i, transform.gameObject);
			}
			if (id != 0)
			{
				TouniuBaseBody touniuBaseBody = Resources.Load<TouniuBaseBody>(string.Format("Touniu/Touniu{0}", id));
				title = touniuBaseBody.title;
				cardTitle = touniuBaseBody.cardTitle;
				content = touniuBaseBody.content;
			}
		}

		protected void Start()
		{
		}

		protected void Update()
		{
		}

		public bool Death()
		{
			_isDeath = true;
			if (TouniuManager.Instance.touniuBaseBody == this)
			{
				TouniuManager.Instance.deathTouniuObj = base.gameObject;
				TouniuManager.Instance.touniuObj = null;
			}
			base.gameObject.SetActive(false);
			return true;
		}

		public void Revive()
		{
			if (!(TouniuManager.Instance.deathTouniuObj != base.gameObject))
			{
				TouniuManager.Instance.touniuObj = TouniuManager.Instance.deathTouniuObj;
				TouniuManager.Instance.deathTouniuObj = null;
				_isDying = false;
				_isDeath = false;
				_isStun = false;
				_invalidStunValue = 0;
				_animator.Play("idle");
				_rigidbody.gravityScale = 0f;
				_rigidbody.drag = 0f;
				_rigidbody.velocity = Vector2.zero;
				_collider.enabled = true;
				TouniuBehaviorManager.Instance.enabled = true;
				_animator.gameObject.SetActive(true);
				_handShortSpriteRenderer.sprite = null;
				TouniuBehaviorManager.Instance.ExecuteNextBehavior();
			}
		}

		public void Stun()
		{
			OnBeforeStun?.Invoke();
			if (_invalidStunValue > 0)
			{
				stunInvalidCount++;
			}
			else
			{
				StartCoroutine(StunFirstFrame());
			}
		}

		public void StunRevive()
		{
			if (_isStun)
			{
				if (_stunCoroutine != null)
				{
					StopCoroutine(_stunCoroutine);
				}
				_isStun = false;
				_animator.Play("idle");
				TouniuBehaviorManager.Instance.ExecuteNextBehavior();
				stunCount++;
				OnAfterStun?.Invoke();
			}
		}

		// 击晕后倒地一秒再复活
		private IEnumerator StunHandle()
		{
			StopMove();
			TouniuCommonHandle handle = this.handle;
			if (handle != null)
			{
				handle.KillCoroutine();
				_isStun = true;
				InterruptQueue();
				if (TouniuManager.Instance.touniuBaseBody == this)
				{
					TouniuBehaviorUtils.InterruptQueue();
				}
				ChangeRage(false);
				AudioManager.Instance.PlayVoice(dyingSound);
				_animator.Play("dying");
				yield return new WaitForSeconds(1f);
				StunRevive();
			}
		}

		// 首帧击晕：连续击晕时播放长音效，隔帧后清零计数
		private IEnumerator StunFirstFrame()
		{
			if (++_stunFirstFrameCount > 1)
			{
				AudioManager.Instance.PlayVoice(dyingSound1);
			}
			yield return null;
			_stunFirstFrameCount = 0;
		}

		public void ChangeInvalidStunValue(int value)
		{
			_invalidStunValue += value;
			if (_invalidStunValue < 0)
			{
				_invalidStunValue = 0;
			}
			if (AreaStatic.IsRandomMode())
			{
				_invalidStunValue = 0;
			}
			invalidStunSpriteRenderer.gameObject.SetActive(_invalidStunValue > 0);
		}

		public void ChangeSpecialPattern(bool isSpecial)
		{
			if (isSpecialPattern == isSpecial)
			{
				return;
			}
			isSpecialPattern = isSpecial;
			Vector3 localEulerAngles = deepBlueRenderer.transform.localEulerAngles;
			localEulerAngles.y = (isSpecial ? 0f : 180f);
			deepBlueRenderer.transform.DOLocalRotate(localEulerAngles, 0.5f);
			if (id != 6)
			{
				return;
			}
			GameUtils.CreateEffect(deepBlueEffect, base.transform.position, Quaternion.identity);
			if (_deepBlueDispelFogObj == null)
			{
				_deepBlueDispelFogObj = UnityEngine.Object.Instantiate(deepBlueDispelFogPrefab, deepBlueRenderer.transform);
			}
			_deepBlueDispelFogObj.SetActive(isSpecial);
		}

		private void InterruptQueue()
		{
			foreach (TouniuBehaviorEntity item in new List<TouniuBehaviorEntity>(directBehaviorList))
			{
				if (item != null)
				{
					item.ForceEnd();
				}
			}
			directBehaviorList.Clear();
			_handShortSpriteRenderer.sprite = null;
		}

		public void ChangeRage(bool flag, float time = 60f)
		{
			if (_buffHandler.HasBuff(3) != flag)
			{
				if (!flag)
				{
					_buffHandler.RemoveBuff(3);
				}
				else
				{
					_buffHandler.AddBuff(3, base.gameObject, time);
				}
			}
		}

		public void ChangeHypnosis(bool flag, float time = -1f)
		{
			if (_buffHandler.HasBuff(7) != flag)
			{
				if (!flag)
				{
					_buffHandler.RemoveBuff(7);
				}
				else
				{
					_buffHandler.AddBuff(7, base.gameObject, time);
				}
			}
		}

		public void ChangeHelmet(bool flag, int spriteIndex = 0, float time = -1f)
		{
			if (_helmetDelayedCall != null)
			{
				_helmetDelayedCall.Kill();
			}
			if (_helmetObj != null)
			{
				UnityEngine.Object.Destroy(_helmetObj);
				ChangeInvalidStunValue(-1);
			}
			_isHelmet = flag;
			if (!flag)
			{
				return;
			}
			_helmetObj = UnityEngine.Object.Instantiate(helmetPrefab, armTransform);
			helmetSpriteRenderer = _helmetObj.GetComponentInChildren<SpriteRenderer>();
			helmetSpriteRenderer.sprite = helmetSpriteList[spriteIndex];
			_helmetObj.transform.localPosition = Vector3.zero;
			ChangeInvalidStunValue(1);
			if (time > 0f)
			{
				_helmetDelayedCall = DOVirtual.DelayedCall(time, delegate
				{
					ChangeHelmet(false);
				});
			}
		}

		public void Dying()
		{
			StartCoroutine(DyingHandle());
		}

		// 濒死：停止行为，播放濒死动画一秒后死亡
		private IEnumerator DyingHandle()
		{
			if (_isDying)
			{
				yield break;
			}
			_isDying = true;
			StopMove();
			TouniuManager.Instance.touniuBaseBody.SpriteRenderer.enabled = false;
			TouniuBehaviorManager.Instance.enabled = false;
			CloseTouniuCollider();
			TouniuBehaviorUtils.ClearQueue();
			AudioManager.Instance.PlayVoice(dyingSound);
			_animator.Play("dying");
			yield return new WaitForSeconds(1f);
			if (!_isDeath)
			{
				Death();
			}
		}

		public void Highlight(bool isHighlight = true)
		{
			_isHighlight = isHighlight;
			foreach (SpriteRenderer spriteRenderer in _spriteRendererList)
			{
				spriteRenderer.material.SetFloat("_FlashAmount", isHighlight ? 1f : 0f);
			}
		}

		public void Flicker()
		{
			StartCoroutine(FlickerCoroutine());
		}

		// 受击闪白：亮起再淡出
		private IEnumerator FlickerCoroutine()
		{
			if (_isHighlight)
			{
				yield break;
			}
			if (_isFlicker)
			{
				yield break;
			}
			_isFlicker = true;
			foreach (SpriteRenderer spriteRenderer in _spriteRendererList)
			{
				spriteRenderer.material.DOFloat(1f, "_FlashAmount", 0.1f);
			}
			yield return new WaitForSeconds(0.1f);
			foreach (SpriteRenderer spriteRenderer2 in _spriteRendererList)
			{
				spriteRenderer2.material.DOFloat(0f, "_FlashAmount", 0.1f);
			}
			yield return new WaitForSeconds(0.1f);
			_isFlicker = false;
		}

		public void OpenTouniuCollider()
		{
			_collider.enabled = true;
		}

		public void CloseTouniuCollider()
		{
			_collider.enabled = false;
		}

		public void ShowAttr()
		{
		}

		public void SetFlipX(bool isFlipX)
		{
			Vector3 localScale = base.transform.localScale;
			float x = Mathf.Abs(localScale.x);
			if (!isFlipX)
			{
				x = 0f - x;
			}
			base.transform.localScale = new Vector3(x, base.transform.localScale.y, base.transform.localScale.z);
			if (handTransform != null)
			{
				Vector3 localScale2 = handTransform.localScale;
				float x2 = Mathf.Abs(localScale2.x);
				if (!isFlipX)
				{
					x2 = 0f - x2;
				}
				handTransform.localScale = new Vector3(x2, handTransform.localScale.y, handTransform.localScale.z);
			}
		}

		public void ChangeTouniu(int touniuId)
		{
		}

		public TweenerCore<Vector3, Vector3, VectorOptions> Move(Vector2 position, float duration)
		{
			StunRevive();
			if (Mathf.Abs(position.x) < 0.01f && Mathf.Abs(position.y) < 0.01f)
			{
				position = base.transform.position;
			}
			if (moveTweenerCore != null)
			{
				moveTweenerCore.Kill();
			}
			bool flipX = base.transform.position.x <= position.x;
			SetFlipX(flipX);
			moveTweenerCore = base.transform.DOMove(position, duration);
			return moveTweenerCore;
		}

		public TouniuSayEntity Talk(int sayId, SayType type)
		{
			StunRevive();
			TouniuSayEntity touniuSayEntity = (TouniuSayEntity)TouniuBehaviorManager.Instance.CreateTalk(sayId, type);
			touniuSayEntity.isDirectSay = true;
			touniuSayEntity.TouniuBaseBody = this;
			directBehaviorList.Add(touniuSayEntity);
			touniuSayEntity.gameObject.SetActive(true);
			return touniuSayEntity;
		}

		public TouniuHandleEntity Handle(int handleId)
		{
			StunRevive();
			TouniuHandleEntity touniuHandleEntity = (TouniuHandleEntity)TouniuBehaviorManager.Instance.CreateHandle(handleId);
			touniuHandleEntity.isDirectSay = true;
			touniuHandleEntity.TouniuBaseBody = this;
			directBehaviorList.Add(touniuHandleEntity);
			touniuHandleEntity.gameObject.SetActive(true);
			return touniuHandleEntity;
		}

		public TouniuShopEntity Shop(int shopId)
		{
			StunRevive();
			TouniuShopEntity touniuShopEntity = TouniuBehaviorManager.Instance.CreateShop(shopId);
			touniuShopEntity.isDirectSay = true;
			touniuShopEntity.TouniuBaseBody = this;
			directBehaviorList.Add(touniuShopEntity);
			touniuShopEntity.gameObject.SetActive(true);
			return touniuShopEntity;
		}

		public void StopMove()
		{
			if (moveTweenerCore != null)
			{
				moveTweenerCore.Kill();
			}
		}

		public void SetHandShortSprite(Sprite sprite = null)
		{
			_handShortSpriteRenderer.sprite = sprite;
		}

		public void SetHandLongSprite(Sprite sprite = null)
		{
			_handLongSpriteRenderer.sprite = sprite;
		}

		public void Remove()
		{
			if (TouniuManager.Instance.touniuBaseBody == this)
			{
				return;
			}
			if (index != -1 && TouniuManager.Instance.touniuCloneDic.ContainsKey(index))
			{
				TouniuManager.Instance.touniuCloneDic.Remove(index);
			}
			UnityEngine.Object.Destroy(base.gameObject);
		}
	}
}
