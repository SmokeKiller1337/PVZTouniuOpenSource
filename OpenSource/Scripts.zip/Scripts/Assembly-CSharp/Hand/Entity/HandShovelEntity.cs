using System.Collections.Generic;
using Land.Entity;
using Plant.Entity;
using UnityEngine;

namespace Hand.Entity
{
	public class HandShovelEntity : HandEntity
	{
		private float _currentLandPositionY;

		protected override void Update()
		{
			base.Update();

			// _currentLandEntity 为空则无需处理铲子高亮
			if (_currentLandEntity == null)
			{
				return;
			}

			// 计算本手（铲子）与当前地皮在世界坐标 Y 上的差值
			float handY = base.transform.position.y;
			Transform landTransform = _currentLandEntity.transform;
			if (landTransform == null)
			{
				return;
			}
			float diff = handY - landTransform.position.y;

			// 仅当本次差值与已记录的 _currentLandPositionY 相比发生了正负号翻转时才刷新高亮，
			// 即 (_currentLandPositionY < 0 && diff > 0) 或 (_currentLandPositionY > 0 && diff < 0)。
			bool signFlipped = (_currentLandPositionY > 0f && diff < 0f) || (_currentLandPositionY < 0f && diff > 0f);
			if (!signFlipped)
			{
				return;
			}

			_currentLandPositionY = diff;

			if (_currentLandList != null)
			{
				// 先清除历史候选地皮的高亮，再高亮当前地皮
				foreach (LandEntity land in _currentLandList)
				{
					if (land != null)
					{
						land.ShovelHighlight(false);
					}
				}
				if (_currentLandEntity != null)
				{
					_currentLandEntity.ShovelHighlight(true, diff);
				}
			}
		}

		protected override void OnPickUp()
		{
			// TODO: reconstruct — 原实现操作 FairyGUI 卡槽盒 UI（CardSlotBoxEntity.GetCurrentCardSlot
			// 取得当前卡槽 GComponent，再取其若干子按钮，按多个无法解析的全局管理器单例
			// (_DAT_182e73f40 / _DAT_182e7d978 / _DAT_182e52f70) 的裸偏移字段设置按钮可见性、
			// alpha 与文本)。这些全局对象与其内部内存布局无法可靠还原，若强行重建会引用
			// 不存在的成员，故保留桩实现。
		}

		protected override void OnDrop()
		{
			// TODO: reconstruct — 与 OnPickUp 逻辑几乎一致（同样通过 FairyGUI 卡槽盒 UI 与多个
			// 无法解析的全局管理器单例裸偏移操作按钮可见性 / alpha / 文本）。无法可靠还原，保留桩实现。
		}

		protected override bool OnUse()
		{
			// 当前地皮为空则直接放下铲子
			if (_currentLandEntity == null)
			{
				base.Drop(true);
				return false;
			}

			// 根据当前铲子与地皮的相对高度取要铲除的植物
			PlantEntity plant = _currentLandEntity.GetShovelPlant(_currentLandPositionY);
			if (plant != null)
			{
				// 植物属性存在且允许被铲除时，铲掉该植物并视为“已使用”
				if (plant.attr != null && !plant.attr.isNotShovel)
				{
					plant.Clear();
					return true;
				}
			}

			// 未铲除任何植物：放下铲子
			base.Drop(true);
			return false;
		}

		protected override void OnEnterLand(LandEntity landEntity)
		{
			if (_currentLandList != null)
			{
				// 先清除其它候选地皮的高亮
				foreach (LandEntity land in _currentLandList)
				{
					if (land != null)
					{
						land.ShovelHighlight(false);
					}
				}
				// 高亮新进入的地皮
				if (landEntity != null)
				{
					landEntity.ShovelHighlight(true, _currentLandPositionY);
				}
			}
		}

		protected override void OnExitLand(LandEntity landEntity)
		{
			if (landEntity == null)
			{
				return;
			}

			// 离开地皮时取消该地皮各层植物的高亮
			// 伪代码依次访问 landEntity 的 floatPlant(0x48) / masterPlant(0x30)
			// / shellPlant(0x38) / basePlant(0x40)，对每个非空植物调用 BaseBody.Highlight(false)。
			if (landEntity.floatPlant != null)
			{
				landEntity.floatPlant.Highlight(false);
			}
			if (landEntity.masterPlant != null)
			{
				landEntity.masterPlant.Highlight(false);
			}
			if (landEntity.shellPlant != null)
			{
				landEntity.shellPlant.Highlight(false);
			}
			if (landEntity.basePlant != null)
			{
				landEntity.basePlant.Highlight(false);
			}
		}
	}
}
