using System.Collections.Generic;
using Land.Entity;
using Plant.Entity;
using UnityEngine;

namespace Hand.Entity
{
	public class HandShovelEntity : HandEntity
	{
		private float _currentLandPositionY;

		protected override void Update()
		{
			base.Update();

			// _currentLandEntity 为空则无需处理铲子高亮
			if (_currentLandEntity == null)
			{
				return;
			}

			// 计算本手（铲子）与当前地皮在世界坐标 Y 上的差值
			float handY = base.transform.position.y;
			Transform landTransform = _currentLandEntity.transform;
			if (landTransform == null)
			{
				return;
			}
			float diff = handY - landTransform.position.y;

			// 仅当本次差值与已记录的 _currentLandPositionY 相比发生了正负号翻转时才刷新高亮，
			// 即 (_currentLandPositionY < 0 && diff > 0) 或 (_currentLandPositionY > 0 && diff < 0)。
			bool signFlipped = (_currentLandPositionY > 0f && diff < 0f) || (_currentLandPositionY < 0f && diff > 0f);
			if (!signFlipped)
			{
				return;
			}

			_currentLandPositionY = diff;

			if (_currentLandList != null)
			{
				// 先清除历史候选地皮的高亮，再高亮当前地皮
				foreach (LandEntity land in _currentLandList)
				{
					if (land != null)
					{
						land.ShovelHighlight(false);
					}
				}
				if (_currentLandEntity != null)
				{
					_currentLandEntity.ShovelHighlight(true, diff);
				}
			}
		}

		protected override void OnPickUp()
		{
		}

		protected override void OnDrop()
		{
		}

		protected override bool OnUse()
		{
			// 当前地皮为空则直接放下铲子
			if (_currentLandEntity == null)
			{
				base.Drop(true);
				return false;
			}

			// 根据当前铲子与地皮的相对高度取要铲除的植物
			PlantEntity plant = _currentLandEntity.GetShovelPlant(_currentLandPositionY);
			if (plant != null)
			{
				// 植物属性存在且允许被铲除时，铲掉该植物并视为“已使用”
				if (plant.attr != null && !plant.attr.isNotShovel)
				{
					plant.Clear();
					return true;
				}
			}

			// 未铲除任何植物：放下铲子
			base.Drop(true);
			return false;
		}

		protected override void OnEnterLand(LandEntity landEntity)
		{
			if (_currentLandList != null)
			{
				// 先清除其它候选地皮的高亮
				foreach (LandEntity land in _currentLandList)
				{
					if (land != null)
					{
						land.ShovelHighlight(false);
					}
				}
				// 高亮新进入的地皮
				if (landEntity != null)
				{
					landEntity.ShovelHighlight(true, _currentLandPositionY);
				}
			}
		}

		protected override void OnExitLand(LandEntity landEntity)
		{
			if (landEntity == null)
			{
				return;
			}

			if (landEntity.floatPlant != null)
			{
				landEntity.floatPlant.Highlight(false);
			}
			if (landEntity.masterPlant != null)
			{
				landEntity.masterPlant.Highlight(false);
			}
			if (landEntity.shellPlant != null)
			{
				landEntity.shellPlant.Highlight(false);
			}
			if (landEntity.basePlant != null)
			{
				landEntity.basePlant.Highlight(false);
			}
		}
	}
}
