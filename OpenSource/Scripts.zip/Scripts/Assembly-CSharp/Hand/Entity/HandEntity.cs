using System;
using System.Collections.Generic;
using Audio.Manager;
using Land.Entity;
using Level.Manager;
using UnityEngine;

namespace Hand.Entity
{
	public abstract class HandEntity : MonoBehaviour
	{
		[Tooltip("拿起音效")]
		public AudioClip pickUpSound;

		[Tooltip("放下音效")]
		public AudioClip dropSound;

		[Tooltip("使用音效")]
		public AudioClip useSound;

		protected LandEntity _currentLandEntity;

		// 伪代码 .ctor: *(this + 0x40) = new List<LandEntity>()
		protected List<LandEntity> _currentLandList = new List<LandEntity>();

		protected SpriteRenderer _spriteRenderer;

		public Action<HandEntity> OnUseAction;

		public LandEntity CurrentLandEntity
		{
			get
			{
				return _currentLandEntity;
			}
			set
			{
				_currentLandEntity = value;
			}
		}

		public SpriteRenderer spriteRenderer
		{
			get
			{
				return _spriteRenderer;
			}
			set
			{
				_spriteRenderer = value;
			}
		}

		protected virtual void Awake()
		{
			_spriteRenderer = GetComponent<SpriteRenderer>();
		}

		protected virtual void Start()
		{
		}

		protected virtual void Update()
		{
			if (_currentLandList == null)
			{
				return;
			}
			if (_currentLandList.Count < 1)
			{
				// 手上没有任何可交互地皮时，退出当前地皮
				ExitLand(_currentLandEntity);
				return;
			}
			// 在候选地皮列表中挑选距离本物体最近的一块地皮
			LandEntity closest = _currentLandEntity;
			float minDistance = float.MaxValue;
			foreach (LandEntity landEntity in _currentLandList)
			{
				float distance = Vector2.Distance(landEntity.transform.position, base.transform.position);
				if (distance < minDistance)
				{
					closest = landEntity;
					minDistance = distance;
				}
			}
			if (closest != _currentLandEntity)
			{
				if (_currentLandEntity != null)
				{
					ExitLand(_currentLandEntity);
				}
				EnterLand(closest);
			}
		}

		public virtual void HandUpdate()
		{
		}

		protected abstract void OnPickUp();

		protected abstract void OnDrop();

		protected abstract bool OnUse();

		protected abstract void OnEnterLand(LandEntity landEntity);

		protected abstract void OnExitLand(LandEntity landEntity);

		public void PickUp()
		{
			AudioManager.Instance.PlayUI(pickUpSound);
			OnPickUp();
		}

		public void Drop(bool isDropSound = true)
		{
			if (isDropSound)
			{
				AudioManager.Instance.PlayUI(dropSound);
			}
			// 伪代码: HandManager.Instance.dropHandEntity = this (写 offset 0x58)
			HandManager.Instance.dropHandEntity = this;
			HandManager.Instance.ChangeHandEntity(null);
			OnDrop();
			base.transform.localPosition = Vector3.zero;
		}

		public void Use()
		{
			if (!OnUse())
			{
				return;
			}
			AudioManager.Instance.PlayUI(useSound);
			if (OnUseAction != null)
			{
				OnUseAction(this);
			}
			// 伪代码: HandManager.Instance.dropHandEntity = this (写 offset 0x58)
			HandManager.Instance.dropHandEntity = this;
			HandManager.Instance.ChangeHandEntity(null);
			OnDrop();
			base.transform.localPosition = Vector3.zero;
		}

		private void OnTriggerEnter2D(Collider2D col)
		{
			LandEntity landEntity = col.gameObject.GetComponent<LandEntity>();
			if (landEntity != null && !_currentLandList.Contains(landEntity))
			{
				_currentLandList.Add(landEntity);
			}
		}

		private void OnTriggerExit2D(Collider2D col)
		{
			LandEntity landEntity = col.gameObject.GetComponent<LandEntity>();
			if (landEntity != null)
			{
				_currentLandList.Remove(landEntity);
			}
		}

		protected virtual void EnterLand(LandEntity landEntity)
		{
			if (landEntity != null)
			{
				_currentLandEntity = landEntity;
				OnEnterLand(landEntity);
			}
		}

		protected virtual void ExitLand(LandEntity landEntity)
		{
			if (landEntity != null)
			{
				OnExitLand(landEntity);
				if (_currentLandList.Count < 1)
				{
					_currentLandEntity = null;
				}
			}
		}
	}
}
