using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Building.Entity;
using Game.Entity;
using Game.Util;
using Land.Entity;
using Level.Manager;
using Touniu.Entity.Body;
using UnityEngine;

namespace Hand.Entity
{
	public class HandHammerEntity : HandEntity
	{
		[CompilerGenerated]
		private sealed class _003CHammerPotCoroutine_003Ed__9 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public HandHammerEntity _003C_003E4__this;

			public PotEntity potEntity;

			private Vector3 _003Cposition_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CHammerPotCoroutine_003Ed__9(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				HandHammerEntity handHammer = this._003C_003E4__this;
				switch (this._003C_003E1__state)
				{
				default:
					return false;
				case 0:
					this._003C_003E1__state = -1;
					// 记录锤子当前位置并在此处生成锤击特效，等待一小段时间后判定命中
					this._003Cposition_003E5__2 = handHammer.transform.position;
					GameUtils.CreateEffect(handHammer.hammerEffect, this._003Cposition_003E5__2, Quaternion.identity);
					this._003C_003E2__current = new WaitForSeconds(HammerHitDelay);
					this._003C_003E1__state = 1;
					return true;
				case 1:
					this._003C_003E1__state = -1;
					if (this.potEntity != null)
					{
						if (!this.potEntity.IsBreak)
						{
							// 罐子尚未打碎：生成击中特效并打碎罐子
							GameUtils.CreateEffect(handHammer.hitEffect, this._003Cposition_003E5__2, Quaternion.identity);
							this.potEntity.BreakPot();
							return false;
						}
						// 罐子已打碎（无效命中）：返还一次锤子次数
						CardSlotManager instance = CardSlotManager.Instance;
						if (instance != null)
						{
							instance.HammerValue++;
						}
					}
					return false;
				}
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CHammerTouniuCoroutine_003Ed__8 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public HandHammerEntity _003C_003E4__this;

			public TouniuBaseBody touniuBaseBody;

			private Vector3 _003Cposition_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CHammerTouniuCoroutine_003Ed__8(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				HandHammerEntity handHammer = this._003C_003E4__this;
				switch (this._003C_003E1__state)
				{
				default:
					return false;
				case 0:
					this._003C_003E1__state = -1;
					// 记录锤子当前位置并在此处生成锤击特效，等待一小段时间后判定命中
					this._003Cposition_003E5__2 = handHammer.transform.position;
					GameUtils.CreateEffect(handHammer.hammerEffect, this._003Cposition_003E5__2, Quaternion.identity);
					this._003C_003E2__current = new WaitForSeconds(HammerHitDelay);
					this._003C_003E1__state = 1;
					return true;
				case 1:
					this._003C_003E1__state = -1;
					if (this.touniuBaseBody != null)
					{
						EffectEntity effect;
						if (!this.touniuBaseBody.IsInvalidStun)
						{
							// 有效命中：生成击中特效并将偷牛眩晕
							effect = handHammer.hitEffect;
						}
						else
						{
							// 无效命中：返还一次锤子次数并生成无效特效
							CardSlotManager instance = CardSlotManager.Instance;
							if (instance != null)
							{
								instance.HammerValue++;
							}
							effect = handHammer.invalidEffect;
						}
						GameUtils.CreateEffect(effect, this._003Cposition_003E5__2, Quaternion.identity);
						if (this.touniuBaseBody != null)
						{
							this.touniuBaseBody.Stun();
						}
					}
					return false;
				}
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		// 锤击特效生成到命中判定之间的等待时间。
		// 原始值为一个无法解析的数据常量 (_UNK_18252ce78)，此处使用占位值。
		// TODO: resolve real WaitForSeconds duration (native _UNK_18252ce78)
		private const float HammerHitDelay = 0.1f;

		[Tooltip("锤子效果")]
		public EffectEntity hammerEffect;

		[Tooltip("击中效果")]
		public EffectEntity hitEffect;

		[Tooltip("无效效果")]
		public EffectEntity invalidEffect;

		[HideInInspector]
		public TouniuBaseBody targetTouniuBody;

		protected override void OnPickUp()
		{
			// TODO: reconstruct - 原方法通过 GameManager.Instance.CardSlotBox 取到卡槽盒，
			// 刷新三个道具按钮(阳光炮/铲子/锤子)的显隐与透明度并写入锤子数量。
			// GameManager 没有 CardSlotBox 成员，且 CardSlotBoxEntity 上被引用的成员均为臆造，
			// 无法可靠还原，保留桩实现。
		}

		protected override void OnDrop()
		{
			// TODO: reconstruct - 原方法先调用 GameManager.Instance.CardSlotBox.UpdateTool()，
			// 但 GameManager 没有 CardSlotBox 成员，该调用链无法还原。
			// 可靠还原的部分：退出当前锁定的偷牛。
			ExitTouniu();
		}

		protected override void Update()
		{
			base.Update();
			// TODO: reconstruct - 原方法在锤子为当前手持物时，遍历僵尸管理器中的偷牛集合
			// 寻找最近目标并高亮/解除高亮。该逻辑依赖多个无法解析的全局管理器单例
			// (_DAT_182e7d978 / _DAT_182e65eb0 及其偏移成员)，且涉及被 ICF 折叠的字典遍历，
			// 无法可靠还原，保留为仅调用基类 Update。
		}

		protected override bool OnUse()
		{
			CardSlotManager cardSlot = CardSlotManager.Instance;
			if (cardSlot == null)
			{
				return false;
			}
			// 没有剩余锤子次数：直接放下锤子
			if (cardSlot.HammerValue < 1)
			{
				Drop();
				return false;
			}
			// 已锁定偷牛目标：消耗一次锤子次数并对该偷牛执行锤击协程
			if (targetTouniuBody != null)
			{
				cardSlot.HammerValue--;
				StartCoroutine(HammerTouniuCoroutine(targetTouniuBody));
				return true;
			}
			// 未锁定偷牛：检查当前地皮上的建筑物是否为可锤击的罐子
			if (_currentLandEntity != null && _currentLandEntity.masterBuilding is PotEntity potEntity && potEntity != null)
			{
				cardSlot.HammerValue--;
				StartCoroutine(HammerPotCoroutine(potEntity));
				return true;
			}
			// 无有效目标：放下锤子
			Drop();
			return false;
		}

		[IteratorStateMachine(typeof(_003CHammerTouniuCoroutine_003Ed__8))]
		private IEnumerator HammerTouniuCoroutine(TouniuBaseBody touniuBaseBody)
		{
			_003CHammerTouniuCoroutine_003Ed__8 stateMachine = new _003CHammerTouniuCoroutine_003Ed__8(0);
			stateMachine._003C_003E4__this = this;
			stateMachine.touniuBaseBody = touniuBaseBody;
			return stateMachine;
		}

		[IteratorStateMachine(typeof(_003CHammerPotCoroutine_003Ed__9))]
		private IEnumerator HammerPotCoroutine(PotEntity potEntity)
		{
			_003CHammerPotCoroutine_003Ed__9 stateMachine = new _003CHammerPotCoroutine_003Ed__9(0);
			stateMachine._003C_003E4__this = this;
			stateMachine.potEntity = potEntity;
			return stateMachine;
		}

		protected override void OnEnterLand(LandEntity landEntity)
		{
			// 先清除当前所有地皮的锤击高亮，再高亮进入的这块地皮
			if (_currentLandList != null)
			{
				foreach (LandEntity land in _currentLandList)
				{
					if (land != null)
					{
						land.HammerHighlight(false);
					}
				}
			}
			if (landEntity != null)
			{
				landEntity.HammerHighlight(true);
			}
		}

		protected override void OnExitLand(LandEntity landEntity)
		{
			// 离开地皮时，如果该地皮上的建筑物是罐子则解除其高亮
			if (landEntity != null && landEntity.masterBuilding is PotEntity potEntity)
			{
				potEntity.Highlight(false);
			}
		}

		private void EnterTouniu(TouniuBaseBody touniuBaseBody)
		{
			// 锁定新的偷牛目标：先退出旧目标，再高亮新目标
			if (targetTouniuBody != touniuBaseBody)
			{
				ExitTouniu();
			}
			targetTouniuBody = touniuBaseBody;
			if (targetTouniuBody == null)
			{
				return;
			}
			// TODO: reconstruct - 原方法随后将目标偷牛标记为选中并遍历其渲染器集合
			// (targetTouniuBody 偏移 0x150 / 0x108) 设置材质浮点参数用于描边高亮。
			// 这些成员未在 TouniuBaseBody 的还原骨架中公开，无法可靠映射，保留高亮以外的部分为空。
			targetTouniuBody.Highlight(true);
		}

		private void ExitTouniu()
		{
			// 解除当前锁定偷牛的高亮并清空引用
			if (targetTouniuBody != null)
			{
				targetTouniuBody.Highlight(false);
			}
			targetTouniuBody = null;
		}
	}
}
