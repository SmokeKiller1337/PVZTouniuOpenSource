using System;
using System.Collections;
using System.Collections.Generic;
using Building.Entity;
using Game.Entity;
using Game.Util;
using Land.Entity;
using Level.Manager;
using Touniu.Entity.Body;
using UnityEngine;

namespace Hand.Entity
{
	public class HandHammerEntity : HandEntity
	{
		private const float HammerHitDelay = 0.1f;

		[Tooltip("锤子效果")]
		public EffectEntity hammerEffect;

		[Tooltip("击中效果")]
		public EffectEntity hitEffect;

		[Tooltip("无效效果")]
		public EffectEntity invalidEffect;

		[HideInInspector]
		public TouniuBaseBody targetTouniuBody;

		protected override void OnPickUp()
		{
		}

		protected override void OnDrop()
		{
			ExitTouniu();
		}

		protected override void Update()
		{
			base.Update();
		}

		protected override bool OnUse()
		{
			CardSlotManager cardSlot = CardSlotManager.Instance;
			if (cardSlot == null)
			{
				return false;
			}
			// 没有剩余锤子次数：直接放下锤子
			if (cardSlot.HammerValue < 1)
			{
				Drop();
				return false;
			}
			// 已锁定偷牛目标：消耗一次锤子次数并对该偷牛执行锤击协程
			if (targetTouniuBody != null)
			{
				cardSlot.HammerValue--;
				StartCoroutine(HammerTouniuCoroutine(targetTouniuBody));
				return true;
			}
			// 未锁定偷牛：检查当前地皮上的建筑物是否为可锤击的罐子
			if (_currentLandEntity != null && _currentLandEntity.masterBuilding is PotEntity potEntity && potEntity != null)
			{
				cardSlot.HammerValue--;
				StartCoroutine(HammerPotCoroutine(potEntity));
				return true;
			}
			// 无有效目标：放下锤子
			Drop();
			return false;
		}

		private IEnumerator HammerTouniuCoroutine(TouniuBaseBody touniuBaseBody)
		{
			// 记录锤子当前位置并在此处生成锤击特效，等待一小段时间后判定命中
			Vector3 position = transform.position;
			GameUtils.CreateEffect(hammerEffect, position, Quaternion.identity);
			yield return new WaitForSeconds(HammerHitDelay);
			if (touniuBaseBody != null)
			{
				EffectEntity effect;
				if (!touniuBaseBody.IsInvalidStun)
				{
					// 有效命中：生成击中特效并将偷牛眩晕
					effect = hitEffect;
				}
				else
				{
					// 无效命中：返还一次锤子次数并生成无效特效
					CardSlotManager instance = CardSlotManager.Instance;
					if (instance != null)
					{
						instance.HammerValue++;
					}
					effect = invalidEffect;
				}
				GameUtils.CreateEffect(effect, position, Quaternion.identity);
				if (touniuBaseBody != null)
				{
					touniuBaseBody.Stun();
				}
			}
		}

		private IEnumerator HammerPotCoroutine(PotEntity potEntity)
		{
			// 记录锤子当前位置并在此处生成锤击特效，等待一小段时间后判定命中
			Vector3 position = transform.position;
			GameUtils.CreateEffect(hammerEffect, position, Quaternion.identity);
			yield return new WaitForSeconds(HammerHitDelay);
			if (potEntity != null)
			{
				if (!potEntity.IsBreak)
				{
					// 罐子尚未打碎：生成击中特效并打碎罐子
					GameUtils.CreateEffect(hitEffect, position, Quaternion.identity);
					potEntity.BreakPot();
					yield break;
				}
				// 罐子已打碎（无效命中）：返还一次锤子次数
				CardSlotManager instance = CardSlotManager.Instance;
				if (instance != null)
				{
					instance.HammerValue++;
				}
			}
		}

		protected override void OnEnterLand(LandEntity landEntity)
		{
			// 先清除当前所有地皮的锤击高亮，再高亮进入的这块地皮
			if (_currentLandList != null)
			{
				foreach (LandEntity land in _currentLandList)
				{
					if (land != null)
					{
						land.HammerHighlight(false);
					}
				}
			}
			if (landEntity != null)
			{
				landEntity.HammerHighlight(true);
			}
		}

		protected override void OnExitLand(LandEntity landEntity)
		{
			// 离开地皮时，如果该地皮上的建筑物是罐子则解除其高亮
			if (landEntity != null && landEntity.masterBuilding is PotEntity potEntity)
			{
				potEntity.Highlight(false);
			}
		}

		private void EnterTouniu(TouniuBaseBody touniuBaseBody)
		{
			// 锁定新的偷牛目标：先退出旧目标，再高亮新目标
			if (targetTouniuBody != touniuBaseBody)
			{
				ExitTouniu();
			}
			targetTouniuBody = touniuBaseBody;
			if (targetTouniuBody == null)
			{
				return;
			}
			targetTouniuBody.Highlight(true);
		}

		private void ExitTouniu()
		{
			// 解除当前锁定偷牛的高亮并清空引用
			if (targetTouniuBody != null)
			{
				targetTouniuBody.Highlight(false);
			}
			targetTouniuBody = null;
		}
	}
}
