using Land.Entity;

namespace Hand.Entity
{
	public class HandPowerEntity : HandEntity
	{
		protected override void OnPickUp()
		{
		}

		protected override void OnDrop()
		{
		}

		protected override bool OnUse()
		{
			return false;
		}

		protected override void OnEnterLand(LandEntity landEntity)
		{
			if (_currentLandList != null)
			{
				foreach (LandEntity land in _currentLandList)
				{
					land.PowerHighlight(false);
				}
				if (landEntity != null)
				{
					landEntity.PowerHighlight(true);
				}
			}
		}

		protected override void OnExitLand(LandEntity landEntity)
		{
			if (landEntity == null)
			{
				return;
			}
			if (landEntity.masterPlant != null)
			{
				landEntity.masterPlant.Highlight(false);
			}
		}
	}
}
