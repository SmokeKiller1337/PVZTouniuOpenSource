using Land.Entity;

namespace Hand.Entity
{
	public class HandPowerEntity : HandEntity
	{
		protected override void OnPickUp()
		{
			// TODO: reconstruct — 该方法整段是 FairyGUI 卡槽盒(CardSlotBoxEntity)的 UI 刷新逻辑：
			// 通过全局游戏/UI 管理器单例取当前卡槽 GComponent，按若干子控件名(均为无法解析的
			// 数据指针)取三个 GButton 与一个 GTextField，再依据另一个全局状态单例
			// (_DAT_182e7d978 + 0xb8) 的 bool/int 字段(0x41/0x42/0x43/0x88) 设置各控件的
			// visible/alpha/text。涉及的子控件名字符串常量与管理器成员均无法从 dump 可靠确认，
			// 强行还原会引用不存在的成员或臆造字面量，故保留桩实现。
		}

		protected override void OnDrop()
		{
			// TODO: reconstruct — 与 OnPickUp 完全相同的 FairyGUI 卡槽 UI 刷新逻辑
			// (ICF 折叠所致函数体一致)。同样依赖无法解析的子控件名与全局状态单例成员，
			// 保留桩实现以免产出错误逻辑或臆造成员。
		}

		protected override bool OnUse()
		{
			// TODO: reconstruct — 该方法在 _currentLandEntity.masterPlant / 其 CardEntity 上做多重判定后，
			// 通过三个 ICF 折叠的 PlantEntity 虚表调用(vtable +0x478/+0x528/+0x538，疑似
			// UsePower / IsSpecialAvailable / UseSpecialSkill 之类，但槽位映射无法 100% 确认)
			// 决定返回 true/false，并在回退分支调用 HandEntity.Drop(true) + AudioManager.PlayUI。
			// 由于关键分支依赖无法可靠还原的虚表分派，其返回值(道具是否被使用)会被错误重建，
			// 按“宁可留桩，绝不臆造”原则保留桩实现。
			return false;
		}

		protected override void OnEnterLand(LandEntity landEntity)
		{
			// 进入地皮：先取消已记录的所有地皮的能量高亮，再高亮当前进入的地皮。
			// 伪代码: 遍历 _currentLandList(字段 @0x40) 对每个元素 PowerHighlight(false)，
			//        随后若 landEntity 非空则 PowerHighlight(true)。
			if (_currentLandList != null)
			{
				foreach (LandEntity land in _currentLandList)
				{
					land.PowerHighlight(false);
				}
				if (landEntity != null)
				{
					landEntity.PowerHighlight(true);
				}
			}
		}

		protected override void OnExitLand(LandEntity landEntity)
		{
			// 离开地皮：若该地皮存在主植物，则取消其高亮。
			// 伪代码: masterPlant = landEntity(param_2) + 0x30；
			//        if (masterPlant != null) BaseBody.Highlight(masterPlant, false)。
			if (landEntity == null)
			{
				return;
			}
			if (landEntity.masterPlant != null)
			{
				landEntity.masterPlant.Highlight(false);
			}
		}
	}
}
