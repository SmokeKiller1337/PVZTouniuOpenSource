using FGUI;
using FGUI.Entity.UI;
using Land.Entity;
using Level.Manager;
using Level.Util;
using Plant.Entity;
using Plant.Entity.Card;
using Plant.Enum;
using UnityEngine;

// NOTE: Reconstructed from IL2CPP/Ghidra output for Hand.Entity.HandCardEntity.
// The structure below (namespace, usings, class/base, fields, method signatures) is
// taken verbatim from the authoritative stub.cs / dump.cs and is NOT modified.
//
// Field offset map (from dump.cs + base HandEntity):
//   base HandEntity: _currentLandEntity @0x38, _currentLandList @0x40,
//                    _spriteRenderer @0x48, OnUseAction @0x50
//   this:            cardId @0x58, cardEntity @0x60, seedCardEntity @0x68
//
// The UI singleton the pseudocode reaches through the global data pointers
// (_DAT_182e47708 -> +0xb8 -> +0x18 / +0x20, with a boolean at +0x80) is the
// FairyGUI CardSlotBox held in the static FGUIConstant.CardSlotBox field. The
// public entry points DropCard / PickUpCard / DropConveyorCard / PickUpConveyorCard
// (all taking a CardEntity) are real and are used below. The boolean flag at
// +0x80 that selects the normal vs. conveyor branch could NOT be mapped to any
// verified member of CardSlotBoxEntity, so the normal-card branch (the default
// case) is reconstructed and the conveyor branch is documented as unrecoverable
// rather than fabricating a member.

namespace Hand.Entity
{
	public class HandCardEntity : HandEntity
	{
		[Tooltip("卡牌id")]
		public int cardId;

		[Tooltip("卡牌实体")]
		public CardEntity cardEntity;

		[Tooltip("种子雨卡牌实体")]
		public SeedCardEntity seedCardEntity;

		protected override void OnPickUp()
		{
			// Refresh the hand sprite to the picked-up card's art.
			// (The localScale block in the pseudocode multiplies by unmapped global
			//  magic constants _DAT_18252cb28/_DAT_18252ce84/_DAT_18252cb70 gated on a
			//  giant-plant flag; those globals cannot be resolved, so the scale tweak
			//  is intentionally omitted rather than fabricated.)
			// TODO: reconstruct pick-up scale adjustment (unmapped scale constants).
			if (_spriteRenderer != null)
			{
				_spriteRenderer.sprite = LevelUtils.GetCardSprite(cardId);
			}

			if (seedCardEntity != null)
			{
				// Seed-rain card: delegate to the seed card entity.
				seedCardEntity.PickUp();
			}
			else
			{
				// Normal card: notify the FairyGUI card-slot UI.
				// The pseudocode selects DropCard vs DropConveyorCard via a boolean at
				// CardSlotBox +0x80 (conveyor mode) that could not be mapped to a
				// verified member; the normal branch is reconstructed here.
				// TODO: reconstruct conveyor-mode branch (PickUpConveyorCard).
				CardSlotBoxEntity cardSlotBox = FGUIConstant.CardSlotBox;
				if (cardSlotBox != null)
				{
					cardSlotBox.PickUpCard(cardEntity);
				}
			}
		}

		protected override void OnDrop()
		{
			if (seedCardEntity == null)
			{
				// Normal card: notify the FairyGUI card-slot UI that the card was
				// dropped. The pseudocode picks DropCard vs DropConveyorCard via the
				// unmapped conveyor-mode flag at CardSlotBox +0x80; the normal branch
				// is reconstructed here.
				// TODO: reconstruct conveyor-mode branch (DropConveyorCard).
				CardSlotBoxEntity cardSlotBox = FGUIConstant.CardSlotBox;
				if (cardSlotBox != null)
				{
					cardSlotBox.DropCard(cardEntity);
				}
			}
			else
			{
				// Seed-rain card: delegate to the seed card entity.
				seedCardEntity.Drop();
			}

			seedCardEntity = null;
		}

		public override void HandUpdate()
		{
			// Mirror the current hand sprite onto the card-ghost renderer and, when a
			// land is targeted, update the placement-preview ghost through the
			// HandManager. The pseudocode reads the ghost renderer through the
			// HandManager singleton (_DAT_182e7d978 -> +0xb8 -> +0x50 == cardGhost).
			HandManager handManager = HandManager.Instance;
			if (handManager == null)
			{
				return;
			}

			SpriteRenderer cardGhost = handManager.cardGhost;
			if (_spriteRenderer == null || cardGhost == null)
			{
				return;
			}

			cardGhost.sprite = _spriteRenderer.sprite;

			if (_currentLandEntity != null)
			{
				// Show/hide the placement preview depending on whether the card can be
				// planted on the currently targeted land.
				if (_currentLandEntity.IsPlaceable(cardEntity))
				{
					handManager.ChangeCardGhost(_currentLandEntity);
				}
				else
				{
					handManager.ChangeCardGhost(null);
				}
			}

			// A seed-rain card that is no longer picked up should be dropped.
			if (seedCardEntity != null && !seedCardEntity.IsPickUp)
			{
				Drop();
			}
		}

		protected override bool OnUse()
		{
			// No land targeted -> nothing to plant, just drop.
			if (_currentLandEntity == null)
			{
				Drop();
				return false;
			}

			if (cardEntity == null)
			{
				return false;
			}

			// The pseudocode branches on cardEntity.type (field @0x44 in that object):
			// types 0/1/2 (Normal/Guest/Special) place a plant, type 3 (Zombie) places
			// a zombie. The interleaving conveyor / cost / sun-availability guards that
			// precede this read through the unmapped CardSlotBox conveyor flag and
			// several unresolved global singletons, so only the verifiable place-plant /
			// place-zombie dispatch and the post-placement seed/UI handling are
			// reconstructed here.
			CardType cardType = cardEntity.type;
			if (cardType == CardType.Zombie)
			{
				ZombieManager zombieManager = ZombieManager.Instance;
				if (zombieManager == null)
				{
					return false;
				}
				if (!zombieManager.PlaceZombie((CardZombieEntity)cardEntity, _currentLandEntity, seedCardEntity))
				{
					return false;
				}
			}
			else
			{
				PlantManager plantManager = PlantManager.Instance;
				if (plantManager == null)
				{
					return false;
				}
				if (!plantManager.PlacePlant(cardEntity, _currentLandEntity, seedCardEntity))
				{
					return false;
				}
			}

			if (seedCardEntity != null)
			{
				// Seed-rain card: release it back to the pool.
				seedCardEntity.Release();
				return true;
			}

			// Normal card placed successfully. The pseudocode then, in conveyor mode,
			// calls CardSlotManager.LeaveConveyorCard(cardEntity); the conveyor-mode
			// flag (CardSlotBox +0x80) is unmapped, so only the non-conveyor success
			// path is reconstructed.
			// TODO: reconstruct conveyor-mode leave (CardSlotManager.LeaveConveyorCard).
			return true;
		}

		protected override void OnEnterLand(LandEntity landEntity)
		{
			if (landEntity == null)
			{
				return;
			}

			HandManager handManager = HandManager.Instance;
			if (handManager == null)
			{
				return;
			}

			// Toggle the placement-preview ghost when hovering a land: if the card can
			// be planted here, show it on this land; otherwise clear it.
			// The full pseudocode additionally repositions/rescales the ghost sprite by
			// reading through several unmapped level/UI singletons and global offset
			// constants (giant-plant offset via _DAT_182e70d90, _DAT_18252cb64, etc.);
			// those cannot be resolved, so only the verifiable ChangeCardGhost toggle is
			// reconstructed.
			// TODO: reconstruct ghost sprite reposition/rescale (unmapped globals).
			if (landEntity.IsPlaceable(cardEntity))
			{
				handManager.ChangeCardGhost(landEntity);
			}
			else
			{
				handManager.ChangeCardGhost(null);
			}
		}

		protected override void OnExitLand(LandEntity landEntity)
		{
			if (landEntity == null)
			{
				return;
			}

			// Only clear the preview if we are leaving the land we are actually
			// targeting (pseudocode compares _currentLandEntity @0x38 with landEntity).
			if (_currentLandEntity != landEntity)
			{
				return;
			}

			HandManager handManager = HandManager.Instance;
			if (handManager == null)
			{
				return;
			}

			handManager.ChangeCardGhost(null);
		}

		protected override void EnterLand(LandEntity landEntity)
		{
			// Guarded by land validity; sets the current land and fires OnEnterLand.
			// The pseudocode gates on an unmapped 4-byte field at LandEntity +0x24
			// (no verified named member maps to that offset), which is omitted here.
			if (landEntity == null)
			{
				return;
			}

			_currentLandEntity = landEntity;
			OnEnterLand(landEntity);
		}

		protected override void ExitLand(LandEntity landEntity)
		{
			// Fires OnExitLand, then clears the current land once no lands remain in the
			// tracked land list (pseudocode checks _currentLandList.Count < 1 @0x40/+0x18).
			// The pseudocode gates on the same unmapped LandEntity +0x24 field, omitted.
			if (landEntity == null)
			{
				return;
			}

			OnExitLand(landEntity);

			if (_currentLandList == null || _currentLandList.Count < 1)
			{
				_currentLandEntity = null;
			}
		}
	}
}
