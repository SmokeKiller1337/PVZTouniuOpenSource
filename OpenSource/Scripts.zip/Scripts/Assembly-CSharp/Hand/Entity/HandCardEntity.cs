using FGUI;
using FGUI.Entity.UI;
using Land.Entity;
using Level.Manager;
using Level.Util;
using Plant.Entity;
using Plant.Entity.Card;
using Plant.Enum;
using UnityEngine;

namespace Hand.Entity
{
	public class HandCardEntity : HandEntity
	{
		[Tooltip("卡牌id")]
		public int cardId;

		[Tooltip("卡牌实体")]
		public CardEntity cardEntity;

		[Tooltip("种子雨卡牌实体")]
		public SeedCardEntity seedCardEntity;

		protected override void OnPickUp()
		{
			if (_spriteRenderer != null)
			{
				_spriteRenderer.sprite = LevelUtils.GetCardSprite(cardId);
			}

			if (seedCardEntity != null)
			{
				// Seed-rain card: delegate to the seed card entity.
				seedCardEntity.PickUp();
			}
			else
			{
				CardSlotBoxEntity cardSlotBox = FGUIConstant.CardSlotBox;
				if (cardSlotBox != null)
				{
					cardSlotBox.PickUpCard(cardEntity);
				}
			}
		}

		protected override void OnDrop()
		{
			if (seedCardEntity == null)
			{
				CardSlotBoxEntity cardSlotBox = FGUIConstant.CardSlotBox;
				if (cardSlotBox != null)
				{
					cardSlotBox.DropCard(cardEntity);
				}
			}
			else
			{
				// Seed-rain card: delegate to the seed card entity.
				seedCardEntity.Drop();
			}

			seedCardEntity = null;
		}

		public override void HandUpdate()
		{
			HandManager handManager = HandManager.Instance;
			if (handManager == null)
			{
				return;
			}

			SpriteRenderer cardGhost = handManager.cardGhost;
			if (_spriteRenderer == null || cardGhost == null)
			{
				return;
			}

			cardGhost.sprite = _spriteRenderer.sprite;

			if (_currentLandEntity != null)
			{
				// Show/hide the placement preview depending on whether the card can be
				// planted on the currently targeted land.
				if (_currentLandEntity.IsPlaceable(cardEntity))
				{
					handManager.ChangeCardGhost(_currentLandEntity);
				}
				else
				{
					handManager.ChangeCardGhost(null);
				}
			}

			// A seed-rain card that is no longer picked up should be dropped.
			if (seedCardEntity != null && !seedCardEntity.IsPickUp)
			{
				Drop();
			}
		}

		protected override bool OnUse()
		{
			// No land targeted -> nothing to plant, just drop.
			if (_currentLandEntity == null)
			{
				Drop();
				return false;
			}

			if (cardEntity == null)
			{
				return false;
			}

			CardType cardType = cardEntity.type;
			if (cardType == CardType.Zombie)
			{
				ZombieManager zombieManager = ZombieManager.Instance;
				if (zombieManager == null)
				{
					return false;
				}
				if (!zombieManager.PlaceZombie((CardZombieEntity)cardEntity, _currentLandEntity, seedCardEntity))
				{
					return false;
				}
			}
			else
			{
				PlantManager plantManager = PlantManager.Instance;
				if (plantManager == null)
				{
					return false;
				}
				if (!plantManager.PlacePlant(cardEntity, _currentLandEntity, seedCardEntity))
				{
					return false;
				}
			}

			if (seedCardEntity != null)
			{
				// Seed-rain card: release it back to the pool.
				seedCardEntity.Release();
				return true;
			}

			return true;
		}

		protected override void OnEnterLand(LandEntity landEntity)
		{
			if (landEntity == null)
			{
				return;
			}

			HandManager handManager = HandManager.Instance;
			if (handManager == null)
			{
				return;
			}

			if (landEntity.IsPlaceable(cardEntity))
			{
				handManager.ChangeCardGhost(landEntity);
			}
			else
			{
				handManager.ChangeCardGhost(null);
			}
		}

		protected override void OnExitLand(LandEntity landEntity)
		{
			if (landEntity == null)
			{
				return;
			}

			if (_currentLandEntity != landEntity)
			{
				return;
			}

			HandManager handManager = HandManager.Instance;
			if (handManager == null)
			{
				return;
			}

			handManager.ChangeCardGhost(null);
		}

		protected override void EnterLand(LandEntity landEntity)
		{
			if (landEntity == null)
			{
				return;
			}

			_currentLandEntity = landEntity;
			OnEnterLand(landEntity);
		}

		protected override void ExitLand(LandEntity landEntity)
		{
			if (landEntity == null)
			{
				return;
			}

			OnExitLand(landEntity);

			if (_currentLandList == null || _currentLandList.Count < 1)
			{
				_currentLandEntity = null;
			}
		}
	}
}
