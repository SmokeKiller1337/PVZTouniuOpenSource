using System.Collections.Generic;
using Bullet.Manager;
using Common.Entity;
using DG.Tweening;
using Game.Entity;
using Game.Util;
using Level.Entity;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Pool;

namespace Bullet.Entity
{
	public class BulletEntity : MonoBehaviour
	{
		[Tooltip("是否使用对象池")]
		public bool isUsePool;

		[Tooltip("引用id")]
		public int autoId;

		[Tooltip("类型编号")]
		public int typeId;

		[Tooltip("是否冻结旋转")]
		public bool isFreezeSpriteRotationZ;

		[Tooltip("子弹目标")]
		public BulletToTargetEntity toTarget;

		[Tooltip("是否持续生效")]
		public bool isContinuousTrigger;

		[Tooltip("持续生效间隔时间")]
		public float continuousTriggerIntervalTime;

		[Tooltip("创建时效果")]
		public EffectEntity createEffect;

		[Tooltip("生效时效果")]
		public EffectEntity triggerEffect;

		[Tooltip("销毁时效果")]
		public EffectEntity destroyEffect;

		[HideInInspector]
		public BulletAttr attr;

		[HideInInspector]
		public BaseBody sourceBaseBody;

		public UnityAction<BulletEntity> OnCreateAction;

		public UnityAction<BulletEntity, BaseBody> OnTriggerAction;

		public UnityAction<BulletEntity> OnDestroyAction;

		private int _targetLayerMask;

		private GameObject _masterTargetObj;

		private float _currentTime;

		private bool _continuousTriggerFlag;

		private float _continuousTriggerIntervalTimer;

		private List<GameObject> _currentTriggerObjList;

		private int _currentTriggerCount;

		private bool _isDestroy;

		[HideInInspector]
		public Transform mainBodyTransform;

		[HideInInspector]
		public GameObject spriteObj;

		[HideInInspector]
		public SpriteRenderer shadowSpriteRenderer;

		private Vector3 _shadowOriginalLocalPosition;

		private Vector3 _shadowOriginalLocalScale;

		private Color _shadowOriginalColor;

		private float _lastSlopeY;

		protected Rigidbody2D _rigidbody;

		// TODO: reconstruct — the following are private/global constants referenced by the
		// decompiled pseudocode (raw *(float*)0x18252cbXX loads) whose exact values could not
		// be recovered. Placeholder values chosen to keep semantics plausible.
		private const float ShadowRaycastDistance = 10f; // _DAT_18252cb30
		private const float ShadowDarkenSlope = 5f;       // _DAT_18252cb64 (scale-per-height factor)
		private const float DestroyOffscreenPosition = -10000f; // _UNK_18252cb74 (moved off-screen before pool release)

		public float CurrentTime
		{
			get
			{
				return _currentTime;
			}
			set
			{
				_currentTime = value;
			}
		}

		public bool IsDestroy
		{
			get
			{
				return _isDestroy;
			}
			set
			{
				_isDestroy = value;
			}
		}

		public float Height
		{
			get
			{
				// Returns the shadow sprite's local Y (the visual "height" of the bullet above ground).
				if (shadowSpriteRenderer == null)
				{
					return 0f;
				}
				return shadowSpriteRenderer.transform.localPosition.y;
			}
		}

		public Rigidbody2D Rigidbody
		{
			get
			{
				return _rigidbody;
			}
			set
			{
				_rigidbody = value;
			}
		}

		protected virtual void Awake()
		{
			BuildTransform();
			// Awake inlines BuildLayerMask + BuildExcludeLayerMask (ICF-folded copies).
			BuildLayerMask();
			BuildExcludeLayerMask();
		}

		public void Reset()
		{
			transform.localScale = Vector3.one;
			transform.localEulerAngles = Vector3.zero;
			if (mainBodyTransform != null)
			{
				mainBodyTransform.localEulerAngles = Vector3.zero;
			}
			if (spriteObj != null)
			{
				spriteObj.transform.localEulerAngles = Vector3.zero;
			}
			if (shadowSpriteRenderer != null)
			{
				shadowSpriteRenderer.transform.eulerAngles = Vector3.zero;
				shadowSpriteRenderer.transform.localPosition = _shadowOriginalLocalPosition;
				shadowSpriteRenderer.transform.localScale = _shadowOriginalLocalScale;
				shadowSpriteRenderer.color = _shadowOriginalColor;
			}
			_lastSlopeY = 0f;
			_currentTime = 0f;
			_continuousTriggerFlag = true;
			_continuousTriggerIntervalTimer = 0f;
			if (attr != null)
			{
				_currentTriggerCount = (int)attr.triggerCount;
				_currentTriggerObjList.Clear();
				_isDestroy = false;
				attr = null;
				BulletEntity[] children = GetComponentsInChildren<BulletEntity>();
				if (children != null)
				{
					for (int i = 0; i < children.Length; i++)
					{
						BulletEntity child = children[i];
						// Virtual call at vtable slot for RotationToTarget/Reset chain in the
						// pseudocode; child is reset the same way as this entity.
						child.Reset();
					}
				}
			}
		}

		public void Init()
		{
			if (attr != null)
			{
				Vector3 scale = transform.localScale;
				float s = attr.scale;
				transform.localScale = new Vector3(scale.x * s, scale.y * s, scale.z * s);
				_currentTriggerCount = (int)attr.triggerCount;
			}
			GameUtils.CreateEffect(createEffect, transform.position, Quaternion.identity, 1f);
			if (OnCreateAction != null)
			{
				OnCreateAction(this);
			}
		}

		protected virtual void Update()
		{
			if (_isDestroy)
			{
				return;
			}
			_currentTime += Time.deltaTime;
			if (!_continuousTriggerFlag)
			{
				_continuousTriggerIntervalTimer += Time.deltaTime;
				if (_continuousTriggerIntervalTimer >= continuousTriggerIntervalTime)
				{
					_continuousTriggerIntervalTimer = 0f;
					_continuousTriggerFlag = true;
				}
			}
			UpdateShadow();
			if (attr != null && attr.duration != 0f && attr.duration <= _currentTime)
			{
				End();
			}
			if (Height < 0f)
			{
				End();
			}
		}

		private void UpdateShadow()
		{
			if (shadowSpriteRenderer == null)
			{
				return;
			}
			Vector3 origin = transform.position;
			// Raycast straight down against the ground layer to find where the shadow should land.
			// TODO: the ground/terrain layer mask came from a global manager singleton in the
			// pseudocode and could not be resolved precisely.
			int groundMask = GroundLayerMask;
			RaycastHit2D hit = Physics2D.Raycast(origin, Vector2.down, ShadowRaycastDistance, groundMask);
			if (hit.collider == null)
			{
				return;
			}
			float lastSlopeY = _lastSlopeY;
			_lastSlopeY = hit.point.y;
			if (shadowSpriteRenderer != null)
			{
				Vector3 localPos = shadowSpriteRenderer.transform.localPosition;
				if (lastSlopeY != 0f)
				{
					localPos.y += _lastSlopeY - lastSlopeY;
				}
				shadowSpriteRenderer.transform.localPosition = localPos;

				float ratio = Mathf.Clamp01(Height / ShadowRaycastDistance);
				Color color = shadowSpriteRenderer.color;
				color.a = Mathf.Lerp(_shadowOriginalColor.a, 1f, ratio);
				shadowSpriteRenderer.color = color;

				float scaleFactor = 1f + Mathf.Clamp01(ratio) * ShadowDarkenSlope;
				shadowSpriteRenderer.transform.localScale = new Vector3(
					_shadowOriginalLocalScale.x * scaleFactor,
					_shadowOriginalLocalScale.y * scaleFactor,
					_shadowOriginalLocalScale.z * scaleFactor);
			}
		}

		public virtual void Trigger(GameObject targetGameObject)
		{
			if (_isDestroy)
			{
				return;
			}
			_masterTargetObj = targetGameObject;
			ChangeTriggerCount(-1);
			GameUtils.CreateEffect(triggerEffect, transform.position, Quaternion.identity, 1f);

			List<GameObject> triggeredObjs = new List<GameObject>();
			triggeredObjs.Add(targetGameObject);

			if (attr != null)
			{
				if (attr.radius > 0f)
				{
					Vector3 position = transform.position;
					// Splash: gather every valid target inside the damage radius.
					Collider2D[] cols = Physics2D.OverlapCircleAll(position, attr.radius, _targetLayerMask);
					if (cols != null)
					{
						for (int i = 0; i < cols.Length; i++)
						{
							Collider2D col = cols[i];
							if (col.gameObject != targetGameObject && CheckTrigger(col.gameObject, false))
							{
								triggeredObjs.Add(col.gameObject);
							}
						}
					}
				}

				foreach (GameObject obj in triggeredObjs)
				{
					if (OnTriggerAction != null)
					{
						BaseBody body = obj.GetComponent<BaseBody>();
						OnTriggerAction(this, body);
					}
					Damage(obj);
				}

				if (_currentTriggerCount != 0)
				{
					return;
				}
				End();
			}
		}

		public void Damage(GameObject targetGameObject)
		{
			if (attr == null)
			{
				return;
			}
			float force = attr.repelForce;
			if (targetGameObject != _masterTargetObj)
			{
				// Splash targets take reduced knockback.
				force *= attr.splashRatio;
			}
			if (targetGameObject == null)
			{
				return;
			}
			BaseBody body = targetGameObject.GetComponentInParent<BaseBody>();
			if (body == null)
			{
				return;
			}

			// TODO: reconstruct — the pseudocode runs an immunity/last-damage-type guard here via
			// two folded virtual calls (a bool predicate on the body, then a null-check on its
			// LastDamageType). The exact predicate could not be recovered reliably, so it is left
			// out to avoid encoding wrong logic; Hit is always applied below.
			body.Hit(attr.damage, attr.damageType, this);

			if (force > 0f && body.Rigidbody != null)
			{
				body.Rigidbody.AddForce(new Vector2(
					attr.forceDirection.x * force,
					attr.forceDirection.y * force), ForceMode2D.Impulse);
			}
		}

		public virtual void ChangeTriggerCount(int value)
		{
			if (_currentTriggerCount != -1)
			{
				_currentTriggerCount += value;
			}
		}

		public virtual void End()
		{
			GameUtils.CreateEffect(destroyEffect, transform.position, Quaternion.identity, 1f);
			if (OnDestroyAction != null)
			{
				OnDestroyAction(this);
			}
			// End inlines the DestroySelf pooling/cleanup logic (ICF-folded copy).
			DestroySelf();
		}

		public virtual void RotationToTarget(Vector2 position)
		{
			Vector3 selfPos = transform.position;
			Vector2 dir = new Vector2(position.x - selfPos.x, position.y - selfPos.y);
			if (dir.magnitude <= 0f)
			{
				// Degenerate direction: nothing to rotate toward.
				return;
			}
			float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;
			transform.localEulerAngles = new Vector3(0f, 0f, angle);
			if (mainBodyTransform != null)
			{
				mainBodyTransform.localEulerAngles = new Vector3(0f, 0f, -angle);
				if (!isFreezeSpriteRotationZ && spriteObj != null)
				{
					spriteObj.transform.localEulerAngles = new Vector3(0f, 0f, angle);
				}
			}
		}

		public BulletEntity ReplaceBullet(BulletAttr bulletAttr)
		{
			Vector3 position = transform.position;
			if (BulletManager.Instance == null)
			{
				return null;
			}
			BulletEntity newBullet = BulletManager.Instance.CreateBullet(bulletAttr);
			if (newBullet == null)
			{
				return null;
			}
			position.z = 0f;
			newBullet.transform.position = position;

			BulletAttr srcAttr = attr;
			// Build a fresh BulletAttr for the replacement, seeded with defaults then copied
			// from this bullet's current attr.
			BulletAttr newAttr = new BulletAttr
			{
				damage = 20,
				damageType = DamageTypeEntity.Common,
				duration = 10f,
				forceDirection = Vector2.zero,
				scale = 1f,
				splashRatio = 1f,
				bulletSpeed = 5f
			};
			if (srcAttr != null)
			{
				newAttr.damage = srcAttr.damage;
				newAttr.damageType = srcAttr.damageType;
				newAttr.duration = srcAttr.duration;
				newAttr.repelForce = srcAttr.repelForce;
				newAttr.forceDirection = srcAttr.forceDirection;
				newAttr.triggerCount = srcAttr.triggerCount;
				newAttr.scale = srcAttr.scale;
				newAttr.radius = srcAttr.radius;
				newAttr.splashRatio = srcAttr.splashRatio;
				newAttr.bulletSpeed = srcAttr.bulletSpeed;
				newAttr.bulletPrefab = srcAttr.bulletPrefab;
			}
			newBullet.attr = newAttr;

			if (attr != null)
			{
				float remainingDuration = attr.duration;
				if (remainingDuration != 0f)
				{
					remainingDuration = attr.duration - _currentTime;
				}
				if (newBullet.attr != null)
				{
					newBullet.attr.duration = remainingDuration;
					newBullet.attr.triggerCount = _currentTriggerCount;
					newBullet.sourceBaseBody = sourceBaseBody;
					newBullet._currentTime = _currentTime;
					newBullet._continuousTriggerFlag = _continuousTriggerFlag;
					newBullet._continuousTriggerIntervalTimer = _continuousTriggerIntervalTimer;
					newBullet._currentTriggerCount = _currentTriggerCount;

					BulletEntity[] children = newBullet.GetComponentsInChildren<BulletEntity>();
					if (children != null)
					{
						for (int i = 0; i < children.Length; i++)
						{
							children[i].Init();
						}
					}

					newBullet.transform.eulerAngles = transform.eulerAngles;
					if (newBullet.mainBodyTransform != null && mainBodyTransform != null)
					{
						newBullet.mainBodyTransform.eulerAngles = mainBodyTransform.eulerAngles;
					}
					if (newBullet.spriteObj != null && spriteObj != null)
					{
						newBullet.spriteObj.transform.eulerAngles = spriteObj.transform.eulerAngles;
					}
					if (newBullet.attr != null)
					{
						Vector3 ns = newBullet.transform.localScale;
						float s = newBullet.attr.scale;
						newBullet.transform.localScale = new Vector3(ns.x * s, ns.y * s, ns.z * s);
						newBullet._currentTriggerCount = (int)newBullet.attr.triggerCount;
					}

					GameUtils.CreateEffect(newBullet.createEffect, newBullet.transform.position, Quaternion.identity, 1f);
					if (newBullet.OnCreateAction != null)
					{
						newBullet.OnCreateAction(newBullet);
					}
					DestroySelf();
					return newBullet;
				}
			}
			return newBullet;
		}

		public void DestroySelf()
		{
			if (_isDestroy)
			{
				return;
			}
			_isDestroy = true;
			if (BulletManager.Instance == null)
			{
				return;
			}
			Dictionary<int, IObjectPool<GameObject>> poolDic = BulletManager.Instance.bulletPoolDic;
			if (!isUsePool)
			{
				Object.Destroy(gameObject);
				return;
			}
			if (poolDic != null && poolDic.ContainsKey(autoId))
			{
				transform.position = new Vector3(DestroyOffscreenPosition, DestroyOffscreenPosition, 0f);
				IObjectPool<GameObject> pool = poolDic[autoId];
				DOVirtual.DelayedCall(1f, delegate
				{
					// Return this bullet's GameObject to its object pool after a short delay.
					if (pool != null && this != null)
					{
						pool.Release(gameObject);
					}
				});
			}
			else
			{
				Object.Destroy(gameObject);
			}
		}

		protected virtual void OnCollisionEnter2D(Collision2D col)
		{
			if (!isContinuousTrigger)
			{
				if (col != null)
				{
					GameObject obj = col.gameObject;
					if (CheckTrigger(obj, true))
					{
						Trigger(obj);
					}
				}
			}
			else
			{
				if (col != null)
				{
					_currentTriggerObjList.Add(col.gameObject);
				}
			}
		}

		protected virtual void OnCollisionStay2D(Collision2D collision)
		{
			// Note: the pseudocode body at this RVA was ICF-folded with the OnTriggerStay2D /
			// ContinuousTrigger body; it iterates the accumulated continuous-trigger targets.
			if (!isContinuousTrigger || !_continuousTriggerFlag)
			{
				return;
			}
			_continuousTriggerFlag = false;
			List<GameObject> snapshot = new List<GameObject>(_currentTriggerObjList);
			foreach (GameObject obj in snapshot)
			{
				if (CheckTrigger(obj, true))
				{
					Trigger(obj);
				}
			}
		}

		private void OnCollisionExit2D(Collision2D other)
		{
			if (!isContinuousTrigger)
			{
				return;
			}
			if (other != null)
			{
				_currentTriggerObjList.Remove(other.gameObject);
			}
		}

		protected virtual void OnTriggerEnter2D(Collider2D col)
		{
			if (!isContinuousTrigger)
			{
				if (col != null)
				{
					GameObject obj = col.gameObject;
					if (CheckTrigger(obj, true))
					{
						Trigger(obj);
					}
				}
			}
			else
			{
				if (col != null)
				{
					_currentTriggerObjList.Add(col.gameObject);
				}
			}
		}

		protected virtual void OnTriggerStay2D(Collider2D other)
		{
			if (!isContinuousTrigger || !_continuousTriggerFlag)
			{
				return;
			}
			_continuousTriggerFlag = false;
			List<GameObject> snapshot = new List<GameObject>(_currentTriggerObjList);
			foreach (GameObject obj in snapshot)
			{
				if (CheckTrigger(obj, true))
				{
					Trigger(obj);
				}
			}
		}

		private void OnTriggerExit2D(Collider2D other)
		{
			if (!isContinuousTrigger)
			{
				return;
			}
			if (other != null)
			{
				_currentTriggerObjList.Remove(other.gameObject);
			}
		}

		private void ContinuousTrigger()
		{
			List<GameObject> snapshot = new List<GameObject>(_currentTriggerObjList);
			foreach (GameObject obj in snapshot)
			{
				if (CheckTrigger(obj, true))
				{
					Trigger(obj);
				}
			}
		}

		protected virtual bool CheckTrigger(GameObject obj, bool isMaster = true)
		{
			if (obj == null)
			{
				return false;
			}
			if (isMaster && _currentTriggerCount == 0)
			{
				return false;
			}
			BaseBody body = obj.GetComponent<BaseBody>();
			if (body == null)
			{
				return false;
			}
			// body.CurrentLandEntity guard chain — skip targets that are un-pickable / already gone.
			// TODO: reconstruct — two folded virtual bool getters on CurrentLandEntity could not be
			// mapped to exact member names; using the recovered semantic guards below.
			if (body.CurrentLandEntity == null)
			{
				return false;
			}
			if (body.IsNotPick())
			{
				return false;
			}
			if (body.CurrentLandEntity == sourceBaseBody)
			{
				return false;
			}
			if (Height > 1f)
			{
				// TODO: reconstruct — height ceiling constant (_DAT_18252cb28) unrecovered; 1f placeholder.
				return false;
			}
			if (toTarget == null)
			{
				return false;
			}
			// TODO: the four tag comparisons below reference tag-name string constants that were
			// data pointers in the pseudocode and could not be recovered exactly. The bool->tag
			// pairing follows the toTarget field offsets (0x10 plant, 0x11 zombie, 0x12 touniu, 0x13 bullet).
			if (toTarget.plant && obj.CompareTag(TagPlant))
			{
				return true;
			}
			if (toTarget.zombie && obj.CompareTag(TagZombie))
			{
				return true;
			}
			if (toTarget.touniu && obj.CompareTag(TagTouniu))
			{
				return true;
			}
			if (toTarget.bullet && obj.CompareTag(TagBullet))
			{
				return true;
			}
			return false;
		}

		private void BuildTransform()
		{
			_rigidbody = GetComponentInChildren<Rigidbody2D>();
			// TODO: the child transform names below ("MainBody", "Sprite", "Shadow") were data
			// pointers in the pseudocode and could not be recovered exactly.
			mainBodyTransform = transform.Find(MainBodyChildName);
			if (mainBodyTransform != null)
			{
				Transform spriteTransform = mainBodyTransform.Find(SpriteChildName);
				if (spriteTransform != null)
				{
					spriteObj = spriteTransform.gameObject;
				}
				Transform shadowTransform = mainBodyTransform.Find(ShadowChildName);
				if (shadowTransform != null)
				{
					shadowSpriteRenderer = shadowTransform.GetComponent<SpriteRenderer>();
					if (shadowSpriteRenderer != null)
					{
						_shadowOriginalLocalPosition = shadowSpriteRenderer.transform.localPosition;
						_shadowOriginalLocalScale = shadowSpriteRenderer.transform.localScale;
						_shadowOriginalColor = shadowSpriteRenderer.color;
					}
				}
			}
		}

		private void BuildLayerMask()
		{
			if (toTarget == null)
			{
				return;
			}
			int mask = 0;
			if (toTarget.plant)
			{
				mask = 1 << LayerMask.NameToLayer(TagPlant);
			}
			if (toTarget.zombie)
			{
				mask |= 1 << LayerMask.NameToLayer(TagZombie);
			}
			if (toTarget.touniu)
			{
				mask |= 1 << LayerMask.NameToLayer(TagTouniu);
			}
			if (toTarget.bullet)
			{
				mask |= 1 << LayerMask.NameToLayer(TagBullet);
			}
			_targetLayerMask = mask;
		}

		private void BuildExcludeLayerMask()
		{
			if (toTarget == null)
			{
				return;
			}
			// For every target category NOT selected, add that layer to the rigidbody's exclude mask.
			if (!toTarget.plant && _rigidbody != null)
			{
				_rigidbody.excludeLayers = (int)_rigidbody.excludeLayers | (1 << LayerMask.NameToLayer(TagPlant));
			}
			if (!toTarget.zombie && _rigidbody != null)
			{
				_rigidbody.excludeLayers = (int)_rigidbody.excludeLayers | (1 << LayerMask.NameToLayer(TagZombie));
			}
			if (!toTarget.touniu && _rigidbody != null)
			{
				_rigidbody.excludeLayers = (int)_rigidbody.excludeLayers | (1 << LayerMask.NameToLayer(TagTouniu));
			}
			if (!toTarget.bullet && _rigidbody != null)
			{
				_rigidbody.excludeLayers = (int)_rigidbody.excludeLayers | (1 << LayerMask.NameToLayer(TagBullet));
			}
		}

		// ---- Recovered tag / child-name / layer constants ----
		// TODO: reconstruct — these string literals were data pointers in the decompilation and
		// their exact text could not be recovered. Names below are plausible placeholders.
		private const string TagPlant = "Plant";
		private const string TagZombie = "Zombie";
		private const string TagTouniu = "Touniu"; // toTarget.touniu (对头牛)
		private const string TagBullet = "Bullet";
		private const string MainBodyChildName = "MainBody";
		private const string SpriteChildName = "Sprite";
		private const string ShadowChildName = "Shadow";

		// TODO: reconstruct — the ground layer mask used by UpdateShadow was read from a manager
		// singleton; using UnityEngine's built-in "Default" as a placeholder.
		private static int GroundLayerMask => LayerMask.GetMask("Default");
	}
}
