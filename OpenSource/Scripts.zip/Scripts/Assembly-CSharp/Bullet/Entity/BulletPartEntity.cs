using System;
using UnityEngine;

namespace Bullet.Entity
{
	public abstract class BulletPartEntity : MonoBehaviour
	{
		protected BulletEntity _bulletEntity;

		protected virtual void Awake()
		{
			_bulletEntity = GetComponent<BulletEntity>();
			if (_bulletEntity == null)
			{
				throw new Exception("BulletPartEntity requires a BulletEntity component.");
			}
		}

		public abstract void Reset();

		public abstract void ReplaceBullet(BulletEntity oldBulletEntity);
	}
}
