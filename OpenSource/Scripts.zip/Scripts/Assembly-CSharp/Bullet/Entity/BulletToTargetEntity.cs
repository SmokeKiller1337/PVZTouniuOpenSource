using System;
using UnityEngine;

namespace Bullet.Entity
{
	[Serializable]
	public class BulletToTargetEntity
	{
		[Tooltip("对植物")]
		public bool plant;

		[Tooltip("对僵尸")]
		public bool zombie;

		[Tooltip("对头牛")]
		public bool touniu;

		[Tooltip("对子弹")]
		public bool bullet;

		// The only method in this type is the default parameterless constructor.
		// Its decompiled body (see pseudocode.c) folded via IL2CPP ICF onto an
		// unrelated empty generated .ctor, and dump.cs confirms `.ctor() { }`.
		// A [Serializable] class with only fields needs no explicit constructor;
		// the C# compiler emits the equivalent empty default constructor.
	}
}
