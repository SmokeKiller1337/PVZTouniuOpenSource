using System;
using UnityEngine;

namespace Bullet.Entity
{
	[Serializable]
	public class BulletToTargetEntity
	{
		[Tooltip("对植物")]
		public bool plant;

		[Tooltip("对僵尸")]
		public bool zombie;

		[Tooltip("对头牛")]
		public bool touniu;

		[Tooltip("对子弹")]
		public bool bullet;

	}
}
