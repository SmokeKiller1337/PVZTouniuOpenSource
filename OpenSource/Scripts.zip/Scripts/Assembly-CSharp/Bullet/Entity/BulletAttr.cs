using System;
using Level.Entity;
using UnityEngine;

namespace Bullet.Entity
{
	[Serializable]
	public class BulletAttr
	{
		[Tooltip("伤害")]
		[Header("---武器基础")]
		public int damage;

		[Tooltip("伤害类型")]
		public DamageTypeEntity damageType;

		[Tooltip("持续时间")]
		public float duration;

		[Tooltip("施加力")]
		public float repelForce;

		[Tooltip("施加力方向")]
		public Vector2 forceDirection;

		[Tooltip("生效次数")]
		public float triggerCount;

		[Tooltip("体积")]
		public float scale;

		[Tooltip("伤害半径")]
		public float radius;

		[Tooltip("溅射伤害比例")]
		public float splashRatio;

		[Tooltip("子弹速度")]
		public float bulletSpeed;

		[Tooltip("子弹预制体")]
		public GameObject bulletPrefab;

		// RVA: 0x6B3DD0
		// Parameterless constructor sets the default weapon-base attributes.
		public BulletAttr()
		{
			// param_1 + 0x10
			this.damage = 20;
			// param_1 + 0x18 : DamageTypeEntity.get_Common()
			this.damageType = DamageTypeEntity.Common;
			// param_1 + 0x20 : 0x41200000
			this.duration = 10f;
			// param_1 + 0x24 (repelForce) left at default 0f
			// param_1 + 0x28 / 0x2c : forceDirection.x / forceDirection.y
			// Read from a global config singleton (_DAT_182e706b8 -> [+0xb8] -> +0x28/+0x2c).
			// The singleton/global cannot be resolved from the dump, so the source value
			// is unknown; default it to Vector2.zero.
			// TODO: reconstruct forceDirection default from the global config singleton
			//       (reads two floats at offsets +0x28 and +0x2c of the config object).
			this.forceDirection = Vector2.zero;
			// param_1 + 0x30 : 0x3f800000
			this.triggerCount = 1f;
			// param_1 + 0x34 : 0x3f800000
			this.scale = 1f;
			// param_1 + 0x38 (radius) left at default 0f
			// param_1 + 0x3c : 0x3f800000
			this.splashRatio = 1f;
			// param_1 + 0x40 : 0x40a00000
			this.bulletSpeed = 5f;
		}

		// RVA: 0x6B3CB0
		// Copy constructor. The decompiled body at this RVA is ICF-folded onto a
		// parameterless-ctor body (it never reads the `attr` parameter), so the real
		// per-field copy logic is not recoverable from the pseudocode. Reconstructed as
		// the standard field-by-field copy, which is the only sensible intent for a
		// BulletAttr(BulletAttr attr) signature.
		// TODO: reconstruct — pseudocode is ICF-folded and does not reference `attr`;
		//       this is the assumed (standard copy-constructor) behavior.
		public BulletAttr(BulletAttr attr)
		{
			if (attr == null)
			{
				return;
			}
			this.damage = attr.damage;
			this.damageType = attr.damageType;
			this.duration = attr.duration;
			this.repelForce = attr.repelForce;
			this.forceDirection = attr.forceDirection;
			this.triggerCount = attr.triggerCount;
			this.scale = attr.scale;
			this.radius = attr.radius;
			this.splashRatio = attr.splashRatio;
			this.bulletSpeed = attr.bulletSpeed;
			this.bulletPrefab = attr.bulletPrefab;
		}
	}
}
