using System;
using Level.Entity;
using UnityEngine;

namespace Bullet.Entity
{
	[Serializable]
	public class BulletAttr
	{
		[Tooltip("伤害")]
		[Header("---武器基础")]
		public int damage;

		[Tooltip("伤害类型")]
		public DamageTypeEntity damageType;

		[Tooltip("持续时间")]
		public float duration;

		[Tooltip("施加力")]
		public float repelForce;

		[Tooltip("施加力方向")]
		public Vector2 forceDirection;

		[Tooltip("生效次数")]
		public float triggerCount;

		[Tooltip("体积")]
		public float scale;

		[Tooltip("伤害半径")]
		public float radius;

		[Tooltip("溅射伤害比例")]
		public float splashRatio;

		[Tooltip("子弹速度")]
		public float bulletSpeed;

		[Tooltip("子弹预制体")]
		public GameObject bulletPrefab;

		// Parameterless constructor sets the default weapon-base attributes.
		public BulletAttr()
		{
			// param_1 + 0x10
			this.damage = 20;
			// param_1 + 0x18 : DamageTypeEntity.get_Common()
			this.damageType = DamageTypeEntity.Common;
			// param_1 + 0x20 : 0x41200000
			this.duration = 10f;
			this.forceDirection = Vector2.zero;
			// param_1 + 0x30 : 0x3f800000
			this.triggerCount = 1f;
			// param_1 + 0x34 : 0x3f800000
			this.scale = 1f;
			// param_1 + 0x38 (radius) left at default 0f
			// param_1 + 0x3c : 0x3f800000
			this.splashRatio = 1f;
			// param_1 + 0x40 : 0x40a00000
			this.bulletSpeed = 5f;
		}

		public BulletAttr(BulletAttr attr)
		{
			if (attr == null)
			{
				return;
			}
			this.damage = attr.damage;
			this.damageType = attr.damageType;
			this.duration = attr.duration;
			this.repelForce = attr.repelForce;
			this.forceDirection = attr.forceDirection;
			this.triggerCount = attr.triggerCount;
			this.scale = attr.scale;
			this.radius = attr.radius;
			this.splashRatio = attr.splashRatio;
			this.bulletSpeed = attr.bulletSpeed;
			this.bulletPrefab = attr.bulletPrefab;
		}
	}
}
