using System.Collections.Generic;
using Bullet.Entity;
using Common.Entity;
using UnityEngine;
using UnityEngine.Pool;

namespace Bullet.Manager
{
	public class BulletManager : MonoBehaviour
	{
		[HideInInspector]
		public Dictionary<int, IObjectPool<GameObject>> bulletPoolDic = new Dictionary<int, IObjectPool<GameObject>>();

		public static BulletManager Instance { get; private set; }

		private void Awake()
		{
			Instance = this;
		}

		public BulletEntity CreateBullet(BaseBody sourceBody, BulletAttr bulletAttr, Vector2 bulletPosition, Vector2 targetPosition)
		{
			// Delegates to the single-argument overload to actually spawn/pool the bullet,
			// then wires up the source body, world position, and initial rotation.
			BulletEntity bullet = CreateBullet(bulletAttr);
			if (bullet == null)
			{
				return null;
			}

			bullet.sourceBaseBody = sourceBody;

			Transform bulletTransform = bullet.transform;
			bulletTransform.position = bulletPosition;

			bullet.RotationToTarget(targetPosition);
			bullet.Init();

			return bullet;
		}

		public BulletEntity CreateBullet(BulletAttr bulletAttr)
		{
			if (bulletAttr.bulletPrefab == null)
			{
				return null;
			}

			BulletEntity prefabEntity = bulletAttr.bulletPrefab.GetComponent<BulletEntity>();
			GameObject bulletObj;

			if (!prefabEntity.isUsePool)
			{
				// Bullet does not use pooling -> plain Instantiate.
				bulletObj = Object.Instantiate(bulletAttr.bulletPrefab);
			}
			else
			{
				int prefabId = bulletAttr.bulletPrefab.GetInstanceID();
				if (!bulletPoolDic.ContainsKey(prefabId))
				{
					InitPool(bulletAttr.bulletPrefab);
				}
				bulletObj = bulletPoolDic[prefabId].Get();
			}

			if (bulletObj == null)
			{
				return null;
			}

			BulletEntity bullet = bulletObj.GetComponent<BulletEntity>();
			// Copy the incoming attribute set so pooled instances don't share a reference.
			bullet.attr = new BulletAttr(bulletAttr);
			return bullet;
		}

		private void InitPool(GameObject bulletPrefab)
		{
			// Capture the prefab and its instance id in a closure used by the pool's create func.
			int prefabId = bulletPrefab.GetInstanceID();
			IObjectPool<GameObject> pool = new ObjectPool<GameObject>(
				createFunc: () =>
				{
					Transform parent = BulletManager.Instance != null ? BulletManager.Instance.transform : null;
					GameObject obj = Object.Instantiate(bulletPrefab, parent);
					BulletEntity entity = obj.GetComponent<BulletEntity>();
					entity.autoId = prefabId;
					return obj;
				},
				actionOnGet: (obj) =>
				{
					obj.SetActive(true);
					obj.GetComponent<BulletEntity>().Reset();
				},
				actionOnRelease: (obj) =>
				{
					obj.SetActive(false);
				},
				actionOnDestroy: (obj) =>
				{
					Object.Destroy(obj);
				},
				collectionCheck: true,
				defaultCapacity: 10,
				maxSize: 10000);

			bulletPoolDic.Add(prefabId, pool);
		}
	}
}
