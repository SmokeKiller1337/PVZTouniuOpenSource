using System.Collections.Generic;
using System.Linq;
using Bullet.Entity;
using Bullet.Part.Custom;
using Common.Entity;
using Level.Util;
using UnityEngine;
using Zombie.Entity;
using Zombie.Entity.Data;

namespace Bullet.Part.Common
{
	public class MovePart : BulletPartEntity
	{
		[Tooltip("移动方向")]
		public Vector2 moveDirection;

		[Tooltip("是否为追踪子弹")]
		public bool isTrack;

		[HideInInspector]
		public Vector2 tempMoveDirection;

		[HideInInspector]
		public float tempMoveTime;

		private float _tempMoveTimer;

		private float _trackIntervalTime;

		private float _trackIntervalTimer;

		private BaseBody _targetBaseBody;

		private Rigidbody2D _rigidbody;

		private PopBalloonPart popBalloonPart;

		private Vector2 _initialMoveDirection;

		private bool _initialIsTrack;

		public override void Reset()
		{
			// Restore the runtime move state back to the values captured in Awake.
			moveDirection = _initialMoveDirection;
			isTrack = _initialIsTrack;
			_trackIntervalTimer = 0f;
			_targetBaseBody = null;
			// The pseudocode seeds tempMoveDirection from a global default-config singleton
			// (_DAT_182e706b8 -> [+0xb8] -> +0x28/+0x2c) that cannot be resolved from the dump,
			// and zeroes tempMoveTime.
			// TODO: reconstruct tempMoveDirection default from the global config singleton.
			tempMoveDirection = Vector2.zero;
			tempMoveTime = 0f;
		}

		public override void ReplaceBullet(BulletEntity oldBulletEntity)
		{
			if (oldBulletEntity == null)
			{
				return;
			}
			// Carry over the full move state from the replaced bullet's MovePart.
			MovePart oldMovePart = oldBulletEntity.GetComponent<MovePart>();
			if (oldMovePart == null)
			{
				return;
			}
			moveDirection = oldMovePart.moveDirection;
			isTrack = oldMovePart.isTrack;
			tempMoveDirection = oldMovePart.tempMoveDirection;
			tempMoveTime = oldMovePart.tempMoveTime;
			_tempMoveTimer = oldMovePart._tempMoveTimer;
			_trackIntervalTime = oldMovePart._trackIntervalTime;
			_trackIntervalTimer = oldMovePart._trackIntervalTimer;
			_targetBaseBody = oldMovePart._targetBaseBody;
		}

		protected override void Awake()
		{
			base.Awake();
			_rigidbody = GetComponent<Rigidbody2D>();
			popBalloonPart = GetComponent<PopBalloonPart>();
			// Capture the authored move state so Reset can restore it later.
			_initialMoveDirection = moveDirection;
			_initialIsTrack = isTrack;
		}

		private void FixedUpdate()
		{
			BulletEntity bulletEntity = _bulletEntity;
			if (bulletEntity == null)
			{
				return;
			}
			// Do not move while destroyed, or while the owning bullet has no live speed attribute.
			if (bulletEntity.IsDestroy || bulletEntity.attr == null || bulletEntity.attr.bulletSpeed <= 0f)
			{
				return;
			}

			if (isTrack)
			{
				_trackIntervalTimer += Time.deltaTime;
				if (_trackIntervalTimer > _trackIntervalTime)
				{
					_trackIntervalTimer = 0f;
					// Re-acquire the nearest zombie and rotate the bullet toward it.
					_targetBaseBody = GetNearestZombie(transform.position);
					if (_targetBaseBody != null)
					{
						bulletEntity.RotationToTarget(_targetBaseBody.transform.position);
					}

					if (popBalloonPart != null)
					{
						// Balloon-popper bullets aim at the configured target point, then
						// steer toward the first balloon zombie in range (if any).
						Vector3 selfPos = transform.position;
						// The aim anchor comes from a global config singleton whose value could
						// not be recovered; fall back to the bullet's own position (no offset).
						// TODO: reconstruct aim anchor from the global config singleton
						//       (_DAT_182e70d90 -> [+0xb8] -> +0x3c/+0x44).
						Vector2 aimAnchor = Vector2.zero;
						bulletEntity.RotationToTarget(new Vector2(selfPos.x + aimAnchor.x, selfPos.y + aimAnchor.y));

						List<Zombie160Entity> balloonZombies = GetBalloonZombieList();
						if (balloonZombies != null && balloonZombies.Count > 0)
						{
							Zombie160Entity balloonZombie = balloonZombies[0];
							_targetBaseBody = balloonZombie;
							if (balloonZombie != null)
							{
								bulletEntity.RotationToTarget(balloonZombie.transform.position);
							}
						}
					}
				}
			}

			Vector2 direction = moveDirection;
			// After the one-shot temp-move window elapses, blend in the temporary direction.
			if (tempMoveTime > 0f && _tempMoveTimer < tempMoveTime)
			{
				direction += tempMoveDirection;
				_tempMoveTimer += Time.deltaTime;
			}

			if (bulletEntity.attr == null)
			{
				return;
			}
			float speed = bulletEntity.attr.bulletSpeed;
			Vector2 velocity = direction * (speed * Time.fixedDeltaTime);

			if (_rigidbody == null)
			{
				// No physics body: move the transform directly in local space.
				Vector3 local = transform.localPosition;
				transform.localPosition = new Vector3(local.x + velocity.x, local.y + velocity.y, local.z);
				return;
			}
			// Physics body present: convert the velocity to world space and MovePosition.
			Vector3 worldPos = transform.position;
			Vector3 worldMove = transform.TransformDirection(new Vector3(velocity.x, velocity.y, 0f));
			_rigidbody.MovePosition(new Vector2(worldPos.x + worldMove.x, worldPos.y + worldMove.y));
		}

		private ZombieEntity GetNearestZombie(Vector2 position)
		{
			// Nearest valid land zombie to the given position.
			List<ZombieEntity> zombies = LevelUtils.GetLandZombieList();
			if (zombies == null)
			{
				return null;
			}
			// Keep only zombies that are alive, pickable and not currently being eaten.
			// (The decompiled predicate also tests one further flag read by raw offset (+0x36)
			// whose member name is not present in the skeleton; it is omitted to avoid inventing it.)
			ZombieEntity nearest = zombies
				.Where(z => z != null && !z.IsDeath && !z.IsNotPick() && !z.IsNotEat())
				.OrderBy(z => (new Vector2(z.transform.position.x, z.transform.position.y) - position).magnitude)
				.FirstOrDefault();
			return nearest;
		}

		private List<Zombie160Entity> GetBalloonZombieList(int row = -1)
		{
			// All balloon-carrying zombies (optionally restricted to a single row).
			List<ZombieEntity> zombies = LevelUtils.GetLandZombieList();
			List<Zombie160Entity> result = new List<Zombie160Entity>();
			if (zombies == null)
			{
				return result;
			}
			foreach (ZombieEntity zombie in zombies)
			{
				if (row != -1 && zombie != null && zombie.GetRow() != row)
				{
					continue;
				}
				Zombie160Entity balloonZombie = zombie as Zombie160Entity;
				if (balloonZombie != null && balloonZombie.isHasBalloon)
				{
					result.Add(balloonZombie);
				}
			}
			return result;
		}
	}
}
