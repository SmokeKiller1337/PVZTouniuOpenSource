using Bullet.Entity;
using UnityEngine;

namespace Bullet.Part.Common
{
	public class RotatePart : BulletPartEntity
	{
		[Tooltip("每秒旋转角度")]
		public float rotateSpeed;

		[Tooltip("是否反向旋转")]
		public bool isReverse;

		private Rigidbody2D _rigidbody;

		protected override void Awake()
		{
			base.Awake();
			_rigidbody = GetComponent<Rigidbody2D>();
		}

		public override void Reset()
		{
		}

		public override void ReplaceBullet(BulletEntity oldBulletEntity)
		{
			if (oldBulletEntity == null)
			{
				return;
			}
			RotatePart oldPart = oldBulletEntity.GetComponent<RotatePart>();
			if (oldPart != null)
			{
				rotateSpeed = oldPart.rotateSpeed;
				isReverse = oldPart.isReverse;
			}
		}

		private void FixedUpdate()
		{
			if (_bulletEntity == null)
			{
				return;
			}
			if (_bulletEntity.IsDestroy)
			{
				return;
			}
			float speed = rotateSpeed;
			if (isReverse)
			{
				speed = -speed;
			}
			Vector3 eulerAngles = transform.eulerAngles;
			eulerAngles.z = Time.fixedDeltaTime * speed + eulerAngles.z;
			transform.eulerAngles = eulerAngles;
		}
	}
}
