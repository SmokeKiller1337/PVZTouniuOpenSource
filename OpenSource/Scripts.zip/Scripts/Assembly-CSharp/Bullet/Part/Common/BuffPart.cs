using System;
using System.Collections.Generic;
using Bullet.Entity;
using Common.Entity;
using Game.Entity;
using NoSLoofah.BuffSystem;
using UnityEngine;

namespace Bullet.Part.Common
{
	public class BuffPart : BulletPartEntity
	{
		[Serializable]
		public class BuffPartItem
		{
			[Tooltip("Buff的id")]
			public int buffId;

			[Tooltip("持续时间")]
			public float duration;

			[Tooltip("值集合")]
			public List<ValueEntity> valueList;
		}

		[Header("施加Buff")]
		public List<BuffPartItem> addBuffList;

		[Header("移除Buff")]
		public List<int> removeBuffList;

		protected override void Awake()
		{
			base.Awake();
			if (_bulletEntity != null)
			{
				_bulletEntity.OnTriggerAction += delegate(BulletEntity bullet, BaseBody baseBody)
				{
					AddBuff(baseBody);
				};
			}
		}

		public override void Reset()
		{
		}

		public override void ReplaceBullet(BulletEntity oldBulletEntity)
		{
		}

		private void AddBuff(BaseBody baseBody)
		{
			if (baseBody == null)
			{
				return;
			}
			BuffHandler buffHandler = baseBody.BuffHandler;
			if (buffHandler == null)
			{
				return;
			}
			GameObject caster = base.gameObject;
			// Apply every configured buff to the hit body's BuffHandler.
			if (addBuffList != null)
			{
				foreach (BuffPartItem item in addBuffList)
				{
					if (item == null || item.buffId == -1)
					{
						continue;
					}
					buffHandler.AddBuff(item.buffId, caster, item.duration, item.valueList);
				}
			}
			// Remove every configured buff from the hit body's BuffHandler.
			if (removeBuffList != null)
			{
				foreach (int buffId in removeBuffList)
				{
					buffHandler.RemoveBuff(buffId);
				}
			}
		}
	}
}
