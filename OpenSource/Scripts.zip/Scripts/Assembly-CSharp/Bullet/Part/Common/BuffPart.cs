using System;
using System.Collections.Generic;
using Bullet.Entity;
using Common.Entity;
using Game.Entity;
using NoSLoofah.BuffSystem;
using UnityEngine;

namespace Bullet.Part.Common
{
	public class BuffPart : BulletPartEntity
	{
		[Serializable]
		public class BuffPartItem
		{
			[Tooltip("Buff的id")]
			public int buffId;

			[Tooltip("持续时间")]
			public float duration;

			[Tooltip("值集合")]
			public List<ValueEntity> valueList;
		}

		[Header("施加Buff")]
		public List<BuffPartItem> addBuffList;

		[Header("移除Buff")]
		public List<int> removeBuffList;

		protected override void Awake()
		{
			base.Awake();
			if (_bulletEntity != null)
			{
				// Awake subscribes AddBuff to the owning bullet's trigger event. The pseudocode
				// combines a new delegate onto the field at _bulletEntity+0x70 (OnTriggerAction);
				// the delegate target is the compiler-generated <Awake>b__2_0 lambda, which simply
				// forwards the hit body to AddBuff. Expressed here as the equivalent lambda so the
				// C# compiler regenerates the same closure method.
				_bulletEntity.OnTriggerAction += delegate(BulletEntity bullet, BaseBody baseBody)
				{
					AddBuff(baseBody);
				};
			}
		}

		public override void Reset()
		{
			// Pseudocode body is a bare return (empty).
		}

		public override void ReplaceBullet(BulletEntity oldBulletEntity)
		{
			// Pseudocode body is a bare return (empty).
		}

		private void AddBuff(BaseBody baseBody)
		{
			if (baseBody == null)
			{
				return;
			}
			BuffHandler buffHandler = baseBody.BuffHandler;
			if (buffHandler == null)
			{
				return;
			}
			GameObject caster = base.gameObject;
			// Apply every configured buff to the hit body's BuffHandler.
			if (addBuffList != null)
			{
				foreach (BuffPartItem item in addBuffList)
				{
					if (item == null || item.buffId == -1)
					{
						// Pseudocode skips this entry when buffId == -1 (jumps straight to the
						// next iteration) before the ZombieEntity gate is even evaluated.
						continue;
					}
					// TODO: reconstruct — the decompiled body contains an additional gate for
					// ZombieEntity targets (reads an unresolved member at zombie offset 0x118 with a
					// float threshold at +0x24, and skips the buff unless ZombieEntity.IsBackAttack
					// returns true for this bullet's world position). The threshold member could not
					// be mapped to a named field, so the conditional gate is omitted here rather than
					// invented; all buffs are applied unconditionally, which matches the common path
					// (threshold <= 0) in the decompilation.
					buffHandler.AddBuff(item.buffId, caster, item.duration, item.valueList);
				}
			}
			// Remove every configured buff from the hit body's BuffHandler.
			if (removeBuffList != null)
			{
				foreach (int buffId in removeBuffList)
				{
					buffHandler.RemoveBuff(buffId);
				}
			}
		}
	}
}
