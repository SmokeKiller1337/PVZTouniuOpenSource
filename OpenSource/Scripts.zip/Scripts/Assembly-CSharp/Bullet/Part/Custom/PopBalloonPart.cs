using Bullet.Entity;
using Common.Collider;
using Land.Entity;
using UnityEngine;
using Zombie.Entity.Data;

namespace Bullet.Part.Custom
{
	public class PopBalloonPart : BulletPartEntity
	{
		[Tooltip("生效行")]
		public int row;

		public override void Reset()
		{
			// Pseudocode: *(int*)(this + 0x28) = 0xffffffff  ->  row = -1
			// (0x28 is the `row` field per dump.cs; -1 means "any row").
			row = -1;
		}

		public override void ReplaceBullet(BulletEntity oldBulletEntity)
		{
			// The body at this RVA is ICF-folded onto an empty method (an empty ..ctor).
			// PopBalloonPart genuinely does nothing on ReplaceBullet.
		}

		protected override void Awake()
		{
			// Pseudocode: this._bulletEntity = GetComponent<BulletEntity>() (stored at offset 0x20,
			// the inherited BulletPartEntity._bulletEntity field). The trailing op_Equality/throw
			// sequence is IL2CPP's inlined null-check boilerplate, not user logic.
			_bulletEntity = GetComponent<BulletEntity>();
		}

		private void Update()
		{
			// ICF-folded onto an empty method; PopBalloonPart has no per-frame logic.
		}

		protected virtual void OnTriggerEnter2D(Collider2D col)
		{
			if (col == null)
			{
				return;
			}
			GameObject go = col.gameObject;
			if (go == null)
			{
				return;
			}

			// Pseudocode: GetComponent<ZombieBodyColliderEntity>() (type token 0x182e3b570).
			ZombieBodyColliderEntity zombieBodyCollider = go.GetComponent<ZombieBodyColliderEntity>();
			if (zombieBodyCollider == null)
			{
				return;
			}

			// baseBody (offset 0x28, inherited from CommonColliderEntity) is isinst-cast to the
			// balloon zombie type Zombie160Entity (type token 0x182e83148).
			Zombie160Entity balloonZombie = zombieBodyCollider.baseBody as Zombie160Entity;
			if (balloonZombie == null)
			{
				return;
			}

			// currentRowLandEntity is ZombieEntity+0x148 (plVar7[0x29]); its `row` is RowLandEntity+0x20.
			// When this part is bound to a specific row (row != -1) and the zombie knows its row,
			// only proceed if the rows match.
			RowLandEntity currentRow = balloonZombie.currentRowLandEntity;
			if (currentRow != null && row != -1)
			{
				if (row != currentRow.row)
				{
					return;
				}
			}

			// isHasBalloon is Zombie160Entity+0x1F0 (plVar7[0x3e]).
			if (balloonZombie.isHasBalloon)
			{
				// vtable+0x558: Zombie160Entity.PopBalloon()
				balloonZombie.PopBalloon();
				// _bulletEntity.<vtable+0x198>(zombie.gameObject): BulletEntity.Trigger(GameObject)
				_bulletEntity.Trigger(balloonZombie.gameObject);
			}
		}
	}
}
