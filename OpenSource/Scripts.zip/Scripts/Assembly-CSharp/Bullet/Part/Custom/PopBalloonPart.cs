using Bullet.Entity;
using Common.Collider;
using Land.Entity;
using UnityEngine;
using Zombie.Entity.Data;

namespace Bullet.Part.Custom
{
	public class PopBalloonPart : BulletPartEntity
	{
		[Tooltip("生效行")]
		public int row;

		public override void Reset()
		{
			row = -1;
		}

		public override void ReplaceBullet(BulletEntity oldBulletEntity)
		{
		}

		protected override void Awake()
		{
			_bulletEntity = GetComponent<BulletEntity>();
		}

		private void Update()
		{
		}

		protected virtual void OnTriggerEnter2D(Collider2D col)
		{
			if (col == null)
			{
				return;
			}
			GameObject go = col.gameObject;
			if (go == null)
			{
				return;
			}

			ZombieBodyColliderEntity zombieBodyCollider = go.GetComponent<ZombieBodyColliderEntity>();
			if (zombieBodyCollider == null)
			{
				return;
			}

			// baseBody (offset 0x28, inherited from CommonColliderEntity) is isinst-cast to the
			// balloon zombie type Zombie160Entity (type token 0x182e83148).
			Zombie160Entity balloonZombie = zombieBodyCollider.baseBody as Zombie160Entity;
			if (balloonZombie == null)
			{
				return;
			}

			RowLandEntity currentRow = balloonZombie.currentRowLandEntity;
			if (currentRow != null && row != -1)
			{
				if (row != currentRow.row)
				{
					return;
				}
			}

			if (balloonZombie.isHasBalloon)
			{
				balloonZombie.PopBalloon();
				_bulletEntity.Trigger(balloonZombie.gameObject);
			}
		}
	}
}
