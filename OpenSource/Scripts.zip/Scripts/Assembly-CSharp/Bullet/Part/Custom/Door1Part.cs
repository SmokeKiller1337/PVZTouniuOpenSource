using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Bullet.Entity;
using Bullet.Util;
using DG.Tweening;
using Game.Entity;
using Game.Util;
using UnityEngine;

namespace Bullet.Part.Custom
{
	public class Door1Part : BulletPartEntity
	{
		[CompilerGenerated]
		private sealed class _003CExplosion_003Ed__10 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Door1Part _003C_003E4__this;

			public Vector3 position;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CExplosion_003Ed__10(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Door1Part door1Part = _003C_003E4__this;
				if (num != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				// 在命中点生成爆炸特效
				GameUtils.CreateEffect(door1Part.explosionEffect, position, Quaternion.identity, 1f);
				// 以自身位置为中心，对指定层的目标造成范围爆炸伤害
				Vector3 origin = door1Part.transform.position;
				// TODO: reconstruct — 爆炸半径 (_UNK_18252cd2c) 与伤害 (_UNK_18252ce98) 为反编译中无法恢复的
				// 常量数据指针，此处采用占位数值；层掩码所用的层名字符串同样无法恢复。
				int layerMask = LayerMask.GetMask(ExplosionTargetLayer);
				DamageUtils.Explosion(origin, ExplosionRadius, ExplosionDamage, layerMask);
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("爆炸效果")]
		public EffectEntity explosionEffect;

		private bool _isExplosion;

		private float _removeBulletTime;

		private float _removeBulletTimer;

		private TrailRenderer _trailRenderer;

		// TODO: reconstruct — 以下常量在反编译中是数据指针 / 裸浮点加载，其真实取值无法可靠恢复，
		// 采用语义合理的占位值以保证可编译。
		private const string ExplosionTargetLayer = "Zombie"; // <Explosion> 中 LayerMask.GetMask 参数
		private const float ExplosionRadius = 1f;              // _UNK_18252cd2c
		private const float ExplosionDamage = 20f;             // _UNK_18252ce98
		private const float RestoreTrailTimeDelay = 0.1f;      // Reset 中 DOVirtual.DelayedCall 延时 (_UNK_18252cb7c)

		public override void Reset()
		{
			// 复位状态标记
			_isExplosion = false;
			_removeBulletTimer = 0f;
			if (_trailRenderer == null)
			{
				return;
			}
			// 暂存并清零拖尾时长，避免复位瞬间残留旧拖尾；延时后恢复原时长
			float savedTime = _trailRenderer.time;
			_trailRenderer.time = 0f;
			DOVirtual.DelayedCall(RestoreTrailTimeDelay, delegate
			{
				if (this != null && _trailRenderer != null)
				{
					_trailRenderer.time = savedTime;
				}
			});
		}

		public override void ReplaceBullet(BulletEntity oldBulletEntity)
		{
			if (oldBulletEntity == null)
			{
				return;
			}
			// 从被替换的子弹上继承同类部件的运行时状态
			Door1Part oldPart = oldBulletEntity.GetComponent<Door1Part>();
			if (oldPart == null)
			{
				return;
			}
			_isExplosion = oldPart._isExplosion;
			_removeBulletTime = oldPart._removeBulletTime;
			_removeBulletTimer = oldPart._removeBulletTimer;
		}

		protected override void Awake()
		{
			base.Awake();
			_trailRenderer = GetComponentInChildren<TrailRenderer>();
		}

		private void Update()
		{
			// TODO: reconstruct — 伪代码在此以 _removeBulletTime 为间隔，用 Physics2D.OverlapCircleAll
			// 扫描周围碰撞体并对满足条件者调用一个虚表方法 (*+0x1b8)。该虚表方法所属类型、被扫描组件
			// 的具体类型以及半径/层掩码常量均无法从反编译中可靠还原，故保留桩实现以避免臆造成员。
		}

		protected virtual void OnTriggerEnter2D(Collider2D col)
		{
			// TODO: reconstruct — 伪代码存在两条分支（命中门/植物 vs 命中子弹），分别引用无法确定
			// 类型的 GetComponent<T> 结果、多个未恢复的虚表槽位 (*+0x1b8) 以及 DOVirtual 延时回调。
			// 无法在不臆造成员的前提下可靠还原，保留桩实现。
		}

		[IteratorStateMachine(typeof(_003CExplosion_003Ed__10))]
		private IEnumerator Explosion(Vector3 position)
		{
			_003CExplosion_003Ed__10 stateMachine = new _003CExplosion_003Ed__10(0);
			stateMachine._003C_003E4__this = this;
			stateMachine.position = position;
			return stateMachine;
		}
	}
}
