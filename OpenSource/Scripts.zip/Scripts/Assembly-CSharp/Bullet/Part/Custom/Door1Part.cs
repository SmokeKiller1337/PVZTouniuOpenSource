using System;
using System.Collections;
using System.Collections.Generic;
using Bullet.Entity;
using Bullet.Util;
using DG.Tweening;
using Game.Entity;
using Game.Util;
using UnityEngine;

namespace Bullet.Part.Custom
{
	public class Door1Part : BulletPartEntity
	{
		[Tooltip("爆炸效果")]
		public EffectEntity explosionEffect;

		private bool _isExplosion;

		private float _removeBulletTime;

		private float _removeBulletTimer;

		private TrailRenderer _trailRenderer;

		private const string ExplosionTargetLayer = "Zombie"; // <Explosion> 中 LayerMask.GetMask 参数
		private const float ExplosionRadius = 1f;
		private const float ExplosionDamage = 20f;
		private const float RestoreTrailTimeDelay = 0.1f;

		public override void Reset()
		{
			// 复位状态标记
			_isExplosion = false;
			_removeBulletTimer = 0f;
			if (_trailRenderer == null)
			{
				return;
			}
			// 暂存并清零拖尾时长，避免复位瞬间残留旧拖尾；延时后恢复原时长
			float savedTime = _trailRenderer.time;
			_trailRenderer.time = 0f;
			DOVirtual.DelayedCall(RestoreTrailTimeDelay, delegate
			{
				if (this != null && _trailRenderer != null)
				{
					_trailRenderer.time = savedTime;
				}
			});
		}

		public override void ReplaceBullet(BulletEntity oldBulletEntity)
		{
			if (oldBulletEntity == null)
			{
				return;
			}
			// 从被替换的子弹上继承同类部件的运行时状态
			Door1Part oldPart = oldBulletEntity.GetComponent<Door1Part>();
			if (oldPart == null)
			{
				return;
			}
			_isExplosion = oldPart._isExplosion;
			_removeBulletTime = oldPart._removeBulletTime;
			_removeBulletTimer = oldPart._removeBulletTimer;
		}

		protected override void Awake()
		{
			base.Awake();
			_trailRenderer = GetComponentInChildren<TrailRenderer>();
		}

		private void Update()
		{
		}

		protected virtual void OnTriggerEnter2D(Collider2D col)
		{
		}

		private IEnumerator Explosion(Vector3 position)
		{
			// 在命中点生成爆炸特效
			GameUtils.CreateEffect(explosionEffect, position, Quaternion.identity, 1f);
			// 以自身位置为中心，对指定层的目标造成范围爆炸伤害
			Vector3 origin = transform.position;
			int layerMask = LayerMask.GetMask(ExplosionTargetLayer);
			DamageUtils.Explosion(origin, ExplosionRadius, ExplosionDamage, layerMask);
			yield break;
		}
	}
}
