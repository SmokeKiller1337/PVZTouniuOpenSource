using System.Collections.Generic;
using Common.Collider;
using Common.Entity;
using Level.Entity;
using Plant.Entity;
using Plant.Enum;
using UnityEngine;

namespace Bullet.Util
{
	public static class DamageUtils
	{
		// Priority weight for each plant placement type, used to order the plants an
		// explosion damages. Higher weight = processed first (descending sort).
		private static readonly Dictionary<PlaceType, int> ExplosionPlantTypePriority;

		private const string ExplosionPlantLayerName = "Plant";

		public static List<BaseBody> Explosion(Vector2 position, float radius, float damage, int layerMask = -1, DamageTypeEntity damageType = null)
		{
			// Default to the shared "Explosion" damage descriptor when none supplied.
			if (damageType == null)
			{
				damageType = DamageTypeEntity.Explosion;
			}

			List<BaseBody> hitBodies = new List<BaseBody>();

			// Gather every collider inside the blast radius. A layerMask of -1 means
			// "all layers", which maps to the parameterless OverlapCircleAll overload.
			Collider2D[] cols;
			if (layerMask == -1)
			{
				cols = Physics2D.OverlapCircleAll(position, radius);
			}
			else
			{
				cols = Physics2D.OverlapCircleAll(position, radius, layerMask);
			}

			if (cols != null)
			{
				for (int i = 0; i < cols.Length; i++)
				{
					Collider2D col = cols[i];
					if (col == null)
					{
						continue;
					}
					CommonColliderEntity colliderEntity = col.GetComponent<CommonColliderEntity>();
					if (colliderEntity == null)
					{
						continue;
					}
					BaseBody body = colliderEntity.baseBody;
					if (body != null)
					{
						hitBodies.Add(body);
					}
				}
			}

			// Apply the damage to every gathered body.
			foreach (BaseBody body in hitBodies)
			{
				if (body == null)
				{
					continue;
				}
				body.Hit(damage, damageType);
			}

			return hitBodies;
		}

		public static List<BaseBody> ExplosionPlant(Vector2 position, float radius, float damage, BaseBody sourceBody = null)
		{
			// Restrict the blast to the plant layer, then reuse Explosion to collect every
			// body in range without dealing damage yet (damage 0, no descriptor).
			int layerMask = LayerMask.GetMask(ExplosionPlantLayerName);
			List<BaseBody> bodies = Explosion(position, radius, 0f, layerMask);
			if (bodies == null)
			{
				return null;
			}

			// Split the affected bodies: plants are collected for ordered handling below;
			// anything else takes immediate explosion damage.
			List<BaseBody> plants = new List<BaseBody>();
			foreach (BaseBody body in bodies)
			{
				if (body is PlantEntity)
				{
					plants.Add(body);
				}
				else if (body != null)
				{
					body.Hit(damage, DamageTypeEntity.Explosion);
				}
			}

			// Order the plants by placement-type priority (highest first) so that the
			// explosion resolves against them in a stable, designer-defined sequence.
			// (comparator recovered from the <ExplosionPlant>b__2_0 lambda: it compares the
			// two plants' placement-type priorities, descending.)
			plants.Sort(delegate(BaseBody a, BaseBody b)
			{
				int priorityA = 0;
				int priorityB = 0;
				if (a is PlantEntity plantA)
				{
					CardEntity cardA = plantA.CardEntity;
					if (cardA != null)
					{
						ExplosionPlantTypePriority.TryGetValue(cardA.placeType, out priorityA);
					}
				}
				if (b is PlantEntity plantB)
				{
					CardEntity cardB = plantB.CardEntity;
					if (cardB != null)
					{
						ExplosionPlantTypePriority.TryGetValue(cardB.placeType, out priorityB);
					}
				}
				return priorityB.CompareTo(priorityA);
			});

			foreach (BaseBody plant in plants)
			{
				// The plant that originated the blast never damages itself.
				if (plant == sourceBody || plant == null)
				{
					continue;
				}
				plant.Hit(damage, DamageTypeEntity.Explosion);
			}

			return bodies;
		}

		static DamageUtils()
		{
			// Placement-type priority table used to order plants hit by an explosion.
			// (recovered from the static constructor's Dictionary.Add sequence)
			ExplosionPlantTypePriority = new Dictionary<PlaceType, int>
			{
				{ PlaceType.Float, 4 },
				{ PlaceType.Master, 3 },
				{ PlaceType.Base, 2 },
				{ PlaceType.Shell, 1 }
			};
		}
	}
}
