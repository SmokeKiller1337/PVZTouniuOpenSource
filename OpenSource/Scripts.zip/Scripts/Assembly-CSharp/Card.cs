using FairyGUI;
using FairyGUI.Utils;

public class Card : GButton
{
	private GObject _back;

	private GObject _front;

	public bool opened
	{
		get
		{
			return false;
		}
		set
		{
		}
	}

	public override void ConstructFromXML(XML xml)
	{
	}

	public void SetPerspective()
	{
	}

	public void Turn()
	{
	}
}
