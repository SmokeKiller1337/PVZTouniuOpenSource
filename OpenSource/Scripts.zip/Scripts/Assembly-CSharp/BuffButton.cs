using NoSLoofah.BuffSystem;
using TMPro;
using UnityEngine;

public class BuffButton : MonoBehaviour
{
	[SerializeField]
	private TMP_InputField inputField;

	[SerializeField]
	private BuffHandler buffHandler;

	public void AddBuff()
	{
		if (int.TryParse(inputField.text, out var buffId))
		{
			buffHandler.AddBuff(buffId, null);
		}
	}

	public void RemoveBuff()
	{
		if (int.TryParse(inputField.text, out var buffId))
		{
			buffHandler.RemoveBuff(buffId, true);
		}
	}

	public void InteruptBuff()
	{
		if (int.TryParse(inputField.text, out var buffId))
		{
			buffHandler.InterruptBuff(buffId, true);
		}
	}
}
