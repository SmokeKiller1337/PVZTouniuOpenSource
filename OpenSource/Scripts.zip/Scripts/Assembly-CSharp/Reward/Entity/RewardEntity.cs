using Audio.Manager;
using DG.Tweening;
using Level.Manager;
using Reward.Enum;
using UnityEngine;
using UnityEngine.Rendering;

namespace Reward.Entity
{
	public abstract class RewardEntity : MonoBehaviour
	{
		[Tooltip("编号")]
		public int id;

		[Tooltip("拾取类型")]
		public PickUpType pickUpType;

		[Tooltip("出现音效")]
		public AudioClip startSound;

		[Tooltip("拾取音效")]
		public AudioClip pickUpSound;

		[Range(0f, 1f)]
		[Tooltip("音频幅度")]
		public float pitchRange;

		[Tooltip("落下速度")]
		public float speed;

		[Tooltip("自动拾取时间")]
		public float autoPickUpTime;

		private float _autoPickUpTimer;

		[HideInInspector]
		public bool isPickedUp;

		[HideInInspector]
		public bool isProduce;

		public Sequence ProduceSequence;

		protected Rigidbody2D _rigidbody;

		protected SortingGroup _sortingGroup;

		protected float _scale;

		public Rigidbody2D Rigidbody
		{
			get
			{
				return _rigidbody;
			}
			set
			{
				_rigidbody = value;
			}
		}

		public SortingGroup SortingGroup
		{
			get
			{
				return _sortingGroup;
			}
			set
			{
				_sortingGroup = value;
			}
		}

		public float Scale
		{
			get
			{
				return _scale;
			}
			set
			{
				_scale = value;
				base.transform.localScale = Vector3.one * value;
			}
		}

		public virtual void Reset()
		{
			// 0x48 isPickedUp, 0x68 _scale (0x3f800000 == 1.0f)
			isPickedUp = false;
			_scale = 1f;
			// See note in the Scale setter about the base-scale Vector3.
			base.transform.localScale = Vector3.one * _scale;
			// 0x3c speed, 0x44 _autoPickUpTimer
			speed = 0f;
			_autoPickUpTimer = 0f;
			if (ProduceSequence != null)
			{
				ProduceSequence.Complete();
				ProduceSequence = null;
			}
		}

		public virtual void Appear()
		{
			// Play the appearance sound effect through the UI audio channel.
			if (AudioManager.Instance != null)
			{
				AudioManager.Instance.PlayUI(startSound);
			}
			// Only entities that were "produced" (spawned with the pop animation) play the
			// appear tween; otherwise Appear only emits the sound.
			if (!isProduce)
			{
				return;
			}
			ProduceSequence = DOTween.Sequence();
			Vector3 position = base.transform.position;
			float duration = 0.25f;
			float offsetX = Random.Range(-1f, 1f);
			Vector3 up = new Vector3(position.x + offsetX, position.y + 1f, position.z);
			Vector3 down = new Vector3(position.x + offsetX, position.y, position.z);
			ProduceSequence.Append(base.transform.DOMove(up, duration).SetEase(Ease.OutQuad));
			ProduceSequence.Append(base.transform.DOMove(down, duration).SetEase(Ease.OutQuad));
			// Reset localScale to the identity base then pop-scale to the target scale.
			base.transform.localScale = Vector3.one;
			base.transform.DOScale(_scale, duration);
		}

		protected virtual void Awake()
		{
			// Cache the child Rigidbody2D used for the falling motion in Update.
			_rigidbody = base.GetComponentInChildren<Rigidbody2D>();
		}

		protected virtual void Start()
		{
		}

		protected virtual void Update()
		{
			if (_rigidbody == null)
			{
				return;
			}
			// Fall straight down at `speed` units/second.
			Vector2 position = _rigidbody.position;
			_rigidbody.position = new Vector2(position.x, position.y - speed * Time.deltaTime);
			// Auto pick-up: once the entity has existed for `autoPickUpTime` seconds
			// (and hasn't already been picked up), pick it up automatically.
			if (!isPickedUp && autoPickUpTime > 0f)
			{
				_autoPickUpTimer += Time.deltaTime;
				if (_autoPickUpTimer >= autoPickUpTime)
				{
					PickUp();
				}
			}
		}

		public void OnRewardEnter()
		{
			if (pickUpType != PickUpType.MouseEnter)
			{
				return;
			}
			if (isPickedUp)
			{
				return;
			}
			isPickedUp = true;
			if (AudioManager.Instance != null)
			{
				AudioManager.Instance.PlayUI(pickUpSound, pitchRange);
			}
			if (ProduceSequence != null)
			{
				ProduceSequence.Kill();
				ProduceSequence = null;
			}
			OnPickUp();
		}

		public void OnRewardClick()
		{
			if (pickUpType != PickUpType.MouseDown)
			{
				return;
			}
			if (isPickedUp)
			{
				return;
			}
			isPickedUp = true;
			if (AudioManager.Instance != null)
			{
				AudioManager.Instance.PlayUI(pickUpSound, pitchRange);
			}
			if (ProduceSequence != null)
			{
				ProduceSequence.Kill();
				ProduceSequence = null;
			}
			OnPickUp();
		}

		public void PickUp()
		{
			if (isPickedUp)
			{
				return;
			}
			isPickedUp = true;
			if (AudioManager.Instance != null)
			{
				AudioManager.Instance.PlayUI(pickUpSound, pitchRange);
			}
			if (ProduceSequence != null)
			{
				ProduceSequence.Kill();
				ProduceSequence = null;
			}
			OnPickUp();
		}

		protected abstract void OnPickUp();

		public virtual void RewardEnd()
		{
			if (RewardManager.Instance != null)
			{
				RewardManager.Instance.ReleaseReward(this);
			}
		}
	}
}
