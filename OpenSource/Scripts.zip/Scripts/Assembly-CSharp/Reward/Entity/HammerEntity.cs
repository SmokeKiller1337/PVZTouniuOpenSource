using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Reward.Entity
{
	public class HammerEntity : RewardEntity
	{
		[Tooltip("锤子价值")]
		public int value;

		public override void Reset()
		{
			base.Reset();
			value = 1;
		}

		protected override void Start()
		{
		}

		protected override void OnPickUp()
		{
			StartCoroutine(PickUpCoroutine());
		}

		private IEnumerator PickUpCoroutine()
		{
			yield break;
		}
	}
}
