using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

namespace Reward.Entity
{
	public class HammerEntity : RewardEntity
	{
		[CompilerGenerated]
		private sealed class _003CPickUpCoroutine_003Ed__4 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public HammerEntity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CPickUpCoroutine_003Ed__4(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct - the original coroutine flew the hammer to the current card
				// slot (state 0), scaled it (state 1), added its value to the hammer counter
				// (state 2: CardSlotManager.Instance.HammerValue += <>4__this.value) and then
				// called RewardEnd (state 3), yielding WaitForSeconds between each step.
				// State 0 depends on GameManager.CardSlotBox (no such member exists on GameManager)
				// plus CardSlotBoxEntity.GetCurrentCardSlot -> GComponent.GetChild -> LocalToGlobal
				// -> Camera.ScreenToWorldPoint -> Transform.DOMove, and every WaitForSeconds
				// duration maps to an unresolved global constant. Because the very first state
				// references a missing member and the wait durations cannot be recovered, the
				// whole state machine is left as a no-op stub rather than fabricating members.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("锤子价值")]
		public int value;

		public override void Reset()
		{
			base.Reset();
			value = 1;
			// TODO: reconstruct - the original also reset transform.localScale to a Vector3 read
			// from a manager singleton (global _DAT_182e70d90, deref +0xb8 -> Instance, fields
			// +0xc/+0x14). The source manager/config field could not be identified, so the scale
			// reset is omitted rather than fabricating a member.
		}

		protected override void Start()
		{
			// Empty in the original (RVA 0x381980 is the shared empty-method body).
		}

		protected override void OnPickUp()
		{
			StartCoroutine(PickUpCoroutine());
		}

		[IteratorStateMachine(typeof(_003CPickUpCoroutine_003Ed__4))]
		private IEnumerator PickUpCoroutine()
		{
			return new _003CPickUpCoroutine_003Ed__4(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
