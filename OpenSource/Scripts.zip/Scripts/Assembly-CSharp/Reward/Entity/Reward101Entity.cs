using System;
using System.Collections;
using System.Collections.Generic;
using Audio.Manager;
using DG.Tweening;
using FGUI;
using Level.Manager.Data.Mini;
using Level.Util;
using Plant.Entity;
using UnityEngine;

namespace Reward.Entity
{
	public class Reward101Entity : RewardEntity
	{
		[Tooltip("贴图集合")]
		public List<Sprite> spriteList;

		private SpriteRenderer _spriteRenderer;

		private int cardIndex;

		public override void Reset()
		{
			base.Reset();
			Transform transform = base.transform;
			if (transform == null)
			{
				return;
			}
			transform.localScale = Vector3.one;
			if (spriteList == null)
			{
				return;
			}

			// Pick a random sprite as the default reward appearance.
			int index = UnityEngine.Random.Range(0, spriteList.Count);
			cardIndex = index;
			if (_spriteRenderer != null)
			{
				_spriteRenderer.sprite = spriteList[index];
			}

			// When the Mini4 data manager is present, let it choose a
			// non-repeating reward sprite index instead.
			if (LevelMini4DataManager.Instance == null)
			{
				return;
			}
			int randomReward101Index = LevelMini4DataManager.Instance.GetRandomReward101Index();
			if (randomReward101Index == -1)
			{
				return;
			}
			if (_spriteRenderer != null)
			{
				_spriteRenderer.sprite = spriteList[randomReward101Index];
				cardIndex = randomReward101Index;
			}
		}

		protected override void Awake()
		{
			base.Awake();
			_spriteRenderer = GetComponentInChildren<SpriteRenderer>();
		}

		protected override void Start()
		{
		}

		protected override void OnPickUp()
		{
			StartCoroutine(PickUpCoroutine());
		}

		private IEnumerator PickUpCoroutine()
		{
			// 标记已拾取并播放拾取音效。
			isPickedUp = true;
			if (AudioManager.Instance != null)
			{
				AudioManager.Instance.PlayOneShot(pickUpSound, pitchRange);
			}

			// 计算飞行目标位置：若卡片索引仍指向当前关卡中的有效卡片，
			// 则飞向该卡片的槽位，否则保持当前位置。
			CardEntity cardEntity = null;
			Vector2 target = transform.position;
			List<CardEntity> cardList = LevelUtils.GetCardList();
			if (cardList != null && cardIndex >= 0 && cardIndex < cardList.Count)
			{
				cardEntity = cardList[cardIndex];
				if (cardEntity != null)
				{
					target = LevelUtils.GetCardPosition(cardEntity.id);
				}
			}

			transform.DOMove(new Vector3(target.x, target.y, 0f), 0.5f);
			yield return new WaitForSeconds(0.5f);

			transform.DOScale(0f, 0.3f);
			yield return new WaitForSeconds(0.3f);

			if (cardEntity != null)
			{
				// 将目标卡片升级到所需等级后刷新卡槽界面。
				while (cardEntity != null)
				{
					if (cardEntity.level > 1)
					{
						if (FGUIConstant.CardSlotBox != null)
						{
							FGUIConstant.CardSlotBox.UpdateCard(cardEntity);
							FGUIConstant.CardSlotBox.UpdateLevelUpButton();
						}
						break;
					}
					cardEntity.LevelUp(0);
				}
			}
			yield return new WaitForSeconds(0.1f);

			if (LevelMini4DataManager.Instance != null)
			{
				if (_spriteRenderer != null)
				{
					LevelMini4DataManager.Instance.CreateReward101Sprite(cardIndex, _spriteRenderer.sprite);
				}
				if (LevelMini4DataManager.Instance != null)
				{
					LevelMini4DataManager.Instance.TouniuTalk(cardIndex);
				}
			}
			RewardEnd();
		}
	}
}
