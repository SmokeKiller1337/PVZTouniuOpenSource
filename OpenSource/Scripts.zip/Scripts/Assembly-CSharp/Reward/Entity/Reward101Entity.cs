using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Audio.Manager;
using DG.Tweening;
using FGUI;
using Level.Manager.Data.Mini;
using Level.Util;
using Plant.Entity;
using UnityEngine;

namespace Reward.Entity
{
	public class Reward101Entity : RewardEntity
	{
		[CompilerGenerated]
		private sealed class _003CPickUpCoroutine_003Ed__7 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Reward101Entity _003C_003E4__this;

			private CardEntity _003CcardEntity_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CPickUpCoroutine_003Ed__7(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				Reward101Entity reward101Entity = _003C_003E4__this;
				switch (num)
				{
				default:
					return false;
				case 0:
				{
					_003C_003E1__state = -1;
					// Mark as picked up and play the pickup sound.
					reward101Entity.isPickedUp = true;
					if (AudioManager.Instance != null)
					{
						AudioManager.Instance.PlayOneShot(reward101Entity.pickUpSound, reward101Entity.pitchRange);
					}

					// Determine the fly-to target position. If the stored card index
					// still refers to a valid card in the current level, fly toward
					// that card's slot; otherwise keep the current transform position.
					Vector2 target = reward101Entity.transform.position;
					List<CardEntity> cardList = LevelUtils.GetCardList();
					if (cardList != null && reward101Entity.cardIndex >= 0 && reward101Entity.cardIndex < cardList.Count)
					{
						_003CcardEntity_003E5__2 = cardList[reward101Entity.cardIndex];
						if (_003CcardEntity_003E5__2 != null)
						{
							target = LevelUtils.GetCardPosition(_003CcardEntity_003E5__2.id);
						}
					}

					reward101Entity.transform.DOMove(new Vector3(target.x, target.y, 0f), 0.5f);
					_003C_003E2__current = new WaitForSeconds(0.5f);
					_003C_003E1__state = 1;
					return true;
				}
				case 1:
					_003C_003E1__state = -1;
					reward101Entity.transform.DOScale(0f, 0.3f);
					_003C_003E2__current = new WaitForSeconds(0.3f);
					_003C_003E1__state = 2;
					return true;
				case 2:
				{
					_003C_003E1__state = -1;
					CardEntity cardEntity = _003CcardEntity_003E5__2;
					if (cardEntity != null)
					{
						// Level the target card up until it reaches the required level,
						// then refresh the card-slot UI.
						while (cardEntity != null)
						{
							if (cardEntity.level > 1)
							{
								if (FGUIConstant.CardSlotBox != null)
								{
									FGUIConstant.CardSlotBox.UpdateCard(cardEntity);
									FGUIConstant.CardSlotBox.UpdateLevelUpButton();
								}
								break;
							}
							cardEntity.LevelUp(0);
							cardEntity = _003CcardEntity_003E5__2;
						}
					}
					_003C_003E2__current = new WaitForSeconds(0.1f);
					_003C_003E1__state = 3;
					return true;
				}
				case 3:
					_003C_003E1__state = -1;
					if (LevelMini4DataManager.Instance != null)
					{
						if (reward101Entity._spriteRenderer != null)
						{
							LevelMini4DataManager.Instance.CreateReward101Sprite(reward101Entity.cardIndex, reward101Entity._spriteRenderer.sprite);
						}
						if (LevelMini4DataManager.Instance != null)
						{
							LevelMini4DataManager.Instance.TouniuTalk(reward101Entity.cardIndex);
						}
					}
					reward101Entity.RewardEnd();
					return false;
				}
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("贴图集合")]
		public List<Sprite> spriteList;

		private SpriteRenderer _spriteRenderer;

		private int cardIndex;

		public override void Reset()
		{
			base.Reset();
			Transform transform = base.transform;
			if (transform == null)
			{
				return;
			}
			transform.localScale = Vector3.one;
			if (spriteList == null)
			{
				return;
			}

			// Pick a random sprite as the default reward appearance.
			int index = UnityEngine.Random.Range(0, spriteList.Count);
			cardIndex = index;
			if (_spriteRenderer != null)
			{
				_spriteRenderer.sprite = spriteList[index];
			}

			// When the Mini4 data manager is present, let it choose a
			// non-repeating reward sprite index instead.
			if (LevelMini4DataManager.Instance == null)
			{
				return;
			}
			int randomReward101Index = LevelMini4DataManager.Instance.GetRandomReward101Index();
			if (randomReward101Index == -1)
			{
				return;
			}
			if (_spriteRenderer != null)
			{
				_spriteRenderer.sprite = spriteList[randomReward101Index];
				cardIndex = randomReward101Index;
			}
		}

		protected override void Awake()
		{
			base.Awake();
			_spriteRenderer = GetComponentInChildren<SpriteRenderer>();
		}

		protected override void Start()
		{
			// Body folded by ICF to the shared empty method (RVA 0x381980).
			// Nothing to reconstruct.
		}

		protected override void OnPickUp()
		{
			StartCoroutine(PickUpCoroutine());
		}

		[IteratorStateMachine(typeof(_003CPickUpCoroutine_003Ed__7))]
		private IEnumerator PickUpCoroutine()
		{
			return new _003CPickUpCoroutine_003Ed__7(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
