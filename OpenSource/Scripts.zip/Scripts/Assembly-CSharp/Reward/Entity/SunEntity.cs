using System;
using System.Collections;
using System.Collections.Generic;
using Audio.Manager;
using Level.Manager;
using Reanim2UnityAnim;
using UnityEngine;

namespace Reward.Entity
{
	public class SunEntity : RewardEntity
	{
		[Tooltip("阳光价值")]
		public int value;

		private Transform baseTransform;

		private UniqueMaterialController _reanimSpriteEntity;

		public new Rigidbody2D Rigidbody
		{
			get
			{
				return _rigidbody;
			}
			set
			{
				_rigidbody = value;
			}
		}

		public override void Reset()
		{
			base.Reset();
			value = 25;
			// Reset the sprite tint that the pick-up fade tween drives to transparent, so a
			// recycled sun is fully visible again.
			if (_reanimSpriteEntity != null && _reanimSpriteEntity.spriteRenderers != null)
			{
				foreach (SpriteRenderer spriteRenderer in _reanimSpriteEntity.spriteRenderers)
				{
					if (spriteRenderer != null)
					{
						spriteRenderer.color = Color.white;
					}
				}
			}
		}

		protected override void Awake()
		{
			base.Awake();
			_reanimSpriteEntity = GetComponent<UniqueMaterialController>();
		}

		protected override void Start()
		{
		}

		protected override void OnPickUp()
		{
			StartCoroutine(PickUpCoroutine());
		}

		private IEnumerator PickUpCoroutine()
		{
			if (this == null)
			{
				yield break;
			}
			// 标记为已拾取并停止下落，让阳光定住不动
			isPickedUp = true;
			speed = 0f;
			// 播放拾取音效
			if (AudioManager.Instance != null)
			{
				AudioManager.Instance.PlayOneShot(pickUpSound);
			}
			yield return new WaitForSeconds(0.1f);
			if (this == null)
			{
				yield break;
			}
			yield return new WaitForSeconds(0.1f);
			if (this == null)
			{
				yield break;
			}
			// 按关卡的阳光价值系数把本阳光的数值加到玩家阳光总量
			if (CardSlotManager.Instance != null)
			{
				CardSlotManager.Instance.SunValue = (int)((float)value * CardSlotManager.Instance.sunValueRatio) + CardSlotManager.Instance.SunValue;
			}
			yield return new WaitForSeconds(0.1f);
			if (this == null)
			{
				yield break;
			}
			// 结束奖励生命周期（回收 / 销毁实体）
			RewardEnd();
		}

		public override void RewardEnd()
		{
			if (RewardManager.Instance != null)
			{
				RewardManager.Instance.ReleaseReward(this);
			}
		}
	}
}
