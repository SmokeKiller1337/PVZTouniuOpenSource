using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Audio.Manager;
using Level.Manager;
using Reanim2UnityAnim;
using UnityEngine;

namespace Reward.Entity
{
	public class SunEntity : RewardEntity
	{
		[CompilerGenerated]
		private sealed class _003CPickUpCoroutine_003Ed__10 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public SunEntity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CPickUpCoroutine_003Ed__10(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				SunEntity sunEntity = _003C_003E4__this;
				switch (num)
				{
				default:
					return false;
				case 0:
				{
					_003C_003E1__state = -1;
					if (sunEntity == null)
					{
						return false;
					}
					// Mark as picked up and stop the falling motion so the sun locks in place.
					sunEntity.isPickedUp = true;
					sunEntity.speed = 0f;
					// Play the pick-up sound effect.
					if (AudioManager.Instance != null)
					{
						AudioManager.Instance.PlayOneShot(sunEntity.pickUpSound);
					}
					// TODO: reconstruct - the original tweened the sun toward the on-screen sun
					// counter in the card slot box (Transform.DOMove to a screen->world point
					// derived from the current card slot UI child). That target relied on
					// GameManager.CardSlotBox (no such member exists on GameManager) plus
					// CardSlotBoxEntity.GetCurrentCardSlot -> GComponent.GetChild -> LocalToGlobal
					// -> Camera.ScreenToWorldPoint, so the movement tween is omitted.
					// The per-step WaitForSeconds duration also maps to an unresolved global
					// constant; a small placeholder delay is used so the coroutine stays functional.
					_003C_003E2__current = new WaitForSeconds(0.1f);
					_003C_003E1__state = 1;
					return true;
				}
				case 1:
					_003C_003E1__state = -1;
					if (sunEntity == null)
					{
						return false;
					}
					// TODO: reconstruct - the original played a scale "pop" tween on the sun
					// (transform.DOScale using _scale) and faded each of _reanimSpriteEntity's
					// SpriteRenderers to transparent (DOColor to Color(0,0,0,0)). Both tweens use
					// design-tuned duration/scale globals that are not recoverable from the
					// decompiled data, so the tween calls are omitted.
					_003C_003E2__current = new WaitForSeconds(0.1f);
					_003C_003E1__state = 2;
					return true;
				case 2:
					_003C_003E1__state = -1;
					if (sunEntity == null)
					{
						return false;
					}
					// Award this sun's value (scaled by the level's sun-value ratio) to the
					// player's sun total.
					if (CardSlotManager.Instance != null)
					{
						CardSlotManager.Instance.SunValue = (int)((float)sunEntity.value * CardSlotManager.Instance.sunValueRatio) + CardSlotManager.Instance.SunValue;
					}
					_003C_003E2__current = new WaitForSeconds(0.1f);
					_003C_003E1__state = 3;
					return true;
				case 3:
					_003C_003E1__state = -1;
					if (sunEntity == null)
					{
						return false;
					}
					// End the reward lifecycle (recycle / despawn the entity).
					sunEntity.RewardEnd();
					return false;
				}
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("阳光价值")]
		public int value;

		private Transform baseTransform;

		private UniqueMaterialController _reanimSpriteEntity;

		public new Rigidbody2D Rigidbody
		{
			get
			{
				return _rigidbody;
			}
			set
			{
				_rigidbody = value;
			}
		}

		public override void Reset()
		{
			base.Reset();
			value = 25;
			// Reset the sprite tint that the pick-up fade tween drives to transparent, so a
			// recycled sun is fully visible again.
			if (_reanimSpriteEntity != null && _reanimSpriteEntity.spriteRenderers != null)
			{
				foreach (SpriteRenderer spriteRenderer in _reanimSpriteEntity.spriteRenderers)
				{
					if (spriteRenderer != null)
					{
						// TODO: reconstruct - the exact reset color came from an unresolved global
						// Color constant; Color.white (fully opaque, untinted) is used as the
						// natural "restored" value.
						spriteRenderer.color = Color.white;
					}
				}
			}
		}

		protected override void Awake()
		{
			base.Awake();
			_reanimSpriteEntity = GetComponent<UniqueMaterialController>();
		}

		protected override void Start()
		{
			// Empty in the original (RVA 0x381980 is the shared empty-method body).
		}

		protected override void OnPickUp()
		{
			StartCoroutine(PickUpCoroutine());
		}

		[IteratorStateMachine(typeof(_003CPickUpCoroutine_003Ed__10))]
		private IEnumerator PickUpCoroutine()
		{
			return new _003CPickUpCoroutine_003Ed__10(0)
			{
				_003C_003E4__this = this
			};
		}

		public override void RewardEnd()
		{
			// End the reward lifecycle: hand the entity back to the reward manager, which
			// owns the object pool and decides whether to recycle or destroy it. The original
			// (ICF-folded) body performed the pool ContainsKey/get_Item lookup inline through
			// RewardManager's private _rewardPoolDic; the equivalent public entry point is
			// ReleaseReward, which performs that same recycle-or-destroy logic.
			if (RewardManager.Instance != null)
			{
				RewardManager.Instance.ReleaseReward(this);
			}
		}
	}
}
