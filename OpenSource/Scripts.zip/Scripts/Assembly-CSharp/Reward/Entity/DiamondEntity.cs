using System;
using System.Collections;
using System.Collections.Generic;
using Audio.Manager;
using Level.Manager;
using UnityEngine;

namespace Reward.Entity
{
	public class DiamondEntity : RewardEntity
	{
		private const float PickUpStepDelay = 0.1f;

		[Tooltip("钻石价值")]
		public int value;

		public override void Reset()
		{
			base.Reset();
			value = 1;
		}

		protected override void Start()
		{
		}

		protected override void OnPickUp()
		{
			StartCoroutine(PickUpCoroutine());
		}

		private IEnumerator PickUpCoroutine()
		{
			// 标记为已拾取，播放拾取音效
			isPickedUp = true;
			if (AudioManager.Instance != null)
			{
				AudioManager.Instance.PlayOneShot(pickUpSound);
			}
			yield return new WaitForSeconds(PickUpStepDelay);
			yield return new WaitForSeconds(PickUpStepDelay);
			// 将钻石价值累加到玩家的钻石总量
			if (CardSlotManager.Instance != null)
			{
				CardSlotManager.Instance.DiamondValue = (float)value + CardSlotManager.Instance.DiamondValue;
			}
			yield return new WaitForSeconds(PickUpStepDelay);
			// 结束奖励流程，回收实体
			RewardEnd();
		}
	}
}
