using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Audio.Manager;
using Level.Manager;
using UnityEngine;

namespace Reward.Entity
{
	public class DiamondEntity : RewardEntity
	{
		[CompilerGenerated]
		private sealed class _003CPickUpCoroutine_003Ed__4 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public DiamondEntity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CPickUpCoroutine_003Ed__4(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				DiamondEntity diamondEntity = _003C_003E4__this;
				switch (num)
				{
				default:
					return false;
				case 0:
				{
					_003C_003E1__state = -1;
					if (diamondEntity == null)
					{
						return false;
					}
					// Mark as picked up so the entity stops being interactable / auto-picked.
					diamondEntity.isPickedUp = true;
					// Play the pick-up sound effect.
					if (AudioManager.Instance != null)
					{
						AudioManager.Instance.PlayOneShot(diamondEntity.pickUpSound);
					}
					// TODO: reconstruct - original tweened the diamond toward the on-screen
					// diamond counter in the card slot box (DOMove to a screen->world point
					// derived from the current card slot UI child). That relied on
					// GameManager.CardSlotBox (missing member) and FairyGUI card-slot children
					// that cannot be resolved here, so the movement tween is omitted.
					_003C_003E2__current = new WaitForSeconds(PickUpStepDelay);
					_003C_003E1__state = 1;
					return true;
				}
				case 1:
					_003C_003E1__state = -1;
					if (diamondEntity == null)
					{
						return false;
					}
					// TODO: reconstruct - original played a scale "pop" tween on the diamond
					// (transform.DOScale) with design-tuned parameters that are not recoverable
					// from the decompiled globals; the tween call is omitted.
					_003C_003E2__current = new WaitForSeconds(PickUpStepDelay);
					_003C_003E1__state = 2;
					return true;
				case 2:
					_003C_003E1__state = -1;
					if (diamondEntity == null)
					{
						return false;
					}
					// Award the diamond value to the player's diamond total.
					if (CardSlotManager.Instance != null)
					{
						CardSlotManager.Instance.DiamondValue = (float)diamondEntity.value + CardSlotManager.Instance.DiamondValue;
					}
					_003C_003E2__current = new WaitForSeconds(PickUpStepDelay);
					_003C_003E1__state = 3;
					return true;
				case 3:
					_003C_003E1__state = -1;
					if (diamondEntity == null)
					{
						return false;
					}
					// End the reward lifecycle (recycle / despawn the entity).
					diamondEntity.RewardEnd();
					return false;
				}
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		// TODO: reconstruct - per-step wait between the pick-up animation stages. The original
		// value came from an unresolved global constant; using a small placeholder delay so the
		// coroutine remains functional and compilable.
		private const float PickUpStepDelay = 0.1f;

		[Tooltip("钻石价值")]
		public int value;

		public override void Reset()
		{
			base.Reset();
			value = 1;
			// TODO: reconstruct - original reset transform.localScale from a global config
			// Vector3 (an unresolved manager singleton). Scale reset omitted.
		}

		protected override void Start()
		{
		}

		protected override void OnPickUp()
		{
			StartCoroutine(PickUpCoroutine());
		}

		[IteratorStateMachine(typeof(_003CPickUpCoroutine_003Ed__4))]
		private IEnumerator PickUpCoroutine()
		{
			return new _003CPickUpCoroutine_003Ed__4(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
