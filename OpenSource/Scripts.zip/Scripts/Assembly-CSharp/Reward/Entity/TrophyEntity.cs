using System;
using System.Collections;
using System.Collections.Generic;
using Game.Entity;
using Land.Entity.Fog;
using UnityEngine;

namespace Reward.Entity
{
	public class TrophyEntity : RewardEntity
	{
		[Tooltip("奖杯头贴图")]
		public List<Sprite> headSpriteList;

		[Tooltip("奖杯体贴图")]
		public List<Sprite> bodySpriteList;

		[Tooltip("奖杯效果")]
		public EffectEntity effectEntity;

		[Tooltip("奖杯头渲染器")]
		public SpriteRenderer headSpriteRenderer;

		[Tooltip("奖杯体渲染器")]
		public SpriteRenderer bodySpriteRenderer;

		[Tooltip("迷雾驱散类")]
		public DispelFog dispelFog;

		public override void Reset()
		{
			base.Reset();
			base.transform.localScale = Vector3.one;
			ResetSprite();
		}

		protected override void Start()
		{
			base.Start();
		}

		private void ResetSprite()
		{
		}

		protected override void OnPickUp()
		{
			StartCoroutine(PickUpCoroutine());
		}

		private IEnumerator PickUpCoroutine()
		{
			yield break;
		}
	}
}
