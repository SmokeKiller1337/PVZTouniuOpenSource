using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Game.Entity;
using Land.Entity.Fog;
using UnityEngine;

namespace Reward.Entity
{
	public class TrophyEntity : RewardEntity
	{
		[CompilerGenerated]
		private sealed class _003CPickUpCoroutine_003Ed__10 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TrophyEntity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CPickUpCoroutine_003Ed__10(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct - the original MoveNext body could not be reliably decoded.
				// It performs, in order (per Ghidra pseudocode @RVA 0x5a0940):
				//   this.<>4__this.isPickedUp = true;
				//   FocusSlowMotionManager.Instance.UnPause();
				//   FindObjectsOfType<?>() -> call an unresolved virtual (vtable +0x278) on each;
				//   GameUtils.CreateEffectUI(<>4__this.effectEntity, <>4__this.transform);
				//   <>4__this.GetComponentInChildren<?>() -> set its transform.localPosition to a const;
				//   <>4__this.transform.DOMove(<const>, <duration>);
				//   DOTween.To(getter, setter, <target>, <duration>) tweening dispelFog dispel size;
				//   LevelAssetsManager.Instance.WinGame();
				//   FindObjectOfType<?>().enabled = false;
				//   FocusSlowMotionManager.Instance.StopFocus();
				// The three FindObjectsOfType/GetComponentInChildren generic type arguments, the
				// virtual called at vtable slot +0x278, and the effect positions/tween durations
				// resolve to il2cpp static-storage DAT symbols that cannot be mapped to concrete
				// project types/members. Reconstructing them would require fabricating type
				// arguments and members, so the body is reduced to a no-op coroutine.
				_003C_003E1__state = -1;
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("奖杯头贴图")]
		public List<Sprite> headSpriteList;

		[Tooltip("奖杯体贴图")]
		public List<Sprite> bodySpriteList;

		[Tooltip("奖杯效果")]
		public EffectEntity effectEntity;

		[Tooltip("奖杯头渲染器")]
		public SpriteRenderer headSpriteRenderer;

		[Tooltip("奖杯体渲染器")]
		public SpriteRenderer bodySpriteRenderer;

		[Tooltip("迷雾驱散类")]
		public DispelFog dispelFog;

		public override void Reset()
		{
			// Faithful portion (per Ghidra pseudocode @RVA 0x599c00): reset base state, restore
			// unit scale, and re-roll the trophy sprites.
			base.Reset();
			base.transform.localScale = Vector3.one;
			ResetSprite();
			// TODO: reconstruct - the tail of the original body could not be reliably decoded:
			//   FindObjectOfType<?>().enabled = false;  (generic type is an unresolved DAT symbol)
			//   dispelFog.<field @0x20> = <Vector2 const>;  (target field/offset in DispelFog and
			//   the constant value could not be mapped to a concrete DispelFog member).
			// Omitted to avoid referencing non-existent members / fabricating values.
		}

		protected override void Start()
		{
			// Faithful portion (per Ghidra pseudocode @RVA 0x599d50): run base start-up.
			base.Start();
			// TODO: reconstruct - the sprite-selection logic reads a head/body index pair and two
			// "randomize" flags from an il2cpp static-storage singleton (DAT_182e507b0 / DAT_182e47708)
			// that could not be mapped to a concrete project type. The observable effect is
			// bodySpriteRenderer.sprite = bodySpriteList[bodyIndex] and
			// headSpriteRenderer.sprite = headSpriteList[headIndex], where each index is re-rolled via
			// Random.Range(1, 5) when its flag is set. Omitted to avoid fabricating the index source.
		}

		private void ResetSprite()
		{
			// TODO: reconstruct - identical logic to Start's sprite selection (per Ghidra pseudocode
			// @RVA 0x599a60): it reads a head/body index pair and two "randomize" flags from an
			// unresolved il2cpp static-storage singleton (DAT_182e507b0 / DAT_182e47708) and assigns
			// bodySpriteRenderer.sprite = bodySpriteList[bodyIndex] /
			// headSpriteRenderer.sprite = headSpriteList[headIndex]. The index source could not be
			// mapped to a concrete project type, so the body is left empty to avoid fabrication.
		}

		protected override void OnPickUp()
		{
			StartCoroutine(PickUpCoroutine());
		}

		[IteratorStateMachine(typeof(_003CPickUpCoroutine_003Ed__10))]
		private IEnumerator PickUpCoroutine()
		{
			return new _003CPickUpCoroutine_003Ed__10(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
