using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Audio.Manager;
using DG.Tweening;
using FairyGUI;
using Level.Manager.Data.Mini;
using UnityEngine;

namespace Reward.Entity
{
	public class Reward102Entity : RewardEntity
	{
		[CompilerGenerated]
		private sealed class _003CPickUpCoroutine_003Ed__7 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Reward102Entity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CPickUpCoroutine_003Ed__7(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				Reward102Entity reward102Entity = _003C_003E4__this;
				switch (_003C_003E1__state)
				{
				default:
					return false;
				case 0:
				{
					_003C_003E1__state = -1;
					reward102Entity.isPickedUp = true;
					// 播放拾取音效
					if (AudioManager.Instance != null)
					{
						AudioManager.Instance.PlayOneShot(reward102Entity.pickUpSound, reward102Entity.pitchRange);
					}
					// 计算飞行的目标位置：若有 Mini9 数据管理器则飞向其内容面板对应的世界坐标，否则使用默认位置
					// TODO: reconstruct - 默认目标向量的精确常量未能从元数据恢复
					Vector3 target = new Vector3(-2f, 0f, 0f);
					LevelMini9DataManager dataManager = LevelMini9DataManager.Instance;
					if (dataManager != null && dataManager.contentCom != null)
					{
						GComponent contentCom = dataManager.contentCom;
						Vector2 global = contentCom.LocalToGlobal(new Vector2(contentCom.width * 0.5f, contentCom.height * 0.5f));
						global.y = Screen.height - global.y;
						Camera main = Camera.main;
						if (main != null)
						{
							target = main.ScreenToWorldPoint(new Vector3(global.x, global.y, 0f));
						}
					}
					// TODO: reconstruct - DOMove 时长常量未能从元数据恢复
					reward102Entity.transform.DOMove(target, 0.5f);
					_003C_003E2__current = new WaitForSeconds(0.5f);
					_003C_003E1__state = 1;
					return true;
				}
				case 1:
					_003C_003E1__state = -1;
					// TODO: reconstruct - DOScale 目标与时长常量未能从元数据恢复
					reward102Entity.transform.DOScale(0f, 0.2f);
					_003C_003E2__current = new WaitForSeconds(0.2f);
					_003C_003E1__state = 2;
					return true;
				case 2:
				{
					_003C_003E1__state = -1;
					// 将拾取到的文字追加到当前文字集合
					LevelMini9DataManager dataManager2 = LevelMini9DataManager.Instance;
					if (dataManager2 != null && dataManager2.currentCharList != null)
					{
						dataManager2.currentCharList.Add(reward102Entity.text);
					}
					// TODO: reconstruct - 等待时长常量未能从元数据恢复
					_003C_003E2__current = new WaitForSeconds(0.1f);
					_003C_003E1__state = 3;
					return true;
				}
				case 3:
					_003C_003E1__state = -1;
					reward102Entity.RewardEnd();
					return false;
				}
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("文字")]
		public char text;

		private SpriteRenderer _spriteRenderer;

		private GTextField _textField;

		public override void Reset()
		{
			base.Reset();
			if (base.transform == null)
			{
				return;
			}
			LevelMini9DataManager dataManager = LevelMini9DataManager.Instance;
			if (dataManager == null || dataManager.allCharList == null)
			{
				return;
			}
			// 从字符池中随机取一个文字作为奖励内容
			int index = UnityEngine.Random.Range(0, dataManager.allCharList.Count);
			text = dataManager.allCharList[index];
			if (_textField != null)
			{
				_textField.text = text.ToString();
			}
		}

		protected override void Awake()
		{
			base.Awake();
			_spriteRenderer = GetComponentInChildren<SpriteRenderer>();
		}

		protected override void Start()
		{
			UIPanel uiPanel = GetComponentInChildren<UIPanel>();
			if (uiPanel == null)
			{
				return;
			}
			GComponent ui = uiPanel.ui;
			if (ui == null)
			{
				return;
			}
			// TODO: reconstruct - GetChild 的子对象名称字面量未能从元数据恢复
			GObject child = ui.GetChild("text");
			if (child != null)
			{
				_textField = child.asTextField;
				if (_textField != null)
				{
					_textField.text = text.ToString();
				}
			}
		}

		protected override void OnPickUp()
		{
			StartCoroutine(PickUpCoroutine());
		}

		[IteratorStateMachine(typeof(_003CPickUpCoroutine_003Ed__7))]
		private IEnumerator PickUpCoroutine()
		{
			return new _003CPickUpCoroutine_003Ed__7(0)
			{
				_003C_003E4__this = this
			};
		}
	}
}
