using System;
using System.Collections;
using System.Collections.Generic;
using Audio.Manager;
using DG.Tweening;
using FairyGUI;
using Level.Manager.Data.Mini;
using UnityEngine;

namespace Reward.Entity
{
	public class Reward102Entity : RewardEntity
	{
		[Tooltip("文字")]
		public char text;

		private SpriteRenderer _spriteRenderer;

		private GTextField _textField;

		public override void Reset()
		{
			base.Reset();
			if (base.transform == null)
			{
				return;
			}
			LevelMini9DataManager dataManager = LevelMini9DataManager.Instance;
			if (dataManager == null || dataManager.allCharList == null)
			{
				return;
			}
			// 从字符池中随机取一个文字作为奖励内容
			int index = UnityEngine.Random.Range(0, dataManager.allCharList.Count);
			text = dataManager.allCharList[index];
			if (_textField != null)
			{
				_textField.text = text.ToString();
			}
		}

		protected override void Awake()
		{
			base.Awake();
			_spriteRenderer = GetComponentInChildren<SpriteRenderer>();
		}

		protected override void Start()
		{
			UIPanel uiPanel = GetComponentInChildren<UIPanel>();
			if (uiPanel == null)
			{
				return;
			}
			GComponent ui = uiPanel.ui;
			if (ui == null)
			{
				return;
			}
			GObject child = ui.GetChild("text");
			if (child != null)
			{
				_textField = child.asTextField;
				if (_textField != null)
				{
					_textField.text = text.ToString();
				}
			}
		}

		protected override void OnPickUp()
		{
			StartCoroutine(PickUpCoroutine());
		}

		private IEnumerator PickUpCoroutine()
		{
			isPickedUp = true;
			// 播放拾取音效
			if (AudioManager.Instance != null)
			{
				AudioManager.Instance.PlayOneShot(pickUpSound, pitchRange);
			}
			// 计算飞向目标位置（屏幕中心对应的世界坐标）
			Vector3 target = new Vector3(-2f, 0f, 0f);
			LevelMini9DataManager dataManager = LevelMini9DataManager.Instance;
			if (dataManager != null && dataManager.contentCom != null)
			{
				GComponent contentCom = dataManager.contentCom;
				Vector2 global = contentCom.LocalToGlobal(new Vector2(contentCom.width * 0.5f, contentCom.height * 0.5f));
				global.y = Screen.height - global.y;
				Camera main = Camera.main;
				if (main != null)
				{
					target = main.ScreenToWorldPoint(new Vector3(global.x, global.y, 0f));
				}
			}
			transform.DOMove(target, 0.5f);
			yield return new WaitForSeconds(0.5f);
			// 缩小消失
			transform.DOScale(0f, 0.2f);
			yield return new WaitForSeconds(0.2f);
			// 将拾取到的文字追加到当前文字集合
			LevelMini9DataManager dataManager2 = LevelMini9DataManager.Instance;
			if (dataManager2 != null && dataManager2.currentCharList != null)
			{
				dataManager2.currentCharList.Add(text);
			}
			yield return new WaitForSeconds(0.1f);
			RewardEnd();
		}
	}
}
