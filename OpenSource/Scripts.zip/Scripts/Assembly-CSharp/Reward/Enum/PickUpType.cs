namespace Reward.Enum
{
	public enum PickUpType
	{
		MouseEnter = 0,
		MouseDown = 1
	}
}
