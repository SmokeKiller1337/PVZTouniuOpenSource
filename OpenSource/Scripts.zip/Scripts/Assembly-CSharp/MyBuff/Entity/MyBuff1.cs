using NoSLoofah.BuffSystem;
using UnityEngine;

namespace MyBuff.Entity
{
	public class MyBuff1 : Buff
	{
		[Tooltip("Buff的参数")]
		public int value;

		public override void OnBuffStart()
		{
		}

		public override void OnBuffModifyLayer(int change)
		{
		}

		public override void Reset()
		{
		}

		protected override void OnBuffTickEffect()
		{
		}

		public override void OnBuffRemove()
		{
		}
	}
}
