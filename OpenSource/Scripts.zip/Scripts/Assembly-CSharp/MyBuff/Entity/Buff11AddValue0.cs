namespace MyBuff.Entity
{
	public class Buff11AddValue0 : BuffDefault
	{
		private float _value0;

		public override void OnBuffStart()
		{
		}

		public override void OnBuffRemove()
		{
		}
	}
}
