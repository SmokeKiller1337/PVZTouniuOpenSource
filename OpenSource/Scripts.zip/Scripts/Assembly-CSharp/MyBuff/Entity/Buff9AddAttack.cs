namespace MyBuff.Entity
{
	public class Buff9AddAttack : BuffDefault
	{
		private int _attack;

		public override void OnBuffStart()
		{
		}

		public override void OnBuffRemove()
		{
		}
	}
}
