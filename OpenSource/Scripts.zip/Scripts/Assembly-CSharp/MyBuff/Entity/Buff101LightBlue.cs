namespace MyBuff.Entity
{
	public class Buff101LightBlue : BuffDefault
	{
		public override void OnBuffStart()
		{
		}

		public override void OnBuffRemove()
		{
		}
	}
}
