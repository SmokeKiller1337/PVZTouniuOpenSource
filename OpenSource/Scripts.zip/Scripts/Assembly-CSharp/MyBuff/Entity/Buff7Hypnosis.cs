namespace MyBuff.Entity
{
	public class Buff7Hypnosis : BuffDefault
	{
		public override void OnBuffAwake()
		{
		}

		public override void OnBuffStart()
		{
		}

		public override void OnBuffRemove()
		{
		}
	}
}
