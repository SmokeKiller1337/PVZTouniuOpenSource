using Game.Entity;
using Plant.Entity;
using UnityEngine;
using Zombie.Entity;

namespace MyBuff.Entity
{
	public class Buff6Freeze : BuffDefault
	{
		[Tooltip("结束时特效")]
		public EffectEntity removeEffect;

		private float _walkSpeedRatio;

		private float _attackSpeed;

		private PlantEntity _plantEntity;

		private ZombieEntity _zombieEntity;

		public override void OnBuffStart()
		{
		}

		protected override void OnBuffUpdateEffect()
		{
		}

		public override void OnBuffRemove()
		{
		}
	}
}
