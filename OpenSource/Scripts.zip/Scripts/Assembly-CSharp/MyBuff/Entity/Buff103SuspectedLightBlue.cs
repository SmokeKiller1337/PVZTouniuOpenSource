namespace MyBuff.Entity
{
	public class Buff103SuspectedLightBlue : BuffDefault
	{
		public override void OnBuffStart()
		{
		}

		public override void OnBuffRemove()
		{
		}
	}
}
