namespace MyBuff.Entity
{
	public class Buff102Fever : BuffDefault
	{
		private int _attack;

		public override void OnBuffStart()
		{
		}

		public override void OnBuffRemove()
		{
		}
	}
}
