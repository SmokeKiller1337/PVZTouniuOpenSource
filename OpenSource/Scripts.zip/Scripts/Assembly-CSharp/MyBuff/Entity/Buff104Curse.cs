namespace MyBuff.Entity
{
	public class Buff104Curse : BuffDefault
	{
		private float _walkSpeedRatio;

		private float _attackSpeed;

		public override void OnBuffStart()
		{
		}

		public override void OnBuffRemove()
		{
		}
	}
}
