using Land.Entity;
using Plant.Entity;
using UnityEngine;

namespace MyBuff.Entity
{
	public class Buff2Flatten : BuffDefault
	{
		private GameObject _obj;

		public override void OnBuffStart()
		{
		}

		public override void OnBuffRemove()
		{
		}

		private void LandRemovePlant(LandEntity landEntity, PlantEntity plantEntity)
		{
		}
	}
}
