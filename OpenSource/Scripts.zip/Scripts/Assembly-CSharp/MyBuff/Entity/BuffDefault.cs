using NoSLoofah.BuffSystem;
using NoSLoofah.BuffSystem.Dependence;
using UnityEngine;

namespace MyBuff.Entity
{
	[CreateAssetMenu(fileName = "Buff", menuName = "Buff/DefaultBuff")]
	public class BuffDefault : Buff
	{
		[ReplaceLabel("叠加颜色")]
		[Header("---Buff效果")]
		public Color overlayColor;

		[ReplaceLabel("叠加强度")]
		[Range(0f, 1f)]
		public float overlayStrength;

		[ReplaceLabel("粒子效果")]
		public GameObject particlePrefab;

		public override void OnBuffAwake()
		{
		}

		public override void OnBuffStart()
		{
		}

		public override void OnBuffModifyLayer(int change)
		{
		}

		public override void Reset()
		{
		}

		protected override void OnBuffTickEffect()
		{
		}

		protected override void OnBuffUpdateEffect()
		{
		}

		public override void OnBuffRemove()
		{
		}

		public override void OnBuffDestroy()
		{
		}

		private void RemoveBuffMaterial()
		{
		}
	}
}
