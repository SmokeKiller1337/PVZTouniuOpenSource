using UnityEngine;

namespace BirdCommon.Manager
{
	public class ValueShopManager : MonoBehaviour
	{
		public static ValueShopManager Instance { get; private set; }

		private void Awake()
		{
		}

		public void ChangeValue(int value)
		{
		}

		public int GetValue()
		{
			return 0;
		}

		public void UpdateLockReward()
		{
		}
	}
}
