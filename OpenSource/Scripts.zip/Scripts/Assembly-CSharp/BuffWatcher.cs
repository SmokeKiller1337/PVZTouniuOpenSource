using System.Collections.Generic;
using System.Linq;
using NoSLoofah.BuffSystem;
using UnityEngine;

public class BuffWatcher : MonoBehaviour
{
	[SerializeField]
	private BuffHandler buffHandler;

	[SerializeField]
	private GameObject displayer;

	private List<BuffDisplayer> displayers;

	private void Update()
	{
		if (displayers == null)
		{
			return;
		}
		for (int i = displayers.Count - 1; i >= 0; i--)
		{
			BuffDisplayer buffDisplayer = displayers[i];
			if (buffDisplayer == null)
			{
				continue;
			}
			Buff buff = buffDisplayer.Buff;
			if (!(buff != null) || !buff.IsEffective)
			{
				GameObject gameObject = buffDisplayer.gameObject;
				displayers.RemoveAt(i);
				Object.Destroy(gameObject);
			}
		}
		if (buffHandler == null)
		{
			return;
		}
		List<Buff> getBuffs = buffHandler.GetBuffs;
		List<int> displayedIds = displayers.Select((BuffDisplayer d) => d.Buff.ID).ToList();
		List<Buff> list = getBuffs.Where((Buff b) => !displayedIds.Contains(b.ID)).ToList();
		foreach (Buff item in list)
		{
			GameObject gameObject2 = Object.Instantiate(displayer);
			BuffDisplayer component = gameObject2.GetComponent<BuffDisplayer>();
			component.SetBuff(item);
			displayers.Add(component);
			component.transform.SetParent(base.transform);
		}
	}

	public BuffWatcher()
	{
		displayers = new List<BuffDisplayer>();
	}
}
