using System;
using System.Collections.Generic;
using Plant.Entity;
using UnityEngine;

namespace Strengthen.Entity
{
	[Serializable]
	public class SelectStrengthenEntity
	{
		[Tooltip("是否选择中")]
		public bool isSelected;

		[Tooltip("卡牌实体")]
		public CardEntity cardEntity;

		[Tooltip("强化集合")]
		public List<StrengthenEntity> strengthenList;
	}
}
