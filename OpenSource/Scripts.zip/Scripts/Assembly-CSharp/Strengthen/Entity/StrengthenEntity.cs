using System;
using System.Collections.Generic;
using System.Text;
using Game.Util;
using Plant.Entity;
using UnityEngine;

namespace Strengthen.Entity
{
	[Serializable]
	public class StrengthenEntity
	{
		[HideInInspector]
		public int index;

		[Tooltip("名称")]
		public string title;

		[TextArea]
		[Tooltip("内容")]
		public string desc;

		[Tooltip("冷却时间")]
		public float cooldownTime;

		[Tooltip("值集合")]
		public List<StrengthenValueEntity> valueList;

		public float GetValue(PlantEntity plantEntity, int index = 0)
		{
			StrengthenValueEntity value = valueList[index];
			float result = value.baseValue;
			if (value.bonusAttr != 0)
			{
				result += plantEntity.GetAttrValue(value.bonusAttr) * value.bonusValue;
			}
			if (value.isInt)
			{
				result = (int)result;
			}
			return result;
		}

		public float GetValue(CardEntity cardEntity, int index = 0)
		{
			StrengthenValueEntity value = valueList[index];
			float result = value.baseValue;
			if (value.bonusAttr != 0)
			{
				result += cardEntity.GetAttrValue(value.bonusAttr) * value.bonusValue;
			}
			if (value.isInt)
			{
				result = (int)result;
			}
			return result;
		}

		public string GetDesc(CardEntity cardEntity)
		{
			string format = GameUtils.AttrStrFormat(desc, cardEntity);
			List<string> args = new List<string>();
			foreach (StrengthenValueEntity value in valueList)
			{
				StringBuilder sb = new StringBuilder();
				sb.Append(value.bonusAttr != 0 ? "+" : string.Empty);
				float num = value.baseValue;
				if (value.bonusAttr != 0)
				{
					num += cardEntity.GetAttrValue(value.bonusAttr) * value.bonusValue;
				}
				if (value.isInt)
				{
					num = (int)num;
				}
				sb.Append(GameUtils.GetValueStr(num, value.isPercentage));
				if (value.bonusAttr != 0)
				{
					sb.Append(GameUtils.GetBonusAttrIcon(value.bonusAttr));
				}
				sb.Append(string.Empty);
				args.Add(sb.ToString());
			}
			return string.Format(format, args.ToArray());
		}

		public string GetDesc(PlantEntity plantEntity)
		{
			if (plantEntity == null)
			{
				return null;
			}
			string format = GameUtils.AttrStrFormat(desc, plantEntity.CardEntity);
			List<string> args = new List<string>();
			foreach (StrengthenValueEntity value in valueList)
			{
				StringBuilder sb = new StringBuilder();
				sb.Append(value.bonusAttr != 0 ? "+" : string.Empty);
				float num = value.baseValue;
				if (value.bonusAttr != 0)
				{
					num += plantEntity.GetAttrValue(value.bonusAttr) * value.bonusValue;
				}
				if (value.isInt)
				{
					num = (int)num;
				}
				sb.Append(GameUtils.GetValueStr(num, value.isPercentage));
				if (value.bonusAttr != 0)
				{
					sb.Append(GameUtils.GetBonusAttrIcon(value.bonusAttr));
				}
				sb.Append(string.Empty);
				args.Add(sb.ToString());
			}
			return string.Format(format, args.ToArray());
		}
	}
}
