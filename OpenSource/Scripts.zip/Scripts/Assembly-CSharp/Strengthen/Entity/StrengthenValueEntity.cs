using System;
using Common.Enum;
using Plant.Entity;
using UnityEngine;

namespace Strengthen.Entity
{
	[Serializable]
	public class StrengthenValueEntity : ICloneable
	{
		[Tooltip("基础值")]
		public float baseValue;

		[Tooltip("是否为百分比")]
		public bool isPercentage;

		[Tooltip("是否取整数")]
		public bool isInt;

		[Tooltip("属性加成")]
		public AttrEnum bonusAttr;

		[Tooltip("加成值")]
		public float bonusValue;

		public float GetValue(CardEntity cardEntity)
		{
			// Observed control flow (RVA 0x580820): when bonusAttr != None the entity
			// is required (null -> NullReferenceException) and cardEntity.GetAttrValue(bonusAttr)
			// is read; a further branch keys off isInt. The float return / arithmetic that
			// combines baseValue, bonusValue, the attr value, isPercentage and the isInt
			// rounding was dropped by the decompiler (folded IL2CPP thunk, no FP path shown),
			// so the value formula cannot be reproduced without inventing it.
			// TODO: reconstruct final value computation.
			return default;
		}

		public float GetValue(PlantEntity plantEntity)
		{
			// Observed control flow (RVA 0x580890): identical shape to the CardEntity overload;
			// when bonusAttr != None the entity is required (null -> NullReferenceException) and
			// plantEntity.GetAttrValue(bonusAttr) is read (BaseBody.GetAttrValue, inherited by
			// PlantEntity), followed by an isInt branch. The float return / arithmetic was dropped
			// by the decompiler, so the value formula cannot be reproduced without inventing it.
			// TODO: reconstruct final value computation.
			return default;
		}

		public object Clone()
		{
			// ICloneable clone of a flat serializable value holder (only value-type / bool / enum
			// fields, no reference members). The pseudocode at RVA 0x40FC80 is ICF-folded onto
			// Hashtable.HashtableEnumerator.Clone and carries no real body for this type; a shallow
			// MemberwiseClone is the correct and compile-safe reconstruction for these fields.
			return MemberwiseClone();
		}
	}
}
