using System;
using Common.Enum;
using Plant.Entity;
using UnityEngine;

namespace Strengthen.Entity
{
	[Serializable]
	public class StrengthenValueEntity : ICloneable
	{
		[Tooltip("基础值")]
		public float baseValue;

		[Tooltip("是否为百分比")]
		public bool isPercentage;

		[Tooltip("是否取整数")]
		public bool isInt;

		[Tooltip("属性加成")]
		public AttrEnum bonusAttr;

		[Tooltip("加成值")]
		public float bonusValue;

		public float GetValue(CardEntity cardEntity)
		{
			return default;
		}

		public float GetValue(PlantEntity plantEntity)
		{
			return default;
		}

		public object Clone()
		{
			return MemberwiseClone();
		}
	}
}
