using System;
using System.Collections.Generic;

namespace Strengthen.Entity
{
	[Serializable]
	public class CardStrengthenEntity
	{
		public StrengthenEntity level0;

		public List<StrengthenEntity> level1List;

		public List<StrengthenEntity> level2List;

		public List<StrengthenEntity> level3List;
	}
}
