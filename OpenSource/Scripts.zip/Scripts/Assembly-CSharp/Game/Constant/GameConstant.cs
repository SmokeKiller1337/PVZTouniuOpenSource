using Game.Enum;

namespace Game.Constant
{
	public static class GameConstant
	{
		public static bool IsLoad;

		public static int Platform;

		public static GameMode GameMode;
	}
}
