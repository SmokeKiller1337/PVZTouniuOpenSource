namespace Game.Enum
{
	public enum GameMode
	{
		Title = 0,
		Level = 1
	}
}
