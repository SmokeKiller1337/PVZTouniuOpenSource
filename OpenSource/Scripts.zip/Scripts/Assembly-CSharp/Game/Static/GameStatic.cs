namespace Game.Static
{
	public static class GameStatic
	{
		public static void InitData()
		{
		}
	}
}
