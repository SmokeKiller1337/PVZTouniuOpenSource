using System;
using UnityEngine;

namespace Game.Entity
{
	[Serializable]
	public class BodyAttribute : ICloneable
	{
		[Header("---通用")]
		[Tooltip("总血量")]
		public float maxHealth;

		[Tooltip("当前血量")]
		public float currentHealth;

		[Tooltip("是否已死亡")]
		public bool isDeath;

		[Tooltip("是否无敌")]
		public bool isInvincible;

		[Tooltip("速度")]
		public float speed;

		[Tooltip("近战防御力")]
		public float meleeDefense;

		[Tooltip("远程防御力")]
		public float rangedDefense;

		[Tooltip("生命恢复")]
		public float recoveryHealth;

		[Tooltip("幸运")]
		public float luck;

		[Header("---玩家")]
		[Tooltip("拾取范围")]
		public float pickupRange;

		[Tooltip("复活范围")]
		public float reviveRange;

		[Tooltip("采集范围")]
		public float collectionRange;

		[Tooltip("照明范围")]
		public float lightRange;

		[Tooltip("复活所需时间")]
		public float reviveTime;

		[Tooltip("复活后血量比例")]
		public float reviveHealthRatio;

		[Header("---敌人")]
		[Tooltip("伤害")]
		public float eDamage;

		[Tooltip("伤害间隔时间")]
		public float eDamageIntervalTime;

		public object Clone()
		{
			return null;
		}
	}
}
