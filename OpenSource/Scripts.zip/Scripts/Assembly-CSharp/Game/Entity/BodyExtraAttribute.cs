using System;
using UnityEngine;

namespace Game.Entity
{
	[Serializable]
	public class BodyExtraAttribute : ICloneable
	{
		[Header("---通用")]
		[Tooltip("伤害倍率")]
		public float damageMultiplier;

		[Tooltip("近战伤害倍率")]
		public float meleeDamageMultiplier;

		[Tooltip("远程伤害倍率")]
		public float rangedDamageMultiplier;

		[Tooltip("近战减伤")]
		public float meleeDamageReduction;

		[Tooltip("远程减伤")]
		public float rangedDamageReduction;

		[Tooltip("速度倍率")]
		public float speedMultiplier;

		[Tooltip("生命恢复倍率")]
		public float recoveryHealthMultiplier;

		[Tooltip("暴击率")]
		public float criticalHitRate;

		[Tooltip("暴击伤害倍率")]
		public float criticalDamageMultiplier;

		[Tooltip("回避率")]
		public float dodgeRate;

		[Tooltip("生命偷取倍率")]
		public float lifeStealMultiplier;

		[Header("---玩家")]
		[Tooltip("经验值倍率")]
		public float experienceMultiplier;

		[Tooltip("拾取范围倍率")]
		public float pickupRangeMultiplier;

		[Tooltip("复活范围倍率")]
		public float reviveRangeMultiplier;

		[Tooltip("复活所需时间倍率")]
		public float reviveTimeMultiplier;

		[Tooltip("采集范围倍率")]
		public float collectionRangeMultiplier;

		[Tooltip("采集速度倍率")]
		public float collectionSpeedMultiplier;

		[Tooltip("照明范围倍率")]
		public float lightRangeMultiplier;

		[Tooltip("获得金币倍率")]
		public float goldMultiplier;

		public object Clone()
		{
			return null;
		}
	}
}
