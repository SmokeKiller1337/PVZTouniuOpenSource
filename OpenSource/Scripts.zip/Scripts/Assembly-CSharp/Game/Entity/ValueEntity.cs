using System;
using Common.Entity;
using Common.Enum;
using Plant.Entity;
using UnityEngine;

namespace Game.Entity
{
	[Serializable]
	public class ValueEntity : ICloneable
	{
		[Tooltip("显示名")]
		public string title;

		[Tooltip("详细描述")]
		public string content;

		[Tooltip("基础值")]
		public float baseValue;

		[Tooltip("是否颜色反转")]
		public bool isColorInversion;

		[Tooltip("是否为百分比")]
		public bool isPercentage;

		[Tooltip("是否取整数")]
		public bool isInt;

		[Tooltip("属性加成")]
		public AttrEnum bonusAttr;

		[Tooltip("加成值")]
		public float bonusValue;

		public float GetValue(CardEntity cardEntity)
		{
			float value = baseValue;

			if (bonusAttr != AttrEnum.None)
			{
				// CardEntity.GetAttrValue takes a single AttrEnum argument.
				float attrValue = cardEntity.GetAttrValue(bonusAttr);
				value += attrValue * bonusValue;
			}

			if (isInt)
			{
				value = (int)value;
			}

			return value;
		}

		public float GetValue(BaseBody baseBody)
		{
			float value = baseValue;

			if (baseBody != null && bonusAttr != AttrEnum.None)
			{
				// BaseBody.GetAttrValue takes a single AttrEnum argument.
				float attrValue = baseBody.GetAttrValue(bonusAttr);
				value += attrValue * bonusValue;
			}

			if (isInt)
			{
				value = (int)value;
			}

			return value;
		}

		public float GetDefaultValue(CardEntity cardEntity)
		{
			float value = baseValue;

			if (isInt)
			{
				value = (int)value;
			}

			return value;
		}

		public float GetDefaultValue(BaseBody baseBody)
		{
			float value = baseValue;

			if (isInt)
			{
				value = (int)value;
			}

			return value;
		}

		public object Clone()
		{
			return MemberwiseClone();
		}
	}
}
