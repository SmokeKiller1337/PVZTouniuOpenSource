using System;
using Common.Entity;
using Common.Enum;
using Plant.Entity;
using UnityEngine;

namespace Game.Entity
{
	[Serializable]
	public class ValueEntity : ICloneable
	{
		[Tooltip("显示名")]
		public string title;

		[Tooltip("详细描述")]
		public string content;

		[Tooltip("基础值")]
		public float baseValue;

		[Tooltip("是否颜色反转")]
		public bool isColorInversion;

		[Tooltip("是否为百分比")]
		public bool isPercentage;

		[Tooltip("是否取整数")]
		public bool isInt;

		[Tooltip("属性加成")]
		public AttrEnum bonusAttr;

		[Tooltip("加成值")]
		public float bonusValue;

		// RVA: 0x66EB40
		// Ghidra typed this method as returning void, so the arithmetic that
		// produces the float result was dropped from the decompilation. Only the
		// control flow is reliably recoverable:
		//   - if bonusAttr != 0 (AttrEnum.None == 0), fetch the attribute value
		//     from the card via CardEntity.GetAttrValue(bonusAttr, 0);
		//   - isInt is consulted to decide whether the result is truncated.
		// The exact combination of baseValue / bonusValue / isPercentage / the
		// attribute value is not present in the pseudocode, so the final formula
		// is reconstructed conservatively and flagged below.
		public float GetValue(CardEntity cardEntity)
		{
			float value = baseValue;

			if (bonusAttr != AttrEnum.None)
			{
				// CardEntity.GetAttrValue takes a single AttrEnum argument.
				float attrValue = cardEntity.GetAttrValue(bonusAttr); // TODO: reconstruct — how attrValue combines with baseValue/bonusValue is not visible in the decompilation
				value += attrValue * bonusValue; // TODO: reconstruct — exact combination formula unverified
			}

			if (isInt)
			{
				value = (int)value;
			}

			return value;
		}

		// RVA: 0x66EA80
		// As with GetValue(CardEntity) the return arithmetic was dropped by the
		// void-typed decompilation. Recoverable facts:
		//   - a static/type initializer guard runs first (compiler generated;
		//     no user-visible effect, omitted);
		//   - a Unity null check via Object.op_Inequality(baseBody, null);
		//   - if the body is non-null AND bonusAttr != 0, fetch the attribute
		//     value via BaseBody.GetAttrValue(bonusAttr, 0);
		//   - isInt is consulted for truncation.
		public float GetValue(BaseBody baseBody)
		{
			float value = baseValue;

			if (baseBody != null && bonusAttr != AttrEnum.None)
			{
				// BaseBody.GetAttrValue takes a single AttrEnum argument.
				float attrValue = baseBody.GetAttrValue(bonusAttr); // TODO: reconstruct — how attrValue combines with baseValue/bonusValue is not visible in the decompilation
				value += attrValue * bonusValue; // TODO: reconstruct — exact combination formula unverified
			}

			if (isInt)
			{
				value = (int)value;
			}

			return value;
		}

		// RVA: 0x66EA60
		// Both GetDefaultValue overloads are ICF-folded to the same trivial body
		// (a bare `return`). Since the method returns float, the only faithful
		// reading is that it returns the raw base value without any bonus applied.
		public float GetDefaultValue(CardEntity cardEntity)
		{
			float value = baseValue;

			if (isInt)
			{
				value = (int)value;
			}

			return value;
		}

		// RVA: 0x66EA60 (ICF-folded with the CardEntity overload)
		public float GetDefaultValue(BaseBody baseBody)
		{
			float value = baseValue;

			if (isInt)
			{
				value = (int)value;
			}

			return value;
		}

		// RVA: 0x40FC80 Slot: 4
		// The pseudocode for this RVA is ICF-folded to
		// System.Collections.Hashtable.HashtableEnumerator.Clone and is entirely
		// unrelated to this type. The canonical ICloneable.Clone for a plain
		// [Serializable] value class is a shallow MemberwiseClone.
		public object Clone()
		{
			return MemberwiseClone();
		}
	}
}
