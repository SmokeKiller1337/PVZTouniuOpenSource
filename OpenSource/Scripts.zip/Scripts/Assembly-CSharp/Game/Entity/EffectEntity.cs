using System;
using System.Collections.Generic;
using UnityEngine;

namespace Game.Entity
{
	[Serializable]
	public class EffectEntity
	{
		[Tooltip("效果预制体")]
		public GameObject effectPrefab;

		[Tooltip("低画质时是否显示")]
		public bool isLowQuality;

		[Tooltip("效果音集合")]
		public List<AudioClip> soundList;

		[Tooltip("是否随机音调")]
		public bool isRandomPitch;

		[Tooltip("位置坐标")]
		public Transform targetPosition;
	}
}
