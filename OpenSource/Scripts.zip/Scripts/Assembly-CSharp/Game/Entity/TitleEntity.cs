using System.IO;
using Audio.Manager;
using FGUI.Static;
using Game.Constant;
using Game.Manager;
using Level.Static;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Game.Entity
{
	public class TitleEntity : MonoBehaviour
	{
		[Tooltip("背景音乐")]
		public AudioClip backgroundMusic;

		private void Awake()
		{
		}

		private void Start()
		{
			// 标题场景主驱动。
			// GameManager 就绪后归一 TimeScale；标题场景播放 BGM；
			// 首次进入时（GameConstant.IsLoad 为 false）调用 FGUIStatic.InitStart()，
			// 由它逐个 Start 已建 UI 并按当前场景显示对应界面（=> 标题界面显示出来）。
			GameManager gameManager = GameManager.Instance;
			Debug.Log("[SHOW] TitleEntity.Start GM=" + (gameManager == null ? "NULL" : "ok") + " scene=" + SceneManager.GetActiveScene().name + " IsLoad=" + GameConstant.IsLoad);
			if (gameManager == null)
			{
				return;
			}
			gameManager.TimeScale = 1f;
			if (SceneManager.GetActiveScene().name == "Title" && AudioManager.Instance != null)
			{
				AudioManager.Instance.PlayMusic(backgroundMusic);
			}
			if (!GameConstant.IsLoad)
			{
				GameConstant.IsLoad = true;
				FGUIStatic.InitStart();
				if (GameConstant.Platform == 0)
				{
					string openFlagPath = Application.streamingAssetsPath + "/Debug/Open";
					if (File.Exists(openFlagPath))
					{
						AreaStatic.IsOpenDebug = true;
					}
				}
			}
		}
	}
}
