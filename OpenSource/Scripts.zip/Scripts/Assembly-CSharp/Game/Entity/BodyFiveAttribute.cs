using System;
using UnityEngine;

namespace Game.Entity
{
	[Serializable]
	public class BodyFiveAttribute : ICloneable
	{
		[Header("---通用")]
		[Tooltip("无伤害倍率")]
		public float damageEmptyMultiplier;

		[Tooltip("金伤害倍率")]
		public float damageMetalMultiplier;

		[Tooltip("木伤害倍率")]
		public float damageWoodMultiplier;

		[Tooltip("水伤害倍率")]
		public float damageWaterMultiplier;

		[Tooltip("火伤害倍率")]
		public float damageFireMultiplier;

		[Tooltip("土伤害倍率")]
		public float damageEarthMultiplier;

		[Tooltip("无防御倍率")]
		public float defenseEmptyMultiplier;

		[Tooltip("金防御倍率")]
		public float defenseMetalMultiplier;

		[Tooltip("木防御倍率")]
		public float defenseWoodMultiplier;

		[Tooltip("水防御倍率")]
		public float defenseWaterMultiplier;

		[Tooltip("火防御倍率")]
		public float defenseFireMultiplier;

		[Tooltip("土防御倍率")]
		public float defenseEarthMultiplier;

		[Tooltip("无暴击率")]
		public float criticalHitEmptyRate;

		[Tooltip("金暴击率")]
		public float criticalHitMetalRate;

		[Tooltip("木暴击率")]
		public float criticalHitWoodRate;

		[Tooltip("水暴击率")]
		public float criticalHitWaterRate;

		[Tooltip("火暴击率")]
		public float criticalHitFireRate;

		[Tooltip("土暴击率")]
		public float criticalHitEarthRate;

		[Tooltip("无暴击伤害倍率")]
		public float criticalDamageEmptyMultiplier;

		[Tooltip("金暴击伤害倍率")]
		public float criticalDamageMetalMultiplier;

		[Tooltip("木暴击伤害倍率")]
		public float criticalDamageWoodMultiplier;

		[Tooltip("水暴击伤害倍率")]
		public float criticalDamageWaterMultiplier;

		[Tooltip("火暴击伤害倍率")]
		public float criticalDamageFireMultiplier;

		[Tooltip("土暴击伤害倍率")]
		public float criticalDamageEarthMultiplier;

		[Tooltip("无回避率")]
		public float dodgeEmptyRate;

		[Tooltip("金回避率")]
		public float dodgeMetalRate;

		[Tooltip("木回避率")]
		public float dodgeWoodRate;

		[Tooltip("水回避率")]
		public float dodgeWaterRate;

		[Tooltip("火回避率")]
		public float dodgeFireRate;

		[Tooltip("土回避率")]
		public float dodgeEarthRate;

		[Tooltip("无生命偷取倍率")]
		public float lifeStealEmptyMultiplier;

		[Tooltip("金生命偷取倍率")]
		public float lifeStealMetalMultiplier;

		[Tooltip("木生命偷取倍率")]
		public float lifeStealWoodMultiplier;

		[Tooltip("水生命偷取倍率")]
		public float lifeStealWaterMultiplier;

		[Tooltip("火生命偷取倍率")]
		public float lifeStealFireMultiplier;

		[Tooltip("土生命偷取倍率")]
		public float lifeStealEarthMultiplier;

		public object Clone()
		{
			return null;
		}
	}
}
