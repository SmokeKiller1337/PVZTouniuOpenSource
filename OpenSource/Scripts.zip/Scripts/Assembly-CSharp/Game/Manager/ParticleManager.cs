using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Pool;

namespace Game.Manager
{
	public class ParticleManager : MonoBehaviour
	{
		private Dictionary<int, IObjectPool<GameObject>> _particlePoolDic;

		public static ParticleManager Instance { get; private set; }

		private void Awake()
		{
		}

		public GameObject CreateParticle(GameObject particlePrefab, bool isUsePool = true)
		{
			return null;
		}

		public void ReleaseParticle(int autoId, GameObject particleObj)
		{
		}

		public bool ContainsParticle(int autoId)
		{
			return false;
		}

		private void InitPool(GameObject particlePrefab)
		{
		}
	}
}
