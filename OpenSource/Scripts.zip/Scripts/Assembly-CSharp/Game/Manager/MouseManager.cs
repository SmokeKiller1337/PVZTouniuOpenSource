using UnityEngine;

namespace Game.Manager
{
	public class MouseManager : MonoBehaviour
	{
		[Header("---鼠标图标")]
		[Tooltip("默认鼠标")]
		public Texture2D cursorDefault;

		[Tooltip("按住鼠标")]
		public Texture2D cursorHold;

		public static MouseManager Instance { get; private set; }

		private void Awake()
		{
		}

		private void Update()
		{
		}
	}
}
