using System.Collections.Generic;
using Cinemachine;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using Particle.Entity;
using UnityEngine;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;

namespace Game.Manager
{
	public class CameraManager : MonoBehaviour
	{
		[Header("---镜头")]
		[Tooltip("主相机")]
		public Camera mainCamera;

		public Camera camera1;

		public Camera camera2;

		[Tooltip("虚拟相机")]
		public CinemachineVirtualCamera virtualCamera;

		[Tooltip("镜头边界")]
		public CinemachineConfiner2D virtualCameraConfine;

		[Tooltip("震动")]
		public CinemachineImpulseSource impulseSource;

		[Tooltip("闪烁")]
		public ScreenFlash2D screenFlash;

		[Tooltip("最小缩放大小")]
		public float virtualCameraMinZoom;

		[Tooltip("最大缩放大小")]
		public float virtualCameraMaxZoom;

		[Tooltip("禁止拖拽屏幕")]
		public bool disabledDrag;

		[Tooltip("禁止缩放屏幕")]
		public bool disabledFOV;

		[Tooltip("普通层UI")]
		[Header("---UI相机")]
		public Camera stageCamera;

		[Tooltip("顶层UI")]
		public Camera topStageCamera;

		[Tooltip("爬塔房间相机")]
		public List<Camera> towerRoomCameraList;

		[Header("---后处理")]
		[Tooltip("全局后处理物体")]
		public GameObject volumeObj;

		[Tooltip("配置文件")]
		public Renderer2DData renderer2DData;

		public Dictionary<string, ScriptableRendererFeature> featureDic;

		private Touch oldTouch1;

		private Touch oldTouch2;

		private int _fovIndex;

		private TweenerCore<float, float, FloatOptions> fovTweenerCore;

		private static readonly float[] FovSteps = new float[6]
		{
			FOV_STEP_0, FOV_STEP_1, FOV_STEP_2, FOV_STEP_3, FOV_STEP_4, FOV_STEP_5
		};

		private const float FOV_STEP_0 = 5f;
		private const float FOV_STEP_1 = 6f;
		private const float FOV_STEP_2 = 7f;
		private const float FOV_STEP_3 = 8f;
		private const float FOV_STEP_4 = 9f;
		private const float FOV_STEP_5 = 10f;
		// Used for the 0xffffffff (index == -1) case.
		private const float FOV_STEP_MIN = 4f;

		// Duration of the FOV tween (DOTween.To(..., duration)). TODO: real value unknown.
		private const float FOV_TWEEN_DURATION = 0.3f;

		// Mouse-drag movement multiplier used in CameraMove. TODO: real value unknown.
		private const float MOUSE_DRAG_SPEED = 0.01f;

		// Scale applied to the mouse-wheel ("Mouse ScrollWheel") delta. TODO: real value unknown.
		private const float MOUSE_WHEEL_ZOOM_SPEED = 10f;

		// Scale applied to the pinch (two-finger) distance delta. TODO: real value unknown.
		private const float PINCH_ZOOM_SPEED = 0.01f;

		private const float CONFINE_PADDING_X = 9f;
		private const float CONFINE_PADDING_Y = 10f;

		public static CameraManager Instance { get; private set; }

		private void Awake()
		{
			Instance = this;

			if (featureDic == null)
			{
				featureDic = new System.Collections.Generic.Dictionary<string, ScriptableRendererFeature>();
			}
			if (renderer2DData != null && renderer2DData.rendererFeatures != null)
			{
				foreach (ScriptableRendererFeature feature in renderer2DData.rendererFeatures)
				{
					if (feature != null && !featureDic.ContainsKey(feature.name))
					{
						featureDic.Add(feature.name, feature);
					}
				}
			}
		}

		private void Update()
		{
			if (IsGameManagerMissing())
			{
				return;
			}
			if (IsGamePaused())
			{
				return;
			}

			CameraMoveHandle();
			CameraFOV();
		}

		private void Start()
		{
			UpdateGameMenu();
		}

		public void UpdateGameMenu()
		{
			CinemachineStateDrivenCamera stateDriven = null;
			if (virtualCamera != null)
			{
				stateDriven = virtualCamera.GetComponentInChildren<CinemachineStateDrivenCamera>();
			}

			if (stateDriven == null)
			{
				return;
			}

			foreach (CinemachineVirtualCameraBase child in stateDriven.ChildCameras)
			{
				if (child == null)
				{
					continue;
				}
				child.enabled = false;
			}

			bool enable = GetDefaultMenuEnabled();

			string sceneName = SceneManager.GetActiveScene().name;
			if (sceneName == SCENE_NAME_A || sceneName == SCENE_NAME_B)
			{
				enable = false;
			}

			if (featureDic != null)
			{
				ScriptableRendererFeature feature = featureDic[MENU_FEATURE_KEY];
				if (feature != null)
				{
					feature.SetActive(enable);
				}
			}
		}

		private void CameraMoveHandle()
		{
			if (!disabledDrag)
			{
				if (!FairyGUI.Stage.isTouchOnUI)
				{
					if (Input.GetMouseButton(0))
					{
						float mouseX = Input.GetAxis(MOUSE_AXIS_X);
						float mouseY = Input.GetAxis(MOUSE_AXIS_Y);
						CameraMove(mouseX, mouseY);
					}
				}
			}
		}

		private void EnabledDrag()
		{
			disabledDrag = false;
		}

		public void CameraFOV()
		{
			if (disabledFOV)
			{
				return;
			}
			if (fovTweenerCore != null)
			{
				return;
			}

			float delta;
			int inputMode = GetInputMode();
			if (inputMode == 0)
			{
				delta = Input.GetAxis(MOUSE_AXIS_SCROLLWHEEL) * Time.deltaTime * MOUSE_WHEEL_ZOOM_SPEED;
			}
			else
			{
				if (inputMode != 1)
				{
					return;
				}
				if (Input.touchCount < 1)
				{
					return;
				}

				Touch touch0 = Input.GetTouch(0);
				Touch touch1 = Input.GetTouch(1);

				if (touch1.phase == TouchPhase.Began)
				{
					oldTouch2 = touch1;
					oldTouch1 = touch0;
					return;
				}

				float oldDistance = Vector2.Distance(oldTouch1.position, oldTouch2.position);
				float newDistance = Vector2.Distance(touch0.position, touch1.position);
				delta = (newDistance - oldDistance) * PINCH_ZOOM_SPEED;
			}

			if (delta == 0f)
			{
				return;
			}

			if (delta > 0f)
			{
				if (_fovIndex > 4)
				{
					return;
				}
				_fovIndex++;
			}
			else
			{
				if (_fovIndex < 0)
				{
					return;
				}
				_fovIndex--;
			}

			float targetFov;
			switch (_fovIndex)
			{
			case 0:
				targetFov = FOV_STEP_0;
				break;
			case 1:
				targetFov = FOV_STEP_1;
				break;
			case 2:
				targetFov = FOV_STEP_2;
				break;
			case 3:
				targetFov = FOV_STEP_3;
				break;
			case 4:
				targetFov = FOV_STEP_4;
				break;
			case 5:
				targetFov = FOV_STEP_5;
				break;
			case -1:
				targetFov = FOV_STEP_MIN;
				break;
			default:
				targetFov = 0f;
				break;
			}

			fovTweenerCore = DOTween.To(
				() => virtualCamera.m_Lens.OrthographicSize,
				x => virtualCamera.m_Lens.OrthographicSize = x,
				targetFov,
				FOV_TWEEN_DURATION);
			fovTweenerCore.OnComplete(() => fovTweenerCore = null);
		}

		public void CameraMove(float mouseX, float mouseY = 0f)
		{
			if (virtualCamera == null)
			{
				throw new System.NullReferenceException();
			}

			// Temporarily disable follow so the virtual camera position can be driven manually.
			virtualCamera.Follow = null;

			Transform vcTransform = virtualCamera.transform;
			Vector3 right = vcTransform.right;
			Vector3 up = vcTransform.up;

			// Movement is faster in touch mode (inputMode == 1) than in mouse mode.
			// TODO: inputMode comes from the external game-input singleton (see GetInputMode).
			float speed = MOUSE_DRAG_SPEED;
			if (GetInputMode() == 1)
			{
				speed = MOUSE_DRAG_SPEED_TOUCH;
			}

			Vector3 position = vcTransform.position;
			float newX = (-right.x * mouseX + -up.x * mouseY) * speed + position.x;
			float newY = (-right.y * mouseX + -up.y * mouseY) * speed + position.y;

			// Clamp inside the confiner's bounding shape if one is assigned.
			if (virtualCameraConfine == null)
			{
				throw new System.NullReferenceException();
			}

			float clampedX = newX;
			float clampedY = newY;
			if (virtualCameraConfine.m_BoundingShape2D != null)
			{
				Collider2D shape = virtualCameraConfine.m_BoundingShape2D;
				Bounds bounds = shape.bounds;

				float minX = (bounds.center.x - bounds.extents.x) + CONFINE_PADDING_X;
				float maxX = (bounds.center.x + bounds.extents.x) - CONFINE_PADDING_X;
				if (newX < minX)
				{
					clampedX = minX;
				}
				if (maxX < newX)
				{
					clampedX = maxX;
				}

				float minY = (bounds.center.y - bounds.extents.y) + CONFINE_PADDING_Y;
				float maxY = (bounds.center.y + bounds.extents.y) - CONFINE_PADDING_Y;
				if (newY < minY)
				{
					clampedY = minY;
				}
				if (maxY < newY)
				{
					clampedY = maxY;
				}
			}

			vcTransform.position = new Vector3(clampedX, clampedY, VIRTUAL_CAMERA_Z);
		}

		// Input axis names passed to Input.GetAxis. TODO: verify exact axis strings.
		private const string MOUSE_AXIS_X = "Mouse X";
		private const string MOUSE_AXIS_Y = "Mouse Y";
		private const string MOUSE_AXIS_SCROLLWHEEL = "Mouse ScrollWheel";

		// Movement speed used specifically when in touch mode. TODO: real value unknown.
		private const float MOUSE_DRAG_SPEED_TOUCH = 0.02f;

		// Z coordinate the virtual camera keeps while being panned. TODO: real value unknown.
		private const float VIRTUAL_CAMERA_Z = -10f;

		// Scene names that force the menu feature off in UpdateGameMenu. TODO: real strings unknown.
		private const string SCENE_NAME_A = "SceneA";
		private const string SCENE_NAME_B = "SceneB";

		// Dictionary key used to fetch the menu renderer feature. TODO: real key unknown.
		private const string MENU_FEATURE_KEY = "Menu";

		private static bool IsGameManagerMissing()
		{
			return false;
		}

		private static bool IsGamePaused()
		{
			return false;
		}

		private static bool GetDefaultMenuEnabled()
		{
			return true;
		}

		private static int GetInputMode()
		{
			return 0;
		}
	}
}
