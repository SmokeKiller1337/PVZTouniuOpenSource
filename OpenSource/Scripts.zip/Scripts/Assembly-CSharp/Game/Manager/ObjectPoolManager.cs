using UnityEngine;

namespace Game.Manager
{
	public class ObjectPoolManager : MonoBehaviour
	{
		[Tooltip("粒子池")]
		public Transform particlePoolParent;

		[Tooltip("子弹池")]
		public Transform bulletPoolParent;

		[Tooltip("僵尸池")]
		public Transform zombiePoolParent;

		[Tooltip("奖励池")]
		public Transform rewardPoolParent;

		public static ObjectPoolManager Instance { get; private set; }

		private void Awake()
		{
			Instance = this;
		}
	}
}
