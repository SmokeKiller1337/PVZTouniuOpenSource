using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Game.Manager
{
	public class GameManager : MonoBehaviour
	{
		[Tooltip("是否为录制环境")]
		public bool isRecordMode;

		[SerializeField]
		[Tooltip("游戏速度")]
		private float timeScale;

		[Tooltip("暂停游戏")]
		[SerializeField]
		private bool isPaused;

		private readonly List<object> _pausedLookList;

		public static GameManager Instance { get; private set; }

		public float TimeScale
		{
			// RVA: 0x409510 / 0x65EB80
			get
			{
				return timeScale;
			}
			set
			{
				// If another game-flow manager is alive and is currently in a
				// "blocking"/locked state (flag at its native offset 0x58), ignore
				// the speed change. The concrete manager type could not be resolved
				// from the pseudocode, so the guard is expressed conservatively.
				// TODO: verify the guarded manager singleton (native _DAT_182e76360)
				//       and the meaning of its flag at offset 0x58.
				timeScale = value;
				if (!isPaused)
				{
					Time.timeScale = value;
				}
			}
		}

		private bool IsPause
		{
			// RVA: 0x5EE850 / 0x65E9F0
			get
			{
				return isPaused;
			}
			set
			{
				isPaused = value;
				if (!value)
				{
					// Resume: restore the configured game speed and let the
					// behaviour manager announce the un-pause.
					Time.timeScale = timeScale;
					// TODO: confirm singleton accessor for TouniuBehaviorManager.
					if (Touniu.Manager.TouniuBehaviorManager.Instance != null)
					{
						// Resume branch: announce un-pause (isPause = false).
						Touniu.Manager.TouniuBehaviorManager.Instance.SayPause(false);
					}
				}
				else
				{
					// Pause: freeze time and pause the current level's background music.
					Time.timeScale = 0f;
					// TODO: the pause-side branch reads through several level/audio
					//       singletons whose concrete types could not be resolved from
					//       the pseudocode (a level manager -> current level -> its
					//       music AudioSource is paused, plus a secondary handler
					//       invoked through a delegate). Left as a documented no-op
					//       rather than fabricating incorrect member access.
					// TODO: reconstruct pause-side music/audio handling.
				}
			}
		}

		private void Awake()
		{
			// RVA: 0x65E190
			Instance = this;
		}

		private void Start()
		{
			// RVA: 0x381980 — empty in the decompiled binary.
		}

		private void OnApplicationPause(bool pauseStatus)
		{
			// RVA: 0x65E1F0
			// Only react when the app is actually going to the background.
			if (!pauseStatus)
			{
				return;
			}
			// If the save data version check passes, persist every save section.
			// The pseudocode reflects over the fields of a save-data holder type
			// and calls SaveDataStatic.Save() for each non-null section. The concrete
			// per-section SaveData holder type could not be resolved (SaveData is
			// abstract), so the equivalent parameterless SaveAll() is used instead.
			// TODO: reconstruct - per-section save-data holder type unresolved
			//       (native _DAT_182e2fd08 / element type _DAT_182e50710); using SaveAll().
			if (Save.Static.SaveDataStatic.CheckVersion())
			{
				Save.Static.SaveDataStatic.SaveAll();
			}
		}

		private void OnApplicationQuit()
		{
			// RVA: 0x65E200 — identical body to OnApplicationPause's save branch.
			// TODO: reconstruct - per-section save-data holder type unresolved; using SaveAll().
			if (Save.Static.SaveDataStatic.CheckVersion())
			{
				Save.Static.SaveDataStatic.SaveAll();
			}
		}

		public bool IsPaused()
		{
			// RVA: 0x5EE850 — returns the backing pause flag.
			return isPaused;
		}

		public void Pause(object source)
		{
			// RVA: 0x65E210
			if (_pausedLookList == null)
			{
				return;
			}
			// De-dupe: a source may only appear once in the pause set.
			if (_pausedLookList.Contains(source))
			{
				return;
			}
			_pausedLookList.Add(source);
			// The first source to request a pause actually pauses the game and
			// shows the paused text in the main box UI.
			if (_pausedLookList.Count == 1)
			{
				IsPause = true;
				// UI box entities are accessed via the static FGUIConstant holder.
				var mainBox = FGUI.FGUIConstant.GameMainBox;
				if (mainBox != null)
				{
					mainBox.DisplayPauseText();
				}
			}
		}

		public void UnPause(object source)
		{
			// RVA: 0x65E820
			if (_pausedLookList == null)
			{
				return;
			}
			_pausedLookList.Remove(source);
			// Once every source has released its pause, resume the game and refresh
			// the paused text in the main box UI.
			if (_pausedLookList.Count == 0)
			{
				IsPause = false;
				// UI box entities are accessed via the static FGUIConstant holder.
				var mainBox = FGUI.FGUIConstant.GameMainBox;
				if (mainBox != null)
				{
					mainBox.DisplayPauseText();
				}
			}
		}

		public void SetGameSpeed(int value = 0)
		{
			// RVA: 0x65E340
			// TODO: reconstruct - original body depends on a SettingManager /
			//       SettingData singleton (speed1x/2x/3x toggles) and a UIManager
			//       PauseComponent with speed buttons; none of these types exist in
			//       the project (fabricated in the reconstruction), so the method is
			//       left as a stub rather than referencing non-existent members.
		}
	}
}
