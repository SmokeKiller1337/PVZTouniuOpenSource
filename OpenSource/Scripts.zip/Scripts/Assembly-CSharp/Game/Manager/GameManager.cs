using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Game.Manager
{
	public class GameManager : MonoBehaviour
	{
		[Tooltip("是否为录制环境")]
		public bool isRecordMode;

		[SerializeField]
		[Tooltip("游戏速度")]
		private float timeScale;

		[Tooltip("暂停游戏")]
		[SerializeField]
		private bool isPaused;

		private readonly List<object> _pausedLookList;

		public static GameManager Instance { get; private set; }

		public float TimeScale
		{
			// / 0x65EB80
			get
			{
				return timeScale;
			}
			set
			{
				timeScale = value;
				if (!isPaused)
				{
					Time.timeScale = value;
				}
			}
		}

		private bool IsPause
		{
			// / 0x65E9F0
			get
			{
				return isPaused;
			}
			set
			{
				isPaused = value;
				if (!value)
				{
					// Resume: restore the configured game speed and let the
					// behaviour manager announce the un-pause.
					Time.timeScale = timeScale;
					// TODO: confirm singleton accessor for TouniuBehaviorManager.
					if (Touniu.Manager.TouniuBehaviorManager.Instance != null)
					{
						// Resume branch: announce un-pause (isPause = false).
						Touniu.Manager.TouniuBehaviorManager.Instance.SayPause(false);
					}
				}
				else
				{
					// Pause: freeze time and pause the current level's background music.
					Time.timeScale = 0f;
				}
			}
		}

		private void Awake()
		{
			Instance = this;
		}

		private void Start()
		{
		}

		private void OnApplicationPause(bool pauseStatus)
		{
			// Only react when the app is actually going to the background.
			if (!pauseStatus)
			{
				return;
			}
			if (Save.Static.SaveDataStatic.CheckVersion())
			{
				Save.Static.SaveDataStatic.SaveAll();
			}
		}

		private void OnApplicationQuit()
		{
			if (Save.Static.SaveDataStatic.CheckVersion())
			{
				Save.Static.SaveDataStatic.SaveAll();
			}
		}

		public bool IsPaused()
		{
			// returns the backing pause flag.
			return isPaused;
		}

		public void Pause(object source)
		{
			if (_pausedLookList == null)
			{
				return;
			}
			// De-dupe: a source may only appear once in the pause set.
			if (_pausedLookList.Contains(source))
			{
				return;
			}
			_pausedLookList.Add(source);
			// The first source to request a pause actually pauses the game and
			// shows the paused text in the main box UI.
			if (_pausedLookList.Count == 1)
			{
				IsPause = true;
				// UI box entities are accessed via the static FGUIConstant holder.
				var mainBox = FGUI.FGUIConstant.GameMainBox;
				if (mainBox != null)
				{
					mainBox.DisplayPauseText();
				}
			}
		}

		public void UnPause(object source)
		{
			if (_pausedLookList == null)
			{
				return;
			}
			_pausedLookList.Remove(source);
			// Once every source has released its pause, resume the game and refresh
			// the paused text in the main box UI.
			if (_pausedLookList.Count == 0)
			{
				IsPause = false;
				// UI box entities are accessed via the static FGUIConstant holder.
				var mainBox = FGUI.FGUIConstant.GameMainBox;
				if (mainBox != null)
				{
					mainBox.DisplayPauseText();
				}
			}
		}

		public void SetGameSpeed(int value = 0)
		{
		}
	}
}
