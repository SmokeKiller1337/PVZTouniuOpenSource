using System;
using System.Collections.Generic;
using Common.Entity;
using Common.Enum;
using DG.Tweening;
using FGUI.Entity;
using Game.Entity;
using Plant.Entity;
using UnityEngine;

namespace Game.Util
{
	public static class GameUtils
	{
		public static GameObject CreateEffect(EffectEntity effect, Vector2 position, Quaternion rotation, float scale = 1f)
		{
			return null;
		}

		public static GameObject CreateEffectUI(EffectEntity effect, Vector2 position, Quaternion rotation, float scale = 1f)
		{
			return null;
		}

		public static GameObject CreateEffect(EffectEntity effect, Transform transform)
		{
			return null;
		}

		public static GameObject CreateEffectUI(EffectEntity effect, Transform transform)
		{
			return null;
		}

		public static GameObject CreateEffect(EffectEntity effect)
		{
			return null;
		}

		public static List<BaseBody> OverlapCircleAll(Vector2 position, float range, int layerMask)
		{
			return null;
		}

		public static void LoadScene(string sceneName)
		{
		}

		public static void InitSceneUI(string sceneName)
		{
			Type type = Type.GetType("FGUI.Entity.Init." + sceneName + "InitEntity");
			if (type == null)
			{
				string originalScene = sceneName switch
				{
					"level1" => "Title",
					"level2" => "Level",
					_ => null
				};
				if (originalScene != null)
				{
					type = Type.GetType("FGUI.Entity.Init." + originalScene + "InitEntity");
				}
			}
			if (type == null)
			{
				return;
			}
			GameObject uiManager = GameObject.Find("UIManager");
			if (uiManager == null)
			{
				return;
			}
			if (uiManager.AddComponent(type) is FGUISceneInitEntity sceneInit)
			{
				sceneInit.isInit = false;
			}
		}

		public static string GetValueStr(float value, bool isPercentage, string format = null)
		{
			return null;
		}

		public static string GetBonusAttrIcon(AttrEnum attrEnum)
		{
			return null;
		}

		public static string GetRatioStr(float value, string format = null)
		{
			return null;
		}

		public static int GetDecimalPlaces(float number)
		{
			return 0;
		}

		public static string GetTimeString(int totalSeconds, int mode = 3)
		{
			return null;
		}

		public static float Map(float value, float fromMin, float fromMax, float toMin, float toMax)
		{
			return 0f;
		}

		public static void ShuffleList<T>(List<T> list)
		{
		}

		public static Tween DelayedCall(int layer, Action action)
		{
			return null;
		}

		public static bool IsTestScene()
		{
			return false;
		}

		public static float GetCurrentAnimationDuration(Animator animator)
		{
			return 0f;
		}

		public static string AttrStrFormat(string str, CardEntity cardEntity)
		{
			return null;
		}

		private static void PlayEffectSound(EffectEntity effect, Vector2 position, bool isUI = false)
		{
		}

		private static bool CheckCreate(EffectEntity effect)
		{
			return false;
		}
	}
}
