using UnityEngine;

public abstract class BuffTagData : ScriptableObject
{
}
