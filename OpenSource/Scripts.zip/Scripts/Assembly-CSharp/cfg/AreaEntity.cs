using Luban;

namespace cfg
{
	public sealed class AreaEntity : BeanBase
	{
		public readonly int Id;

		public readonly string Title;

		public const int __ID__ = -1875566864;

		public AreaEntity(ByteBuf _buf)
		{
		}

		public static AreaEntity DeserializeAreaEntity(ByteBuf _buf)
		{
			return null;
		}

		public override int GetTypeId()
		{
			return 0;
		}

		public void ResolveRef(Tables tables)
		{
		}

		public override string ToString()
		{
			return null;
		}
	}
}
