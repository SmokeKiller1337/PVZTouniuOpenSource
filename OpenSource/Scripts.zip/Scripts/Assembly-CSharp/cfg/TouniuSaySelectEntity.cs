using Luban;
using cfg.common;

namespace cfg
{
	public sealed class TouniuSaySelectEntity : BeanBase
	{
		public readonly int Id;

		public readonly string Content;

		public readonly string SkinName;

		public readonly float LimitTime;

		public readonly string OptionATitle;

		public readonly string OptionBTitle;

		public readonly bool DefaultOption;

		public readonly int BoxType;

		public readonly ColorType ColorType;

		public readonly bool IsProvideValue;

		public readonly float ProvideBaseValue;

		public readonly float ProvideStepValue;

		public readonly float ProvideMinValue;

		public readonly float ProvideMaxValue;

		public const int __ID__ = 311715018;

		public TouniuSaySelectEntity(ByteBuf _buf)
		{
		}

		public static TouniuSaySelectEntity DeserializeTouniuSaySelectEntity(ByteBuf _buf)
		{
			return null;
		}

		public override int GetTypeId()
		{
			return 0;
		}

		public void ResolveRef(Tables tables)
		{
		}

		public override string ToString()
		{
			return null;
		}
	}
}
