using Luban;
using cfg.common;

namespace cfg
{
	public sealed class TouniuSayFixedEntity : BeanBase
	{
		public readonly int Id;

		public readonly string Content;

		public readonly string SkinName;

		public readonly int BoxType;

		public readonly ColorType ColorType;

		public const int __ID__ = 197787212;

		public TouniuSayFixedEntity(ByteBuf _buf)
		{
		}

		public static TouniuSayFixedEntity DeserializeTouniuSayFixedEntity(ByteBuf _buf)
		{
			return null;
		}

		public override int GetTypeId()
		{
			return 0;
		}

		public void ResolveRef(Tables tables)
		{
		}

		public override string ToString()
		{
			return null;
		}
	}
}
