using Luban;

namespace cfg
{
	public sealed class TouniuHandleEntity : BeanBase
	{
		public readonly int Id;

		public readonly string Title;

		public readonly string Describe;

		public const int __ID__ = 2014348011;

		public TouniuHandleEntity(ByteBuf _buf)
		{
		}

		public static TouniuHandleEntity DeserializeTouniuHandleEntity(ByteBuf _buf)
		{
			return null;
		}

		public override int GetTypeId()
		{
			return 0;
		}

		public void ResolveRef(Tables tables)
		{
		}

		public override string ToString()
		{
			return null;
		}
	}
}
