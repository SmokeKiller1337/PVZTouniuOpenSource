using Luban;

namespace cfg
{
	public sealed class TeachEntity : BeanBase
	{
		public readonly int Id;

		public readonly string Title;

		public readonly string Content;

		public readonly bool IsUnique;

		public const int __ID__ = -1886284648;

		public TeachEntity(ByteBuf _buf)
		{
		}

		public static TeachEntity DeserializeTeachEntity(ByteBuf _buf)
		{
			return null;
		}

		public override int GetTypeId()
		{
			return 0;
		}

		public void ResolveRef(Tables tables)
		{
		}

		public override string ToString()
		{
			return null;
		}
	}
}
