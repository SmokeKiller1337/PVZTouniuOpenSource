using Luban;
using cfg.common;

namespace cfg
{
	public sealed class GuestSayEntity : BeanBase
	{
		public readonly int Id;

		public readonly string Content;

		public readonly string AnimationAme;

		public readonly ColorType ColorType;

		public const int __ID__ = 785744086;

		public GuestSayEntity(ByteBuf _buf)
		{
		}

		public static GuestSayEntity DeserializeGuestSayEntity(ByteBuf _buf)
		{
			return null;
		}

		public override int GetTypeId()
		{
			return 0;
		}

		public void ResolveRef(Tables tables)
		{
		}

		public override string ToString()
		{
			return null;
		}
	}
}
