namespace cfg.common
{
	public enum ColorType
	{
		White = 0,
		Black = 1,
		Red = 2,
		Blue = 3,
		Yellow = 4,
		Green = 5,
		Pink = 6
	}
}
