using System.Collections.Generic;
using Luban;

namespace cfg.common
{
	public class TouniuSayFixed
	{
		private readonly Dictionary<int, TouniuSayFixedEntity> _dataMap;

		private readonly List<TouniuSayFixedEntity> _dataList;

		public Dictionary<int, TouniuSayFixedEntity> DataMap => null;

		public List<TouniuSayFixedEntity> DataList => null;

		public TouniuSayFixedEntity this[int key] => null;

		public TouniuSayFixed(ByteBuf _buf)
		{
		}

		public TouniuSayFixedEntity GetOrDefault(int key)
		{
			return null;
		}

		public TouniuSayFixedEntity Get(int key)
		{
			return null;
		}

		public void ResolveRef(Tables tables)
		{
		}
	}
}
