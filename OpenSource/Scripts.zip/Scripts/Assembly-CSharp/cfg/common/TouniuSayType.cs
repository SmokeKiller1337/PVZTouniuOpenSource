namespace cfg.common
{
	public enum TouniuSayType
	{
		None = 0,
		Select = 2,
		Fixed = 4,
		Shop = 6
	}
}
