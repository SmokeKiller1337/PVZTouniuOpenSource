namespace cfg.common
{
	public enum TouniuBehaviorType
	{
		None = 0,
		Talk = 1,
		Handle = 2
	}
}
