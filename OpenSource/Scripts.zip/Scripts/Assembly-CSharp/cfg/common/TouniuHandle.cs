using System.Collections.Generic;
using Luban;

namespace cfg.common
{
	public class TouniuHandle
	{
		private readonly Dictionary<int, TouniuHandleEntity> _dataMap;

		private readonly List<TouniuHandleEntity> _dataList;

		public Dictionary<int, TouniuHandleEntity> DataMap => null;

		public List<TouniuHandleEntity> DataList => null;

		public TouniuHandleEntity this[int key] => null;

		public TouniuHandle(ByteBuf _buf)
		{
		}

		public TouniuHandleEntity GetOrDefault(int key)
		{
			return null;
		}

		public TouniuHandleEntity Get(int key)
		{
			return null;
		}

		public void ResolveRef(Tables tables)
		{
		}
	}
}
