using System.Collections.Generic;
using Luban;

namespace cfg.common
{
	public class TouniuSaySelect
	{
		private readonly Dictionary<int, TouniuSaySelectEntity> _dataMap;

		private readonly List<TouniuSaySelectEntity> _dataList;

		public Dictionary<int, TouniuSaySelectEntity> DataMap => null;

		public List<TouniuSaySelectEntity> DataList => null;

		public TouniuSaySelectEntity this[int key] => null;

		public TouniuSaySelect(ByteBuf _buf)
		{
		}

		public TouniuSaySelectEntity GetOrDefault(int key)
		{
			return null;
		}

		public TouniuSaySelectEntity Get(int key)
		{
			return null;
		}

		public void ResolveRef(Tables tables)
		{
		}
	}
}
