using System.Collections.Generic;
using Luban;

namespace cfg.common
{
	public class Teach
	{
		private readonly Dictionary<int, TeachEntity> _dataMap;

		private readonly List<TeachEntity> _dataList;

		public Dictionary<int, TeachEntity> DataMap => null;

		public List<TeachEntity> DataList => null;

		public TeachEntity this[int key] => null;

		public Teach(ByteBuf _buf)
		{
		}

		public TeachEntity GetOrDefault(int key)
		{
			return null;
		}

		public TeachEntity Get(int key)
		{
			return null;
		}

		public void ResolveRef(Tables tables)
		{
		}
	}
}
