using System;
using Luban;
using cfg.common;
using cfg.pvz;

namespace cfg
{
	public class Tables
	{
		public TouniuSaySelect TouniuSaySelect { get; }

		public TouniuSayFixed TouniuSayFixed { get; }

		public TouniuHandle TouniuHandle { get; }

		public Teach Teach { get; }

		public Area Area { get; }

		public GuestSay GuestSay { get; }

		public Tables(Func<string, ByteBuf> loader)
		{
		}

		private void ResolveRef()
		{
		}
	}
}
