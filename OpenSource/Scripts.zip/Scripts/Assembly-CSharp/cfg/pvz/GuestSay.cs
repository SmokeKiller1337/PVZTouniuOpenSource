using System.Collections.Generic;
using Luban;

namespace cfg.pvz
{
	public class GuestSay
	{
		private readonly Dictionary<int, GuestSayEntity> _dataMap;

		private readonly List<GuestSayEntity> _dataList;

		public Dictionary<int, GuestSayEntity> DataMap => null;

		public List<GuestSayEntity> DataList => null;

		public GuestSayEntity this[int key] => null;

		public GuestSay(ByteBuf _buf)
		{
		}

		public GuestSayEntity GetOrDefault(int key)
		{
			return null;
		}

		public GuestSayEntity Get(int key)
		{
			return null;
		}

		public void ResolveRef(Tables tables)
		{
		}
	}
}
