using System.Collections.Generic;
using Luban;

namespace cfg.pvz
{
	public class Area
	{
		private readonly Dictionary<int, AreaEntity> _dataMap;

		private readonly List<AreaEntity> _dataList;

		public Dictionary<int, AreaEntity> DataMap => null;

		public List<AreaEntity> DataList => null;

		public AreaEntity this[int key] => null;

		public Area(ByteBuf _buf)
		{
		}

		public AreaEntity GetOrDefault(int key)
		{
			return null;
		}

		public AreaEntity Get(int key)
		{
			return null;
		}

		public void ResolveRef(Tables tables)
		{
		}
	}
}
