using System;
using System.Collections.Generic;
using Level.Enum;
using Touniu.Enum;
using UnityEngine;
using UnityEngine.Rendering;
using Zombie.Entity;

namespace Level.Object
{
	[CreateAssetMenu(fileName = "ZombieWaveObject", menuName = "Level/WaveObject", order = 1)]
	public class ZombieWaveObject : ScriptableObject
	{
		[Serializable]
		public class ZombieWaveItem : ICloneable
		{
			[TextArea]
			[Tooltip("按级别指定僵尸")]
			public string zombieRankStr;

			[TextArea]
			[Tooltip("按编号指定僵尸")]
			public string zombieIdStr;

			[Tooltip("等待时间")]
			public float waitTime;

			[Tooltip("持续时间")]
			public float durationTime;

			[Tooltip("血量倍率")]
			public float healthRatio;

			[Tooltip("是否均匀分配")]
			public bool isUniform;

			[Tooltip("是否随机顺序")]
			public bool isRandom;

			[Tooltip("是存档点")]
			public bool isSave;

			[Tooltip("是否为大波")]
			public bool isBigWave;

			[Tooltip("是否为最后一波")]
			public bool isLastWave;

			[Tooltip("是否为Boss")]
			public bool isBossWave;

			[Tooltip("Boss编号")]
			public int bossId;

			[Tooltip("战利品字典")]
			public SerializedDictionary<int, int> rewardDic;

			[Tooltip("事件集合")]
			public List<WaveEventItem> eventList;

			[HideInInspector]
			public List<int> zombieIdList;

			[HideInInspector]
			public List<ZombieDeathRewardEntity> rewardList;

			[HideInInspector]
			public int startEventCount;

			[HideInInspector]
			public int endEventCount;

			public object Clone()
			{
				return null;
			}
		}

		[Serializable]
		public class WaveEventItem : ICloneable
		{
			public WaveEventType eventType;

			[Tooltip("旁白事件类型")]
			public SayType sayType;

			[Tooltip("事件id(0随机)")]
			public int eventId;

			[Tooltip("间隔时间(-1表示说话时间)")]
			public float intervalTime;

			[Tooltip("是新队列(打断到这里停止)")]
			public bool isNewQueue;

			[Tooltip("是解除眩晕")]
			public bool isInvalidStun;

			public object Clone()
			{
				return null;
			}
		}

		[Tooltip("流程图路线标题")]
		public string title;

		[Tooltip("僵尸级别字典")]
		public SerializedDictionary<int, string> zombieRankDic;

		[Tooltip("僵尸波次")]
		public List<ZombieWaveItem> waveList;
	}
}
