using System;
using System.Collections.Generic;
using UnityEngine;

namespace Level.Object
{
	[Serializable]
	public class LevelWinRewardEntity
	{
		[Tooltip("解锁卡牌集合")]
		public List<int> cardIdList;
	}
}
