using System.Collections.Generic;
using Level.Enum;
using UnityEngine;
using UnityEngine.Rendering;

namespace Level.Object
{
	[CreateAssetMenu(fileName = "LevelEntity", menuName = "Level/LevelObject")]
	public class LevelObject : ScriptableObject
	{
		[Tooltip("区域编号")]
		public int areaId;

		[Tooltip("关卡编号")]
		public int levelId;

		[Tooltip("关卡名")]
		public string levelTitle;

		[Tooltip("背景id")]
		public int backgroundId;

		[TextArea]
		[Tooltip("描述")]
		public string desc;

		[TextArea]
		[Tooltip("选卡建议")]
		public string selectCardDesc;

		[Tooltip("有流程图")]
		public bool isHasMap;

		[Tooltip("是随机关卡")]
		public bool isRandomLevel;

		[Tooltip("有专属UI")]
		public bool isHasMain;

		[Tooltip("有终极奖杯")]
		public bool isHasDifficulty5;

		[Tooltip("音乐")]
		public AudioClip music;

		[Tooltip("阳光数")]
		public SerializedDictionary<int, int> sunNumberDic;

		[Tooltip("锤子次数")]
		public SerializedDictionary<int, int> hammerNumberDic;

		[Tooltip("僵尸强度")]
		public int rank;

		[Tooltip("人气指数")]
		public int touniuRank;

		[Tooltip("类型")]
		public MiniType miniType;

		[Tooltip("排序")]
		public int sort;

		[Tooltip("必备卡牌集合")]
		public List<int> needCardList;

		[Tooltip("通关奖励")]
		public LevelWinRewardEntity winRewardEntity;

		[Tooltip("是传送带关卡")]
		public bool isConveyor;

		[Tooltip("传送带循环列表")]
		public List<int> conveyorCardList;

		public List<int> mode1ConveyorCardList;

		[Tooltip("是固定卡牌关卡")]
		public bool isFixedCard;

		[Tooltip("固定卡牌集合")]
		public List<int> fixedCardList;

		[Tooltip("墓碑数量")]
		public int tombstoneNumber;

		[Tooltip("迷雾距离")]
		public float fogDistance;
	}
}
