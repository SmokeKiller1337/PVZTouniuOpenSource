namespace Level.Enum
{
	public enum DeathType
	{
		Normal = 0,
		Ashes = 1,
		Clear = 2
	}
}
