namespace Level.Enum
{
	public enum WaveEventType
	{
		Wait = 0,
		Handle = 1,
		TouniuSay = 2,
		GuestSay = 3
	}
}
