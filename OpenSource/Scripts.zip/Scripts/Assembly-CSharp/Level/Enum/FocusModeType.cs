namespace Level.Enum
{
	public enum FocusModeType
	{
		SlowDown = 0,
		Backtrack = 1,
		Event = 2
	}
}
