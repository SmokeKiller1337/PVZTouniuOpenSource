namespace Level.Enum
{
	public enum LandType
	{
		Grass = 0,
		Water = 1,
		Space = 2,
		Auto = 3
	}
}
