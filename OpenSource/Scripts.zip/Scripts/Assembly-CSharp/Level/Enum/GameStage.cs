namespace Level.Enum
{
	public enum GameStage
	{
		InPreparation = 0,
		PreparationEnd = 1,
		InGame = 2,
		GameEnd = 3
	}
}
