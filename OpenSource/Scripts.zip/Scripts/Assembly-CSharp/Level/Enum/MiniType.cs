namespace Level.Enum
{
	public enum MiniType
	{
		Story = 0,
		Puzzle = 1,
		Random = 2
	}
}
