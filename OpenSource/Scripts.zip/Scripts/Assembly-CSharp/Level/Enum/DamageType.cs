namespace Level.Enum
{
	public enum DamageType
	{
		Common = 0,
		Pierce = 1,
		Explosion = 2,
		Parabolic = 3,
		God = 4
	}
}
