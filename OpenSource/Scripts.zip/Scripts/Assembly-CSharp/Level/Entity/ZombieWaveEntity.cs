using System;
using System.Collections.Generic;
using Level.Object;
using UnityEngine;
using Zombie.Entity;

namespace Level.Entity
{
	[Serializable]
	public class ZombieWaveEntity
	{
		[Tooltip("流程图路线标题")]
		public string title;

		public Dictionary<int, List<int>> ZombieRankDic;

		[Tooltip("僵尸波次")]
		public List<ZombieWaveObject.ZombieWaveItem> waveList;

		public ZombieWaveEntity()
		{
		}

		public ZombieWaveEntity(ZombieWaveObject zombieWaveObject)
		{
		}

		private void BuildZombieWaveDic(ZombieWaveObject zombieWaveObject)
		{
		}

		private List<int> GetZombieIdListByRank(string rankStr)
		{
			return null;
		}

		private List<int> GetZombieIdListById(string idStr)
		{
			return null;
		}

		private List<ZombieDeathRewardEntity> GetZombieRewardList(ZombieWaveObject.ZombieWaveItem waveItem)
		{
			return null;
		}

		private List<int> ZombieRewardSplitAmount(int total, int parts)
		{
			return null;
		}
	}
}
