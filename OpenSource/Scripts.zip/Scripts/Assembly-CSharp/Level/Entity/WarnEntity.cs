using System.Collections.Generic;
using UnityEngine;

namespace Level.Entity
{
	public class WarnEntity : MonoBehaviour
	{
		[HideInInspector]
		public Transform warnTransform;

		[HideInInspector]
		public List<GameObject> warnList;

		private void Awake()
		{
		}

		public virtual void PlayWarn(int index = 0, float time = 2f)
		{
		}
	}
}
