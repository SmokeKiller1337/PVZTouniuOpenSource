using UnityEngine;

namespace Level.Entity
{
	public class WarnItemEntity : MonoBehaviour
	{
		[HideInInspector]
		public float alpha;

		private void Awake()
		{
		}
	}
}
