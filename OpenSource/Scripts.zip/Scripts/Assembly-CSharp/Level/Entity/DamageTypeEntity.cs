using System;
using Level.Enum;
using UnityEngine;

namespace Level.Entity
{
	[Serializable]
	public class DamageTypeEntity
	{
		[Tooltip("伤害类型")]
		public DamageType damageType;

		[Tooltip("死亡类型")]
		public DeathType deathType;

		[Tooltip("是否掉落部件")]
		public bool isLosePart;

		[Tooltip("是否掉落防具")]
		public bool isLoseArm;

		[Tooltip("是否有掉落物")]
		public bool isReward;

		[Tooltip("是否Boss减免")]
		public bool isBossReduce;

		// Each getter allocates a fresh DamageTypeEntity with a fixed set of field
		// values (the decompiled code guards on the IL2CPP per-type static-init flag,
		// then allocates a new instance and writes the field bytes directly).
		// Enum member names are not available in the stub/dump; the raw integral values
		// from the field writes are cast to the enum types.
		// TODO: confirm DamageType / DeathType enum member names match these integral values.

		public static DamageTypeEntity Common => new DamageTypeEntity
		{
			damageType = (DamageType)0,
			deathType = (DeathType)0,
			isLosePart = true,
			isLoseArm = true,
			isReward = true,
			isBossReduce = false
		};

		public static DamageTypeEntity Pierce => new DamageTypeEntity
		{
			damageType = (DamageType)1,
			deathType = (DeathType)0,
			isLosePart = true,
			isLoseArm = true,
			isReward = true,
			isBossReduce = false
		};

		public static DamageTypeEntity Parabolic => new DamageTypeEntity
		{
			damageType = (DamageType)3,
			deathType = (DeathType)0,
			isLosePart = true,
			isLoseArm = true,
			isReward = true,
			isBossReduce = false
		};

		public static DamageTypeEntity Explosion => new DamageTypeEntity
		{
			damageType = (DamageType)2,
			deathType = (DeathType)1,
			isLosePart = false,
			isLoseArm = false,
			isReward = true,
			isBossReduce = true
		};

		public static DamageTypeEntity Clear => new DamageTypeEntity
		{
			damageType = (DamageType)0,
			deathType = (DeathType)2,
			isLosePart = false,
			isLoseArm = false,
			isReward = true,
			isBossReduce = false
		};

		public static DamageTypeEntity LawnMower => new DamageTypeEntity
		{
			damageType = (DamageType)4,
			deathType = (DeathType)0,
			isLosePart = true,
			isLoseArm = true,
			isReward = true,
			isBossReduce = false
		};

		public static DamageTypeEntity Remove => new DamageTypeEntity
		{
			damageType = (DamageType)4,
			deathType = (DeathType)2,
			isLosePart = false,
			isLoseArm = false,
			isReward = false,
			isBossReduce = false
		};
	}
}
