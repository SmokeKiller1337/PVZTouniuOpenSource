using Game.Entity;
using Land.Entity;
using Level.Enum;
using Plant.Entity;
using UnityEngine;

namespace Level.Manager
{
	public class LandManager : MonoBehaviour
	{
		[HideInInspector]
		public int rowNumber;

		[HideInInspector]
		public int columnNumber;

		[HideInInspector]
		public AllLandEntity allLandEntity;

		[Tooltip("小推车预制体")]
		public GameObject lawnPrefab;

		public GameObject lawnPrefab1;

		[Tooltip("种植陆地效果")]
		public EffectEntity growEffect;

		[Tooltip("种植水地效果")]
		public EffectEntity growWaterEffect;

		[Tooltip("入水效果")]
		public EffectEntity enterWaterEffect;

		[Tooltip("出水效果")]
		public EffectEntity exitWaterEffect;

		[Tooltip("水路摇晃振幅")]
		public float waterAmplitude;

		[Tooltip("水路摇晃频率")]
		public float waterFrequency;

		private float _checkInvalidPlantTimer;

		[Tooltip("斜坡检测层")]
		public LayerMask slopeLayer;

		public static LandManager Instance { get; private set; }

		private void Awake()
		{
		}

		private void Start()
		{
		}

		private void Update()
		{
		}

		private void ClearInvalidPlantList()
		{
		}

		private void CheckClearInvalidPlant(PlantEntity plantEntity, LandEntity landEntity)
		{
		}

		public PlantEntity AddPlant(int id, LandEntity landEntity, bool isCover = false)
		{
			return null;
		}

		public PlantEntity AddPlant(CardEntity cardEntity, LandEntity landEntity, bool isCover = false)
		{
			return null;
		}

		public LawnMowerEntity AddLawnMower(int row, LandType type = LandType.Auto)
		{
			return null;
		}

		public void RemoveLawnMower(int row)
		{
		}
	}
}
