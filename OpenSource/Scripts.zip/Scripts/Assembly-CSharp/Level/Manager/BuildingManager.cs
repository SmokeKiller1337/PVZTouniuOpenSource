using Building.Entity;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using Land.Entity;
using Land.Entity.Fog;
using UnityEngine;

namespace Level.Manager
{
	public class BuildingManager : MonoBehaviour
	{
		[Tooltip("墓碑预制体")]
		public GameObject tombstonePrefab;

		[Tooltip("弹坑预制体")]
		public GameObject craterPrefab;

		[Tooltip("罐子预制体")]
		public GameObject potPrefab;

		[Tooltip("迷雾预制体")]
		public GameObject fogPrefab;

		[HideInInspector]
		public GameObject fogObj;

		[HideInInspector]
		public FogManager fogManager;

		[Tooltip("迷雾距离")]
		public float fogDistance;

		[Tooltip("是否更新迷雾位置")]
		public bool isUpdateFog;

		private readonly float _fogDefaultX;

		private TweenerCore<Vector3, Vector3, VectorOptions> _fogTween;

		[Tooltip("墓碑图标")]
		public Sprite tombstoneSprite;

		public float FogLeftX => 0f;

		public float FogRightX => 0f;

		public static BuildingManager Instance { get; private set; }

		private void Awake()
		{
		}

		private void Start()
		{
		}

		private void Update()
		{
		}

		public BuildingEntity AddBuilding(int id, LandEntity landEntity)
		{
			return null;
		}

		public BuildingEntity AddBuilding(GameObject buildingPrefab, LandEntity landEntity)
		{
			return null;
		}

		public TombstoneEntity AddTombstone(LandEntity landEntity)
		{
			return null;
		}

		public TombstoneEntity AddTombstone(int row, int column)
		{
			return null;
		}

		public CraterEntity AddCrater(LandEntity landEntity)
		{
			return null;
		}

		public CraterEntity AddCrater(int row, int column)
		{
			return null;
		}

		public PotEntity AddPot(LandEntity landEntity)
		{
			return null;
		}

		public PotEntity AddPot(int row, int column)
		{
			return null;
		}

		private void FogUpdate()
		{
		}

		public FogManager CreateFog()
		{
			return null;
		}

		public void MoveFog(float x, float time = 1f)
		{
		}

		public void BlowFog(float distance)
		{
		}

		public void InitFog()
		{
		}

		public float GetFogDistance()
		{
			return 0f;
		}
	}
}
