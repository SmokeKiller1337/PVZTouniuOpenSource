using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

namespace Level.Manager
{
	public class TestManager : MonoBehaviour
	{
		[CompilerGenerated]
		private sealed class _003CTest1_003Ed__20 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TestManager _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CTest1_003Ed__20(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CTest2_003Ed__18 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CTest2_003Ed__18(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("开启测试模式")]
		public bool isTest;

		[Tooltip("是否极速模式")]
		public bool isSpeedUp;

		[Tooltip("是否禁用旁白")]
		public bool isDeathTouniu;

		[Tooltip("是否旁白自动移动")]
		public bool isTouniuMove;

		[Tooltip("无限阳光")]
		public bool isSun;

		[Tooltip("阳光值")]
		public int sunValue;

		[Tooltip("无限钻石")]
		public bool isDiamond;

		[Tooltip("无冷却")]
		public bool isCooldown;

		[Tooltip("无限锤子")]
		public bool isHammer;

		[Tooltip("是否落下阳光")]
		public bool isFallSun;

		private int _test1Value;

		public static TestManager Instance { get; private set; }

		private void Awake()
		{
		}

		private void Start()
		{
		}

		private void Update()
		{
		}

		public void StartLevelGameEnd()
		{
		}

		[IteratorStateMachine(typeof(_003CTest2_003Ed__18))]
		private IEnumerator Test2()
		{
			return null;
		}

		[IteratorStateMachine(typeof(_003CTest1_003Ed__20))]
		private IEnumerator Test1()
		{
			return null;
		}
	}
}
