using Guest.Entity;
using UnityEngine;

namespace Level.Manager
{
	public class PreparationManager : MonoBehaviour
	{
		[Tooltip("准备阶段音乐")]
		public AudioClip preparationMusic;

		public static PreparationManager Instance { get; private set; }

		private void Awake()
		{
		}

		private void Start()
		{
		}

		public void ResetPreparation()
		{
		}

		public void UpdateGuest(GuestEntity guestEntity)
		{
		}

		public void Confirm()
		{
		}
	}
}
