using UnityEngine;

namespace Level.Manager
{
	public class ShortcutKeysManager : MonoBehaviour
	{
		private bool _isEnablePause;

		private bool _isEnableFocus;

		private bool _isEnableNumber;

		[SerializeField]
		private float clickThreshold;

		private float _clickThresholdTimer;

		private bool _isHoldFocus;

		[HideInInspector]
		public bool isHideUI;

		[Tooltip("是否启用暂停")]
		public bool IsEnablePause
		{
			get
			{
				return false;
			}
			set
			{
			}
		}

		[Tooltip("是否启用集中")]
		public bool IsEnableFocus
		{
			get
			{
				return false;
			}
			set
			{
			}
		}

		[Tooltip("是否启用数字键")]
		public bool IsEnableNumber
		{
			get
			{
				return false;
			}
			set
			{
			}
		}

		public static ShortcutKeysManager Instance { get; private set; }

		private void Awake()
		{
		}

		private void Start()
		{
		}

		private void Update()
		{
		}

		private void CommonKeyUpdate()
		{
		}

		private void InGameKeyUpdate()
		{
		}
	}
}
