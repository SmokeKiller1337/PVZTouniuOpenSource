using Guest.Entity;
using Guest.Entity.Say;
using UnityEngine;

namespace Level.Manager
{
	public class GuestManager : MonoBehaviour
	{
		[Tooltip("嘉宾实体")]
		public GuestEntity guestEntity;

		[Tooltip("默认说话预制体")]
		public GameObject guestSayDefaultPrefab;

		public static GuestManager Instance { get; private set; }

		private void Awake()
		{
		}

		private void Start()
		{
		}

		private void Update()
		{
		}

		public void CreateGuest()
		{
		}

		public GuestSayEntity TalkStart(int sayId)
		{
			return null;
		}

		public void TalkEnd()
		{
		}

		public void PlayAnimation(string title)
		{
		}
	}
}
