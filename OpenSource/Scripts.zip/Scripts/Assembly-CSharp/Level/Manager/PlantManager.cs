using System;
using Game.Entity;
using Land.Entity;
using Plant.Entity;
using UnityEngine;

namespace Level.Manager
{
	public class PlantManager : MonoBehaviour
	{
		[Tooltip("樱桃爆炸效果")]
		public EffectEntity plant30Effect;

		[Tooltip("紫樱桃爆炸效果")]
		public EffectEntity plant35Effect;

		[Tooltip("魅惑效果")]
		public EffectEntity hypnosisEffect;

		public Action<PlantEntity> OnPlacePlantAction;

		public static PlantManager Instance { get; private set; }

		private void Awake()
		{
		}

		private void Start()
		{
		}

		public bool PlacePlant(CardEntity cardEntity, LandEntity landEntity, SeedCardEntity seedCardEntity = null)
		{
			return false;
		}
	}
}
