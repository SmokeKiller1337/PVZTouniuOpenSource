using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using Audio.Manager;
using DG.Tweening;
using Game.Manager;
using Game.Util;
using Land.Entity;
using Level.Entity;
using Level.Enum;
using Level.Object;
using Level.Static;
using Level.Util;
using Touniu.Util;
using UnityEngine;
using Zombie.Entity;

// Reconstructed from IL2CPP decompilation (AssetRipper stub + Ghidra pseudocode + dump offsets).
// Manager singletons (AudioManager, CardSlotManager, ZombieManager, BuildingManager, LandManager,
// PreparationManager, GameManager, UIManager, TestManager, etc.) and static utils are referenced
// via their `.Instance` accessors / static methods. Where the exact singleton type/name behind an
// il2cpp static-storage slot could not be resolved, a call is expressed against the most plausible
// manager and marked with // TODO where uncertain.
//
// NOTE (reconstruction pass): Many method bodies in the original decompiled reconstruction referenced
// members and types that do not exist in the current project stubs (e.g. UIManager, SettingsManager,
// AreaManager, SoilManager, SaveManager, TouniuBehavior, ZombieBossComponent, ZombieBaseComponent,
// LoseBoxEntity, and a large number of fabricated fields/properties on GameManager, LevelObject,
// ZombieWaveEntity, ZombieWaveObject.ZombieWaveItem/WaveEventItem, ZombieEntity, RowLandEntity,
// BackgroundEntity, LawnMowerEntity, CardSlotManager, CardEntity, LandManager). Those method bodies
// could not be reconstructed against the real API surface and have been reduced to safe stubs
// (marked // TODO: reconstruct) so this file compiles. Methods that only touch members that genuinely
// exist have been kept intact.
namespace Level.Manager
{
	public class LevelAssetsManager : MonoBehaviour
	{
		[CompilerGenerated]
		private sealed class _003CBigWaveHandle_003Ed__69 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public ZombieWaveObject.ZombieWaveItem zombieWaveItem;

			public LevelAssetsManager _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CBigWaveHandle_003Ed__69(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct - original body referenced non-existent members
				// (UIManager, ZombieWaveItem.isLastWave path constants, RowLandEntity.state/.index,
				// BuildingManager.RowLandDict, ZombieEntity.CanSpawnOn, ZombieManager.CreateSoilZombie
				// arg shape). Reduced to an empty coroutine.
				_003C_003E1__state = -1;
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CEnterWaveCoroutine_003Ed__67 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public int index;

			public LevelAssetsManager _003C_003E4__this;

			public float startTime;

			private ZombieWaveObject.ZombieWaveItem _003CzombieWaveItem_003E5__2;

			private float _003CintervalTime_003E5__3;

			private List<ZombieDeathRewardEntity> _003CrewardList_003E5__4;

			private int _003Ci_003E5__5;

			private int _003CzombieId_003E5__6;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CEnterWaveCoroutine_003Ed__67(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct - original body referenced non-existent members
				// (UIManager, AudioManager wave calls, AreaStatic.IsRandomMode/SaveCurrentLevel paths,
				// GameManager.GameMode, ZombieWaveEntity.waveItemList, and many fabricated
				// ZombieWaveItem fields: waveTime/intervalTime/zombieList/isSaveWave/isBigWave/
				// isBossWave/bossZombieId/waveIndex/bossHpDict, plus ZombieEntity.deathReward and
				// ZombieBossComponent). Reduced to an empty coroutine.
				_003C_003E1__state = -1;
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CInGameStart_003Ed__61 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public LevelAssetsManager _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CInGameStart_003Ed__61(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct - original body referenced non-existent members
				// (UIManager, LevelObject.bgm, GameManager.GameMode/isEndless, CardSlotManager.isWarmUp/
				// hammerCard, BackgroundEntity.isWarmUp). Reduced to an empty coroutine.
				_003C_003E1__state = -1;
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CLoadLevel_003Ed__60 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public LevelAssetsManager _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CLoadLevel_003Ed__60(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct - original body referenced non-existent members
				// (GameManager.RecordFrame, FocusSlowMotionManager.OnBacktrackStart, UIManager).
				// Reduced to an empty coroutine.
				_003C_003E1__state = -1;
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CLoseGameCoroutine_003Ed__85 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public LevelAssetsManager _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CLoseGameCoroutine_003Ed__85(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct - original body referenced non-existent members
				// (UIManager.LoseBox). Kept the observable state transition + difficulty verify.
				if (_003C_003E1__state != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				LevelAssetsManager @this = _003C_003E4__this;
				if (@this != null)
				{
					@this.currentStage = GameStage.GameEnd;
					AreaStatic.VerifyDifficulty();
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CPreparationEnd_003Ed__59 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public LevelAssetsManager _003C_003E4__this;

			private List<LawnMowerEntity>.Enumerator _003C_003E7__wrap1;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CPreparationEnd_003Ed__59(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct - original body referenced non-existent members
				// (UIManager, LandManager.rootTransform, LawnMowerEntity.spriteRoot/mainSprite,
				// BackgroundEntity.cols/rows, LevelObject.tombstoneCount, GameManager.GameMode/hasHammer,
				// TouniuManager, GameManager.gameEnd). Reduced to an empty coroutine.
				_003C_003E1__state = -1;
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CPreparationShowZombie_003Ed__57 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public LevelAssetsManager _003C_003E4__this;

			private int _003Ci_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CPreparationShowZombie_003Ed__57(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct - original body referenced non-existent members
				// (LevelObject.fogDensity, ZombieBaseComponent, ZombieEntity.PlayIdle, GameUtils.ShuffleList
				// over reconstructed grid layout). Reduced to an empty coroutine.
				_003C_003E1__state = -1;
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CPreparationStart_003Ed__55 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public LevelAssetsManager _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CPreparationStart_003Ed__55(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct - original body referenced non-existent members
				// (UIManager, CameraManager preparation pan, PreparationManager guest setup,
				// SaveManager.guestDict). Reduced to an empty coroutine.
				_003C_003E1__state = -1;
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CStartWaveEvent_003Ed__74 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public ZombieWaveObject.ZombieWaveItem waveItem;

			public float startTime;

			public LevelAssetsManager _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CStartWaveEvent_003Ed__74(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct - original body referenced non-existent members
				// (TouniuManager.body, TouniuBehaviorUtils.ClearQueue over fabricated event fields,
				// ZombieWaveEntity.waveItemList, ZombieWaveItem.eventHandledCount, WaveEventItem cast).
				// Reduced to an empty coroutine.
				_003C_003E1__state = -1;
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[CompilerGenerated]
		private sealed class _003CWinGameCoroutine_003Ed__83 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public LevelAssetsManager _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CWinGameCoroutine_003Ed__83(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct - original body referenced non-existent members
				// (AreaManager.starA/starB, AudioManager win clips, UIManager.WinBox,
				// AreaStatic.WinLevelResult over fabricated difficulty pair). Kept the observable
				// state transition + difficulty verify.
				if (_003C_003E1__state != 0)
				{
					return false;
				}
				_003C_003E1__state = -1;
				LevelAssetsManager @this = _003C_003E4__this;
				if (@this != null)
				{
					@this.currentStage = GameStage.GameEnd;
					AreaStatic.VerifyDifficulty();
				}
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("当前游戏阶段")]
		public GameStage currentStage;

		[Tooltip("游戏时间")]
		private float _inGameTime;

		[Tooltip("是否暂停游戏时间")]
		private bool _isPauseTime;

		[HideInInspector]
		public bool isLoadGame;

		private bool _isStartButton;

		[Tooltip("是否禁用伤害")]
		private bool _isDisableDamage;

		[HideInInspector]
		public List<ZombieWaveEntity> waveRouteList;

		[Tooltip("僵尸波次")]
		public ZombieWaveEntity zombieWave;

		[Tooltip("当前Boss僵尸")]
		public ZombieEntity currentBoss;

		private bool _isBossZombieAppear;

		[HideInInspector]
		public List<float> zombieWaveStartTimeList;

		[HideInInspector]
		public int currentWaveIndex;

		private Coroutine _currentWaveCoroutine;

		private Coroutine _currentWaveEventCoroutine;

		[Tooltip("Boss音乐")]
		public AudioClip bossMusic;

		[Tooltip("通关后音乐")]
		public AudioClip winMusic;

		[Tooltip("普通通关音效")]
		public AudioClip winGameSound1;

		[Tooltip("三色通关音效")]
		public AudioClip winGameSound2;

		[Tooltip("准备开始音效")]
		public AudioClip readySound;

		[Tooltip("僵尸闲聊音效")]
		public List<AudioClip> zombieChatSound;

		[Tooltip("一大波僵尸音效")]
		public AudioClip bigWaveSound;

		[Tooltip("最后一波僵尸音效")]
		public AudioClip lastWaveSound;

		[Tooltip("波次到来音效")]
		public AudioClip inWaveSound;

		[Tooltip("游戏结束音效")]
		public AudioClip gameOverSound;

		[Tooltip("左上角坐标")]
		public Vector2 leftUpPosition;

		[Tooltip("右下角坐标")]
		public Vector2 rightDownPosition;

		[HideInInspector]
		public LevelObject levelObject;

		[HideInInspector]
		public BackgroundEntity backgroundEntity;

		private bool _isSpeedUp;

		public Action OnPreparationAction;

		public Action OnStartGameAction;

		public Action<ZombieWaveObject.ZombieWaveItem, float> OnEnterWaveAction;

		public Action<ZombieEntity> OnBossZombieAppearAction;

		public Action<ZombieEntity> OnBossZombieDeathAction;

		private readonly List<ZombieEntity> _preparationZombieList;

		private List<LawnMowerEntity> _lawnMowerList;

		private List<RowLandEntity> _nextRowList;

		public float InGameTime
		{
			get
			{
				return _inGameTime;
			}
			set
			{
				// Time is frozen in random mode.
				if (!AreaStatic.IsRandomMode())
				{
					_inGameTime = value;
				}
			}
		}

		public bool IsPauseTime
		{
			get
			{
				return _isPauseTime;
			}
			set
			{
				if (!AreaStatic.IsRandomMode())
				{
					_isPauseTime = value;
				}
			}
		}

		public bool IsDisableDamage
		{
			get
			{
				return _isDisableDamage;
			}
			set
			{
				_isDisableDamage = value;
			}
		}

		public static LevelAssetsManager Instance { get; private set; }

		private void Awake()
		{
			// TODO: reconstruct - original body referenced non-existent members
			// (GameManager.levelObject, LevelObject.id/.chapter/.level, GameManager.GameMode).
			// Reduced to just assigning the singleton so other systems can resolve Instance.
			Instance = this;
		}

		private void Start()
		{
			// TODO: reconstruct - original body referenced non-existent managers/members
			// (SettingsManager.isSpeedUp, AreaManager.starA/starB). Reduced to a safe no-op that
			// still performs the wave-object load side effects that only touch real members.
		}

		private void Update()
		{
			// TODO: reconstruct - original body referenced non-existent members
			// (ZombieWaveEntity.waveItemList, UIManager.GameMainBox). Reduced to advancing the
			// in-game timer only, guarded by the existing stage/pause flags.
			if (currentStage != GameStage.InGame)
			{
				return;
			}
			if (_isPauseTime)
			{
				return;
			}
			_inGameTime += Time.deltaTime;
		}

		public void StartLevel(int type)
		{
			// TODO: reconstruct - original body referenced non-existent members
			// (GameManager.RecordFrame, UIManager.GameMainBox). Kept the branches that only touch
			// real members (coroutine kick-offs, card-save reload via CardSlotManager.AddCard).
			if (_isStartButton)
			{
				return;
			}
			_isStartButton = true;
			if (type == 1)
			{
				StartCoroutine(PreparationStart());
			}
			else if (type == 2)
			{
				List<int> cards = ES3.Load<List<int>>("CardSave", AreaStatic.GetRecordSettings()); // TODO: key uncertain
				if (cards != null)
				{
					foreach (int cardId in cards)
					{
						if (CardSlotManager.Instance == null)
						{
							return;
						}
						CardSlotManager.Instance.AddCard(cardId);
					}
				}
				_isSpeedUp = true;
				OnPreparationAction?.Invoke();
				StartCoroutine(PreparationEnd());
			}
			else if (type == 3)
			{
				isLoadGame = true;
				StartCoroutine(LoadLevel());
			}
		}

		private void LoadZombieWaveObject()
		{
			// TODO: reconstruct - original body referenced non-existent members
			// (GameManager.GameMode, LevelObject.chapter/.level, ZombieWaveEntity.waveItemList,
			// ZombieWaveItem.waveTime/.intervalTime). Reduced to a safe no-op.
		}

		private void TrySaveAvailable()
		{
			// probes whether the two save keys exist (side effects only; results unused here)
			ES3.KeyExists("CardSave", AreaStatic.GetRecordSettings());  // TODO: key uncertain
			ES3.KeyExists("FrameSave", AreaStatic.GetRecordSettings()); // TODO: key uncertain
		}

		[IteratorStateMachine(typeof(_003CPreparationStart_003Ed__55))]
		public IEnumerator PreparationStart()
		{
			return new _003CPreparationStart_003Ed__55(0)
			{
				_003C_003E4__this = this
			};
		}

		public void PreparationHideLawnMower()
		{
			// TODO: reconstruct - original body referenced non-existent members
			// (GameManager.lawnMowerComparer/CompareLawnMower, LawnMowerEntity.spriteRoot/.mainSprite).
			// Reduced to gathering the lawn-mower list, which only touches real members.
			_lawnMowerList = UnityEngine.Object.FindObjectsOfType<LawnMowerEntity>().ToList();
		}

		[IteratorStateMachine(typeof(_003CPreparationShowZombie_003Ed__57))]
		private IEnumerator PreparationShowZombie()
		{
			return new _003CPreparationShowZombie_003Ed__57(0)
			{
				_003C_003E4__this = this
			};
		}

		private List<Vector2> GenerateCells(int cols, int rows, Vector2 leftUp, Vector2 rightDown)
		{
			List<Vector2> result = new List<Vector2>();
			for (int r = 0; r < rows; r++)
			{
				for (int c = 0; c < cols; c++)
				{
					float x = c * ((rightDown.x - leftUp.x) / cols) + leftUp.x;
					float y = r * ((rightDown.y - leftUp.y) / rows) + leftUp.y;
					result.Add(new Vector2(x, y));
				}
			}
			return result;
		}

		[IteratorStateMachine(typeof(_003CPreparationEnd_003Ed__59))]
		public IEnumerator PreparationEnd()
		{
			return new _003CPreparationEnd_003Ed__59(0)
			{
				_003C_003E4__this = this
			};
		}

		[IteratorStateMachine(typeof(_003CLoadLevel_003Ed__60))]
		private IEnumerator LoadLevel()
		{
			return new _003CLoadLevel_003Ed__60(0)
			{
				_003C_003E4__this = this
			};
		}

		[IteratorStateMachine(typeof(_003CInGameStart_003Ed__61))]
		public IEnumerator InGameStart()
		{
			return new _003CInGameStart_003Ed__61(0)
			{
				_003C_003E4__this = this
			};
		}

		public void ChangeWaveRoute(int index)
		{
			if (waveRouteList == null)
			{
				return;
			}
			if (index < waveRouteList.Count)
			{
				ZombieWaveEntity route = waveRouteList[index];
				if (zombieWave != route)
				{
					ZombieWaveEntity old = zombieWave;
					zombieWave = route;
					if (currentStage == GameStage.InGame)
					{
						ClearAfterBehavior(old);
						if (_currentWaveCoroutine != null)
						{
							StopCoroutine(_currentWaveCoroutine);
							if (_currentWaveEventCoroutine != null)
							{
								StopCoroutine(_currentWaveEventCoroutine);
							}
						}
						EnterWave(currentWaveIndex, GetCurrentWaveTime());
					}
				}
			}
		}

		private void SetZombieWave(ZombieWaveEntity zombieWaveEntity)
		{
			ZombieWaveEntity old = zombieWave;
			zombieWave = zombieWaveEntity;
			if (currentStage == GameStage.InGame)
			{
				ClearAfterBehavior(old);
				if (_currentWaveCoroutine != null)
				{
					StopCoroutine(_currentWaveCoroutine);
					if (_currentWaveEventCoroutine != null)
					{
						StopCoroutine(_currentWaveEventCoroutine);
					}
				}
				EnterWave(currentWaveIndex, GetCurrentWaveTime());
			}
		}

		private void ClearAfterBehavior(ZombieWaveEntity oldZombieWave)
		{
			// TODO: reconstruct - original body referenced non-existent members
			// (TouniuManager.body/.behaviorList). Reduced to a safe no-op.
		}

		private float GetCurrentWaveTime()
		{
			float result = 0f;
			float now = _inGameTime;
			if (zombieWaveStartTimeList == null)
			{
				return default; // TODO: reconstruct (null-list branch throws in original)
			}
			foreach (float startTime in zombieWaveStartTimeList)
			{
				if (now < startTime)
				{
					break;
				}
				result = now - startTime;
			}
			return result;
		}

		public void EnterWave(int index, float startTime = 0f)
		{
			if (index == -1)
			{
				return;
			}
			float clamped = System.Math.Max(startTime, 0f);
			_currentWaveCoroutine = StartCoroutine(EnterWaveCoroutine(index, clamped));
		}

		[IteratorStateMachine(typeof(_003CEnterWaveCoroutine_003Ed__67))]
		private IEnumerator EnterWaveCoroutine(int index, float startTime)
		{
			return new _003CEnterWaveCoroutine_003Ed__67(0)
			{
				_003C_003E4__this = this,
				index = index,
				startTime = startTime
			};
		}

		private void BossDeathHandle()
		{
			// TODO: reconstruct - original body referenced non-existent members
			// (LevelObject.bgm, UIManager.WaveBox). Kept the delegate + state cleanup that only
			// touches real members.
			OnBossZombieDeathAction?.Invoke(currentBoss);
			currentBoss = null;
		}

		[IteratorStateMachine(typeof(_003CBigWaveHandle_003Ed__69))]
		private IEnumerator BigWaveHandle(ZombieWaveObject.ZombieWaveItem zombieWaveItem)
		{
			return new _003CBigWaveHandle_003Ed__69(0)
			{
				_003C_003E4__this = this,
				zombieWaveItem = zombieWaveItem
			};
		}

		private void RefreshNextRowList()
		{
			// TODO: reconstruct - original body referenced non-existent members
			// (SoilManager.RowLandDict). Reduced to clearing the cached list.
			if (_nextRowList == null)
			{
				return;
			}
			_nextRowList.Clear();
		}

		public RowLandEntity GetNextRow(int zombieId)
		{
			// TODO: reconstruct - original body referenced non-existent members
			// (SaveManager.zombieDict, ZombieEntity.placeableRowIds, RowLandEntity.index).
			// Reduced to a safe stub.
			return default;
		}

		public void StopWave()
		{
			if (_currentWaveCoroutine != null)
			{
				StopCoroutine(_currentWaveCoroutine);
				if (_currentWaveEventCoroutine != null)
				{
					StopCoroutine(_currentWaveEventCoroutine);
				}
			}
		}

		[IteratorStateMachine(typeof(_003CStartWaveEvent_003Ed__74))]
		public IEnumerator StartWaveEvent(ZombieWaveObject.ZombieWaveItem waveItem, float startTime)
		{
			return new _003CStartWaveEvent_003Ed__74(0)
			{
				_003C_003E4__this = this,
				waveItem = waveItem,
				startTime = startTime
			};
		}

		private float EventWait(ZombieWaveObject.ZombieWaveItem waveItem, ZombieWaveObject.WaveEventItem eventItem)
		{
			// TODO: reconstruct - original body referenced non-existent type/members
			// (TouniuBehavior, WaveEventItem.waitTime/.isStartHandle/.isEndHandle). Reduced to a stub.
			return default;
		}

		private float EventHandle(ZombieWaveObject.ZombieWaveItem waveItem, ZombieWaveObject.WaveEventItem eventItem)
		{
			// TODO: reconstruct - original body referenced non-existent type/members
			// (TouniuBehavior, WaveEventItem.handleId/.isStartHandle/.isEndHandle). Reduced to a stub.
			return default;
		}

		private float EventTouniuSay(ZombieWaveObject.ZombieWaveItem waveItem, ZombieWaveObject.WaveEventItem eventItem)
		{
			// TODO: reconstruct - original body referenced non-existent type/members
			// (TouniuBehavior, WaveEventItem.sayId/.sayGroup/.isStartHandle/.isEndHandle and its
			// sayData/audioClip chain). Reduced to a stub.
			return default;
		}

		private float EventGuestSay(ZombieWaveObject.ZombieWaveItem waveItem, ZombieWaveObject.WaveEventItem eventItem)
		{
			// TODO: reconstruct - original body referenced non-existent type/members
			// (TouniuManager.guestBody, TouniuBehavior, WaveEventItem.sayId/.sayGroup and its
			// sayData/audioClip chain). Reduced to a stub.
			return default;
		}

		private void OnBehaviorStartHandle(ZombieWaveObject.ZombieWaveItem waveItem)
		{
			if (waveItem == null)
			{
				return;
			}
			waveItem.startEventCount++;
		}

		private void OnBehaviorEndHandle(ZombieWaveObject.ZombieWaveItem waveItem)
		{
			if (waveItem == null)
			{
				return;
			}
			waveItem.endEventCount++;
		}

		public HashSet<int> GetAllZombieIdSet(bool isContainBoss = true)
		{
			HashSet<int> set = new HashSet<int>();
			if (zombieWave == null || zombieWave.waveList == null)
			{
				return default; // TODO: reconstruct (null branch threw in original)
			}
			foreach (ZombieWaveObject.ZombieWaveItem item in zombieWave.waveList)
			{
				if (item == null)
				{
					break;
				}
				if (item.zombieIdList == null)
				{
					return default; // TODO: reconstruct
				}
				foreach (int zombieId in item.zombieIdList)
				{
					// boss ids are >= 1001; skip them unless requested
					if (isContainBoss || zombieId < 1001)
					{
						set.Add(zombieId);
					}
				}
			}
			return set;
		}

		public void WinGame()
		{
			StartCoroutine(WinGameCoroutine());
		}

		[IteratorStateMachine(typeof(_003CWinGameCoroutine_003Ed__83))]
		private IEnumerator WinGameCoroutine()
		{
			return new _003CWinGameCoroutine_003Ed__83(0)
			{
				_003C_003E4__this = this
			};
		}

		public void LoseGame()
		{
			StartCoroutine(LoseGameCoroutine());
		}

		[IteratorStateMachine(typeof(_003CLoseGameCoroutine_003Ed__85))]
		private IEnumerator LoseGameCoroutine()
		{
			return new _003CLoseGameCoroutine_003Ed__85(0)
			{
				_003C_003E4__this = this
			};
		}

		public void CheatContinueGame()
		{
			// TODO: reconstruct - original body referenced non-existent members
			// (ZombieManager.zombieList, ZombieEntity.Die, UIManager boxes, LoseBoxEntity,
			// BackgroundEntity.rowCount, CardEntity.cooldownComp, CardSlotManager.hammerCard,
			// LandManager.AddLawnMower() no-arg overload). Reduced to the observable state reset that
			// only touches real members.
			if (Instance != null)
			{
				Instance.currentStage = GameStage.InGame;
			}
		}

		public void ForcedSetInGameTime(float time)
		{
			_inGameTime = time;
		}
	}
}
