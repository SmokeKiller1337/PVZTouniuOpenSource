using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Audio.Manager;
using DG.Tweening;
using Game.Manager;
using Game.Util;
using Land.Entity;
using Level.Entity;
using Level.Enum;
using Level.Object;
using Level.Static;
using Level.Util;
using Touniu.Util;
using UnityEngine;
using Zombie.Entity;

namespace Level.Manager
{
	public class LevelAssetsManager : MonoBehaviour
	{
		[Tooltip("当前游戏阶段")]
		public GameStage currentStage;

		[Tooltip("游戏时间")]
		private float _inGameTime;

		[Tooltip("是否暂停游戏时间")]
		private bool _isPauseTime;

		[HideInInspector]
		public bool isLoadGame;

		private bool _isStartButton;

		[Tooltip("是否禁用伤害")]
		private bool _isDisableDamage;

		[HideInInspector]
		public List<ZombieWaveEntity> waveRouteList;

		[Tooltip("僵尸波次")]
		public ZombieWaveEntity zombieWave;

		[Tooltip("当前Boss僵尸")]
		public ZombieEntity currentBoss;

		private bool _isBossZombieAppear;

		[HideInInspector]
		public List<float> zombieWaveStartTimeList;

		[HideInInspector]
		public int currentWaveIndex;

		private Coroutine _currentWaveCoroutine;

		private Coroutine _currentWaveEventCoroutine;

		[Tooltip("Boss音乐")]
		public AudioClip bossMusic;

		[Tooltip("通关后音乐")]
		public AudioClip winMusic;

		[Tooltip("普通通关音效")]
		public AudioClip winGameSound1;

		[Tooltip("三色通关音效")]
		public AudioClip winGameSound2;

		[Tooltip("准备开始音效")]
		public AudioClip readySound;

		[Tooltip("僵尸闲聊音效")]
		public List<AudioClip> zombieChatSound;

		[Tooltip("一大波僵尸音效")]
		public AudioClip bigWaveSound;

		[Tooltip("最后一波僵尸音效")]
		public AudioClip lastWaveSound;

		[Tooltip("波次到来音效")]
		public AudioClip inWaveSound;

		[Tooltip("游戏结束音效")]
		public AudioClip gameOverSound;

		[Tooltip("左上角坐标")]
		public Vector2 leftUpPosition;

		[Tooltip("右下角坐标")]
		public Vector2 rightDownPosition;

		[HideInInspector]
		public LevelObject levelObject;

		[HideInInspector]
		public BackgroundEntity backgroundEntity;

		private bool _isSpeedUp;

		public Action OnPreparationAction;

		public Action OnStartGameAction;

		public Action<ZombieWaveObject.ZombieWaveItem, float> OnEnterWaveAction;

		public Action<ZombieEntity> OnBossZombieAppearAction;

		public Action<ZombieEntity> OnBossZombieDeathAction;

		private readonly List<ZombieEntity> _preparationZombieList;

		private List<LawnMowerEntity> _lawnMowerList;

		private List<RowLandEntity> _nextRowList;

		public float InGameTime
		{
			get
			{
				return _inGameTime;
			}
			set
			{
				// Time is frozen in random mode.
				if (!AreaStatic.IsRandomMode())
				{
					_inGameTime = value;
				}
			}
		}

		public bool IsPauseTime
		{
			get
			{
				return _isPauseTime;
			}
			set
			{
				if (!AreaStatic.IsRandomMode())
				{
					_isPauseTime = value;
				}
			}
		}

		public bool IsDisableDamage
		{
			get
			{
				return _isDisableDamage;
			}
			set
			{
				_isDisableDamage = value;
			}
		}

		public static LevelAssetsManager Instance { get; private set; }

		private void Awake()
		{
			Instance = this;
		}

		private void Start()
		{
		}

		private void Update()
		{
			if (currentStage != GameStage.InGame)
			{
				return;
			}
			if (_isPauseTime)
			{
				return;
			}
			_inGameTime += Time.deltaTime;
		}

		public void StartLevel(int type)
		{
			if (_isStartButton)
			{
				return;
			}
			_isStartButton = true;
			if (type == 1)
			{
				StartCoroutine(PreparationStart());
			}
			else if (type == 2)
			{
				List<int> cards = ES3.Load<List<int>>("CardSave", AreaStatic.GetRecordSettings()); // TODO: key uncertain
				if (cards != null)
				{
					foreach (int cardId in cards)
					{
						if (CardSlotManager.Instance == null)
						{
							return;
						}
						CardSlotManager.Instance.AddCard(cardId);
					}
				}
				_isSpeedUp = true;
				OnPreparationAction?.Invoke();
				StartCoroutine(PreparationEnd());
			}
			else if (type == 3)
			{
				isLoadGame = true;
				StartCoroutine(LoadLevel());
			}
		}

		private void LoadZombieWaveObject()
		{
		}

		private void TrySaveAvailable()
		{
			// probes whether the two save keys exist (side effects only; results unused here)
			ES3.KeyExists("CardSave", AreaStatic.GetRecordSettings());  // TODO: key uncertain
			ES3.KeyExists("FrameSave", AreaStatic.GetRecordSettings()); // TODO: key uncertain
		}

		public IEnumerator PreparationStart()
		{
			yield break;
		}

		public void PreparationHideLawnMower()
		{
			_lawnMowerList = UnityEngine.Object.FindObjectsOfType<LawnMowerEntity>().ToList();
		}

		private IEnumerator PreparationShowZombie()
		{
			yield break;
		}

		private List<Vector2> GenerateCells(int cols, int rows, Vector2 leftUp, Vector2 rightDown)
		{
			List<Vector2> result = new List<Vector2>();
			for (int r = 0; r < rows; r++)
			{
				for (int c = 0; c < cols; c++)
				{
					float x = c * ((rightDown.x - leftUp.x) / cols) + leftUp.x;
					float y = r * ((rightDown.y - leftUp.y) / rows) + leftUp.y;
					result.Add(new Vector2(x, y));
				}
			}
			return result;
		}

		public IEnumerator PreparationEnd()
		{
			yield break;
		}

		private IEnumerator LoadLevel()
		{
			yield break;
		}

		public IEnumerator InGameStart()
		{
			yield break;
		}

		public void ChangeWaveRoute(int index)
		{
			if (waveRouteList == null)
			{
				return;
			}
			if (index < waveRouteList.Count)
			{
				ZombieWaveEntity route = waveRouteList[index];
				if (zombieWave != route)
				{
					ZombieWaveEntity old = zombieWave;
					zombieWave = route;
					if (currentStage == GameStage.InGame)
					{
						ClearAfterBehavior(old);
						if (_currentWaveCoroutine != null)
						{
							StopCoroutine(_currentWaveCoroutine);
							if (_currentWaveEventCoroutine != null)
							{
								StopCoroutine(_currentWaveEventCoroutine);
							}
						}
						EnterWave(currentWaveIndex, GetCurrentWaveTime());
					}
				}
			}
		}

		private void SetZombieWave(ZombieWaveEntity zombieWaveEntity)
		{
			ZombieWaveEntity old = zombieWave;
			zombieWave = zombieWaveEntity;
			if (currentStage == GameStage.InGame)
			{
				ClearAfterBehavior(old);
				if (_currentWaveCoroutine != null)
				{
					StopCoroutine(_currentWaveCoroutine);
					if (_currentWaveEventCoroutine != null)
					{
						StopCoroutine(_currentWaveEventCoroutine);
					}
				}
				EnterWave(currentWaveIndex, GetCurrentWaveTime());
			}
		}

		private void ClearAfterBehavior(ZombieWaveEntity oldZombieWave)
		{
		}

		private float GetCurrentWaveTime()
		{
			float result = 0f;
			float now = _inGameTime;
			if (zombieWaveStartTimeList == null)
			{
				return default;
			}
			foreach (float startTime in zombieWaveStartTimeList)
			{
				if (now < startTime)
				{
					break;
				}
				result = now - startTime;
			}
			return result;
		}

		public void EnterWave(int index, float startTime = 0f)
		{
			if (index == -1)
			{
				return;
			}
			float clamped = System.Math.Max(startTime, 0f);
			_currentWaveCoroutine = StartCoroutine(EnterWaveCoroutine(index, clamped));
		}

		private IEnumerator EnterWaveCoroutine(int index, float startTime)
		{
			yield break;
		}

		private void BossDeathHandle()
		{
			OnBossZombieDeathAction?.Invoke(currentBoss);
			currentBoss = null;
		}

		private IEnumerator BigWaveHandle(ZombieWaveObject.ZombieWaveItem zombieWaveItem)
		{
			yield break;
		}

		private void RefreshNextRowList()
		{
			if (_nextRowList == null)
			{
				return;
			}
			_nextRowList.Clear();
		}

		public RowLandEntity GetNextRow(int zombieId)
		{
			return default;
		}

		public void StopWave()
		{
			if (_currentWaveCoroutine != null)
			{
				StopCoroutine(_currentWaveCoroutine);
				if (_currentWaveEventCoroutine != null)
				{
					StopCoroutine(_currentWaveEventCoroutine);
				}
			}
		}

		public IEnumerator StartWaveEvent(ZombieWaveObject.ZombieWaveItem waveItem, float startTime)
		{
			yield break;
		}

		private float EventWait(ZombieWaveObject.ZombieWaveItem waveItem, ZombieWaveObject.WaveEventItem eventItem)
		{
			return default;
		}

		private float EventHandle(ZombieWaveObject.ZombieWaveItem waveItem, ZombieWaveObject.WaveEventItem eventItem)
		{
			return default;
		}

		private float EventTouniuSay(ZombieWaveObject.ZombieWaveItem waveItem, ZombieWaveObject.WaveEventItem eventItem)
		{
			return default;
		}

		private float EventGuestSay(ZombieWaveObject.ZombieWaveItem waveItem, ZombieWaveObject.WaveEventItem eventItem)
		{
			return default;
		}

		private void OnBehaviorStartHandle(ZombieWaveObject.ZombieWaveItem waveItem)
		{
			if (waveItem == null)
			{
				return;
			}
			waveItem.startEventCount++;
		}

		private void OnBehaviorEndHandle(ZombieWaveObject.ZombieWaveItem waveItem)
		{
			if (waveItem == null)
			{
				return;
			}
			waveItem.endEventCount++;
		}

		public HashSet<int> GetAllZombieIdSet(bool isContainBoss = true)
		{
			HashSet<int> set = new HashSet<int>();
			if (zombieWave == null || zombieWave.waveList == null)
			{
				return default;
			}
			foreach (ZombieWaveObject.ZombieWaveItem item in zombieWave.waveList)
			{
				if (item == null)
				{
					break;
				}
				if (item.zombieIdList == null)
				{
					return default;
				}
				foreach (int zombieId in item.zombieIdList)
				{
					// boss ids are >= 1001; skip them unless requested
					if (isContainBoss || zombieId < 1001)
					{
						set.Add(zombieId);
					}
				}
			}
			return set;
		}

		public void WinGame()
		{
			StartCoroutine(WinGameCoroutine());
		}

		private IEnumerator WinGameCoroutine()
		{
			// 结算胜利：进入结束阶段并校验难度
			currentStage = GameStage.GameEnd;
			AreaStatic.VerifyDifficulty();
			yield break;
		}

		public void LoseGame()
		{
			StartCoroutine(LoseGameCoroutine());
		}

		private IEnumerator LoseGameCoroutine()
		{
			// 结算失败：进入结束阶段并校验难度
			currentStage = GameStage.GameEnd;
			AreaStatic.VerifyDifficulty();
			yield break;
		}

		public void CheatContinueGame()
		{
			if (Instance != null)
			{
				Instance.currentStage = GameStage.InGame;
			}
		}

		public void ForcedSetInGameTime(float time)
		{
			_inGameTime = time;
		}
	}
}
