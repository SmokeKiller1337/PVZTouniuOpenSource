namespace Level.Manager.Data
{
	public class LevelTestDataManager : LevelDataManager
	{
		public new static LevelTestDataManager Instance => null;

		private void Start()
		{
		}

		private void Update()
		{
		}
	}
}
