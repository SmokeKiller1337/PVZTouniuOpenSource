using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Building.Entity;
using FairyGUI;
using Land.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Level.Manager.Data.Area
{
	public class Level46DataManager : LevelDataManager
	{
		[CompilerGenerated]
		private sealed class _003CAddDiamond_003Ed__28 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level46DataManager _003C_003E4__this;

			public int value;

			private Vector3 _003Cposition_003E5__2;

			private int _003Cnumber_003E5__3;

			private int _003Ci_003E5__4;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CAddDiamond_003Ed__28(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CAddHammer_003Ed__29 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level46DataManager _003C_003E4__this;

			public int value;

			private Vector3 _003Cposition_003E5__2;

			private int _003Cnumber_003E5__3;

			private int _003Ci_003E5__4;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CAddHammer_003Ed__29(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CAddPlant300ValueCoroutine_003Ed__32 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level46DataManager _003C_003E4__this;

			public Vector2 startPosition;

			public int value;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CAddPlant300ValueCoroutine_003Ed__32(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CAddSun_003Ed__27 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level46DataManager _003C_003E4__this;

			public int value;

			private Vector3 _003Cposition_003E5__2;

			private int _003Cnumber_003E5__3;

			private int _003Ci_003E5__4;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CAddSun_003Ed__27(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CAddValueEvent_003Ed__34 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level46DataManager _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CAddValueEvent_003Ed__34(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CCheckLevelUpTrophy_003Ed__37 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level46DataManager _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CCheckLevelUpTrophy_003Ed__37(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CExplosionAttack_003Ed__26 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level46DataManager _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CExplosionAttack_003Ed__26(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CLoadLevelCoroutine_003Ed__19 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level46DataManager _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CLoadLevelCoroutine_003Ed__19(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CRefreshPot_003Ed__25 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level46DataManager _003C_003E4__this;

			private LandEntity _003ClandEntity_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CRefreshPot_003Ed__25(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[HideInInspector]
		public PotEntity potEntity;

		[Tooltip("罐子UI预制体")]
		public GameObject potUIPrefab;

		private GameObject _potUIObj;

		private GTextField _potTextField;

		[Tooltip("罐子价值")]
		public float potValue;

		[Tooltip("罐子价值上限")]
		public float potMaxValue;

		[Tooltip("是否升级罐子")]
		public bool isLevelUpPot;

		[Tooltip("是否保存了钻石")]
		public bool isDiamond;

		[Tooltip("是否说完罐子上限")]
		public bool isPotSay;

		[HideInInspector]
		public bool isLevelUpTrophy;

		private float _potSayTimer;

		public GComponent contentCom;

		public GButton startButton;

		private bool _isShowComponent;

		private bool _isPotEnd;

		public new static Level46DataManager Instance => null;

		public override void SaveLevel()
		{
		}

		public override void LoadLevel()
		{
		}

		[IteratorStateMachine(typeof(_003CLoadLevelCoroutine_003Ed__19))]
		private IEnumerator LoadLevelCoroutine()
		{
			return null;
		}

		public override void OnCreateGameMainUI()
		{
		}

		private void SetCardButton(GObject gObject, int cardId)
		{
		}

		private void Start()
		{
		}

		private void Update()
		{
		}

		public void PotRewardHandle()
		{
		}

		[IteratorStateMachine(typeof(_003CRefreshPot_003Ed__25))]
		private IEnumerator RefreshPot()
		{
			return null;
		}

		[IteratorStateMachine(typeof(_003CExplosionAttack_003Ed__26))]
		private IEnumerator ExplosionAttack()
		{
			return null;
		}

		[IteratorStateMachine(typeof(_003CAddSun_003Ed__27))]
		public IEnumerator AddSun(int value)
		{
			return null;
		}

		[IteratorStateMachine(typeof(_003CAddDiamond_003Ed__28))]
		public IEnumerator AddDiamond(int value)
		{
			return null;
		}

		[IteratorStateMachine(typeof(_003CAddHammer_003Ed__29))]
		public IEnumerator AddHammer(int value)
		{
			return null;
		}

		public void SetPotUI(PotEntity potEntity1)
		{
		}

		public void AddPlant300Value(Vector2 startPosition, int value = 0)
		{
		}

		[IteratorStateMachine(typeof(_003CAddPlant300ValueCoroutine_003Ed__32))]
		private IEnumerator AddPlant300ValueCoroutine(Vector2 startPosition, int value)
		{
			return null;
		}

		public void CheckPotSay()
		{
		}

		[IteratorStateMachine(typeof(_003CAddValueEvent_003Ed__34))]
		private IEnumerator AddValueEvent()
		{
			return null;
		}

		public void BreakWait()
		{
		}

		private void WaitBossCheck(ZombieEntity zombieEntity)
		{
		}

		[IteratorStateMachine(typeof(_003CCheckLevelUpTrophy_003Ed__37))]
		private IEnumerator CheckLevelUpTrophy()
		{
			return null;
		}

		public void AddPotValue(float value)
		{
		}

		public void SetPlant300Death()
		{
		}
	}
}
