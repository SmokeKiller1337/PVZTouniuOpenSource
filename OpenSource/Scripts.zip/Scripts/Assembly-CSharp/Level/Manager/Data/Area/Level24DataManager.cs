using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Plant.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Level.Manager.Data.Area
{
	public class Level24DataManager : LevelDataManager
	{
		[CompilerGenerated]
		private sealed class _003CBossTombstone_003Ed__12 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public ZombieEntity zombieEntity;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CBossTombstone_003Ed__12(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("购买数组数组")]
		public bool[] bayPlantArr;

		[Tooltip("通讯器变红次数")]
		public int redCount;

		[Tooltip("是否开局种了阵法")]
		public bool isStartPlant;

		[Tooltip("开局阵法植物")]
		public List<PlantEntity> startPlantList;

		[HideInInspector]
		public GameObject phoneObj;

		[HideInInspector]
		public float tombstoneTime;

		private float _tombstoneTimer;

		public new static Level24DataManager Instance => null;

		private void Start()
		{
		}

		private void Update()
		{
		}

		private void CreateTombstone()
		{
		}

		[IteratorStateMachine(typeof(_003CBossTombstone_003Ed__12))]
		private IEnumerator BossTombstone(ZombieEntity zombieEntity)
		{
			return null;
		}
	}
}
