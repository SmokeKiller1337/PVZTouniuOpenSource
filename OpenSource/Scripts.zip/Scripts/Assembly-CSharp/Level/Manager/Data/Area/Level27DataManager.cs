using UnityEngine;

namespace Level.Manager.Data.Area
{
	public class Level27DataManager : LevelDataManager
	{
		private float _startBossTimer;

		private float _startAddSpeedTimer;

		private bool _startBossEnd;

		private float _mode1StartTimer;

		private bool _mode1StartFlag;

		private float _mode1EndHomeTimer;

		private bool _mode1EndHomeFlag;

		public GameObject backgroundPrefab;

		public GameObject deathZombieLinePrefab;

		public new static Level26DataManager Instance => null;

		public override void LoadLevel()
		{
		}

		private void Start()
		{
		}

		private void Update()
		{
		}
	}
}
