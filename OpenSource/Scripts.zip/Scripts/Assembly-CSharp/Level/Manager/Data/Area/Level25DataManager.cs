namespace Level.Manager.Data.Area
{
	public class Level25DataManager : LevelDataManager
	{
		public bool isFirstHypnosis;

		public new static Level25DataManager Instance => null;

		private void Start()
		{
		}

		private void Update()
		{
		}
	}
}
