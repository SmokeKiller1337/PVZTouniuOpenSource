using UnityEngine;

namespace Level.Manager.Data.Area
{
	public class Level18DataManager : LevelDataManager
	{
		[Tooltip("开局借了推车")]
		public bool isStartLawn;

		[Tooltip("开局借了阳光")]
		public bool isStartSun;

		public new static Level18DataManager Instance => null;

		private void Start()
		{
		}

		private void Update()
		{
		}
	}
}
