using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Plant.Entity.Plant;
using UnityEngine;

namespace Level.Manager.Data.Area
{
	public class Level23DataManager : LevelDataManager
	{
		[CompilerGenerated]
		private sealed class _003CLoadLevelCoroutine_003Ed__10 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level23DataManager _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CLoadLevelCoroutine_003Ed__10(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("是否为铁桶")]
		public bool isTopic2;

		[Tooltip("是否为豌豆射手")]
		public bool isTopic3;

		[Tooltip("是否扣了3000阳光")]
		public bool isReduceSun;

		[Tooltip("正确答题次数")]
		public int correctNumber;

		[Tooltip("答题正确数组")]
		public bool[] correctFlagArr;

		[Tooltip("是否答题结束")]
		public bool isEndTopic;

		[Tooltip("变大的阳光菇集合")]
		public List<Plant100Entity> plant100List;

		public new static Level23DataManager Instance => null;

		public override void LoadLevel()
		{
		}

		[IteratorStateMachine(typeof(_003CLoadLevelCoroutine_003Ed__10))]
		private IEnumerator LoadLevelCoroutine()
		{
			return null;
		}

		private void Start()
		{
		}

		private void Update()
		{
		}
	}
}
