namespace Level.Manager.Data.Area
{
	public class Level19DataManager : LevelDataManager
	{
		public new static Level19DataManager Instance => null;

		private void Start()
		{
		}

		private void Update()
		{
		}
	}
}
