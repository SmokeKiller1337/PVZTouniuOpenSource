using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Plant.Entity;
using Touniu.Entity;
using Touniu.Entity.Body;
using UnityEngine;

namespace Level.Manager.Data.Area
{
	public class Level31DataManager : LevelDataManager
	{
		[CompilerGenerated]
		private sealed class _003CLoadLevelCoroutine_003Ed__14 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level31DataManager _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CLoadLevelCoroutine_003Ed__14(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CStartTouniu_003Ed__17 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level31DataManager _003C_003E4__this;

			private TouniuSayEntity _003CtouniuSayEntity_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CStartTouniu_003Ed__17(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("头牛遮罩")]
		public GameObject touniuMaskPrefab;

		[HideInInspector]
		public GameObject touniuMaskObj;

		[HideInInspector]
		public GameObject touniuCloneMaskObj;

		[HideInInspector]
		public TouniuBaseBody touniuClone;

		[Tooltip("头羊持续给阳光")]
		public bool isAddSun;

		[Tooltip("给阳光间隔时间")]
		public float addSunTime;

		[Tooltip("给阳光价值")]
		public int sunValue;

		private float _addSunTimer;

		[Tooltip("种植的免费睡莲集合")]
		public List<PlantEntity> free170PlantList;

		[Tooltip("免费睡莲数量记录")]
		public int free170PlantNumber;

		private bool _isStartTouniu;

		public new static Level31DataManager Instance => null;

		public override void LoadLevel()
		{
		}

		[IteratorStateMachine(typeof(_003CLoadLevelCoroutine_003Ed__14))]
		private IEnumerator LoadLevelCoroutine()
		{
			return null;
		}

		private void Start()
		{
		}

		private void Update()
		{
		}

		[IteratorStateMachine(typeof(_003CStartTouniu_003Ed__17))]
		private IEnumerator StartTouniu()
		{
			return null;
		}

		public void TouniuCloneExitWater()
		{
		}

		public void TouniuCloneEnterWater()
		{
		}

		public void PlaceFree170(PlantEntity plantEntity)
		{
		}
	}
}
