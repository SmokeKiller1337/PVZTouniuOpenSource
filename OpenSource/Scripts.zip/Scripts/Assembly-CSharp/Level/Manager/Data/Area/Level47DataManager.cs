using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Land.Entity;
using UnityEngine;

namespace Level.Manager.Data.Area
{
	public class Level47DataManager : LevelDataManager
	{
		[CompilerGenerated]
		private sealed class _003CLoadLevelCoroutine_003Ed__12 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level47DataManager _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CLoadLevelCoroutine_003Ed__12(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("标题地雷预制体")]
		public GameObject markMinePrefab;

		public Dictionary<int, GameObject> markMineObjDic;

		[Tooltip("是否种植爆炸")]
		public bool isPlantExplode;

		[Tooltip("铲除地雷次数")]
		public int shovelMineNumber;

		[Tooltip("地雷音频")]
		public AudioClip mineSound;

		private int[] _triggerTimes;

		private int _mineSoundCurrentIndex;

		public int[,] mineGrid;

		private const int Rows = 6;

		private const int Cols = 9;

		public new static Level47DataManager Instance => null;

		public override void SaveLevel()
		{
		}

		public override void LoadLevel()
		{
		}

		[IteratorStateMachine(typeof(_003CLoadLevelCoroutine_003Ed__12))]
		private IEnumerator LoadLevelCoroutine()
		{
			return null;
		}

		private void Start()
		{
		}

		private void OnStartGameHandle()
		{
		}

		private void Update()
		{
		}

		private void InitializeMineGrid()
		{
		}

		public void MarkMine(LandEntity landEntity, int col)
		{
		}

		public void UpdateMine()
		{
		}

		public bool IsHasMine(int row, int col)
		{
			return false;
		}

		public void MineExplosion(int row, int col, float radius = 2.2f, float effectScale = 1f)
		{
		}

		public LandEntity GetRandomMine()
		{
			return null;
		}

		public static string GridToString(int[,] mineGrid)
		{
			return null;
		}

		public static int[,] StringToGrid(string str)
		{
			return null;
		}
	}
}
