using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Game.Entity;
using Land.Entity;
using Plant.Entity;
using UnityEngine;

namespace Level.Manager.Data.Area
{
	public class Level26DataManager : LevelDataManager
	{
		[CompilerGenerated]
		private sealed class _003CLoadLevelCoroutine_003Ed__13 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level26DataManager _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CLoadLevelCoroutine_003Ed__13(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("爆炸效果")]
		public EffectEntity explosionEffect;

		public List<LandEntity> tombstoneLandList;

		public int sunValue;

		public CardEntity cardEntity1;

		public CardEntity cardEntity2;

		public CardEntity cardEntity3;

		public bool blueLeave;

		public int touniuBackNumber;

		private float _checkTimer;

		private bool _isCheckFlinch;

		public new static Level26DataManager Instance => null;

		public override void LoadLevel()
		{
		}

		[IteratorStateMachine(typeof(_003CLoadLevelCoroutine_003Ed__13))]
		private IEnumerator LoadLevelCoroutine()
		{
			return null;
		}

		private void Start()
		{
		}

		private void Update()
		{
		}

		public void TouniuExit()
		{
		}

		public static void LevelUpPlant140(PlantEntity plantEntity)
		{
		}

		public void LevelUpPlant140Error(PlantEntity plant)
		{
		}
	}
}
