using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Plant.Entity;
using UnityEngine;

namespace Level.Manager.Data.Area
{
	public class Level32DataManager : LevelDataManager
	{
		[CompilerGenerated]
		private sealed class _003CLoadLevelCoroutine_003Ed__11 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CLoadLevelCoroutine_003Ed__11(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CSetDefaultLawnCoroutine_003Ed__16 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CSetDefaultLawnCoroutine_003Ed__16(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("是否开启窝瓜奖励系统")]
		public bool isOpenReward;

		[Tooltip("窝瓜系统成功次数")]
		public int successCount;

		[Tooltip("窝瓜系统阳光值")]
		public int successSunValue;

		[Tooltip("减少冷却奖励")]
		public bool isRewardCooldown;

		[Tooltip("攻击力奖励")]
		public bool isRewardAttack;

		[Tooltip("钻石奖励")]
		public bool isRewardDiamond;

		[Tooltip("头牛是否拿着锤子")]
		public bool isTouniuHammer;

		[Tooltip("淡蓝卡牌")]
		public CardEntity targetCardEntity;

		public new static Level32DataManager Instance => null;

		public override void LoadLevel()
		{
		}

		[IteratorStateMachine(typeof(_003CLoadLevelCoroutine_003Ed__11))]
		private IEnumerator LoadLevelCoroutine()
		{
			return null;
		}

		private void Start()
		{
		}

		private void Update()
		{
		}

		public static void OpenReward()
		{
		}

		public void SetDefaultLawn()
		{
		}

		[IteratorStateMachine(typeof(_003CSetDefaultLawnCoroutine_003Ed__16))]
		public IEnumerator SetDefaultLawnCoroutine()
		{
			return null;
		}
	}
}
