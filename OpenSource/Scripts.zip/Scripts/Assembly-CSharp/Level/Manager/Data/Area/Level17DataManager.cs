using UnityEngine;

namespace Level.Manager.Data.Area
{
	public class Level17DataManager : LevelDataManager
	{
		[Tooltip("开局借了阳光")]
		public bool isStartSun;

		public new static Level17DataManager Instance => null;

		private void Start()
		{
		}

		private void Update()
		{
		}
	}
}
