using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using FairyGUI;
using Land.Entity;
using Plant.Entity;
using Touniu.Entity.Say.Fixed.Area4.Level4;
using UnityEngine;

namespace Level.Manager.Data.Area
{
	public class Level44DataManager : LevelDataManager
	{
		[CompilerGenerated]
		private sealed class _003CLoadLevelCoroutine_003Ed__23 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level44DataManager _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CLoadLevelCoroutine_003Ed__23(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("燃料值")]
		public float fuelValue;

		[Tooltip("燃料值基础单位")]
		public float fuelBaseValue;

		[Tooltip("是否可增长燃料")]
		public bool isCanAddFuel;

		[Tooltip("训练植物集合")]
		public List<PlantEntity> trainPlantList;

		public List<LandEntity> trainPlantLandList;

		public List<GameObject> trainPlantBalloonList;

		[Tooltip("敲燃料桶次数")]
		public int hammerFuelCount;

		[Tooltip("是否最后支付阳光")]
		public bool isLastSun;

		[Tooltip("燃料预制体")]
		public GameObject fuelPrefab;

		private GameObject _fuelObj;

		private Animator _inflateAnimator;

		[Tooltip("风力管理器预制体")]
		public GameObject windControllerPrefab;

		private Level44WindController _windController;

		private GTextField _fuelValueTextField;

		private GTextField _windTextField;

		private bool _isFuelExplosion;

		public GameObject FuelObj
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		public new static Level44DataManager Instance => null;

		public override void SaveLevel()
		{
		}

		public override void LoadLevel()
		{
		}

		[IteratorStateMachine(typeof(_003CLoadLevelCoroutine_003Ed__23))]
		private IEnumerator LoadLevelCoroutine()
		{
			return null;
		}

		private void Start()
		{
		}

		private void Update()
		{
		}

		public void FuelExplosion()
		{
		}

		private void InitWindController()
		{
		}

		private void InitFuel()
		{
		}

		public void ShowInflate(bool flag)
		{
		}
	}
}
