using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Plant.Entity;
using Plant.Entity.Plant;
using Touniu.Entity.Say.Fixed.Area3.Level5;
using UnityEngine;
using Zombie.Entity;

namespace Level.Manager.Data.Area
{
	public class Level35DataManager : LevelDataManager
	{
		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass17_0
		{
			public GameObject sunObj;

			internal void _003CClickTargetLight_003Eb__0()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CCheckLawnMowerBoom_003Ed__19 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level35DataManager _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CCheckLawnMowerBoom_003Ed__19(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CCheckZombieMove_003Ed__20 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level35DataManager _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CCheckZombieMove_003Ed__20(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CClickTargetLight_003Ed__17 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level35TrafficLightEntity minLightEntity;

			private _003C_003Ec__DisplayClass17_0 _003C_003E8__1;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CClickTargetLight_003Ed__17(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CExplodeLight_003Ed__14 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public ZombieEntity zombieEntity;

			public Level35DataManager _003C_003E4__this;

			private List<ZombieEntity> _003Czombie120List_003E5__2;

			private int _003Ci_003E5__3;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CExplodeLight_003Ed__14(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CLoadLevelCoroutine_003Ed__12 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level35DataManager _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CLoadLevelCoroutine_003Ed__12(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("阳光卡预制体")]
		public GameObject sunCardPrefab;

		[Tooltip("信号灯预制体")]
		public GameObject trafficLightPrefab;

		[Tooltip("是否爆炸")]
		public bool isExplosion;

		[Tooltip("是否检测僵尸停车")]
		public bool isSetZombieMove;

		[Tooltip("是否辣椒不爆炸")]
		public bool isNoExplosion210;

		[Tooltip("是小推车首次爆炸")]
		public bool isLawnFirstBoom;

		[Tooltip("是可以点击灯")]
		public bool isClickLight;

		[HideInInspector]
		public GameObject sunCardObj;

		[HideInInspector]
		public Dictionary<int, Level35TrafficLightEntity> trafficLightDic;

		public new static Level35DataManager Instance => null;

		public override void LoadLevel()
		{
		}

		[IteratorStateMachine(typeof(_003CLoadLevelCoroutine_003Ed__12))]
		private IEnumerator LoadLevelCoroutine()
		{
			return null;
		}

		private void Start()
		{
		}

		[IteratorStateMachine(typeof(_003CExplodeLight_003Ed__14))]
		private IEnumerator ExplodeLight(ZombieEntity zombieEntity)
		{
			return null;
		}

		private void Update()
		{
		}

		private void CheckClickLight()
		{
		}

		[IteratorStateMachine(typeof(_003CClickTargetLight_003Ed__17))]
		private IEnumerator ClickTargetLight(Level35TrafficLightEntity minLightEntity)
		{
			return null;
		}

		private void InitTrafficLight()
		{
		}

		[IteratorStateMachine(typeof(_003CCheckLawnMowerBoom_003Ed__19))]
		private IEnumerator CheckLawnMowerBoom()
		{
			return null;
		}

		[IteratorStateMachine(typeof(_003CCheckZombieMove_003Ed__20))]
		private IEnumerator CheckZombieMove()
		{
			return null;
		}

		private void CheckPlantBoom(PlantEntity plantEntity)
		{
		}

		public void Plant210Attack(Plant210Entity plant210Entity)
		{
		}
	}
}
