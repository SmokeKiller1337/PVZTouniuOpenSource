using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;
using Zombie.Entity;

namespace Level.Manager.Data.Area
{
	public class Level15DataManager : LevelDataManager
	{
		[CompilerGenerated]
		private sealed class _003CCheckBossEnd_003Ed__12 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CCheckBossEnd_003Ed__12(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CLoadLevelCoroutine_003Ed__9 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CLoadLevelCoroutine_003Ed__9(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("警戒值")]
		public int alertValue;

		[Tooltip("获胜检测线")]
		public GameObject winCheckPrefab;

		[HideInInspector]
		public bool isEndWave;

		[HideInInspector]
		public bool isEndExplosion;

		private float _timer;

		private bool _isPath1;

		public new static Level15DataManager Instance => null;

		public override void LoadLevel()
		{
		}

		[IteratorStateMachine(typeof(_003CLoadLevelCoroutine_003Ed__9))]
		private IEnumerator LoadLevelCoroutine()
		{
			return null;
		}

		private void Start()
		{
		}

		private void InitBoss(ZombieEntity zombieEntity)
		{
		}

		[IteratorStateMachine(typeof(_003CCheckBossEnd_003Ed__12))]
		private IEnumerator CheckBossEnd()
		{
			return null;
		}

		private void Update()
		{
		}
	}
}
