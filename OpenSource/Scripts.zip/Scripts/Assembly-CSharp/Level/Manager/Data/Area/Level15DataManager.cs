using System;
using System.Collections;
using UnityEngine;
using Zombie.Entity;

namespace Level.Manager.Data.Area
{
	public class Level15DataManager : LevelDataManager
	{
		[Tooltip("警戒值")]
		public int alertValue;

		[Tooltip("获胜检测线")]
		public GameObject winCheckPrefab;

		[HideInInspector]
		public bool isEndWave;

		[HideInInspector]
		public bool isEndExplosion;

		private float _timer;

		private bool _isPath1;

		public new static Level15DataManager Instance => null;

		public override void LoadLevel()
		{
		}

		private IEnumerator LoadLevelCoroutine()
		{
			yield break;
		}

		private void Start()
		{
		}

		private void InitBoss(ZombieEntity zombieEntity)
		{
		}

		private IEnumerator CheckBossEnd()
		{
			yield break;
		}

		private void Update()
		{
		}
	}
}
