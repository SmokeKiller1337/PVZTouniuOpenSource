using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

namespace Level.Manager.Data.Area
{
	public class Level30DataManager : LevelDataManager
	{
		[CompilerGenerated]
		private sealed class _003CGourdAttack_003Ed__18 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level30DataManager _003C_003E4__this;

			private GameObject _003Cobj_003E5__2;

			private SpriteRenderer _003CspriteRenderer_003E5__3;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CGourdAttack_003Ed__18(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CLoadLevelCoroutine_003Ed__15 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CLoadLevelCoroutine_003Ed__15(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("水池预制体")]
		public GameObject waterPrefab;

		private GameObject _waterObj;

		[HideInInspector]
		public GameObject gourdObj;

		[Tooltip("葫芦模式(1吸僵尸，2吸植物)")]
		public int gourdMode;

		[Tooltip("吸取时间")]
		public float gourdTime;

		[Tooltip("吸取速度比例")]
		public float gourdRatio;

		private float _gourdTimer;

		private bool _isStartTouniu;

		[Tooltip("葫芦图片预制体")]
		public GameObject gourdIconPrefab;

		private bool _randomWater1;

		private bool _randomWater2;

		private bool _randomWater3;

		public new static Level30DataManager Instance => null;

		public override void LoadLevel()
		{
		}

		[IteratorStateMachine(typeof(_003CLoadLevelCoroutine_003Ed__15))]
		private IEnumerator LoadLevelCoroutine()
		{
			return null;
		}

		private void Start()
		{
		}

		private void Update()
		{
		}

		[IteratorStateMachine(typeof(_003CGourdAttack_003Ed__18))]
		private IEnumerator GourdAttack()
		{
			return null;
		}

		public void CreateWater(int index)
		{
		}

		private void SetToWaterType(int row)
		{
		}
	}
}
