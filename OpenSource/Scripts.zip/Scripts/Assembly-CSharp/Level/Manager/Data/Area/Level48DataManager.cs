using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using FairyGUI;
using Touniu.Entity.Body;
using UnityEngine;

namespace Level.Manager.Data.Area
{
	public class Level48DataManager : LevelDataManager
	{
		[CompilerGenerated]
		private sealed class _003CLoadLevelCoroutine_003Ed__11 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CLoadLevelCoroutine_003Ed__11(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CTouniuBuy1Coroutine_003Ed__15 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level48DataManager _003C_003E4__this;

			private TouniuBaseBody _003CtouniuBaseBody_003E5__2;

			private bool _003CisHasHelmet_003E5__3;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CTouniuBuy1Coroutine_003Ed__15(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CTouniuBuy2Coroutine_003Ed__17 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level48DataManager _003C_003E4__this;

			private TouniuBaseBody _003CtouniuBaseBody_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CTouniuBuy2Coroutine_003Ed__17(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CTouniuBuy3Coroutine_003Ed__19 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level48DataManager _003C_003E4__this;

			private TouniuBaseBody _003CtouniuBaseBody_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CTouniuBuy3Coroutine_003Ed__19(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("玩家头盔数量")]
		public int playerHelmetNumber;

		[Tooltip("赤红头盔数量")]
		public int redHelmetNumber;

		public GComponent contentCom;

		public GList helmetList;

		public int PlayerHelmetNumber
		{
			get
			{
				return 0;
			}
			set
			{
			}
		}

		public new static Level48DataManager Instance => null;

		public override void SaveLevel()
		{
		}

		public override void LoadLevel()
		{
		}

		[IteratorStateMachine(typeof(_003CLoadLevelCoroutine_003Ed__11))]
		private IEnumerator LoadLevelCoroutine()
		{
			return null;
		}

		private void Start()
		{
		}

		public override void OnCreateGameMainUI()
		{
		}

		public void TouniuBuy1()
		{
		}

		[IteratorStateMachine(typeof(_003CTouniuBuy1Coroutine_003Ed__15))]
		private IEnumerator TouniuBuy1Coroutine()
		{
			return null;
		}

		public void TouniuBuy2()
		{
		}

		[IteratorStateMachine(typeof(_003CTouniuBuy2Coroutine_003Ed__17))]
		private IEnumerator TouniuBuy2Coroutine()
		{
			return null;
		}

		public void TouniuBuy3()
		{
		}

		[IteratorStateMachine(typeof(_003CTouniuBuy3Coroutine_003Ed__19))]
		private IEnumerator TouniuBuy3Coroutine()
		{
			return null;
		}

		public void Plant325BiteHandle()
		{
		}
	}
}
