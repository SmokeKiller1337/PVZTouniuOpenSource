using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using FairyGUI;
using Land.Entity;
using Plant.Entity;
using Touniu.Entity;
using Touniu.Entity.Body;
using UnityEngine;
using Zombie.Entity;

namespace Level.Manager.Data.Area
{
	public class Level38DataManager : LevelDataManager
	{
		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass43_0
		{
			public GameObject cloudyTextObj;

			internal void _003CStartCloudyCoroutine_003Eb__0()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CCheckPlant20_003Ed__51 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level38DataManager _003C_003E4__this;

			private List<PlantEntity> _003CplantList_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CCheckPlant20_003Ed__51(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CLoadLevelCoroutine_003Ed__40 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CLoadLevelCoroutine_003Ed__40(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CSellCoroutine_003Ed__50 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level38DataManager _003C_003E4__this;

			public int index;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CSellCoroutine_003Ed__50(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CSellTouniuCoroutine_003Ed__46 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public int id;

			public Level38DataManager _003C_003E4__this;

			private TouniuBaseBody _003CtouniuBaseBody_003E5__2;

			private List<PlantEntity> _003Cplant20List_003E5__3;

			private List<LawnMowerEntity> _003ClawnList_003E5__4;

			private GameObject _003CshovelObj_003E5__5;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CSellTouniuCoroutine_003Ed__46(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CShowSunCoroutine_003Ed__47 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuBaseBody touniuBaseBody;

			public int sun3;

			public int sun2;

			public int sun1;

			public Level38DataManager _003C_003E4__this;

			private int _003CsunValue_003E5__2;

			private GameObject _003Csun1Obj_003E5__3;

			private GameObject _003Csun2Obj_003E5__4;

			private GameObject _003Csun3Obj_003E5__5;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CShowSunCoroutine_003Ed__47(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CStartAuctionCoroutine_003Ed__49 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level38DataManager _003C_003E4__this;

			private TouniuSayEntity _003CtouniuSayEntity_003E5__2;

			private int _003CexplosionNumber_003E5__3;

			private Vector2 _003ChitPosition_003E5__4;

			private int _003Ci_003E5__5;

			private ZombieEntity _003CzombieEntity_003E5__6;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CStartAuctionCoroutine_003Ed__49(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CStartCloudyCoroutine_003Ed__43 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level38DataManager _003C_003E4__this;

			private _003C_003Ec__DisplayClass43_0 _003C_003E8__1;

			private SpriteRenderer _003CtextSpriteRenderer_003E5__2;

			private SpriteRenderer _003CspriteRenderer_003E5__3;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CStartCloudyCoroutine_003Ed__43(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		public GComponent contentCom;

		public GTextField timeTextField;

		public GLabel l1abel;

		public GLabel l2abel;

		public GLabel l3abel;

		[Tooltip("阴天预制体")]
		public GameObject cloudyPrefab;

		private GameObject _cloudyObj;

		[Tooltip("阴天文字预制体")]
		public GameObject cloudyTextPrefab;

		private bool _isCloudy;

		[Tooltip("卖预制体")]
		public GameObject sellPrefab;

		private GameObject _sellObj;

		private Animator _sellAnimator;

		private SpriteRenderer _sellSpriteRenderer;

		[Tooltip("出售物品图标")]
		public List<Sprite> sellItemList;

		[Tooltip("是否保管阳光")]
		public bool isProvideSun;

		[Tooltip("贩卖开始音效")]
		public AudioClip sellStartSound;

		[Tooltip("下一件音效")]
		public AudioClip nextSellSound;

		[Tooltip("铲子图标预制体")]
		public GameObject sell3ShovelPrefab;

		[Tooltip("显示阳光预制体")]
		public GameObject sunValuePrefab;

		[Tooltip("显示阳光音效")]
		public AudioClip showSunSound;

		[HideInInspector]
		public TouniuBaseBody touniu1;

		[HideInInspector]
		public TouniuBaseBody touniu2;

		[HideInInspector]
		public TouniuBaseBody touniu3;

		[HideInInspector]
		public TouniuBaseBody touniu5;

		private int _currentSellIndex;

		[HideInInspector]
		public bool isSell;

		[HideInInspector]
		public bool isSellEnd;

		[HideInInspector]
		public float sellTime;

		[HideInInspector]
		public int difficulty5Value;

		[HideInInspector]
		public int sellTouniuNumber;

		[HideInInspector]
		public GameObject touniuMaskObj;

		[HideInInspector]
		public GameObject touniuCloneMaskObj;

		private bool _sellEventEnd;

		private bool _isCheckPlant20Flag;

		private readonly Vector2 _sellPosition1;

		private readonly Vector2 _sellPosition2;

		private readonly Vector2 _sellPosition3;

		public new static Level38DataManager Instance => null;

		public override void LoadLevel()
		{
		}

		[IteratorStateMachine(typeof(_003CLoadLevelCoroutine_003Ed__40))]
		private IEnumerator LoadLevelCoroutine()
		{
			return null;
		}

		private void Start()
		{
		}

		private void Update()
		{
		}

		[IteratorStateMachine(typeof(_003CStartCloudyCoroutine_003Ed__43))]
		private IEnumerator StartCloudyCoroutine()
		{
			return null;
		}

		public override void OnCreateGameMainUI()
		{
		}

		private void SellTouniu(int id)
		{
		}

		[IteratorStateMachine(typeof(_003CSellTouniuCoroutine_003Ed__46))]
		private IEnumerator SellTouniuCoroutine(int id)
		{
			return null;
		}

		[IteratorStateMachine(typeof(_003CShowSunCoroutine_003Ed__47))]
		private IEnumerator ShowSunCoroutine(TouniuBaseBody touniuBaseBody, int sun1, int sun2, int sun3)
		{
			return null;
		}

		public void CreateCloneTouniu()
		{
		}

		[IteratorStateMachine(typeof(_003CStartAuctionCoroutine_003Ed__49))]
		private IEnumerator StartAuctionCoroutine()
		{
			return null;
		}

		[IteratorStateMachine(typeof(_003CSellCoroutine_003Ed__50))]
		private IEnumerator SellCoroutine(int index)
		{
			return null;
		}

		[IteratorStateMachine(typeof(_003CCheckPlant20_003Ed__51))]
		public IEnumerator CheckPlant20()
		{
			return null;
		}

		private void WaitBossCheck(ZombieEntity zombieEntity)
		{
		}
	}
}
