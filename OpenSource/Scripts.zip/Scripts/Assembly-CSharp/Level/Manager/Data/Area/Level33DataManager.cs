using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using FairyGUI;

namespace Level.Manager.Data.Area
{
	public class Level33DataManager : LevelDataManager
	{
		[CompilerGenerated]
		private sealed class _003CLoadLevelCoroutine_003Ed__10 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CLoadLevelCoroutine_003Ed__10(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CSetDefaultLawnCoroutine_003Ed__17 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CSetDefaultLawnCoroutine_003Ed__17(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		public GComponent contentCom;

		public GProgressBar headBar;

		private float _barUpdateTimer;

		private bool _isReward1;

		private bool _isReward2;

		private bool _isReward3;

		private bool _isReward4;

		public new static Level33DataManager Instance => null;

		public override void LoadLevel()
		{
		}

		[IteratorStateMachine(typeof(_003CLoadLevelCoroutine_003Ed__10))]
		private IEnumerator LoadLevelCoroutine()
		{
			return null;
		}

		public override void OnCreateGameMainUI()
		{
		}

		private void Start()
		{
		}

		private void Update()
		{
		}

		private void UpdateBar()
		{
		}

		private void CheckReward(int number)
		{
		}

		public void SetDefaultLawn()
		{
		}

		[IteratorStateMachine(typeof(_003CSetDefaultLawnCoroutine_003Ed__17))]
		public IEnumerator SetDefaultLawnCoroutine()
		{
			return null;
		}

		public void BreakWait()
		{
		}
	}
}
