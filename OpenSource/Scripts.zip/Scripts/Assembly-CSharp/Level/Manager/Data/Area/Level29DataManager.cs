using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Plant.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Level.Manager.Data.Area
{
	public class Level29DataManager : LevelDataManager
	{
		[CompilerGenerated]
		private sealed class _003CLoadLevelCoroutine_003Ed__10 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Level29DataManager _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CLoadLevelCoroutine_003Ed__10(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[HideInInspector]
		public GameObject phoneObj;

		[HideInInspector]
		public GameObject milkObj;

		[HideInInspector]
		public CardEntity cardEntity1;

		public List<bool> giftFlag;

		public new static Level29DataManager Instance => null;

		private void Start()
		{
		}

		private void Update()
		{
		}

		public override void SaveLevel()
		{
		}

		public override void LoadLevel()
		{
		}

		[IteratorStateMachine(typeof(_003CLoadLevelCoroutine_003Ed__10))]
		private IEnumerator LoadLevelCoroutine()
		{
			return null;
		}

		private void WaitBossCheck(ZombieEntity zombieEntity)
		{
		}

		public static void AddPlantBuff101(PlantEntity plantEntity)
		{
		}
	}
}
