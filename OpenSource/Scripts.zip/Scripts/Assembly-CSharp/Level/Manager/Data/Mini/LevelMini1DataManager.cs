using Touniu.Entity;
using UnityEngine;

namespace Level.Manager.Data.Mini
{
	public class LevelMini1DataManager : LevelDataManager
	{
		[Tooltip("分配说话")]
		public AssignBehaviorEntity assignTalk;

		private float _assignTime;

		private float _assignTimer;

		public new static LevelMini1DataManager Instance => null;

		private void Start()
		{
		}

		private void Update()
		{
		}
	}
}
