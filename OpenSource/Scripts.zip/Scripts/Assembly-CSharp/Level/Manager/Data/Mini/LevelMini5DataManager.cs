using System.Collections.Generic;
using Touniu.Entity;
using Touniu.Entity.Fixed.Mini.Level5;
using UnityEngine;

namespace Level.Manager.Data.Mini
{
	public class LevelMini5DataManager : LevelDataManager
	{
		[Tooltip("分配说话")]
		public AssignBehaviorEntity assignTalk;

		private List<Mini5SelectSayEntity> _sayList;

		private float _assignTime;

		private float _assignTimer;

		private float _selectTimer;

		public new static LevelMini5DataManager Instance => null;

		private void Start()
		{
		}

		public override void OnCreateGameMainUI()
		{
		}

		private void Update()
		{
		}

		private void EndSelectSay()
		{
		}

		private void StartSelectSay()
		{
		}

		public void UpdateSelectSay()
		{
		}

		private string GetSimpleSayText(Mini5SelectSayEntity sayEntity)
		{
			return null;
		}
	}
}
