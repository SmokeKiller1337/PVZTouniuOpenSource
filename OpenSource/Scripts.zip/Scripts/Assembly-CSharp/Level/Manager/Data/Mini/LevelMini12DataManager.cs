using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Building.Entity;
using Plant.Entity;
using Touniu.Entity.Body;
using UnityEngine;

namespace Level.Manager.Data.Mini
{
	public class LevelMini12DataManager : LevelDataManager
	{
		[CompilerGenerated]
		private sealed class _003CAttackTouniu_003Ed__21 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TouniuBaseBody targetTouniu;

			public TouniuBaseBody touniuClone;

			public LevelMini12DataManager _003C_003E4__this;

			private Vector3 _003Cposition_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CAttackTouniu_003Ed__21(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CCheckEndPotCoroutine_003Ed__11 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public LevelMini12DataManager _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CCheckEndPotCoroutine_003Ed__11(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CTou1Attack_003Ed__15 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public PotEntity potEntity;

			private TouniuBaseBody _003CtouniuClone_003E5__2;

			private int _003CsunNumber_003E5__3;

			private int _003CcardNumber_003E5__4;

			private int _003Ci_003E5__5;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CTou1Attack_003Ed__15(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CTou2Attack_003Ed__16 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public PotEntity potEntity;

			private TouniuBaseBody _003CtouniuClone_003E5__2;

			private int _003Cnumber_003E5__3;

			private int _003Ci_003E5__4;

			private PlantEntity _003CplantEntity_003E5__5;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CTou2Attack_003Ed__16(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CTou3Attack_003Ed__17 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public PotEntity potEntity;

			public LevelMini12DataManager _003C_003E4__this;

			private TouniuBaseBody _003CtouniuClone_003E5__2;

			private int _003Ci_003E5__3;

			private TouniuBaseBody _003CtargetTouniu_003E5__4;

			private Vector3 _003Cposition_003E5__5;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CTou3Attack_003Ed__17(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CTou4Attack_003Ed__18 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public PotEntity potEntity;

			public LevelMini12DataManager _003C_003E4__this;

			private TouniuBaseBody _003CtouniuClone_003E5__2;

			private int _003Cnumber_003E5__3;

			private float _003Cratio_003E5__4;

			private CardEntity _003CcardEntity_003E5__5;

			private int _003Ci_003E5__6;

			private PlantEntity _003Cplant_003E5__7;

			private List<Vector2>.Enumerator _003C_003E7__wrap7;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CTou4Attack_003Ed__18(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			private void _003C_003Em__Finally1()
			{
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CTou5Attack_003Ed__19 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public PotEntity potEntity;

			private TouniuBaseBody _003CtouniuClone_003E5__2;

			private int _003Cnumber_003E5__3;

			private int _003Ci_003E5__4;

			private PotEntity _003CpotEntity1_003E5__5;

			private Vector3 _003Cposition_003E5__6;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CTou5Attack_003Ed__19(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CTou6Attack_003Ed__20 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public PotEntity potEntity;

			public LevelMini12DataManager _003C_003E4__this;

			private TouniuBaseBody _003CtouniuClone_003E5__2;

			private int _003Cnumber_003E5__3;

			private int _003Ci_003E5__4;

			private PotEntity _003CpotEntity1_003E5__5;

			private PlantEntity _003CplantEntity_003E5__6;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CTou6Attack_003Ed__20(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("罐子列表")]
		public List<PotEntity> potList;

		[Tooltip("头牛图片集合")]
		public List<Sprite> touniuSpriteList;

		[Tooltip("放大镜图片集合")]
		public List<Sprite> touniu6ItemSpriteList;

		private bool _isStartPot;

		private float _checkPotTimer;

		private int _currentTurn;

		private Coroutine[] _touCoroutineArr;

		public new static LevelMini12DataManager Instance => null;

		private void Start()
		{
		}

		private void Update()
		{
		}

		[IteratorStateMachine(typeof(_003CCheckEndPotCoroutine_003Ed__11))]
		private IEnumerator CheckEndPotCoroutine()
		{
			return null;
		}

		public void InitPot(int index)
		{
		}

		private void ApplyPot(int index)
		{
		}

		private void PotAddTouniu(int touniuNumber)
		{
		}

		[IteratorStateMachine(typeof(_003CTou1Attack_003Ed__15))]
		private IEnumerator Tou1Attack(PotEntity potEntity)
		{
			return null;
		}

		[IteratorStateMachine(typeof(_003CTou2Attack_003Ed__16))]
		private IEnumerator Tou2Attack(PotEntity potEntity)
		{
			return null;
		}

		[IteratorStateMachine(typeof(_003CTou3Attack_003Ed__17))]
		private IEnumerator Tou3Attack(PotEntity potEntity)
		{
			return null;
		}

		[IteratorStateMachine(typeof(_003CTou4Attack_003Ed__18))]
		private IEnumerator Tou4Attack(PotEntity potEntity)
		{
			return null;
		}

		[IteratorStateMachine(typeof(_003CTou5Attack_003Ed__19))]
		private IEnumerator Tou5Attack(PotEntity potEntity)
		{
			return null;
		}

		[IteratorStateMachine(typeof(_003CTou6Attack_003Ed__20))]
		private IEnumerator Tou6Attack(PotEntity potEntity)
		{
			return null;
		}

		[IteratorStateMachine(typeof(_003CAttackTouniu_003Ed__21))]
		private IEnumerator AttackTouniu(TouniuBaseBody touniuClone, TouniuBaseBody targetTouniu)
		{
			return null;
		}
	}
}
