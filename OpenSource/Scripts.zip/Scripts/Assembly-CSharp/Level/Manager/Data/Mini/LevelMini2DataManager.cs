using UnityEngine;

namespace Level.Manager.Data.Mini
{
	public class LevelMini2DataManager : LevelDataManager
	{
		[Tooltip("是蓝色")]
		public bool isBlueSkin;

		public new static LevelMini2DataManager Instance => null;

		private void Start()
		{
		}

		private void Update()
		{
		}

		public void SetTouniuInvalidStun(bool flag)
		{
		}
	}
}
