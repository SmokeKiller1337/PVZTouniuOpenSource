using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Plant.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Level.Manager.Data.Mini
{
	public class LevelMini7DataManager : LevelDataManager
	{
		[CompilerGenerated]
		private sealed class _003CLoadLevelCoroutine_003Ed__10 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public LevelMini7DataManager _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CLoadLevelCoroutine_003Ed__10(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("温度")]
		public float temperature;

		[Tooltip("每秒增加温度")]
		public float temperatureAdd;

		[Tooltip("是否锁定温度增长")]
		public bool isLock;

		[Tooltip("是否旋转")]
		public bool isRotate;

		[Tooltip("正常温度次数")]
		public int goodCount;

		[Tooltip("错误温度次数")]
		public int badCount;

		public GameObject touniuNormal;

		public new static LevelMini7DataManager Instance => null;

		public override void LoadLevel()
		{
		}

		[IteratorStateMachine(typeof(_003CLoadLevelCoroutine_003Ed__10))]
		private IEnumerator LoadLevelCoroutine()
		{
			return null;
		}

		private void Start()
		{
		}

		private void Update()
		{
		}

		private void OnPlace150(PlantEntity plantEntity)
		{
		}

		private void OnPlace155(PlantEntity plantEntity)
		{
		}

		public void AddRestoreTemperature(List<ZombieEntity> zombieList)
		{
		}

		public void SubRestoreTemperature(List<ZombieEntity> zombieList)
		{
		}

		public bool IsGoodTemperature(bool isBadAdd = true)
		{
			return false;
		}

		public bool EndCheckGood()
		{
			return false;
		}
	}
}
