using System.Collections.Generic;
using Touniu.Entity.Fixed.Mini.Level5;
using UnityEngine;

namespace Level.Manager.Data.Mini
{
	public class LevelMini14DataManager : LevelDataManager
	{
		[Tooltip("已选择的对话集合")]
		public List<Mini5SelectSayEntity> sayList;

		private List<Mini5SelectSayEntity> _selectSayList;

		private int _maxSayCount;

		private float _assignTime;

		private float _assignTimer;

		private float _selectTimer;

		public new static LevelMini14DataManager Instance => null;

		private void Start()
		{
		}

		private void Update()
		{
		}

		public override void OnCreateGameMainUI()
		{
		}

		private void SelectSay()
		{
		}

		private List<Mini5SelectSayEntity> GetRandomSayEntityList(int number)
		{
			return null;
		}

		private void StartSelectSay()
		{
		}

		private void CloseSelectSay()
		{
		}

		public void UpdateSelectSay()
		{
		}
	}
}
