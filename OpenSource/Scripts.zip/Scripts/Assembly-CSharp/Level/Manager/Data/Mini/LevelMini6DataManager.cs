using System.Collections.Generic;
using FairyGUI;
using Game.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Level.Manager.Data.Mini
{
	public class LevelMini6DataManager : LevelDataManager
	{
		[Tooltip("白天音乐")]
		public AudioClip dayMusic;

		[Tooltip("黑屏音乐")]
		public AudioClip blackMusic;

		[Tooltip("遗言预制体")]
		public GameObject deathTextPrefab;

		[Tooltip("标签预制体")]
		public GameObject labelPrefab;

		[Tooltip("标签图标集合")]
		public List<Sprite> labelSpriteList;

		public Dictionary<int, GameObject> currentLabelDic;

		[Tooltip("黑屏预制体")]
		public GameObject blackPrefab;

		private GameObject _blackObj;

		[Tooltip("爆炸效果")]
		public EffectEntity explosionEffect;

		[HideInInspector]
		public GTextField textField;

		[HideInInspector]
		public int inspectCardIndex;

		[Tooltip("身份数组")]
		public int[] roleArr;

		public int endSuccessCount;

		public new static LevelMini6DataManager Instance => null;

		private void Start()
		{
		}

		public override void OnCreateGameMainUI()
		{
		}

		private void Update()
		{
		}

		public void SetLabel(int cardSlotIndex, int labelIndex)
		{
		}

		public void SetDeathText(int cardSlotIndex)
		{
		}

		public void EnterBlack()
		{
		}

		public void ExitBlack()
		{
		}

		public void OutCard(int cardSlotIndex = -1, bool isDeathText = false)
		{
		}

		public void InspectCard(int value)
		{
		}

		public void EndGame()
		{
		}

		private void WaitHitBoss(ZombieEntity zombieEntity)
		{
		}

		private bool IsExplosion(int id)
		{
			return false;
		}

		public int GetDayResult()
		{
			return 0;
		}

		public int[] CreateRoleArraySimplified(int i, int j)
		{
			return null;
		}
	}
}
