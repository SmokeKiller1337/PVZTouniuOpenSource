using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Text;
using FairyGUI;
using Game.Entity;
using UnityEngine;

namespace Level.Manager.Data.Mini
{
	public class LevelMini11DataManager : LevelDataManager
	{
		[CompilerGenerated]
		private sealed class _003CLoadLevelCoroutine_003Ed__15 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public LevelMini11DataManager _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CLoadLevelCoroutine_003Ed__15(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CTurnResultCoroutine_003Ed__19 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public LevelMini11DataManager _003C_003E4__this;

			private bool _003CisSuccess_003E5__2;

			private StringBuilder _003Cbuilder_003E5__3;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CTurnResultCoroutine_003Ed__19(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("头羊效果")]
		public EffectEntity blue2Effect;

		[Tooltip("淡蓝头羊效果")]
		public EffectEntity blue4Effect;

		[Tooltip("深蓝头羊效果")]
		public EffectEntity blue6Effect;

		[Tooltip("是否异常数组")]
		public bool[] isErrorArr;

		[Tooltip("异常提示文字")]
		public List<string> errorTextList;

		[Tooltip("当前轮次索引")]
		public int currentTurnIndex;

		[Tooltip("正确音效")]
		public AudioClip successSound;

		[Tooltip("错误音效")]
		public AudioClip errorSound;

		private GTextField _textField;

		private Transition _showTransition;

		public new static LevelMini11DataManager Instance => null;

		protected override void Awake()
		{
		}

		public override void OnCreateGameMainUI()
		{
		}

		public override void LoadLevel()
		{
		}

		[IteratorStateMachine(typeof(_003CLoadLevelCoroutine_003Ed__15))]
		private IEnumerator LoadLevelCoroutine()
		{
			return null;
		}

		private void Start()
		{
		}

		private void Update()
		{
		}

		public void TurnResult()
		{
		}

		[IteratorStateMachine(typeof(_003CTurnResultCoroutine_003Ed__19))]
		private IEnumerator TurnResultCoroutine()
		{
			return null;
		}
	}
}
