using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Game.Entity;
using UnityEngine;

namespace Level.Manager.Data.Mini
{
	public class LevelMini4DataManager : LevelDataManager
	{
		[CompilerGenerated]
		private sealed class _003CExplosion_003Ed__16 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public LevelMini4DataManager _003C_003E4__this;

			public GameObject obj;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CExplosion_003Ed__16(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("龙珠图标预制体")]
		public GameObject reward101SpritePrefab;

		[Tooltip("神龙预制体")]
		public GameObject dragonPrefab;

		[HideInInspector]
		public GameObject dragonObj;

		[Tooltip("施法效果")]
		public EffectEntity dragonEffect;

		[Tooltip("爆炸效果")]
		public EffectEntity explosionEffect;

		public List<GameObject> reward101SpriteList;

		public List<int> hasReward101List;

		public new static LevelMini4DataManager Instance => null;

		private void Start()
		{
		}

		private void Update()
		{
		}

		public int GetRandomReward101Index()
		{
			return 0;
		}

		public void CreateReward101Sprite(int index, Sprite sprite)
		{
		}

		public void CreateDragon()
		{
		}

		public void DragonExplosion()
		{
		}

		public void DragonRed()
		{
		}

		[IteratorStateMachine(typeof(_003CExplosion_003Ed__16))]
		private IEnumerator Explosion(GameObject obj)
		{
			return null;
		}

		public void TouniuTalk(int index)
		{
		}

		public Vector2 GetDragonPosition()
		{
			return default(Vector2);
		}
	}
}
