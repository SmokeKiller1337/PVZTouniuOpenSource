using System.Collections.Generic;
using FairyGUI;
using UnityEngine;
using Zombie.Entity;
using cfg;

namespace Level.Manager.Data.Mini
{
	public class LevelMini9DataManager : LevelDataManager
	{
		[Tooltip("卖出音效")]
		public AudioClip sellSound;

		[Tooltip("错误音效")]
		public AudioClip errorSound;

		[Tooltip("当前文字集合")]
		public List<char> currentCharList;

		[HideInInspector]
		public List<char> allCharList;

		[Tooltip("对话框文字集合")]
		public List<char> dialogList;

		[Tooltip("常用字集合")]
		public List<char> commonList;

		private int _successCharCount;

		private int _successType;

		private TouniuSayFixedEntity _successFixedEntity;

		private TouniuSaySelectEntity _successSelectEntity;

		public GComponent contentCom;

		public GButton startButton;

		private bool _isShowComponent;

		private GList _currentTextList;

		private GList _dialogList;

		private GList _commonList;

		private GTextField _sunValueTextField;

		private GTextField _sunNumberTextField;

		private GLabel _dialogLabel;

		private GButton _composeButton;

		private GButton _useButton;

		private GButton _sellButton;

		private List<int> _successIdList;

		private List<int> _successTypeList;

		public new static LevelMini9DataManager Instance => null;

		protected override void Awake()
		{
		}

		public override void OnCreateGameMainUI()
		{
		}

		private void ComposeText()
		{
		}

		private void UseText()
		{
		}

		private void SellText()
		{
		}

		private void ClearText()
		{
		}

		public void UpdateTextList()
		{
		}

		private int GetSunValue()
		{
			return 0;
		}

		private void Start()
		{
		}

		private void Update()
		{
		}

		private void InitTextPool()
		{
		}

		private void OnCreateZombie(ZombieEntity zombieEntity)
		{
		}
	}
}
