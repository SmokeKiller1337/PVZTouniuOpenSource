using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using FairyGUI;
using Level.Entity;
using Level.Object;
using UnityEngine;

namespace Level.Manager.Data.Mini
{
	public class LevelMini13DataManager : LevelDataManager
	{
		[CompilerGenerated]
		private sealed class _003CEnterDayCoroutine_003Ed__27 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public LevelMini13DataManager _003C_003E4__this;

			private ZombieWaveObject.ZombieWaveItem _003CwaveItem_003E5__2;

			private int _003CendEventCount_003E5__3;

			private SpriteRenderer _003CnewSpriteRenderer_003E5__4;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CEnterDayCoroutine_003Ed__27(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CEnterNightCoroutine_003Ed__29 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public LevelMini13DataManager _003C_003E4__this;

			private ZombieWaveObject.ZombieWaveItem _003CwaveItem_003E5__2;

			private int _003CendEventCount_003E5__3;

			private SpriteRenderer _003CnewSpriteRenderer_003E5__4;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CEnterNightCoroutine_003Ed__29(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("启用白天消耗时间")]
		public bool isEnableDayTime;

		[Tooltip("白天剩余时间")]
		public float dayTime;

		[Tooltip("白天图片")]
		public Sprite dayBackgroundSprite;

		public AudioClip dayMusic;

		[Tooltip("夜晚图片")]
		public Sprite nightBackgroundSprite;

		public AudioClip nightMusic;

		[Tooltip("路线0,白天")]
		public ZombieWaveObject path0Object;

		[HideInInspector]
		public ZombieWaveEntity path0Entity;

		[Tooltip("路线1,夜晚")]
		public ZombieWaveObject path1Object;

		[HideInInspector]
		public ZombieWaveEntity path1Entity;

		[Tooltip("是否拿走1000阳光")]
		public bool isTakeSun;

		[Tooltip("是否首次戴头盔")]
		public bool isFirstHelmet;

		private int _dayTouniuEventNumber;

		private int _nightTouniuEventNumber;

		private bool _isDayTimeEnd;

		private GTextField _timeTextField;

		public new static LevelMini13DataManager Instance => null;

		public override void OnCreateGameMainUI()
		{
		}

		private void Start()
		{
		}

		private void Update()
		{
		}

		private void OnBossDeath()
		{
		}

		public void OpenFocusEvent()
		{
		}

		private void DayEnd()
		{
		}

		private void OnEnterWave(ZombieWaveObject.ZombieWaveItem waveItem, float startTime)
		{
		}

		private void FocusHandle()
		{
		}

		public void EnterDay()
		{
		}

		[IteratorStateMachine(typeof(_003CEnterDayCoroutine_003Ed__27))]
		private IEnumerator EnterDayCoroutine()
		{
			return null;
		}

		public void EnterNight()
		{
		}

		[IteratorStateMachine(typeof(_003CEnterNightCoroutine_003Ed__29))]
		private IEnumerator EnterNightCoroutine()
		{
			return null;
		}

		private float GetCurrentWaveTime()
		{
			return 0f;
		}
	}
}
