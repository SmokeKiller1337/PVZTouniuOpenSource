using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Game.Entity;
using Land.Entity;
using Plant.Entity;
using Plant.Entity.Card;
using UnityEngine;
using UnityEngine.Pool;
using Zombie.Entity;

namespace Level.Manager
{
	public class ZombieManager : MonoBehaviour
	{
		[CompilerGenerated]
		private sealed class _003CCreateSoilZombieGrassCoroutine_003Ed__23 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public LandEntity landEntity;

			public int zombieId;

			public ZombieManager _003C_003E4__this;

			private Vector2 _003Cposition_003E5__2;

			private GameObject _003CzombieMask_003E5__3;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CCreateSoilZombieGrassCoroutine_003Ed__23(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CCreateSoilZombieWaterCoroutine_003Ed__25 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public LandEntity landEntity;

			public int zombieId;

			public ZombieManager _003C_003E4__this;

			private GameObject _003CzombieMask_003E5__2;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CCreateSoilZombieWaterCoroutine_003Ed__25(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("草坪僵尸集合")]
		public List<ZombieEntity> landZombieList;

		[Tooltip("整个背景僵尸集合")]
		public List<ZombieEntity> backgroundZombieList;

		[Tooltip("僵尸遮罩预制体")]
		public GameObject zombieMaskPrefab;

		[Tooltip("地下出现效果")]
		public EffectEntity soilAppearEffect;

		[Tooltip("地下生成僵尸效果")]
		public EffectEntity soilCreateZombieEffect;

		[Tooltip("卡牌僵尸预制体")]
		public GameObject cardZombiePrefab;

		[Tooltip("吃音频")]
		public List<AudioClip> eatSound;

		[Tooltip("吃血多植物的音频")]
		public List<AudioClip> eatSound1;

		[Tooltip("吃掉植物音频")]
		public AudioClip eatEndSound;

		[Tooltip("警告音频")]
		public AudioClip warnSound;

		private readonly Dictionary<int, IObjectPool<ZombieEntity>> _zombiePoolDic;

		private readonly Dictionary<int, IObjectPool<ZombieExplosionEntity>> _zombieExplosionPoolDic;

		public Action<ZombieEntity> OnCreateZombieAction;

		public static ZombieManager Instance { get; private set; }

		private void Awake()
		{
		}

		private void Start()
		{
		}

		public bool PlaceZombie(CardZombieEntity cardEntity, LandEntity landEntity, SeedCardEntity seedCardEntity = null)
		{
			return false;
		}

		public ZombieEntity CreateZombie(int id)
		{
			return null;
		}

		public ZombieEntity CreateZombie(int id, int row, float healthRatio = 1f)
		{
			return null;
		}

		public void CreateSoilZombie(int zombieId, LandEntity landEntity)
		{
		}

		[IteratorStateMachine(typeof(_003CCreateSoilZombieGrassCoroutine_003Ed__23))]
		private IEnumerator CreateSoilZombieGrassCoroutine(int zombieId, LandEntity landEntity)
		{
			return null;
		}

		public ZombieEntity GetRandomZombieByLand(LandEntity landEntity)
		{
			return null;
		}

		[IteratorStateMachine(typeof(_003CCreateSoilZombieWaterCoroutine_003Ed__25))]
		private IEnumerator CreateSoilZombieWaterCoroutine(int zombieId, LandEntity landEntity)
		{
			return null;
		}

		public void ReleaseZombie(ZombieEntity zombieEntity)
		{
		}

		public bool ContainsZombie(int id)
		{
			return false;
		}

		private void InitPool(int id)
		{
		}

		public ZombieExplosionEntity CreateZombieExplosion(int id, bool isUsePool = true)
		{
			return null;
		}

		public void ReleaseZombieExplosion(ZombieExplosionEntity zombieExplosionEntity)
		{
		}

		public bool ContainsZombieExplosion(int id)
		{
			return false;
		}

		private void InitExplosionPool(int id)
		{
		}
	}
}
