using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Hand.Entity;
using Land.Entity;
using UnityEngine;

namespace Level.Manager
{
	public class HandManager : MonoBehaviour
	{
		[CompilerGenerated]
		private sealed class _003CPlatform1Use_003Ed__35 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public HandManager _003C_003E4__this;

			public Vector2 worldPoint;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CPlatform1Use_003Ed__35(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("手持卡牌")]
		public HandCardEntity handCard;

		[Tooltip("手持铲子")]
		public HandShovelEntity handShovel;

		[Tooltip("手持能量叶")]
		public HandPowerEntity handPower;

		[Tooltip("手持锤子")]
		public HandHammerEntity handHammer;

		private bool _isDisableCard;

		private bool _isHasShovel;

		private bool _isHasPower;

		private bool _isHasHammer;

		[Tooltip("当前物品")]
		public HandEntity currentHandEntity;

		[Tooltip("卡牌残影")]
		public SpriteRenderer cardGhost;

		[Tooltip("放下的物品")]
		public HandEntity dropHandEntity;

		[Tooltip("拿起物品后经过时间")]
		public float pickUpHandTimer;

		[Tooltip("放下物品后经过时间")]
		public float dropHandTimer;

		private Camera _cameraMain;

		[Tooltip("是否禁用卡牌")]
		public bool IsDisableCard
		{
			get
			{
				return false;
			}
			set
			{
			}
		}

		[Tooltip("是否有铲子")]
		public bool IsHasShovel
		{
			get
			{
				return false;
			}
			set
			{
			}
		}

		[Tooltip("是否有能量叶")]
		public bool IsHasPower
		{
			get
			{
				return false;
			}
			set
			{
			}
		}

		[Tooltip("是否有锤子")]
		public bool IsHasHammer
		{
			get
			{
				return false;
			}
			set
			{
			}
		}

		public bool IsEmptyHand => false;

		public static HandManager Instance { get; private set; }

		private void Awake()
		{
		}

		private void Start()
		{
		}

		private void Update()
		{
		}

		[IteratorStateMachine(typeof(_003CPlatform1Use_003Ed__35))]
		private IEnumerator Platform1Use(Vector2 worldPoint)
		{
			return null;
		}

		public void ChangeHandEntity(HandEntity handEntity)
		{
		}

		public void ChangeCardGhost(LandEntity landEntity)
		{
		}

		public void DropCurrentHandEntity()
		{
		}

		public bool IsAvailableTool(int toolType)
		{
			return false;
		}
	}
}
