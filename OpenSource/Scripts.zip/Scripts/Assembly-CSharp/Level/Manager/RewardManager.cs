using System.Collections.Generic;
using Reward.Entity;
using UnityEngine;
using UnityEngine.Pool;

namespace Level.Manager
{
	public class RewardManager : MonoBehaviour
	{
		private readonly Dictionary<int, IObjectPool<RewardEntity>> _rewardPoolDic;

		public static RewardManager Instance { get; private set; }

		private void Awake()
		{
		}

		private void Start()
		{
		}

		public SunEntity CreateSun(Vector2 position, int value = 25, float scale = 1f, bool isProduce = true)
		{
			return null;
		}

		public DiamondEntity CreateDiamond(Vector2 position, int value = 1, float scale = 1f, bool isProduce = true)
		{
			return null;
		}

		public TrophyEntity CreateTrophy(Vector2 position, float scale = 1f, bool isProduce = true)
		{
			return null;
		}

		public HammerEntity CreateHammer(Vector2 position, int value = 1, float scale = 1f, bool isProduce = true)
		{
			return null;
		}

		public RewardEntity CreateReward(int id, Vector2 position, float scale = 1f, bool isProduce = true)
		{
			return null;
		}

		public void ReleaseReward(RewardEntity rewardEntity)
		{
		}

		public bool ContainsReward(int id)
		{
			return false;
		}

		private void InitPool(int id)
		{
		}
	}
}
