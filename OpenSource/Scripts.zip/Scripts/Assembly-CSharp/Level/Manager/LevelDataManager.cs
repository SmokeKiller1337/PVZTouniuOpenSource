using System.Collections.Generic;
using UnityEngine;

namespace Level.Manager
{
	public class LevelDataManager : MonoBehaviour
	{
		public Dictionary<string, object> ParamDic;

		public static LevelDataManager Instance { get; protected set; }

		protected virtual void Awake()
		{
		}

		public virtual void OnCreateGameMainUI()
		{
		}

		public virtual void SaveLevel()
		{
		}

		public virtual void LoadLevel()
		{
		}

		public void SetParam(string key, object value)
		{
		}

		public void AddParam(string key, object value)
		{
		}

		public object GetParam(string key)
		{
			return null;
		}

		public void RemoveParam(string key)
		{
		}

		public void SaveParam(string key, object obj)
		{
		}

		public bool LoadParam<T>(string key, ref T value)
		{
			return false;
		}
	}
}
