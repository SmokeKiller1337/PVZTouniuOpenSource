using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using FocusSlowMotion.Controller;
using Game.Entity;
using Level.Enum;
using Plant.Entity;
using UnityEngine;

namespace Level.Manager
{
	public class FocusSlowMotionManager : MonoBehaviour
	{
		[CompilerGenerated]
		private sealed class _003CStartEventCoroutine_003Ed__54 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public FocusSlowMotionManager _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CStartEventCoroutine_003Ed__54(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("是禁用暂停")]
		public bool disablePause;

		[HideInInspector]
		public bool isPause;

		[HideInInspector]
		public int pauseCount;

		[Tooltip("是否无限集中时间")]
		public bool isInfiniteFocusTime;

		[Tooltip("可集中时间")]
		public float totalFocusTime;

		[Tooltip("集中模式")]
		public FocusModeType focusMode;

		[Tooltip("减速曲线（控制减速速度变化）")]
		public AnimationCurve slowDownCurve;

		[Tooltip("最大减速比例）")]
		[Range(0.1f, 0.9f)]
		public float maxSlowFactor;

		[Min(0.1f)]
		[Tooltip("减速达到最大效果所需时间")]
		public float slowDownDuration;

		[Min(0.1f)]
		[Tooltip("恢复速度所需时间")]
		public float speedUpDuration;

		[Tooltip("集中返还特效")]
		public EffectEntity returnSunEffect;

		[HideInInspector]
		public bool isFocus;

		[HideInInspector]
		public bool isBacktrack;

		[HideInInspector]
		public bool isEvent;

		[HideInInspector]
		public bool isSpeedUp;

		private float _focusTimer;

		private float _targetTimeScale;

		private float _currentTimeScale;

		private float _backSoundTimer;

		[HideInInspector]
		public float returnSunTime;

		private float _returnSunTimer;

		[Tooltip("暂停音效")]
		public AudioClip pauseSound;

		[Tooltip("集中开始音效")]
		public AudioClip focusStartSound;

		[Tooltip("集中停止音效")]
		public AudioClip focusStopSound;

		[Tooltip("集中回溯音效")]
		public AudioClip focusBackSound;

		[Tooltip("全屏特效材质")]
		public Material focusMaterial;

		public Material focus2Material;

		private FocusRotationController _focusRotationController;

		private FocusBackRecordController _focusBackRecordController;

		private TweenerCore<Color, Color, ColorOptions> _focusTween1;

		private TweenerCore<Color, Color, ColorOptions> _focusTween2;

		private TweenerCore<float, float, FloatOptions> _focusTween3;

		private TweenerCore<float, float, FloatOptions> _focusTween4;

		private TweenerCore<float, float, FloatOptions> _focusTween5;

		public Action OnFocusEventAction;

		public static FocusSlowMotionManager Instance { get; private set; }

		private void Awake()
		{
		}

		private void Start()
		{
		}

		private void Update()
		{
		}

		public void Pause()
		{
		}

		public void UnPause()
		{
		}

		public void StartFocus()
		{
		}

		private void UpdateFocus()
		{
		}

		public void StopFocus()
		{
		}

		private void UpdateSpeedUp()
		{
		}

		private void EndSpeedUp()
		{
		}

		private void StartBacktrack()
		{
		}

		private void UpdateBacktrack(float curveFactor)
		{
		}

		private void ResetMaterial()
		{
		}

		public void FocusUseCard(CardEntity cardEntity)
		{
		}

		private void StartEvent()
		{
		}

		[IteratorStateMachine(typeof(_003CStartEventCoroutine_003Ed__54))]
		private IEnumerator StartEventCoroutine()
		{
			return null;
		}
	}
}
