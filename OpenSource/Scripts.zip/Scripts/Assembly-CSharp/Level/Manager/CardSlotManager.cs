using System.Collections.Generic;
using Audio.Manager;
using Common.Entity;
using FairyGUI;
using FGUI.Entity.UI;
using FGUI.Entity.UI.GameMain.Entity;
using Game.Entity;
using Level.Static;
using Plant.Entity;
using Strengthen.Entity;
using UnityEngine;
using UnityEngine.Pool;

namespace Level.Manager
{
	public class CardSlotManager : MonoBehaviour
	{
		[Tooltip("卡牌集合")]
		public List<CardEntity> cardList;

		[Tooltip("嘉宾编号")]
		public int guestId;

		[Tooltip("额外卡牌")]
		public CardEntity extraCard;

		[Tooltip("隐藏卡牌集合")]
		public List<CardEntity> hiddenCardList;

		[Tooltip("传送带卡牌集合")]
		public List<int> conveyorCardIdList;

		[Tooltip("传送带中的卡牌")]
		public List<CardEntity> conveyorCurrentCardList;

		[Tooltip("传送带卡牌与原卡牌对照表")]
		public readonly Dictionary<CardEntity, CardEntity> ConveyorSourceCardDic;

		[Tooltip("出现卡牌间隔")]
		public float createCardIntervalTime;

		private float _createCardIntervalTimer;

		private float _conveyorSpeed;

		private int _conveyorCardIndex;

		[HideInInspector]
		public List<CardEntity> conveyorLeaveCardList;

		[Tooltip("种子雨卡牌集合")]
		public List<SeedCardEntity> seedCardList;

		private IObjectPool<SeedCardEntity> _seedCardPool;

		[Tooltip("阳光数量")]
		private int _sunValue;

		[Tooltip("钻石数量")]
		private float _diamondValue;

		[Tooltip("锤子次数")]
		private int _hammerValue;

		[Tooltip("阳光价值倍率")]
		public float sunValueRatio;

		[Tooltip("是否落下阳光")]
		public bool isFallSun;

		[Tooltip("落下阳光间隔")]
		public float fallSunIntervalTime;

		[HideInInspector]
		public float fallSunIntervalTimer;

		[Tooltip("卡牌是否可减冷却")]
		public bool isCooldownFlow;

		[Tooltip("卡牌大招是否可减冷却")]
		public bool isPowerCooldownFlow;

		[Tooltip("使用大招效果")]
		public EffectEntity usePowerEffect;

		[Tooltip("扣除阳光预制体")]
		public GameObject reduceSunPrefab;

		[Tooltip("扣除钻石预制体")]
		public GameObject reduceDiamondPrefab;

		[Tooltip("扣除锤子预制体")]
		public GameObject reduceHammerPrefab;

		[Tooltip("错误音效")]
		public AudioClip errorSound;

		[Tooltip("升级音效")]
		public AudioClip levelUpSound;

		[HideInInspector]
		public SelectStrengthenEntity selectStrengthenEntity;

		// TODO: unresolved private/global constants used by GetLevelUpCost and the
		// diamond-cost checks. Offsets in the pseudocode map to these level-up costs
		// (level 0/1/2/3+). Replace with the real design values when known.
		private const float LevelUpCostLevel0 = 0f;      // TODO: _DAT_18252cb28 (also used as generic 0f)
		private const float LevelUpCostLevel1 = 0f;      // TODO: _DAT_18252ce84
		private const float LevelUpCostLevel2 = 0f;      // TODO: _DAT_18252cb88
		private const float LevelUpCostLevel3Plus = 0f;  // TODO: _DAT_18252d1a0

		[Tooltip("传送带速度")]
		public float ConveyorSpeed
		{
			get
			{
				return _conveyorSpeed;
			}
			set
			{
				_conveyorSpeed = value;
				// TODO: reconstruct - original synced the animator on the current card slot
				// with the conveyor speed/direction, but GameManager has no CardSlotBox member
				// and CardSlotBoxEntity has no animatorTransform member (fabricated).
			}
		}

		public int ConveyorCardIndex
		{
			get
			{
				return _conveyorCardIndex;
			}
			set
			{
				_conveyorCardIndex = value;
			}
		}

		public IObjectPool<SeedCardEntity> SeedCardPool
		{
			get
			{
				return _seedCardPool;
			}
			set
			{
				_seedCardPool = value;
			}
		}

		[Tooltip("阳光数量")]
		public int SunValue
		{
			get
			{
				return _sunValue;
			}
			set
			{
				_sunValue = value;
				// TODO: reconstruct - original pushed the count into the current card slot's
				// sun text field, but GameManager has no CardSlotBox member and
				// CardSlotBoxEntity.GetCurrentCardSlot returns a GComponent, not a slot entity
				// with GetChild (member usage was fabricated).
			}
		}

		[Tooltip("钻石数量")]
		public float DiamondValue
		{
			get
			{
				return _diamondValue;
			}
			set
			{
				_diamondValue = value;
				if (_diamondValue < 0f)
				{
					_diamondValue = 0f;
				}
				// TODO: reconstruct - original refreshed the level-up button backgrounds for the
				// normal and conveyor cards, but this relied on GameManager.CardSlotBox (missing),
				// CardSlotBoxEntity.cardItemDic / conveyorCardComDic / SetLevelUpButtonBackground
				// (missing/inaccessible) and CardEntity.cardBaseAttrList / levelUpButton /
				// levelUpTransition (all fabricated).
			}
		}

		[Tooltip("锤子次数")]
		public int HammerValue
		{
			get
			{
				return _hammerValue;
			}
			set
			{
				_hammerValue = value;
				if (_hammerValue < 0)
				{
					_hammerValue = 0;
				}
				// TODO: reconstruct - original toggled the three tool buttons and wrote the hammer
				// count into the current card slot, but GameManager has no CardSlotBox member,
				// CardSlotBoxEntity has no GetChild, and LevelManager has no Instance / tool flags
				// (isUseSunCannon / isUseShovel / isUseHammer were fabricated).
			}
		}

		public static CardSlotManager Instance { get; private set; }

		private void Awake()
		{
			Instance = this;
		}

		private void Start()
		{
			// TODO: reconstruct - original seeded the conveyor from the level's configured
			// conveyor card id list, but LevelManager has no Instance / levelData, and there is
			// no LevelData type with isConveyor / conveyorCardIdList / mode / conveyorCardIdList2
			// (all fabricated).
		}

		private void Update()
		{
			// TODO: reconstruct - original gated on GameManager.GameState (missing member),
			// dropped falling sun via fabricated FallSun* range constants and SunEntity.targetX
			// (missing), and drove the conveyor/seed-card timers off LevelManager.Instance.levelData
			// (missing). Left as a no-op rather than fabricating those members.
		}

		public bool IsSunEnough(int value)
		{
			if (value <= _sunValue)
			{
				return true;
			}
			// TODO: reconstruct - original called GameManager.CardSlotBox.SunNotEnough(), but
			// GameManager has no CardSlotBox member.
			AudioManager.Instance.PlayUI(errorSound);
			return false;
		}

		public bool IsDiamondEnough(float value)
		{
			if (value <= _diamondValue)
			{
				return true;
			}
			// TODO: reconstruct - original called GameManager.CardSlotBox.DiamondNotEnough(), but
			// GameManager has no CardSlotBox member.
			AudioManager.Instance.PlayUI(errorSound);
			return false;
		}

		public bool IsHammerEnough(int value)
		{
			if (value <= _hammerValue)
			{
				return true;
			}
			// TODO: reconstruct - original called GameManager.CardSlotBox.HammerNotEnough(), but
			// GameManager has no CardSlotBox member.
			AudioManager.Instance.PlayUI(errorSound);
			return false;
		}

		public CardEntity AddCard(int id)
		{
			CardEntity card = GetCard(id);
			if (card != null)
			{
				return card;
			}
			card = LevelStatic.CreateCard(id);
			cardList.Add(card);
			// TODO: reconstruct - original zeroed the card's runtime attribute state and pushed it
			// onto the card slot for conveyor levels, but this relied on LevelManager.Instance.levelData
			// (missing), CardEntity.cardBaseAttr / cardBaseAttr2 / cardBaseAttrList (fabricated) and
			// GameManager.CardSlotBox (missing).
			return card;
		}

		public void RemoveCard(int id)
		{
			CardEntity target = null;
			foreach (CardEntity card in cardList)
			{
				if (card.id == id)
				{
					target = card;
					break;
				}
			}
			if (target == null)
			{
				return;
			}
			cardList.Remove(target);
			UnityEngine.Object.Destroy(target.gameObject);
			// TODO: reconstruct - original removed all conveyor entries for this id and refreshed
			// the card slot, but that relied on LevelManager.Instance.levelData (missing) and
			// GameManager.CardSlotBox (missing).
		}

		public CardEntity GetCard(int id)
		{
			foreach (CardEntity card in cardList)
			{
				if (card.id == id)
				{
					return card;
				}
			}
			return null;
		}

		public CardEntity GetHiddenCard(int cardId)
		{
			foreach (CardEntity card in hiddenCardList)
			{
				if (card.id == cardId)
				{
					return card;
				}
			}
			CardEntity newCard = LevelStatic.CreateCard(cardId);
			hiddenCardList.Add(newCard);
			return newCard;
		}

		public CardEntity AddConveyorCard(int id)
		{
			conveyorCardIdList.Add(id);
			CardEntity card = GetCard(id);
			if (card != null)
			{
				return card;
			}
			card = LevelStatic.CreateCard(id);
			cardList.Add(card);
			// TODO: reconstruct - original zeroed the card's runtime attribute state and pushed it
			// onto the card slot for conveyor levels, but this relied on LevelManager.Instance.levelData
			// (missing), CardEntity.cardBaseAttr / cardBaseAttr2 / cardBaseAttrList (fabricated) and
			// GameManager.CardSlotBox (missing).
			return card;
		}

		public CardEntity SetConveyorCard(int index, int id)
		{
			if (id == 0)
			{
				if (index < conveyorCardIdList.Count)
				{
					conveyorCardIdList.RemoveAt(index);
				}
				return null;
			}
			if (index < conveyorCardIdList.Count)
			{
				conveyorCardIdList[index] = id;
			}
			else
			{
				conveyorCardIdList.Add(id);
			}
			CardEntity card = GetCard(id);
			if (card != null)
			{
				return card;
			}
			card = LevelStatic.CreateCard(id);
			cardList.Add(card);
			// TODO: reconstruct - original zeroed the card's runtime attribute state and pushed it
			// onto the card slot for conveyor levels, but this relied on LevelManager.Instance.levelData
			// (missing), CardEntity.cardBaseAttr / cardBaseAttr2 / cardBaseAttrList (fabricated) and
			// GameManager.CardSlotBox (missing).
			return card;
		}

		public bool RemoveConveyorCard(int id)
		{
			int count = 0;
			foreach (int cardId in conveyorCardIdList)
			{
				if (cardId == id)
				{
					count++;
				}
			}
			conveyorCardIdList.Remove(id);
			if (count > 1)
			{
				return false;
			}
			RemoveCard(id);
			return true;
		}

		public int RemoveAllConveyorCard(int id)
		{
			RemoveCard(id);
			return conveyorCardIdList.RemoveAll((int cardId) => cardId == id);
		}

		private void ConveyorUpdate()
		{
			// TODO: reconstruct - original drove the conveyor update off LevelManager.Instance.levelData
			// (missing) and JoinConveyorCard, which itself depends on fabricated members.
		}

		private void ConveyorUpdateLeftCard()
		{
			// TODO: reconstruct - original refreshed every conveyor card's position and removed the
			// "leaving" cards, but that relied on GameManager.CardSlotBox (missing) and
			// CardEntity.isLeaving (fabricated).
		}

		private void JoinConveyorCard()
		{
			// TODO: reconstruct - original cloned a conveyor card, copied its runtime state and built
			// its FairyGUI component, but this relied on CardEntity.field14/field16/cardBaseAttr*/
			// plantBaseAttr* (fabricated), the non-existent ZombieCardEntity type, GameManager.CardSlotBox
			// (missing), inaccessible CardSlotBoxEntity members (GetCurrentCardItemType, InitConveyorCardItem),
			// fabricated CardSlotBoxEntity members (conveyorContainer, conveyorCardComDic, animatorTransform),
			// fabricated ConveyorCardComEntity members (conveyorPosition, startX, startY) and
			// LevelManager.Instance flags (all missing).
		}

		public void LeaveConveyorCard(CardEntity cardEntity)
		{
			if (cardEntity == null)
			{
				return;
			}
			// TODO: reconstruct - original guarded on CardEntity.isLeaving (fabricated) and called
			// GameManager.CardSlotBox.LeaveConveyorCard (missing). Preserve the list/dictionary cleanup
			// and destroy that only touch this class's real members.
			CardSlotManager.Instance.conveyorCurrentCardList.Remove(cardEntity);
			if (ConveyorSourceCardDic != null)
			{
				ConveyorSourceCardDic.Remove(cardEntity);
			}
			UnityEngine.Object.Destroy(cardEntity.gameObject);
		}

		private void SeedCardUpdate()
		{
			// TODO: reconstruct - original ticked each seed card's DurationTimer down while it was not
			// producing, but SeedCardEntity exposes IsProduce (not isProduce); the per-frame tick is
			// preserved here against the real member.
			for (int i = seedCardList.Count - 1; i >= 0; i--)
			{
				SeedCardEntity seedCard = seedCardList[i];
				if (seedCard == null)
				{
					break;
				}
				if (!seedCard.IsProduce)
				{
					seedCard.DurationTimer = seedCard.DurationTimer - Time.deltaTime;
				}
			}
		}

		public SeedCardEntity CreateSeedCard(int id, Vector2 position, bool isProduce = true)
		{
			SeedCardEntity seedCard = _seedCardPool.Get();
			seedCard.Reset(id, position, isProduce);
			seedCardList.Add(seedCard);
			return seedCard;
		}

		public void ClearSeedCard()
		{
			List<SeedCardEntity> snapshot = new List<SeedCardEntity>(seedCardList);
			foreach (SeedCardEntity seedCard in snapshot)
			{
				if (seedCard != null)
				{
					seedCard.Release();
				}
			}
		}

		private void InitSeedCardPool()
		{
			// TODO: reconstruct - original pool create/get/release actions toggled SeedCardEntity.gameObject
			// (SeedCardEntity is a plain class with no gameObject member - fabricated). Use no-op
			// get/release actions so the pool still functions against the real type.
			_seedCardPool = new ObjectPool<SeedCardEntity>(
				() =>
				{
					SeedCardEntity seedCard = new SeedCardEntity();
					seedCard.Start();
					return seedCard;
				},
				(SeedCardEntity seedCard) => { },
				(SeedCardEntity seedCard) => { },
				null,
				true,
				10,
				10000);
		}

		public void PickUpCard(CardEntity cardEntity)
		{
			if (cardEntity == null)
			{
				return;
			}
			// TODO: reconstruct - original picked up a card into the hand manager, but this relied on
			// the non-existent CardHandEntity / HandEntity (in-scope) types and fabricated members
			// HandManager.pickUpTimer, HandEntity.cardId / cardEntity, CardBaseAttr.isFree / sunCost,
			// CardEntity.cardBaseAttr and GameManager.CardSlotBox (all missing/fabricated).
			HandManager handManager = HandManager.Instance;
			handManager.DropCurrentHandEntity();
		}

		public void PickUpCard(int index)
		{
			// TODO: reconstruct - original selected conveyor vs. normal cards via
			// LevelManager.Instance.levelData.isConveyor (missing). Fall back to the normal card list.
			if (index < cardList.Count)
			{
				PickUpCard(cardList[index]);
			}
		}

		public void PickUpSeedCard(SeedCardEntity seedCardEntity)
		{
			if (seedCardEntity == null)
			{
				return;
			}
			// TODO: reconstruct - original picked up a seed card into the hand manager, but this relied
			// on the non-existent SeedCardHandEntity / HandEntity (in-scope) types and fabricated members
			// HandEntity.seedCardEntity / cardEntity / cardId and SeedCardEntity.cardEntity / id
			// (real members are SeedCardEntity.CardEntity / CardId). Left as a hand-drop no-op.
			HandManager handManager = HandManager.Instance;
			handManager.DropCurrentHandEntity();
		}

		private void FallSunUpdate()
		{
			// TODO: reconstruct - original spawned a falling sun, but this relied on the fabricated
			// FallSun* range constants and SunEntity.targetX (missing member).
		}

		public void LevelUpCard(CardEntity cardEntity)
		{
			// TODO: reconstruct - original opened the strengthen selection for a card, but this relied
			// on CardEntity.cardBaseAttrList / isLeaving (fabricated), SelectStrengthenEntity.isOpen
			// (real member is isSelected), LevelManager.Instance.levelData / mainUI (missing) and the
			// fabricated per-level strengthen list members. Left as a no-op.
		}

		public void LevelUpCard(int index)
		{
			// TODO: reconstruct - original selected conveyor vs. normal cards via
			// LevelManager.Instance.levelData.isConveyor (missing). Fall back to the normal card list.
			if (index < cardList.Count)
			{
				LevelUpCard(cardList[index]);
			}
		}

		private void OpenCardStrengthen(CardEntity cardEntity)
		{
			// TODO: reconstruct - original opened the strengthen selection, but this relied on
			// SelectStrengthenEntity.isOpen (real member is isSelected), CardEntity.cardBaseAttrList
			// (fabricated), the fabricated per-level strengthen list members and
			// LevelManager.Instance.mainUI (missing). Left as a no-op.
		}

		public void ConfirmCardStrengthen(int index)
		{
			// TODO: reconstruct - original confirmed the strengthen choice and spent diamonds, but this
			// relied on SelectStrengthenEntity.isOpen (real member is isSelected), GameManager.CardSlotBox
			// (missing) and LevelManager.Instance.mainUI (missing). Left as a no-op.
		}

		public void RevokeCardStrengthen()
		{
			// TODO: reconstruct - original closed the strengthen panel, but this relied on
			// SelectStrengthenEntity.isOpen (real member is isSelected) and LevelManager.Instance.mainUI
			// (missing). Left as a no-op.
		}

		public float GetLevelUpCost(int level)
		{
			if (level == 0)
			{
				return LevelUpCostLevel0;
			}
			if (level == 1)
			{
				return LevelUpCostLevel1;
			}
			if (level == 2)
			{
				return LevelUpCostLevel2;
			}
			return LevelUpCostLevel3Plus;
		}
	}
}
