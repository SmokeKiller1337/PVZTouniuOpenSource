using System.Collections.Generic;
using Audio.Manager;
using Common.Entity;
using FairyGUI;
using FGUI.Entity.UI;
using FGUI.Entity.UI.GameMain.Entity;
using Game.Entity;
using Level.Static;
using Plant.Entity;
using Strengthen.Entity;
using UnityEngine;
using UnityEngine.Pool;

namespace Level.Manager
{
	public class CardSlotManager : MonoBehaviour
	{
		[Tooltip("卡牌集合")]
		public List<CardEntity> cardList;

		[Tooltip("嘉宾编号")]
		public int guestId;

		[Tooltip("额外卡牌")]
		public CardEntity extraCard;

		[Tooltip("隐藏卡牌集合")]
		public List<CardEntity> hiddenCardList;

		[Tooltip("传送带卡牌集合")]
		public List<int> conveyorCardIdList;

		[Tooltip("传送带中的卡牌")]
		public List<CardEntity> conveyorCurrentCardList;

		[Tooltip("传送带卡牌与原卡牌对照表")]
		public readonly Dictionary<CardEntity, CardEntity> ConveyorSourceCardDic;

		[Tooltip("出现卡牌间隔")]
		public float createCardIntervalTime;

		private float _createCardIntervalTimer;

		private float _conveyorSpeed;

		private int _conveyorCardIndex;

		[HideInInspector]
		public List<CardEntity> conveyorLeaveCardList;

		[Tooltip("种子雨卡牌集合")]
		public List<SeedCardEntity> seedCardList;

		private IObjectPool<SeedCardEntity> _seedCardPool;

		[Tooltip("阳光数量")]
		private int _sunValue;

		[Tooltip("钻石数量")]
		private float _diamondValue;

		[Tooltip("锤子次数")]
		private int _hammerValue;

		[Tooltip("阳光价值倍率")]
		public float sunValueRatio;

		[Tooltip("是否落下阳光")]
		public bool isFallSun;

		[Tooltip("落下阳光间隔")]
		public float fallSunIntervalTime;

		[HideInInspector]
		public float fallSunIntervalTimer;

		[Tooltip("卡牌是否可减冷却")]
		public bool isCooldownFlow;

		[Tooltip("卡牌大招是否可减冷却")]
		public bool isPowerCooldownFlow;

		[Tooltip("使用大招效果")]
		public EffectEntity usePowerEffect;

		[Tooltip("扣除阳光预制体")]
		public GameObject reduceSunPrefab;

		[Tooltip("扣除钻石预制体")]
		public GameObject reduceDiamondPrefab;

		[Tooltip("扣除锤子预制体")]
		public GameObject reduceHammerPrefab;

		[Tooltip("错误音效")]
		public AudioClip errorSound;

		[Tooltip("升级音效")]
		public AudioClip levelUpSound;

		[HideInInspector]
		public SelectStrengthenEntity selectStrengthenEntity;

		private const float LevelUpCostLevel0 = 0f;
		private const float LevelUpCostLevel1 = 0f;
		private const float LevelUpCostLevel2 = 0f;
		private const float LevelUpCostLevel3Plus = 0f;

		[Tooltip("传送带速度")]
		public float ConveyorSpeed
		{
			get
			{
				return _conveyorSpeed;
			}
			set
			{
				_conveyorSpeed = value;
			}
		}

		public int ConveyorCardIndex
		{
			get
			{
				return _conveyorCardIndex;
			}
			set
			{
				_conveyorCardIndex = value;
			}
		}

		public IObjectPool<SeedCardEntity> SeedCardPool
		{
			get
			{
				return _seedCardPool;
			}
			set
			{
				_seedCardPool = value;
			}
		}

		[Tooltip("阳光数量")]
		public int SunValue
		{
			get
			{
				return _sunValue;
			}
			set
			{
				_sunValue = value;
			}
		}

		[Tooltip("钻石数量")]
		public float DiamondValue
		{
			get
			{
				return _diamondValue;
			}
			set
			{
				_diamondValue = value;
				if (_diamondValue < 0f)
				{
					_diamondValue = 0f;
				}
			}
		}

		[Tooltip("锤子次数")]
		public int HammerValue
		{
			get
			{
				return _hammerValue;
			}
			set
			{
				_hammerValue = value;
				if (_hammerValue < 0)
				{
					_hammerValue = 0;
				}
			}
		}

		public static CardSlotManager Instance { get; private set; }

		private void Awake()
		{
			Instance = this;
		}

		private void Start()
		{
		}

		private void Update()
		{
		}

		public bool IsSunEnough(int value)
		{
			if (value <= _sunValue)
			{
				return true;
			}
			AudioManager.Instance.PlayUI(errorSound);
			return false;
		}

		public bool IsDiamondEnough(float value)
		{
			if (value <= _diamondValue)
			{
				return true;
			}
			AudioManager.Instance.PlayUI(errorSound);
			return false;
		}

		public bool IsHammerEnough(int value)
		{
			if (value <= _hammerValue)
			{
				return true;
			}
			AudioManager.Instance.PlayUI(errorSound);
			return false;
		}

		public CardEntity AddCard(int id)
		{
			CardEntity card = GetCard(id);
			if (card != null)
			{
				return card;
			}
			card = LevelStatic.CreateCard(id);
			cardList.Add(card);
			return card;
		}

		public void RemoveCard(int id)
		{
			CardEntity target = null;
			foreach (CardEntity card in cardList)
			{
				if (card.id == id)
				{
					target = card;
					break;
				}
			}
			if (target == null)
			{
				return;
			}
			cardList.Remove(target);
			UnityEngine.Object.Destroy(target.gameObject);
		}

		public CardEntity GetCard(int id)
		{
			foreach (CardEntity card in cardList)
			{
				if (card.id == id)
				{
					return card;
				}
			}
			return null;
		}

		public CardEntity GetHiddenCard(int cardId)
		{
			foreach (CardEntity card in hiddenCardList)
			{
				if (card.id == cardId)
				{
					return card;
				}
			}
			CardEntity newCard = LevelStatic.CreateCard(cardId);
			hiddenCardList.Add(newCard);
			return newCard;
		}

		public CardEntity AddConveyorCard(int id)
		{
			conveyorCardIdList.Add(id);
			CardEntity card = GetCard(id);
			if (card != null)
			{
				return card;
			}
			card = LevelStatic.CreateCard(id);
			cardList.Add(card);
			return card;
		}

		public CardEntity SetConveyorCard(int index, int id)
		{
			if (id == 0)
			{
				if (index < conveyorCardIdList.Count)
				{
					conveyorCardIdList.RemoveAt(index);
				}
				return null;
			}
			if (index < conveyorCardIdList.Count)
			{
				conveyorCardIdList[index] = id;
			}
			else
			{
				conveyorCardIdList.Add(id);
			}
			CardEntity card = GetCard(id);
			if (card != null)
			{
				return card;
			}
			card = LevelStatic.CreateCard(id);
			cardList.Add(card);
			return card;
		}

		public bool RemoveConveyorCard(int id)
		{
			int count = 0;
			foreach (int cardId in conveyorCardIdList)
			{
				if (cardId == id)
				{
					count++;
				}
			}
			conveyorCardIdList.Remove(id);
			if (count > 1)
			{
				return false;
			}
			RemoveCard(id);
			return true;
		}

		public int RemoveAllConveyorCard(int id)
		{
			RemoveCard(id);
			return conveyorCardIdList.RemoveAll((int cardId) => cardId == id);
		}

		private void ConveyorUpdate()
		{
		}

		private void ConveyorUpdateLeftCard()
		{
		}

		private void JoinConveyorCard()
		{
		}

		public void LeaveConveyorCard(CardEntity cardEntity)
		{
			if (cardEntity == null)
			{
				return;
			}
			CardSlotManager.Instance.conveyorCurrentCardList.Remove(cardEntity);
			if (ConveyorSourceCardDic != null)
			{
				ConveyorSourceCardDic.Remove(cardEntity);
			}
			UnityEngine.Object.Destroy(cardEntity.gameObject);
		}

		private void SeedCardUpdate()
		{
			for (int i = seedCardList.Count - 1; i >= 0; i--)
			{
				SeedCardEntity seedCard = seedCardList[i];
				if (seedCard == null)
				{
					break;
				}
				if (!seedCard.IsProduce)
				{
					seedCard.DurationTimer = seedCard.DurationTimer - Time.deltaTime;
				}
			}
		}

		public SeedCardEntity CreateSeedCard(int id, Vector2 position, bool isProduce = true)
		{
			SeedCardEntity seedCard = _seedCardPool.Get();
			seedCard.Reset(id, position, isProduce);
			seedCardList.Add(seedCard);
			return seedCard;
		}

		public void ClearSeedCard()
		{
			List<SeedCardEntity> snapshot = new List<SeedCardEntity>(seedCardList);
			foreach (SeedCardEntity seedCard in snapshot)
			{
				if (seedCard != null)
				{
					seedCard.Release();
				}
			}
		}

		private void InitSeedCardPool()
		{
			_seedCardPool = new ObjectPool<SeedCardEntity>(
				() =>
				{
					SeedCardEntity seedCard = new SeedCardEntity();
					seedCard.Start();
					return seedCard;
				},
				(SeedCardEntity seedCard) => { },
				(SeedCardEntity seedCard) => { },
				null,
				true,
				10,
				10000);
		}

		public void PickUpCard(CardEntity cardEntity)
		{
			if (cardEntity == null)
			{
				return;
			}
			HandManager handManager = HandManager.Instance;
			handManager.DropCurrentHandEntity();
		}

		public void PickUpCard(int index)
		{
			if (index < cardList.Count)
			{
				PickUpCard(cardList[index]);
			}
		}

		public void PickUpSeedCard(SeedCardEntity seedCardEntity)
		{
			if (seedCardEntity == null)
			{
				return;
			}
			HandManager handManager = HandManager.Instance;
			handManager.DropCurrentHandEntity();
		}

		private void FallSunUpdate()
		{
		}

		public void LevelUpCard(CardEntity cardEntity)
		{
		}

		public void LevelUpCard(int index)
		{
			if (index < cardList.Count)
			{
				LevelUpCard(cardList[index]);
			}
		}

		private void OpenCardStrengthen(CardEntity cardEntity)
		{
		}

		public void ConfirmCardStrengthen(int index)
		{
		}

		public void RevokeCardStrengthen()
		{
		}

		public float GetLevelUpCost(int level)
		{
			if (level == 0)
			{
				return LevelUpCostLevel0;
			}
			if (level == 1)
			{
				return LevelUpCostLevel1;
			}
			if (level == 2)
			{
				return LevelUpCostLevel2;
			}
			return LevelUpCostLevel3Plus;
		}
	}
}
