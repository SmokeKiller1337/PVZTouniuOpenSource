using FairyGUI;
using FocusSlowMotion.Entity;
using Level.Object;
using Save.Data;
using cfg;

namespace Level.Static
{
	public static class AreaStatic
	{
		public static bool IsOpenDebug;

		public static bool IsBeta;

		public static int Mode;

		public static AreaEntity AreaEntity;

		public static AreaData.LevelData LevelData;

		public static LevelObject LevelObject;

		public static bool IsRandomDifficulty;

		public static bool IsRandomTouniuDifficulty;

		public static RecordFrameEntity SaveFrameEntity;

		static AreaStatic()
		{
		}

		public static void SetLevel(int mode, LevelObject levelObject)
		{
		}

		public static void StartLevel()
		{
		}

		public static void RestartLevel()
		{
		}

		public static void SkipLevel()
		{
		}

		public static void SkipAllLevel()
		{
		}

		public static void WinLevelResult(int inGameTime)
		{
		}

		public static void NextLevel()
		{
		}

		public static void ToSelectLevel()
		{
		}

		public static void OpenMap(GButton button, int mode, LevelObject targetLevelObject)
		{
		}

		public static float GetTotalFocusTime()
		{
			return 0f;
		}

		private static float GetDifficultyFocusTime(int difficulty)
		{
			return 0f;
		}

		public static int GetTotalTrophyValue()
		{
			return 0;
		}

		public static bool IsRandomMode()
		{
			return false;
		}

		public static void VerifyDifficulty()
		{
		}

		public static void SaveCurrentLevel()
		{
		}

		public static void RecordLevelPreparation()
		{
		}

		public static ES3Settings GetRecordSettings()
		{
			return null;
		}

		public static string GetRecordPath()
		{
			return null;
		}
	}
}
