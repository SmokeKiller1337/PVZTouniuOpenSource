using System.Collections.Generic;
using System.Text.RegularExpressions;
using Guest.Entity;
using Level.Object;
using Plant.Entity;
using Plant.Entity.Card;
using Save.Data;
using Touniu.Object;
using Zombie.Entity;

namespace Level.Static
{
	public static class LevelStatic
	{
		public static readonly Dictionary<int, CardEntity> cardDic;

		public static readonly Dictionary<int, PlantEntity> plantDic;

		public static readonly Dictionary<int, ZombieEntity> zombieDic;

		public static readonly Dictionary<int, GuestEntity> guestDic;

		public static readonly Dictionary<int, TouniuObject> touniuDic;

		public static readonly Dictionary<int, List<LevelObject>> mode0LevelObjectDic;

		public static readonly List<LevelObject> mode2LevelObjectList;

		public static readonly Regex attrPattern;

		public static readonly Dictionary<string, string> attrTitleMapping;

		static LevelStatic()
		{
		}

		public static CardEntity CreateCard(int id)
		{
			return null;
		}

		public static CardZombieEntity CreateCardZombie(int id)
		{
			return null;
		}

		public static AreaData.LevelData GetLevelData(int mode, LevelObject levelObject)
		{
			return null;
		}
	}
}
