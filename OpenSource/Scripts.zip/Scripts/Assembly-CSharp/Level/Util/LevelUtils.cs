using System.Collections.Generic;
using Building.Entity;
using Land.Entity;
using Level.Enum;
using Level.Object;
using Plant.Entity;
using Plant.Enum;
using UnityEngine;
using Zombie.Entity;

namespace Level.Util
{
	public static class LevelUtils
	{
		public static List<CardEntity> GetCardList(bool containCooldown = true)
		{
			return null;
		}

		public static CardEntity GetCard(int id = -1)
		{
			return null;
		}

		public static CardEntity GetExtraCard()
		{
			return null;
		}

		public static CardEntity SetCard(int index, int cardId)
		{
			return null;
		}

		public static CardEntity SetExtraCard(int cardId = 0)
		{
			return null;
		}

		public static Vector2 GetCardPosition(int id)
		{
			return default(Vector2);
		}

		public static Vector2 GetExtraCardPosition()
		{
			return default(Vector2);
		}

		public static Vector2 GetSunPosition()
		{
			return default(Vector2);
		}

		public static Vector2 GetDiamondPosition()
		{
			return default(Vector2);
		}

		public static Vector2 GetHammerPosition()
		{
			return default(Vector2);
		}

		public static Vector2 GetToolPosition(int toolType)
		{
			return default(Vector2);
		}

		public static Vector2 GetConveyorPosition()
		{
			return default(Vector2);
		}

		public static List<LandEntity> GetLandList(int row = -1, int column = -1)
		{
			return null;
		}

		public static LandEntity GetLand(int row = -1, int column = -1)
		{
			return null;
		}

		private static LandEntity GetExtraLand(int row)
		{
			return null;
		}

		public static LandEntity GetEmptyLand(int row = -1, int column = -1)
		{
			return null;
		}

		public static LandEntity GetEmptyLandByCardId(int id)
		{
			return null;
		}

		public static List<LandEntity> GetEmptyLandList(int id = 0)
		{
			return null;
		}

		public static LandType GetRowLandType(int row)
		{
			return default(LandType);
		}

		public static List<LawnMowerEntity> GetLawnMowerList()
		{
			return null;
		}

		public static LawnMowerEntity GetLawnMower(int row = -1)
		{
			return null;
		}

		public static List<PlantEntity> GetLandPlantList(int row = -1, int column = -1, PlaceType placeType = PlaceType.Master, bool isHasSpecial = true)
		{
			return null;
		}

		public static PlantEntity GetLandPlant(int row = -1, int column = -1, PlaceType placeType = PlaceType.Master)
		{
			return null;
		}

		public static PlantEntity GetLandPlantByType(LandEntity landEntity, PlaceType placeType)
		{
			return null;
		}

		public static List<ZombieEntity> GetLevelZombieList(bool isContainBoss = true)
		{
			return null;
		}

		public static List<ZombieEntity> GetLandZombieList()
		{
			return null;
		}

		public static List<ZombieEntity> GetLandEnemyZombieList()
		{
			return null;
		}

		public static List<ZombieEntity> GetBackgroundZombieList()
		{
			return null;
		}

		public static ZombieEntity GetNearestZombie(Vector2 position)
		{
			return null;
		}

		public static List<BuildingEntity> GetLandBuildingList()
		{
			return null;
		}

		public static BuildingEntity GetLandBuilding(int row = -1, int column = -1)
		{
			return null;
		}

		public static int GetInitSunValue(LevelObject levelObj, int mode, bool isRandomDifficulty = false)
		{
			return 0;
		}

		public static int GetInitHammerValue(LevelObject levelObj, int mode, bool isRandomTouniuDifficulty = false)
		{
			return 0;
		}

		public static Sprite GetCardSprite(int id)
		{
			return null;
		}
	}
}
