using NoSLoofah.BuffSystem;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class BuffDisplayer : MonoBehaviour
{
	private Buff buff;

	[SerializeField]
	private CanvasGroup canvasGroup;

	[SerializeField]
	private Image icon;

	[SerializeField]
	private TMP_Text text;

	public bool isWorking => buff != null && buff.IsEffective;

	public Buff Buff => buff;

	public void SetBuff(Buff bf)
	{
		buff = bf;
		if (isWorking)
		{
			return;
		}
		canvasGroup.alpha = 0f;
	}

	private void Update()
	{
		// TODO: reconstruct
		// Original reads Buff private timer/tickTimer fields (offsets 0x98/0xB4) directly
		// and formats them into a status string with unresolved literals; no public
		// accessor returns those raw values, so faithful reconstruction is not possible.
	}

	private void Show()
	{
		// TODO: reconstruct
		// Same body as Update: reads Buff private timer/tickTimer fields directly and
		// formats a status string with unresolved literals; not reliably recoverable.
	}
}
