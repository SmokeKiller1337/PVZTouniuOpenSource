using NoSLoofah.BuffSystem;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class BuffDisplayer : MonoBehaviour
{
	private Buff buff;

	[SerializeField]
	private CanvasGroup canvasGroup;

	[SerializeField]
	private Image icon;

	[SerializeField]
	private TMP_Text text;

	public bool isWorking => buff != null && buff.IsEffective;

	public Buff Buff => buff;

	public void SetBuff(Buff bf)
	{
		buff = bf;
		if (isWorking)
		{
			return;
		}
		canvasGroup.alpha = 0f;
	}

	private void Update()
	{
	}

	private void Show()
	{
	}
}
