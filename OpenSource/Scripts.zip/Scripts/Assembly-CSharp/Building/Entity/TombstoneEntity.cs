using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Level.Manager;
using UnityEngine;

namespace Building.Entity
{
	public class TombstoneEntity : BuildingEntity
	{
		[CompilerGenerated]
		private sealed class _003CAppearAnimationCoroutine_003Ed__11 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TombstoneEntity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CAppearAnimationCoroutine_003Ed__11(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("墓碑是否有出现动画")]
		public bool isAppearAnimation;

		[Tooltip("墓碑贴图集合")]
		public List<Sprite> bodySpriteList;

		[Tooltip("土地贴图集合")]
		public List<Sprite> footSpriteList;

		[Tooltip("遮罩贴图集合")]
		public List<Sprite> maskSpriteList;

		[Tooltip("墓碑渲染器")]
		public SpriteRenderer bodySpriteRenderer;

		[Tooltip("土地渲染器")]
		public SpriteRenderer footSpriteRenderer;

		[Tooltip("遮罩渲染器")]
		public SpriteMask spriteMask;

		private void OdinCreateZombie()
		{
			if (currentLandEntity != null)
			{
				ZombieManager.Instance.CreateSoilZombie(0, currentLandEntity);
			}
		}

		protected override void Awake()
		{
			// Chain to base (sets up _rigidbody), then pick a random skin index shared
			// across the three sprite lists and apply it to the body / foot renderers and the mask.
			base.Awake();

			if (bodySpriteList != null)
			{
				int index = UnityEngine.Random.Range(0, bodySpriteList.Count);

				if (bodySpriteRenderer != null)
				{
					bodySpriteRenderer.sprite = bodySpriteList[index];
				}
				if (footSpriteRenderer != null)
				{
					footSpriteRenderer.sprite = footSpriteList[index];
				}
				if (spriteMask != null)
				{
					spriteMask.sprite = maskSpriteList[index];
				}
			}

		}

		protected override void Start()
		{
		}

		protected override void Update()
		{
		}

		[IteratorStateMachine(typeof(_003CAppearAnimationCoroutine_003Ed__11))]
		private IEnumerator AppearAnimationCoroutine()
		{
			return null;
		}

		public void CreateZombie(int zombieId = 0)
		{
			if (currentLandEntity != null)
			{
				ZombieManager.Instance.CreateSoilZombie(zombieId, currentLandEntity);
			}
		}
	}
}
