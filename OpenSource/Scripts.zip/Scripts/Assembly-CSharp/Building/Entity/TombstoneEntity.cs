using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Level.Manager;
using UnityEngine;

namespace Building.Entity
{
	public class TombstoneEntity : BuildingEntity
	{
		[CompilerGenerated]
		private sealed class _003CAppearAnimationCoroutine_003Ed__11 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public TombstoneEntity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CAppearAnimationCoroutine_003Ed__11(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				// TODO: reconstruct
				// The real MoveNext (RVA 0x6E1330) plays the tombstone "appear" sequence:
				//   state 0 -> spawn ZombieManager.Instance.<soil-appear EffectEntity> at this.transform.position
				//              via GameUtils.CreateEffect(effect, position, Quaternion.identity, 1f),
				//              DOLocalMove the footSpriteRenderer to an (unrecovered) target Vector3,
				//              then `yield return new WaitForSeconds(<unrecovered duration>)`.
				//   state 1 -> DOLocalMove the bodySpriteRenderer to an (unrecovered) target Vector3, finish.
				// Left as a stub: the manager singleton field at ZombieManager+0x38, the DOTween target
				// Vector3 statics (_DAT_182e70d90) and the WaitForSeconds duration constants cannot be
				// recovered reliably from the pseudocode, so the whole sequence is not reproduced here.
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("墓碑是否有出现动画")]
		public bool isAppearAnimation;

		[Tooltip("墓碑贴图集合")]
		public List<Sprite> bodySpriteList;

		[Tooltip("土地贴图集合")]
		public List<Sprite> footSpriteList;

		[Tooltip("遮罩贴图集合")]
		public List<Sprite> maskSpriteList;

		[Tooltip("墓碑渲染器")]
		public SpriteRenderer bodySpriteRenderer;

		[Tooltip("土地渲染器")]
		public SpriteRenderer footSpriteRenderer;

		[Tooltip("遮罩渲染器")]
		public SpriteMask spriteMask;

		private void OdinCreateZombie()
		{
			// RVA 0x6DF4D0. Body is ICF-folded onto ZombieManager.CreateSoilZombie: it reads
			// this.currentLandEntity (BuildingEntity+0x38), null-guards it, then dispatches a soil-zombie
			// creation coroutine on the ZombieManager singleton with a hard-coded zombie id of 0.
			// Faithfully reproduced via the verified public API ZombieManager.CreateSoilZombie(int, LandEntity).
			if (currentLandEntity != null)
			{
				ZombieManager.Instance.CreateSoilZombie(0, currentLandEntity);
			}
		}

		protected override void Awake()
		{
			// RVA 0x6DF2B0. Chain to base (sets up _rigidbody), then pick a random skin index shared
			// across the three sprite lists and apply it to the body / foot renderers and the mask.
			base.Awake();

			if (bodySpriteList != null)
			{
				int index = UnityEngine.Random.Range(0, bodySpriteList.Count);

				if (bodySpriteRenderer != null)
				{
					bodySpriteRenderer.sprite = bodySpriteList[index];
				}
				if (footSpriteRenderer != null)
				{
					footSpriteRenderer.sprite = footSpriteList[index];
				}
				if (spriteMask != null)
				{
					spriteMask.sprite = maskSpriteList[index];
				}
			}

			// TODO: reconstruct — after applying the sprites the original also reset
			// bodySpriteRenderer.transform.localPosition and footSpriteRenderer.transform.localPosition
			// to Vector3(0, C, 0). The Y constant C (_UNK_18252cf30) could not be recovered from the
			// pseudocode, so those cosmetic local-position resets are intentionally omitted rather than
			// guessed.
		}

		protected override void Start()
		{
			// TODO: reconstruct
			// RVA 0x6DF530. When isAppearAnimation is false the original snaps bodySpriteRenderer and
			// footSpriteRenderer local positions to an unrecovered Vector3 static (_DAT_182e70d90);
			// when true it does StartCoroutine(AppearAnimationCoroutine()). Both branches depend on
			// pieces that cannot be reconstructed reliably (the Vector3 constant, and the appear
			// coroutine which is itself left as a stub), so this method is kept as a stub.
		}

		protected override void Update()
		{
			// TODO: reconstruct
			// RVA 0x6DF6A0. The original recomputes the SortingGroup order from the Y position:
			// it reads the base-class private field _rigidbody (BuildingEntity+0x40) for the fallback
			// world Y, prefers currentLandEntity.originalPosition.y when standing on a tile, then sets
			// SortingGroup.sortingOrder = RoundToInt(-y * scale) + addSortingOrder. _rigidbody is a
			// private base field with no accessible getter from this subclass, so a faithful, compilable
			// reconstruction is not possible here; kept as a stub.
		}

		[IteratorStateMachine(typeof(_003CAppearAnimationCoroutine_003Ed__11))]
		private IEnumerator AppearAnimationCoroutine()
		{
			// TODO: reconstruct
			// RVA 0x6DF240 is just the compiler-generated factory that instantiates the state machine
			// above. The actual sequence lives in _003CAppearAnimationCoroutine_003Ed__11.MoveNext,
			// which is left as a stub (see there), so this factory is likewise left returning null.
			return null;
		}

		public void CreateZombie(int zombieId = 0)
		{
			// RVA 0x6DF470. Same ICF-folded ZombieManager.CreateSoilZombie body as OdinCreateZombie, but
			// forwarding the caller-supplied zombieId instead of a hard-coded 0. It reads
			// this.currentLandEntity (BuildingEntity+0x38), null-guards it, and dispatches the soil-zombie
			// creation coroutine on the ZombieManager singleton.
			if (currentLandEntity != null)
			{
				ZombieManager.Instance.CreateSoilZombie(zombieId, currentLandEntity);
			}
		}
	}
}
