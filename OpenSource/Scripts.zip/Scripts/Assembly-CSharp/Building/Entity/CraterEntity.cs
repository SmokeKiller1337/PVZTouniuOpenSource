using System;
using System.Collections.Generic;
using Level.Enum;
using UnityEngine;

namespace Building.Entity
{
	public class CraterEntity : BuildingEntity
	{
		[Serializable]
		public struct SpriteGroup
		{
			public int key;

			public List<Sprite> sprites;
		}

		[Tooltip("弹坑贴图集合")]
		[SerializeField]
		private List<SpriteGroup> _spriteGroups = new List<SpriteGroup>();

		private Dictionary<int, List<Sprite>> _runtimeBodySpriteDic;

		[Tooltip("弹坑渲染器")]
		public SpriteRenderer bodySpriteRenderer;

		[HideInInspector]
		public float durationTime = 180f;

		private float _durationTimer;

		[HideInInspector]
		public int key;

		// ---- 占位常量：源自无法解析的全局浮点常量 (_DAT_18252cb64) ----
		// TODO: reconstruct — 这是 Update() 里用于决定弹坑切换到“后期”贴图的时间比例阈值
		//       (durationTime * _AgingSpriteThreshold <= _durationTimer 时切到序号 1 的贴图)。
		//       其真实数值来自全局常量表，无法从本类字段还原，此处仅为可编译占位。
		private const float _AgingSpriteThreshold = 0.5f;

		protected override void Awake()
		{
			// 伪代码: base.Awake(); key = 0xfffffc19 (= -999); 随后内联了 InitializeSpriteDictionary 的整段逻辑
			base.Awake();
			key = -999;
			InitializeSpriteDictionary();
		}

		public override void Reset()
		{
			// 伪代码: key = 1; 依据所在地皮类型调整 key，再根据字典查出对应贴图组，
			//         把渲染器的贴图设为该组的第 0 张（弹坑初始外观）。
			key = 1;
			if (currentLandEntity != null)
			{
				// currentLandEntity.type 在偏移 0x28，与 LandEntity.Update 中的判定一致
				int landType = (int)currentLandEntity.type;
				if (landType == (int)LandType.Water)
				{
					key = 3;
				}
				else if (landType == (int)LandType.Space)
				{
					key = 5;
				}
				// 伪代码此处还根据一个全局关卡管理器实例上的布尔标记（昼夜/变体）对 key 做 +1 调整：
				//   if (!<globalLevelManager>.Instance.<someState>.<flag>) key++;
				// 该全局单例与其内部标记无法从本类可靠解析，遵循“宁可留桩”原则不臆造成员，
				// 故此分支保留为 TODO，不改动 key。
				// TODO: reconstruct — 昼夜/变体标记导致的 key++ 调整（依赖无法解析的全局关卡管理器单例）。

				if (_runtimeBodySpriteDic != null)
				{
					if (!_runtimeBodySpriteDic.ContainsKey(key))
					{
						key = 1;
						if (!_runtimeBodySpriteDic.ContainsKey(key))
						{
							Debug.LogError(string.Format("弹坑缺少 key={0} 对应的贴图组", key));
							return;
						}
					}

					List<Sprite> sprites = _runtimeBodySpriteDic[key];
					if (sprites != null && bodySpriteRenderer != null)
					{
						bodySpriteRenderer.sprite = sprites[0];
					}
				}
			}
		}

		private void InitializeSpriteDictionary()
		{
			// 伪代码: 若运行时字典为空则新建，遍历 _spriteGroups，把每个非空且含贴图的组
			//         以其 key 存入字典；重复 key 记警告，跳过。
			if (_runtimeBodySpriteDic == null)
			{
				_runtimeBodySpriteDic = new Dictionary<int, List<Sprite>>();
				foreach (SpriteGroup group in _spriteGroups)
				{
					if (group.sprites != null && group.sprites.Count > 0)
					{
						if (_runtimeBodySpriteDic.ContainsKey(group.key))
						{
							Debug.LogWarning(string.Format("弹坑贴图组存在重复 key={0}", group.key));
						}
						else
						{
							_runtimeBodySpriteDic.Add(group.key, group.sprites);
						}
					}
				}
			}
		}

		protected override void Update()
		{
			// 伪代码: base.Update(); 若字典为空或不含当前 key 则返回；累加计时器，
			//         依据计时进度在贴图组内选择当前应显示的贴图；计时到时调用 Clear() 自毁。
			base.Update();
			if (_runtimeBodySpriteDic == null || !_runtimeBodySpriteDic.ContainsKey(key))
			{
				return;
			}

			_durationTimer += Time.deltaTime;

			List<Sprite> sprites = _runtimeBodySpriteDic[key];
			// 伪代码: bVar3 = (durationTime * _DAT_18252cb64 <= _durationTimer)，作为 0/1 的贴图序号
			int index = (durationTime * _AgingSpriteThreshold <= _durationTimer) ? 1 : 0;
			if (sprites != null)
			{
				if (index < sprites.Count)
				{
					Sprite sprite = sprites[index];
					if (sprite != null && bodySpriteRenderer != null)
					{
						bodySpriteRenderer.sprite = sprites[index];
					}
				}

				if (_durationTimer < durationTime)
				{
					return;
				}
				// 计时结束，弹坑消失（伪代码里是对自身虚表 +0x1b8 的调用，即 BuildingEntity.Clear）
				Clear();
			}
		}
	}
}
