using System;
using System.Collections.Generic;
using Level.Enum;
using UnityEngine;

namespace Building.Entity
{
	public class CraterEntity : BuildingEntity
	{
		[Serializable]
		public struct SpriteGroup
		{
			public int key;

			public List<Sprite> sprites;
		}

		[Tooltip("弹坑贴图集合")]
		[SerializeField]
		private List<SpriteGroup> _spriteGroups = new List<SpriteGroup>();

		private Dictionary<int, List<Sprite>> _runtimeBodySpriteDic;

		[Tooltip("弹坑渲染器")]
		public SpriteRenderer bodySpriteRenderer;

		[HideInInspector]
		public float durationTime = 180f;

		private float _durationTimer;

		[HideInInspector]
		public int key;

		private const float _AgingSpriteThreshold = 0.5f;

		protected override void Awake()
		{
			base.Awake();
			key = -999;
			InitializeSpriteDictionary();
		}

		public override void Reset()
		{
			key = 1;
			if (currentLandEntity != null)
			{
				// currentLandEntity.type 在偏移 0x28，与 LandEntity.Update 中的判定一致
				int landType = (int)currentLandEntity.type;
				if (landType == (int)LandType.Water)
				{
					key = 3;
				}
				else if (landType == (int)LandType.Space)
				{
					key = 5;
				}

				if (_runtimeBodySpriteDic != null)
				{
					if (!_runtimeBodySpriteDic.ContainsKey(key))
					{
						key = 1;
						if (!_runtimeBodySpriteDic.ContainsKey(key))
						{
							Debug.LogError(string.Format("弹坑缺少 key={0} 对应的贴图组", key));
							return;
						}
					}

					List<Sprite> sprites = _runtimeBodySpriteDic[key];
					if (sprites != null && bodySpriteRenderer != null)
					{
						bodySpriteRenderer.sprite = sprites[0];
					}
				}
			}
		}

		private void InitializeSpriteDictionary()
		{
			if (_runtimeBodySpriteDic == null)
			{
				_runtimeBodySpriteDic = new Dictionary<int, List<Sprite>>();
				foreach (SpriteGroup group in _spriteGroups)
				{
					if (group.sprites != null && group.sprites.Count > 0)
					{
						if (_runtimeBodySpriteDic.ContainsKey(group.key))
						{
							Debug.LogWarning(string.Format("弹坑贴图组存在重复 key={0}", group.key));
						}
						else
						{
							_runtimeBodySpriteDic.Add(group.key, group.sprites);
						}
					}
				}
			}
		}

		protected override void Update()
		{
			base.Update();
			if (_runtimeBodySpriteDic == null || !_runtimeBodySpriteDic.ContainsKey(key))
			{
				return;
			}

			_durationTimer += Time.deltaTime;

			List<Sprite> sprites = _runtimeBodySpriteDic[key];
			int index = (durationTime * _AgingSpriteThreshold <= _durationTimer) ? 1 : 0;
			if (sprites != null)
			{
				if (index < sprites.Count)
				{
					Sprite sprite = sprites[index];
					if (sprite != null && bodySpriteRenderer != null)
					{
						bodySpriteRenderer.sprite = sprites[index];
					}
				}

				if (_durationTimer < durationTime)
				{
					return;
				}
				Clear();
			}
		}
	}
}
