using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Building.Enum;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using Game.Entity;
using Game.Util;
using Level.Manager;
using Level.Util;
using UnityEngine;

namespace Building.Entity
{
	public class PotEntity : BuildingEntity
	{
		[CompilerGenerated]
		private sealed class _003CAppearAnimationCoroutine_003Ed__35 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public PotEntity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CAppearAnimationCoroutine_003Ed__35(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				PotEntity potEntity = _003C_003E4__this;
				int state = _003C_003E1__state;
				if (state == 0)
				{
					_003C_003E1__state = -1;
					// 罐子出现时，在自身位置播放第一个打碎特效
					if (potEntity.breakEffectList == null || potEntity.breakEffectList.Count == 0)
					{
						return false;
					}
					EffectEntity effect = potEntity.breakEffectList[(int)potEntity.type];
					Transform selfTransform = potEntity.transform;
					if (selfTransform == null)
					{
						return false;
					}
					Vector2 position = selfTransform.position;
					GameUtils.CreateEffect(effect, position, Quaternion.identity, AppearEffectScale);
					// 等待特效播放
					_003C_003E2__current = new WaitForSeconds(AppearWaitDuration);
					_003C_003E1__state = 1;
					return true;
				}
				if (state != 1)
				{
					return false;
				}
				_003C_003E1__state = -1;
				if (potEntity.spriteObj == null)
				{
					return false;
				}
				// 罐子体从上方缓入落下就位
				potEntity.spriteObj.transform.DOLocalMove(Vector3.zero, AppearMoveDuration);
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		// TODO: unresolved float/data constants recovered from the decompiled binary.
		// These were global data pointers with no recoverable source value; the names
		// document intent and the values are best-effort placeholders.
		private const float AppearEffectScale = 1f;        // TODO: _DAT_18252cb28
		private const float AppearWaitDuration = 0.5f;     // TODO: _DAT_18252cb64
		private const float AppearMoveDuration = 1f;       // TODO: _DAT_18252cb28
		private const float BreakEffectScale = 1f;         // TODO: _DAT_18252cb28
		private const float RewardCreateScale = 1f;        // TODO: _DAT_18252cb28
		private const float RewardSpriteScale = 0.7f;      // TODO: _DAT_18252cd0c
		private const float RewardSpriteScaleFlip = 0.7f;  // TODO: _UNK_18252cf98 (mirrored X for zombie card)
		private const float DispelColorFadeDuration = 0.5f; // TODO: _DAT_18252cb64
		private const float ZombieSpawnYOffset = 0.5f;      // TODO: _DAT_18252cb64

		// TODO: shader property name / highlight value could not be recovered from the
		// decompiled binary (data pointer _DAT_182e3b3a0). Names/values follow the
		// project's BaseBody convention for the same effect.
		private const string HighlightShaderProperty = "_HighlightIntensity";
		private const float HighlightOnValue = 1f;
		private const float HighlightOffValue = 0f;

		// TODO: Resources paths for the custom-pot sprites were string data pointers with
		// no recoverable value. Structure is preserved; paths are placeholders.
		private const string GoodCustomSpritePath = "Sprites/Pot/GoodCustom";     // TODO: _DAT_182e41188
		private const string BadCustomSpritePath = "Sprites/Pot/BadCustom";       // TODO: _DAT_182e41230
		private const string NeutralCustomSpritePath = "Sprites/Pot/NeutralCustom"; // TODO: _DAT_182e412d0
		private const string SunRewardSpritePath = "Sprites/Pot/Sun";             // TODO: _DAT_182e40fa0
		private const string DiamondRewardSpritePath = "Sprites/Pot/Diamond";     // TODO: _DAT_182e41040
		private const string HammerRewardSpritePath = "Sprites/Pot/Hammer";       // TODO: _DAT_182e410e8

		[Tooltip("是否有出现动画")]
		public bool isAppearAnimation;

		[Tooltip("罐子类型")]
		public PotType type;

		[Tooltip("是否更新透视")]
		public bool isUpdateDispel;

		[Tooltip("罐子奖励")]
		public PotRewardEntity rewardEntity;

		[Tooltip("罐子贴图集合")]
		public List<Sprite> bodySpriteList;

		[Tooltip("罐子穿透贴图集合")]
		public List<Sprite> emptySpriteList;

		[Tooltip("罐子体物体")]
		public GameObject spriteObj;

		[Tooltip("罐子体渲染器")]
		public SpriteRenderer bodySpriteRenderer;

		[Tooltip("罐子奖励渲染器")]
		public SpriteRenderer rewardSpriteRenderer;

		[Tooltip("罐子空壳渲染器")]
		public SpriteRenderer emptySpriteRenderer;

		[Tooltip("遮罩渲染器")]
		public SpriteMask spriteMask;

		[Tooltip("打碎特效")]
		public List<EffectEntity> breakEffectList;

		private Sprite _customSprite;

		private bool _isDispel;

		private TweenerCore<Color, Color, ColorOptions> _changeDispelTween;

		private float _updateDispelTimer;

		private bool _isBreak;

		public Action OnBreakPotAction;

		public Action OnPotRewardAction;

		private bool _isHighlight;

		public Sprite CustomSprite
		{
			get
			{
				return _customSprite;
			}
			set
			{
				_customSprite = value;
				// 设置自定义贴图后立即刷新奖励贴图显示
				UpdateRewardSprite();
			}
		}

		public bool IsDispel
		{
			get
			{
				return _isDispel;
			}
			set
			{
				_isDispel = value;
			}
		}

		public bool IsBreak
		{
			get
			{
				return _isBreak;
			}
			set
			{
				_isBreak = value;
			}
		}

		private void OdinBreakPot()
		{
			// Odin 编辑器调试按钮，直接触发打碎逻辑
			BreakPot();
		}

		protected override void Awake()
		{
			// 缓存子物体上的罐子体渲染器
			bodySpriteRenderer = base.GetComponentInChildren<SpriteRenderer>();
		}

		protected override void Start()
		{
			_isBreak = false;
			if (spriteObj == null)
			{
				return;
			}
			if (isAppearAnimation)
			{
				// 有出现动画：先把罐子体抬到起始高度，再启动出现协程
				spriteObj.transform.localPosition = Vector3.zero;
				UpdateRewardSprite();
				StartCoroutine(AppearAnimationCoroutine());
			}
			else
			{
				// 无出现动画：罐子体直接就位
				spriteObj.transform.localPosition = Vector3.zero;
				UpdateRewardSprite();
				spriteObj.transform.localPosition = Vector3.zero;
			}
		}

		protected override void Update()
		{
			base.Update();
			// TODO: reconstruct - 透视(dispel)检测循环依赖一个无法解析的关卡边界单例
			// (native _DAT_182e2bc20 -> 关卡数据的行/列数) 以及一个无法解析的植物类型全局引用
			// (native lRam0000000182e412b0)。项目中没有可访问的关卡边界单例(LevelManager 无 Instance /
			// levelData，GameManager 无行列数)，因此这里保留桩，不臆造成员。
			// 原逻辑：当 isUpdateDispel 为真时，按计时器周期性扫描当前地皮周围 3x3 的地皮，
			// 若相邻存在"透视"植物则将罐子体渐变为半透明，否则恢复不透明。
		}

		public void UpdateDispel()
		{
			// TODO: reconstruct - 与 Update 中的透视检测同源，依赖无法解析的关卡边界单例
			// (native _DAT_182e2bc20) 和植物类型全局引用 (native lRam0000000182e412b0)。
			// 项目中没有可访问的关卡边界单例，保留桩。
		}

		public void UpdateRewardSprite()
		{
			// 罐子体贴图按类型取，空壳贴图同样按类型取
			if (bodySpriteRenderer != null && bodySpriteList != null)
			{
				bodySpriteRenderer.sprite = bodySpriteList[(int)type];
			}
			if (emptySpriteRenderer == null || emptySpriteList == null)
			{
				return;
			}
			emptySpriteRenderer.sprite = emptySpriteList[(int)type];
			if (rewardSpriteRenderer == null)
			{
				return;
			}
			// 先清空奖励贴图
			rewardSpriteRenderer.sprite = null;
			if (_customSprite != null)
			{
				// 有自定义贴图时直接使用
				rewardSpriteRenderer.sprite = _customSprite;
				return;
			}
			// 无自定义贴图：根据奖励内容选择要显示的奖励图标
			Transform rewardTransform = rewardSpriteRenderer.transform;
			if (rewardTransform == null)
			{
				return;
			}
			rewardTransform.localScale = new Vector3(RewardSpriteScale, RewardSpriteScale, 0f);
			if (rewardEntity == null)
			{
				return;
			}
			if (rewardEntity.sunValue != 0)
			{
				rewardSpriteRenderer.sprite = Resources.Load<Sprite>(SunRewardSpritePath);
			}
			if (rewardEntity.diamondValue != 0)
			{
				rewardSpriteRenderer.sprite = Resources.Load<Sprite>(DiamondRewardSpritePath);
			}
			if (rewardEntity.hammerValue != 0)
			{
				rewardSpriteRenderer.sprite = Resources.Load<Sprite>(HammerRewardSpritePath);
			}
			if (rewardEntity.plantCardId != 0)
			{
				rewardSpriteRenderer.sprite = LevelUtils.GetCardSprite(rewardEntity.plantCardId);
			}
			if (rewardEntity.zombieCardId != 0)
			{
				rewardSpriteRenderer.sprite = LevelUtils.GetCardSprite(rewardEntity.zombieCardId + 10000);
			}
			if (rewardEntity.isHypnosisCard)
			{
				// 魅惑僵尸卡牌图标水平镜像显示
				rewardTransform.localScale = new Vector3(RewardSpriteScaleFlip, RewardSpriteScale, 0f);
			}
			if (rewardEntity.isGoodCustom)
			{
				rewardSpriteRenderer.sprite = Resources.Load<Sprite>(GoodCustomSpritePath);
			}
			if (rewardEntity.isBadCustom)
			{
				rewardSpriteRenderer.sprite = Resources.Load<Sprite>(BadCustomSpritePath);
			}
			if (rewardEntity.isNeutralCustom)
			{
				rewardSpriteRenderer.sprite = Resources.Load<Sprite>(NeutralCustomSpritePath);
			}
		}

		[IteratorStateMachine(typeof(_003CAppearAnimationCoroutine_003Ed__35))]
		private IEnumerator AppearAnimationCoroutine()
		{
			return new _003CAppearAnimationCoroutine_003Ed__35(0)
			{
				_003C_003E4__this = this
			};
		}

		public void BreakPot()
		{
			if (_isBreak)
			{
				return;
			}
			_isBreak = true;
			// 通知外部罐子被打碎
			if (OnBreakPotAction != null)
			{
				OnBreakPotAction();
			}
			if (breakEffectList == null || breakEffectList.Count == 0)
			{
				return;
			}
			// 在罐子位置播放对应类型的打碎特效
			EffectEntity effect = breakEffectList[(int)type];
			Transform selfTransform = base.transform;
			if (selfTransform == null)
			{
				return;
			}
			Vector2 position = selfTransform.position;
			GameUtils.CreateEffect(effect, position, Quaternion.identity, BreakEffectScale);
			// 发放奖励并触发死亡
			PotReward();
			Death();
		}

		private void PotReward()
		{
			if (rewardSpriteRenderer == null)
			{
				return;
			}
			Transform rewardTransform = rewardSpriteRenderer.transform;
			if (rewardTransform == null)
			{
				return;
			}
			rewardTransform.localScale = new Vector3(RewardSpriteScale, RewardSpriteScale, 0f);
			if (rewardEntity == null)
			{
				return;
			}
			// 阳光奖励
			if (rewardEntity.sunValue != 0)
			{
				RewardManager rewardManager = RewardManager.Instance;
				Transform selfTransform = base.transform;
				if (selfTransform == null || rewardEntity == null || rewardManager == null)
				{
					return;
				}
				Vector2 position = selfTransform.position;
				rewardManager.CreateSun(position, rewardEntity.sunValue, RewardCreateScale, true);
			}
			// 钻石奖励
			if (rewardEntity.diamondValue != 0)
			{
				RewardManager rewardManager = RewardManager.Instance;
				Transform selfTransform = base.transform;
				if (selfTransform == null || rewardEntity == null || rewardManager == null)
				{
					return;
				}
				Vector2 position = selfTransform.position;
				rewardManager.CreateDiamond(position, rewardEntity.diamondValue, RewardCreateScale, true);
			}
			// 锤子奖励
			if (rewardEntity.hammerValue != 0)
			{
				RewardManager rewardManager = RewardManager.Instance;
				Transform selfTransform = base.transform;
				if (selfTransform == null || rewardEntity == null || rewardManager == null)
				{
					return;
				}
				Vector2 position = selfTransform.position;
				rewardManager.CreateHammer(position, rewardEntity.hammerValue, RewardCreateScale, true);
			}
			// 植物卡牌奖励
			if (rewardEntity.plantCardId != 0)
			{
				CardSlotManager cardSlotManager = CardSlotManager.Instance;
				if (rewardEntity == null)
				{
					return;
				}
				int plantCardId = rewardEntity.plantCardId;
				Transform selfTransform = base.transform;
				if (selfTransform == null || cardSlotManager == null)
				{
					return;
				}
				Vector2 position = selfTransform.position;
				cardSlotManager.CreateSeedCard(plantCardId, position, true);
			}
			// 僵尸卡牌奖励
			if (rewardEntity != null && rewardEntity.zombieCardId != 0)
			{
				if (!rewardEntity.isHypnosisCard)
				{
					// 非魅惑：在罐子下方生成一只僵尸
					ZombieManager zombieManager = ZombieManager.Instance;
					if (rewardEntity != null && zombieManager != null)
					{
						var zombie = zombieManager.CreateZombie(rewardEntity.zombieCardId);
						if (zombie != null)
						{
							Transform zombieTransform = zombie.transform;
							Transform selfTransform = base.transform;
							if (selfTransform != null && zombieTransform != null)
							{
								Vector2 position = selfTransform.position;
								zombieTransform.position = new Vector3(position.x, position.y - ZombieSpawnYOffset, 0f);
							}
						}
					}
				}
				else
				{
					// 魅惑：作为种子雨僵尸卡牌发放
					CardSlotManager cardSlotManager = CardSlotManager.Instance;
					if (rewardEntity != null)
					{
						int zombieCardId = rewardEntity.zombieCardId;
						Transform selfTransform = base.transform;
						if (selfTransform != null && cardSlotManager != null)
						{
							Vector2 position = selfTransform.position;
							cardSlotManager.CreateSeedCard(zombieCardId + 10000, position, true);
						}
					}
				}
			}
			// 通知外部奖励已发放
			if (OnPotRewardAction != null)
			{
				OnPotRewardAction();
			}
		}

		public void Highlight(bool isHighlight = true)
		{
			if (!base.enabled)
			{
				return;
			}
			_isHighlight = isHighlight;
			float value = (isHighlight ? HighlightOnValue : HighlightOffValue);
			if (bodySpriteRenderer == null)
			{
				return;
			}
			Material bodyMaterial = bodySpriteRenderer.material;
			if (bodyMaterial == null)
			{
				return;
			}
			bodyMaterial.SetFloat(HighlightShaderProperty, value);
			if (emptySpriteRenderer == null)
			{
				return;
			}
			Material emptyMaterial = emptySpriteRenderer.material;
			if (emptyMaterial == null)
			{
				return;
			}
			emptyMaterial.SetFloat(HighlightShaderProperty, value);
			if (rewardSpriteRenderer == null)
			{
				return;
			}
			Material rewardMaterial = rewardSpriteRenderer.material;
			if (rewardMaterial == null)
			{
				return;
			}
			rewardMaterial.SetFloat(HighlightShaderProperty, value);
		}

		public void ChangeDispel(bool flag)
		{
			// 状态未变化则不重复处理
			if (_isDispel == flag)
			{
				return;
			}
			_isDispel = flag;
			// 透视时罐子体变半透明(alpha=0)，否则恢复不透明(alpha=1)
			float alpha = (flag ? 0f : 1f);
			Color targetColor = new Color(1f, 1f, 1f, alpha);
			if (_changeDispelTween != null)
			{
				_changeDispelTween.Kill();
			}
			_changeDispelTween = bodySpriteRenderer.DOColor(targetColor, DispelColorFadeDuration);
		}

		public PotEntity()
		{
			isUpdateDispel = true;
		}
	}
}
