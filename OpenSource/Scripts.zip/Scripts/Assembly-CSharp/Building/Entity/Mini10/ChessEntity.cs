using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Audio.Manager;
using DG.Tweening;
using Land.Entity;
using Level.Entity;
using Level.Manager;
using Plant.Entity;
using UnityEngine;

namespace Building.Entity.Mini10
{
	public class ChessEntity : BuildingEntity
	{
		[CompilerGenerated]
		private sealed class _003CMoveToTargetLand_003Ed__16 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public ChessEntity _003C_003E4__this;

			public LandEntity targetLand;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CMoveToTargetLand_003Ed__16(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int num = _003C_003E1__state;
				ChessEntity chess = _003C_003E4__this;
				if (num != 0)
				{
					if (num != 1)
					{
						return false;
					}
					_003C_003E1__state = -1;
					// Movement tween finished: clear the moving flag and drop the chess
					// piece onto its target land.
					if (chess == null)
					{
						return false;
					}
					chess._isMove = false;
					chess.DropLand(targetLand);
					return false;
				}
				_003C_003E1__state = -1;
				// Spend 25 sun for the move (isSun path uses the card slot manager's SunValue).
				CardSlotManager cardSlotManager = CardSlotManager.Instance;
				if (cardSlotManager == null)
				{
					return false;
				}
				cardSlotManager.SunValue -= 25;
				if (chess == null)
				{
					return false;
				}
				// Leave the "picked up" state and hide the range indicator.
				chess.isPickUp = false;
				if (chess.rangeObj != null)
				{
					chess.rangeObj.SetActive(false);
				}
				if (targetLand == null)
				{
					return false;
				}
				// Remember the building already sitting on the target land.
				chess._targetBuilding = targetLand.masterBuilding;
				// Detach from the previous land if this piece still owns its building slot.
				if (chess.currentLandEntity != null && chess.currentLandEntity.masterBuilding == chess)
				{
					chess.currentLandEntity.masterBuilding = null;
				}
				// Claim the target land and start moving.
				targetLand.masterBuilding = chess;
				chess._isMove = true;
				// Tween to the target land's position over the configured duration.
				chess.transform.DOMove(targetLand.transform.position, MoveDuration);
				_003C_003E2__current = new WaitForSeconds(MoveDuration);
				_003C_003E1__state = 1;
				return true;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		// TODO: unresolved global constants. _DAT_18252cb64 is the move/tween duration
		// used by MoveToTargetLand and as the UpdateRange refresh interval in Update.
		// Replace with the real design value when known.
		private const float MoveDuration = 0.5f; // TODO: reconstruct constant (_DAT_18252cb64)

		// Sun cost charged when a piece moves to a new land.
		private const int MoveSunCost = 25;

		[Tooltip("范围指示器")]
		public GameObject rangeObj;

		[Tooltip("是否拾取")]
		public bool isPickUp;

		[Tooltip("吃子音效")]
		public List<AudioClip> eatSoundList;

		[Tooltip("拾取音效")]
		public AudioClip pickUpSound;

		[Tooltip("放下音效")]
		public AudioClip dropSound;

		[Tooltip("是否返还阳光")]
		public bool isSun;

		protected Animator _animator;

		protected BuildingEntity _targetBuilding;

		protected bool _isMove;

		private float _updateRangeTimer;

		public Action<PlantEntity, BuildingEntity> OnEatAction;

		protected override void Awake()
		{
			base.Awake();
			if (rangeObj == null)
			{
				return;
			}
			// Range indicator starts hidden; grab the animator used for pick-up/drop clips.
			rangeObj.SetActive(false);
			_animator = GetComponent<Animator>();
		}

		protected override void Start()
		{
		}

		protected override void Update()
		{
			base.Update();
			// Only tick while the piece is picked up and not mid-move.
			if (_isMove || !isPickUp)
			{
				return;
			}
			// Periodically refresh the range indicator.
			_updateRangeTimer += Time.deltaTime;
			if (_updateRangeTimer > MoveDuration)
			{
				_updateRangeTimer = 0f;
				UpdateRange();
			}
			// While picked up, a left click with an empty hand tries to attack/move onto
			// the land nearest the cursor.
			if (!isPickUp || !Input.GetMouseButtonDown(0))
			{
				return;
			}
			if (CardSlotManager.Instance == null)
			{
				return;
			}
			if (!HandManager.Instance.IsEmptyHand)
			{
				return;
			}
			// TODO: reconstruct - the pseudocode gated the click on an unresolved helper
			// (FUN_1804178e0) reading a positive float at +0x64 before proceeding. That
			// object/member could not be identified, so the guard is dropped.
			Camera camera = Camera.main;
			if (camera == null)
			{
				return;
			}
			Vector2 worldPoint = camera.ScreenToWorldPoint(Input.mousePosition);
			CheckChessAttack(worldPoint);
		}

		protected virtual void CheckChessAttack(Vector2 position)
		{
			// Find the land whose transform is closest to the given position.
			List<LandEntity> landList = Level.Util.LevelUtils.GetLandList();
			if (landList == null)
			{
				return;
			}
			LandEntity nearest = null;
			if (landList.Count > 0)
			{
				nearest = landList[0];
			}
			float nearestDistance = NearestInitDistance;
			foreach (LandEntity land in landList)
			{
				if (land == null)
				{
					return;
				}
				Vector2 landPosition = land.transform.position;
				float distance = Vector2.Distance(landPosition, position);
				if (distance < nearestDistance)
				{
					nearest = land;
					nearestDistance = distance;
				}
			}
			// Only react if the closest land is within the allowed click radius.
			if (nearestDistance > MaxClickDistance)
			{
				return;
			}
			if (nearest == null)
			{
				return;
			}
			// Ignore a click that lands on the piece's own current land.
			if (currentLandEntity == nearest)
			{
				return;
			}
			// If the target land already holds a chess piece, don't try to move onto it.
			if (nearest.masterBuilding != null && nearest.masterBuilding is ChessEntity)
			{
				return;
			}
			if (CardSlotManager.Instance == null)
			{
				return;
			}
			// Need enough sun to make the move.
			if (CardSlotManager.Instance.SunValue > MoveSunCost)
			{
				if (!CheckMove(nearest))
				{
					return;
				}
				StartCoroutine(MoveToTargetLand(nearest));
				return;
			}
			// Not enough sun: flash the card slot's "not enough sun" feedback and play the
			// error sound.
			// TODO: reconstruct - the original reached the card-slot box UI via an
			// unresolved global (_DAT_182e73f40 -> +0x20) to call SunNotEnough(); that
			// owner could not be identified, so only the audio feedback is reproduced.
			if (AudioManager.Instance != null)
			{
				AudioManager.Instance.PlayUI(CardSlotManager.Instance.errorSound);
			}
		}

		// TODO: unresolved global constants used by CheckChessAttack.
		// _DAT_18252d134 is the initial "nearest" distance sentinel, _DAT_18252cb28 the
		// maximum click radius. Replace with the real design values when known.
		private const float NearestInitDistance = float.MaxValue; // TODO: reconstruct (_DAT_18252d134)
		private const float MaxClickDistance = 1f; // TODO: reconstruct (_DAT_18252cb28)

		protected virtual bool CheckMove(LandEntity targetLand)
		{
			// The compiled body is ICF-folded onto a stub that always returns true; the
			// real move-eligibility logic could not be recovered from the dump.
			// TODO: reconstruct - original likely validated targetLand against move rules.
			return true;
		}

		[IteratorStateMachine(typeof(_003CMoveToTargetLand_003Ed__16))]
		protected virtual IEnumerator MoveToTargetLand(LandEntity targetLand)
		{
			return new _003CMoveToTargetLand_003Ed__16(0)
			{
				_003C_003E4__this = this,
				targetLand = targetLand
			};
		}

		protected virtual void DropLand(LandEntity targetLand)
		{
			if (targetLand == null)
			{
				return;
			}
			// If the target land already has a plant or this piece is carrying a building,
			// eat what's there before settling in.
			if (targetLand.masterPlant != null || _targetBuilding != null)
			{
				EatChess(targetLand);
			}
			// Bind the piece to the land and mark the land as occupied.
			currentLandEntity = targetLand;
			targetLand.masterBuilding = this;
			// Leave the picked-up state and play the drop animation + sound.
			isPickUp = false;
			if (_animator == null)
			{
				return;
			}
			_animator.Play(DropAnimName);
			if (AudioManager.Instance == null)
			{
				return;
			}
			AudioManager.Instance.PlayUI(dropSound);
			if (rangeObj != null)
			{
				rangeObj.SetActive(false);
			}
		}

		protected virtual void EatChess(LandEntity targetLand)
		{
			// Notify listeners that this piece ate whatever was on the target land.
			if (OnEatAction != null)
			{
				if (targetLand == null)
				{
					return;
				}
				OnEatAction(targetLand.masterPlant, _targetBuilding);
			}
			// Play a random "eat" sound.
			if (AudioManager.Instance != null && eatSoundList != null && eatSoundList.Count != 0)
			{
				int index = UnityEngine.Random.Range(0, eatSoundList.Count);
				AudioManager.Instance.PlayUI(eatSoundList[index]);
			}
			if (targetLand == null)
			{
				return;
			}
			// Remove the plant currently on the land.
			if (targetLand.masterPlant != null)
			{
				targetLand.masterPlant.Clear();
			}
			// Remove the building this piece was carrying, and remember whether it was a
			// chess piece (that changes the reward payout below).
			bool ateChess = false;
			if (_targetBuilding != null)
			{
				ateChess = _targetBuilding is ChessEntity;
				_targetBuilding.Clear();
			}
			// Reward sun based on the current level difficulty.
			if (CardSlotManager.Instance == null)
			{
				return;
			}
			int sunReward = EatSunRewardDefault;
			int difficulty = CardSlotManager.Instance.guestId;
			if (difficulty == 1)
			{
				sunReward = 100;
			}
			else if (difficulty == 2)
			{
				sunReward = 75;
			}
			else if (difficulty == 3)
			{
				sunReward = 50;
			}
			else if (difficulty == 4)
			{
				sunReward = 25;
			}
			// Spawn a sun reward when a chess piece was eaten or the piece returns sun.
			if (ateChess || isSun)
			{
				if (RewardManager.Instance == null)
				{
					return;
				}
				RewardManager.Instance.CreateSun(transform.position, sunReward);
			}
			// Deal an explosion of damage at this piece's position.
			DamageTypeEntity damageType = DamageTypeEntity.Common;
			if (damageType == null)
			{
				return;
			}
			// TODO: reconstruct - the original overwrote damageType.deathType (a field at
			// +0x10) with the raw value 2 before the explosion; that maps to a DeathType
			// enum member whose name is unknown, so it is cast from the integral value.
			damageType.deathType = (Level.Enum.DeathType)2;
			Vector2 explosionPosition = transform.position;
			// TODO: reconstruct - the layer mask, radius (_DAT_18252cd10) and damage
			// (_UNK_18252d4f4) were built from unresolved globals / a LayerMask.GetMask
			// call over an unrecovered name list; placeholder constants are used so the
			// call compiles.
			int layerMask = ExplosionLayerMask;
			Bullet.Util.DamageUtils.Explosion(explosionPosition, ExplosionRadius, ExplosionDamage, layerMask, damageType);
		}

		// TODO: unresolved reward / explosion constants pulled from globals in EatChess.
		private const int EatSunRewardDefault = 200; // TODO: verify default reward
		private const int ExplosionLayerMask = -1; // TODO: reconstruct LayerMask (name list unresolved)
		private const float ExplosionRadius = 1f; // TODO: reconstruct (_DAT_18252cd10)
		private const float ExplosionDamage = 1f; // TODO: reconstruct (_UNK_18252d4f4)

		protected virtual bool HasChess(LandEntity land)
		{
			if (land == null)
			{
				return false;
			}
			// A land "has a chess piece" if it already carries a building.
			if (land.masterBuilding != null)
			{
				return true;
			}
			// Otherwise, it counts if it has a plant with a live inner reference.
			PlantEntity plant = land.masterPlant;
			if (plant == null)
			{
				return false;
			}
			// TODO: reconstruct - the original tested an inner reference on the plant at
			// PlantEntity+0x10 (op_Inequality against null). The exact member is unknown,
			// so this falls back to the plant simply existing.
			return plant != null;
		}

		public void PickUp()
		{
			// Enter the picked-up state and play the pick-up animation + sound, then show
			// and refresh the range indicator.
			isPickUp = true;
			if (_animator == null)
			{
				return;
			}
			_animator.Play(PickUpAnimName);
			if (AudioManager.Instance == null)
			{
				return;
			}
			AudioManager.Instance.PlayUI(pickUpSound);
			if (rangeObj != null)
			{
				rangeObj.SetActive(true);
				UpdateRange();
			}
		}

		public void Drop()
		{
			// Leave the picked-up state and play the drop animation + sound, then hide the
			// range indicator.
			isPickUp = false;
			if (_animator == null)
			{
				return;
			}
			_animator.Play(DropAnimName);
			if (AudioManager.Instance == null)
			{
				return;
			}
			AudioManager.Instance.PlayUI(dropSound);
			if (rangeObj != null)
			{
				rangeObj.SetActive(false);
			}
		}

		public override void OnBuildingClick()
		{
			// Toggle the picked-up state.
			bool wasPickedUp = isPickUp;
			isPickUp = !wasPickedUp;
			if (wasPickedUp)
			{
				Drop();
				return;
			}
			// Being picked up now: first drop any other chess piece that is currently
			// picked up so only one is active at a time.
			List<BuildingEntity> buildingList = Level.Util.LevelUtils.GetLandBuildingList();
			if (buildingList != null)
			{
				foreach (BuildingEntity building in buildingList)
				{
					if (building == null)
					{
						continue;
					}
					if (!(building is ChessEntity otherChess))
					{
						continue;
					}
					if (otherChess != this && otherChess.isPickUp)
					{
						otherChess.Drop();
					}
				}
			}
			// Now pick this piece up: play the pick-up animation + sound and show the range.
			isPickUp = true;
			if (_animator == null)
			{
				return;
			}
			_animator.Play(PickUpAnimName);
			if (AudioManager.Instance == null)
			{
				return;
			}
			AudioManager.Instance.PlayUI(pickUpSound);
			if (rangeObj != null)
			{
				rangeObj.SetActive(true);
				UpdateRange();
			}
		}

		protected virtual void UpdateRange()
		{
		}

		// TODO: animation state names are data pointers in the pseudocode that could not
		// be resolved to their literal strings. Replace with the real Animator state
		// names when known.
		private const string PickUpAnimName = "PickUp"; // TODO: reconstruct literal (_DAT_182e1bd00)
		private const string DropAnimName = "Drop"; // TODO: reconstruct literal (_DAT_182e788d0)
	}
}
