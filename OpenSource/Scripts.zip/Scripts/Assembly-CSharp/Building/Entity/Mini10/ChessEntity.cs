using System;
using System.Collections;
using System.Collections.Generic;
using Audio.Manager;
using DG.Tweening;
using Land.Entity;
using Level.Entity;
using Level.Manager;
using Plant.Entity;
using UnityEngine;

namespace Building.Entity.Mini10
{
	public class ChessEntity : BuildingEntity
	{
		private const float MoveDuration = 0.5f;

		// Sun cost charged when a piece moves to a new land.
		private const int MoveSunCost = 25;

		[Tooltip("范围指示器")]
		public GameObject rangeObj;

		[Tooltip("是否拾取")]
		public bool isPickUp;

		[Tooltip("吃子音效")]
		public List<AudioClip> eatSoundList;

		[Tooltip("拾取音效")]
		public AudioClip pickUpSound;

		[Tooltip("放下音效")]
		public AudioClip dropSound;

		[Tooltip("是否返还阳光")]
		public bool isSun;

		protected Animator _animator;

		protected BuildingEntity _targetBuilding;

		protected bool _isMove;

		private float _updateRangeTimer;

		public Action<PlantEntity, BuildingEntity> OnEatAction;

		protected override void Awake()
		{
			base.Awake();
			if (rangeObj == null)
			{
				return;
			}
			// Range indicator starts hidden; grab the animator used for pick-up/drop clips.
			rangeObj.SetActive(false);
			_animator = GetComponent<Animator>();
		}

		protected override void Start()
		{
		}

		protected override void Update()
		{
			base.Update();
			// Only tick while the piece is picked up and not mid-move.
			if (_isMove || !isPickUp)
			{
				return;
			}
			// Periodically refresh the range indicator.
			_updateRangeTimer += Time.deltaTime;
			if (_updateRangeTimer > MoveDuration)
			{
				_updateRangeTimer = 0f;
				UpdateRange();
			}
			// While picked up, a left click with an empty hand tries to attack/move onto
			// the land nearest the cursor.
			if (!isPickUp || !Input.GetMouseButtonDown(0))
			{
				return;
			}
			if (CardSlotManager.Instance == null)
			{
				return;
			}
			if (!HandManager.Instance.IsEmptyHand)
			{
				return;
			}
			Camera camera = Camera.main;
			if (camera == null)
			{
				return;
			}
			Vector2 worldPoint = camera.ScreenToWorldPoint(Input.mousePosition);
			CheckChessAttack(worldPoint);
		}

		protected virtual void CheckChessAttack(Vector2 position)
		{
			// Find the land whose transform is closest to the given position.
			List<LandEntity> landList = Level.Util.LevelUtils.GetLandList();
			if (landList == null)
			{
				return;
			}
			LandEntity nearest = null;
			if (landList.Count > 0)
			{
				nearest = landList[0];
			}
			float nearestDistance = NearestInitDistance;
			foreach (LandEntity land in landList)
			{
				if (land == null)
				{
					return;
				}
				Vector2 landPosition = land.transform.position;
				float distance = Vector2.Distance(landPosition, position);
				if (distance < nearestDistance)
				{
					nearest = land;
					nearestDistance = distance;
				}
			}
			// Only react if the closest land is within the allowed click radius.
			if (nearestDistance > MaxClickDistance)
			{
				return;
			}
			if (nearest == null)
			{
				return;
			}
			// Ignore a click that lands on the piece's own current land.
			if (currentLandEntity == nearest)
			{
				return;
			}
			// If the target land already holds a chess piece, don't try to move onto it.
			if (nearest.masterBuilding != null && nearest.masterBuilding is ChessEntity)
			{
				return;
			}
			if (CardSlotManager.Instance == null)
			{
				return;
			}
			// Need enough sun to make the move.
			if (CardSlotManager.Instance.SunValue > MoveSunCost)
			{
				if (!CheckMove(nearest))
				{
					return;
				}
				StartCoroutine(MoveToTargetLand(nearest));
				return;
			}
			if (AudioManager.Instance != null)
			{
				AudioManager.Instance.PlayUI(CardSlotManager.Instance.errorSound);
			}
		}

		private const float NearestInitDistance = float.MaxValue;
		private const float MaxClickDistance = 1f;

		protected virtual bool CheckMove(LandEntity targetLand)
		{
			return true;
		}

		protected virtual IEnumerator MoveToTargetLand(LandEntity targetLand)
		{
			// 扣除移动所需的 25 阳光
			CardSlotManager cardSlotManager = CardSlotManager.Instance;
			if (cardSlotManager == null)
			{
				yield break;
			}
			cardSlotManager.SunValue -= 25;
			// 退出拾取状态并隐藏范围指示器
			isPickUp = false;
			if (rangeObj != null)
			{
				rangeObj.SetActive(false);
			}
			if (targetLand == null)
			{
				yield break;
			}
			// 记录目标格子上已有的建筑
			_targetBuilding = targetLand.masterBuilding;
			// 若旧格子仍归属本棋子，则先解除占用
			if (currentLandEntity != null && currentLandEntity.masterBuilding == this)
			{
				currentLandEntity.masterBuilding = null;
			}
			// 占据目标格子并开始移动
			targetLand.masterBuilding = this;
			_isMove = true;
			// 用配置的时长补间移动到目标格子位置
			transform.DOMove(targetLand.transform.position, MoveDuration);
			yield return new WaitForSeconds(MoveDuration);
			// 移动结束：清除移动标记并把棋子放到目标格子
			_isMove = false;
			DropLand(targetLand);
		}

		protected virtual void DropLand(LandEntity targetLand)
		{
			if (targetLand == null)
			{
				return;
			}
			// If the target land already has a plant or this piece is carrying a building,
			// eat what's there before settling in.
			if (targetLand.masterPlant != null || _targetBuilding != null)
			{
				EatChess(targetLand);
			}
			// Bind the piece to the land and mark the land as occupied.
			currentLandEntity = targetLand;
			targetLand.masterBuilding = this;
			// Leave the picked-up state and play the drop animation + sound.
			isPickUp = false;
			if (_animator == null)
			{
				return;
			}
			_animator.Play(DropAnimName);
			if (AudioManager.Instance == null)
			{
				return;
			}
			AudioManager.Instance.PlayUI(dropSound);
			if (rangeObj != null)
			{
				rangeObj.SetActive(false);
			}
		}

		protected virtual void EatChess(LandEntity targetLand)
		{
			// Notify listeners that this piece ate whatever was on the target land.
			if (OnEatAction != null)
			{
				if (targetLand == null)
				{
					return;
				}
				OnEatAction(targetLand.masterPlant, _targetBuilding);
			}
			// Play a random "eat" sound.
			if (AudioManager.Instance != null && eatSoundList != null && eatSoundList.Count != 0)
			{
				int index = UnityEngine.Random.Range(0, eatSoundList.Count);
				AudioManager.Instance.PlayUI(eatSoundList[index]);
			}
			if (targetLand == null)
			{
				return;
			}
			// Remove the plant currently on the land.
			if (targetLand.masterPlant != null)
			{
				targetLand.masterPlant.Clear();
			}
			// Remove the building this piece was carrying, and remember whether it was a
			// chess piece (that changes the reward payout below).
			bool ateChess = false;
			if (_targetBuilding != null)
			{
				ateChess = _targetBuilding is ChessEntity;
				_targetBuilding.Clear();
			}
			// Reward sun based on the current level difficulty.
			if (CardSlotManager.Instance == null)
			{
				return;
			}
			int sunReward = EatSunRewardDefault;
			int difficulty = CardSlotManager.Instance.guestId;
			if (difficulty == 1)
			{
				sunReward = 100;
			}
			else if (difficulty == 2)
			{
				sunReward = 75;
			}
			else if (difficulty == 3)
			{
				sunReward = 50;
			}
			else if (difficulty == 4)
			{
				sunReward = 25;
			}
			// Spawn a sun reward when a chess piece was eaten or the piece returns sun.
			if (ateChess || isSun)
			{
				if (RewardManager.Instance == null)
				{
					return;
				}
				RewardManager.Instance.CreateSun(transform.position, sunReward);
			}
			// Deal an explosion of damage at this piece's position.
			DamageTypeEntity damageType = DamageTypeEntity.Common;
			if (damageType == null)
			{
				return;
			}
			damageType.deathType = (Level.Enum.DeathType)2;
			Vector2 explosionPosition = transform.position;
			int layerMask = ExplosionLayerMask;
			Bullet.Util.DamageUtils.Explosion(explosionPosition, ExplosionRadius, ExplosionDamage, layerMask, damageType);
		}

		// TODO: unresolved reward / explosion constants pulled from globals in EatChess.
		private const int EatSunRewardDefault = 200; // TODO: verify default reward
		private const int ExplosionLayerMask = -1;
		private const float ExplosionRadius = 1f;
		private const float ExplosionDamage = 1f;

		protected virtual bool HasChess(LandEntity land)
		{
			if (land == null)
			{
				return false;
			}
			// A land "has a chess piece" if it already carries a building.
			if (land.masterBuilding != null)
			{
				return true;
			}
			// Otherwise, it counts if it has a plant with a live inner reference.
			PlantEntity plant = land.masterPlant;
			if (plant == null)
			{
				return false;
			}
			return plant != null;
		}

		public void PickUp()
		{
			// Enter the picked-up state and play the pick-up animation + sound, then show
			// and refresh the range indicator.
			isPickUp = true;
			if (_animator == null)
			{
				return;
			}
			_animator.Play(PickUpAnimName);
			if (AudioManager.Instance == null)
			{
				return;
			}
			AudioManager.Instance.PlayUI(pickUpSound);
			if (rangeObj != null)
			{
				rangeObj.SetActive(true);
				UpdateRange();
			}
		}

		public void Drop()
		{
			// Leave the picked-up state and play the drop animation + sound, then hide the
			// range indicator.
			isPickUp = false;
			if (_animator == null)
			{
				return;
			}
			_animator.Play(DropAnimName);
			if (AudioManager.Instance == null)
			{
				return;
			}
			AudioManager.Instance.PlayUI(dropSound);
			if (rangeObj != null)
			{
				rangeObj.SetActive(false);
			}
		}

		public override void OnBuildingClick()
		{
			// Toggle the picked-up state.
			bool wasPickedUp = isPickUp;
			isPickUp = !wasPickedUp;
			if (wasPickedUp)
			{
				Drop();
				return;
			}
			// Being picked up now: first drop any other chess piece that is currently
			// picked up so only one is active at a time.
			List<BuildingEntity> buildingList = Level.Util.LevelUtils.GetLandBuildingList();
			if (buildingList != null)
			{
				foreach (BuildingEntity building in buildingList)
				{
					if (building == null)
					{
						continue;
					}
					if (!(building is ChessEntity otherChess))
					{
						continue;
					}
					if (otherChess != this && otherChess.isPickUp)
					{
						otherChess.Drop();
					}
				}
			}
			// Now pick this piece up: play the pick-up animation + sound and show the range.
			isPickUp = true;
			if (_animator == null)
			{
				return;
			}
			_animator.Play(PickUpAnimName);
			if (AudioManager.Instance == null)
			{
				return;
			}
			AudioManager.Instance.PlayUI(pickUpSound);
			if (rangeObj != null)
			{
				rangeObj.SetActive(true);
				UpdateRange();
			}
		}

		protected virtual void UpdateRange()
		{
		}

		private const string PickUpAnimName = "PickUp";
		private const string DropAnimName = "Drop";
	}
}
