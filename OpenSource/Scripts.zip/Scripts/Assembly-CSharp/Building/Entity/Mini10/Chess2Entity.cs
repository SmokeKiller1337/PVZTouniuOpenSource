using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Bullet.Entity;
using Bullet.Manager;
using Bullet.Util;
using Land.Entity;
using Level.Entity;
using Level.Enum;
using Level.Util;
using UnityEngine;
using Zombie.Entity;

namespace Building.Entity.Mini10
{
	public class Chess2Entity : ChessEntity
	{
		[CompilerGenerated]
		private sealed class _003CPeaAttack_003Ed__7 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Chess2Entity _003C_003E4__this;

			private int _003Ci_003E5__2;

			// 豌豆连射间隔（秒）。伪代码使用全局常量 _DAT_18252cb80，无法解析其真实值，
			// 取一个与豌豆射手节奏相近的占位值。
			// TODO: resolve the real shot interval constant (_DAT_18252cb80).
			private const float PeaShotInterval = 0.2f;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return _003C_003E2__current;
				}
			}

			[DebuggerHidden]
			public _003CPeaAttack_003Ed__7(int _003C_003E1__state)
			{
				this._003C_003E1__state = _003C_003E1__state;
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				int state = _003C_003E1__state;
				Chess2Entity self = _003C_003E4__this;
				if (state == 0)
				{
					_003C_003E1__state = -1;
					_003Ci_003E5__2 = 0;
				}
				else if (state == 1)
				{
					_003C_003E1__state = -1;
					_003Ci_003E5__2++;
				}
				else
				{
					return false;
				}

				if (_003Ci_003E5__2 >= 10)
				{
					return false;
				}

				// 以自身当前世界坐标寻找最近的僵尸，找不到就结束连射
				Vector2 selfPos = self.transform.position;
				ZombieEntity zombie = LevelUtils.GetNearestZombie(selfPos);
				if (zombie == null)
				{
					return false;
				}

				Vector2 targetPos = zombie.GetPosition();
				BulletManager manager = BulletManager.Instance;
				if (manager == null)
				{
					return false;
				}

				BulletEntity bullet = manager.CreateBullet(self.peaBulletAttr);
				if (bullet != null)
				{
					// 子弹落在棋子当前位置（z 归零），朝目标旋转后初始化
					Vector3 p = self.transform.position;
					bullet.transform.position = new Vector3(p.x, p.y, 0f);
					bullet.RotationToTarget(targetPos);
					bullet.Init();

					_003C_003E2__current = new WaitForSeconds(PeaShotInterval);
					_003C_003E1__state = 1;
					return true;
				}

				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
				throw new NotSupportedException();
			}
		}

		[Tooltip("启用蹩马腿规则")]
		public bool isHobble;

		[Tooltip("是否附带豌豆")]
		public bool isPea;

		[Tooltip("豌豆子弹")]
		public BulletAttr peaBulletAttr;

		[Tooltip("范围指示器物体集合")]
		public List<GameObject> rangeItemObjList;

		// 马（象棋）的 8 个“日”字跳跃偏移：{ 行偏移, 列偏移 }
		// 伪代码 UpdateRange 内以 RuntimeHelpers.InitializeArray 初始化的 8x2 常量表。
		private static readonly int[,] KnightOffsets = new int[8, 2]
		{
			{ 1, 2 }, { 1, -2 }, { -1, 2 }, { -1, -2 },
			{ 2, 1 }, { 2, -1 }, { -2, 1 }, { -2, -1 }
		};

		protected override bool CheckMove(LandEntity targetLand)
		{
			LandEntity current = currentLandEntity;
			if (current == null || targetLand == null)
			{
				return false;
			}

			// 象棋“马”走日：行、列偏移必须是 (1,2) 或 (2,1)
			int rowDelta = Mathf.Abs(targetLand.rowId - current.rowId);
			int columnDelta = Mathf.Abs(targetLand.columnId - current.columnId);

			if (rowDelta == 1)
			{
				if (columnDelta != 2)
				{
					return false;
				}
			}
			else
			{
				if (rowDelta != 2 || columnDelta != 1)
				{
					return false;
				}
			}

			// 蹩马腿：长边中点的相邻格若已有棋子，则该方向被别住，不能走
			if (isHobble)
			{
				int legRow = current.rowId;
				int legColumn = current.columnId;
				if (rowDelta == 2)
				{
					legRow = current.rowId + (targetLand.rowId - current.rowId) / 2;
				}
				else if (columnDelta == 2)
				{
					legColumn = current.columnId + (targetLand.columnId - current.columnId) / 2;
				}

				LandEntity legLand = LevelUtils.GetLand(legRow, legColumn);
				if (legLand != null && HasChess(legLand))
				{
					return false;
				}
			}

			return true;
		}

		protected override void EatChess(LandEntity targetLand)
		{
			base.EatChess(targetLand);
			if (isPea)
			{
				StartCoroutine(PeaAttack());
			}
		}

		protected override void DropLand(LandEntity targetLand)
		{
			if (targetLand == null)
			{
				return;
			}

			// 目标地皮上已有植物，或本棋子已锁定了一个待吃建筑，则先执行吃子
			if (targetLand.masterPlant != null || _targetBuilding != null)
			{
				EatChess(targetLand);
			}

			// 绑定棋子与地皮的相互引用，然后落子
			currentLandEntity = targetLand;
			targetLand.masterBuilding = this;
			Drop();

			// 落子处产生一次爆炸伤害
			DamageTypeEntity damageType = DamageTypeEntity.Common;
			if (damageType == null)
			{
				return;
			}
			damageType.damageType = (DamageType)2;

			Vector2 position = transform.position;
			// 伪代码用 LayerMask.GetMask(...) 计算目标层，具体层名字符串与半径/伤害
			// 均来自无法解析的全局常量，保留占位并标注。
			// TODO: resolve explosion layer name(s) / radius / damage globals.
			int layerMask = LayerMask.GetMask("Zombie");
			DamageUtils.Explosion(position, ExplosionRadius, ExplosionDamage, layerMask, damageType);
		}

		// 落子爆炸的半径与伤害：伪代码取自全局常量 _DAT_18252cd10 / _DAT_18252cb6c，
		// 无法解析真实数值，使用占位常量。
		// TODO: resolve explosion radius/damage globals (_DAT_18252cd10 / _DAT_18252cb6c).
		private const float ExplosionRadius = 1f;

		private const float ExplosionDamage = 1800f;

		[IteratorStateMachine(typeof(_003CPeaAttack_003Ed__7))]
		private IEnumerator PeaAttack()
		{
			return new _003CPeaAttack_003Ed__7(0)
			{
				_003C_003E4__this = this
			};
		}

		protected override void UpdateRange()
		{
			if (rangeItemObjList == null)
			{
				return;
			}

			// 先隐藏所有范围指示器
			foreach (GameObject item in rangeItemObjList)
			{
				if (item == null)
				{
					return;
				}
				item.SetActive(false);
			}

			// 读取棋盘尺寸参数（最大行、最大列、以及两个坐标换算系数）。
			// 伪代码通过全局关卡管理器单例读取棋盘配置，这些字段无法可靠映射，
			// 因此棋盘边界与坐标缩放系数用占位常量，仅保留“可走的日字格点亮指示器”的核心逻辑。
			// TODO: resolve board manager singleton fields (maxRow / maxColumn / cell scale x&y).
			int maxRow = BoardMaxRow;
			int maxColumn = BoardMaxColumn;
			float cellScaleX = BoardCellScaleX;
			float cellScaleY = BoardCellScaleY;

			LandEntity current = currentLandEntity;
			if (current == null)
			{
				return;
			}

			int baseRow = current.rowId;
			int baseColumn = current.columnId;
			int shown = 0;

			for (int i = 0; i < 8; i++)
			{
				int targetRow = baseRow + KnightOffsets[i, 0];
				int targetColumn = baseColumn + KnightOffsets[i, 1];

				if (targetRow <= 0 || targetRow > maxRow || targetColumn <= 0 || targetColumn > maxColumn)
				{
					continue;
				}

				LandEntity land = LevelUtils.GetLand(targetRow, targetColumn);
				if (land == null || !CheckMove(land))
				{
					continue;
				}

				if (shown >= rangeItemObjList.Count)
				{
					continue;
				}

				GameObject indicator = rangeItemObjList[shown];
				if (indicator == null)
				{
					return;
				}

				indicator.SetActive(true);
				Transform indicatorTransform = indicator.transform;
				Vector3 local = indicatorTransform.localPosition;
				// 伪代码按目标格的行列与缩放系数计算指示器本地坐标，保持原 z 不变
				indicatorTransform.localPosition = new Vector3(
					KnightOffsets[i, 0] * cellScaleX,
					KnightOffsets[i, 1] * cellScaleY,
					local.z);
				shown++;
			}
		}

		// 棋盘边界与格距缩放：伪代码从全局关卡/棋盘管理器单例读取，无法可靠解析，使用占位常量。
		// TODO: resolve board dimensions and per-cell scale from the level/board manager singleton.
		private const int BoardMaxRow = 9;

		private const int BoardMaxColumn = 9;

		private const float BoardCellScaleX = 1f;

		private const float BoardCellScaleY = 1f;
	}
}
