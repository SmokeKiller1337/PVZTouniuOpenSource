using System;
using System.Collections;
using System.Collections.Generic;
using Bullet.Entity;
using Bullet.Manager;
using Bullet.Util;
using Land.Entity;
using Level.Entity;
using Level.Enum;
using Level.Util;
using UnityEngine;
using Zombie.Entity;

namespace Building.Entity.Mini10
{
	public class Chess2Entity : ChessEntity
	{
		[Tooltip("启用蹩马腿规则")]
		public bool isHobble;

		[Tooltip("是否附带豌豆")]
		public bool isPea;

		[Tooltip("豌豆子弹")]
		public BulletAttr peaBulletAttr;

		[Tooltip("范围指示器物体集合")]
		public List<GameObject> rangeItemObjList;

		private static readonly int[,] KnightOffsets = new int[8, 2]
		{
			{ 1, 2 }, { 1, -2 }, { -1, 2 }, { -1, -2 },
			{ 2, 1 }, { 2, -1 }, { -2, 1 }, { -2, -1 }
		};

		protected override bool CheckMove(LandEntity targetLand)
		{
			LandEntity current = currentLandEntity;
			if (current == null || targetLand == null)
			{
				return false;
			}

			// 象棋“马”走日：行、列偏移必须是 (1,2) 或 (2,1)
			int rowDelta = Mathf.Abs(targetLand.rowId - current.rowId);
			int columnDelta = Mathf.Abs(targetLand.columnId - current.columnId);

			if (rowDelta == 1)
			{
				if (columnDelta != 2)
				{
					return false;
				}
			}
			else
			{
				if (rowDelta != 2 || columnDelta != 1)
				{
					return false;
				}
			}

			// 蹩马腿：长边中点的相邻格若已有棋子，则该方向被别住，不能走
			if (isHobble)
			{
				int legRow = current.rowId;
				int legColumn = current.columnId;
				if (rowDelta == 2)
				{
					legRow = current.rowId + (targetLand.rowId - current.rowId) / 2;
				}
				else if (columnDelta == 2)
				{
					legColumn = current.columnId + (targetLand.columnId - current.columnId) / 2;
				}

				LandEntity legLand = LevelUtils.GetLand(legRow, legColumn);
				if (legLand != null && HasChess(legLand))
				{
					return false;
				}
			}

			return true;
		}

		protected override void EatChess(LandEntity targetLand)
		{
			base.EatChess(targetLand);
			if (isPea)
			{
				StartCoroutine(PeaAttack());
			}
		}

		protected override void DropLand(LandEntity targetLand)
		{
			if (targetLand == null)
			{
				return;
			}

			// 目标地皮上已有植物，或本棋子已锁定了一个待吃建筑，则先执行吃子
			if (targetLand.masterPlant != null || _targetBuilding != null)
			{
				EatChess(targetLand);
			}

			// 绑定棋子与地皮的相互引用，然后落子
			currentLandEntity = targetLand;
			targetLand.masterBuilding = this;
			Drop();

			// 落子处产生一次爆炸伤害
			DamageTypeEntity damageType = DamageTypeEntity.Common;
			if (damageType == null)
			{
				return;
			}
			damageType.damageType = (DamageType)2;

			Vector2 position = transform.position;
			int layerMask = LayerMask.GetMask("Zombie");
			DamageUtils.Explosion(position, ExplosionRadius, ExplosionDamage, layerMask, damageType);
		}

		private const float ExplosionRadius = 1f;

		private const float ExplosionDamage = 1800f;

		private IEnumerator PeaAttack()
		{
			const float PeaShotInterval = 0.2f;

			// 最多连射 10 发豌豆，每发之间间隔 PeaShotInterval 秒
			for (int i = 0; i < 10; i++)
			{
				// 以自身当前世界坐标寻找最近的僵尸，找不到就结束连射
				Vector2 selfPos = transform.position;
				ZombieEntity zombie = LevelUtils.GetNearestZombie(selfPos);
				if (zombie == null)
				{
					yield break;
				}

				Vector2 targetPos = zombie.GetPosition();
				BulletManager manager = BulletManager.Instance;
				if (manager == null)
				{
					yield break;
				}

				BulletEntity bullet = manager.CreateBullet(peaBulletAttr);
				if (bullet == null)
				{
					yield break;
				}

				// 子弹落在棋子当前位置（z 归零），朝目标旋转后初始化
				Vector3 p = transform.position;
				bullet.transform.position = new Vector3(p.x, p.y, 0f);
				bullet.RotationToTarget(targetPos);
				bullet.Init();

				yield return new WaitForSeconds(PeaShotInterval);
			}
		}

		protected override void UpdateRange()
		{
			if (rangeItemObjList == null)
			{
				return;
			}

			// 先隐藏所有范围指示器
			foreach (GameObject item in rangeItemObjList)
			{
				if (item == null)
				{
					return;
				}
				item.SetActive(false);
			}

			int maxRow = BoardMaxRow;
			int maxColumn = BoardMaxColumn;
			float cellScaleX = BoardCellScaleX;
			float cellScaleY = BoardCellScaleY;

			LandEntity current = currentLandEntity;
			if (current == null)
			{
				return;
			}

			int baseRow = current.rowId;
			int baseColumn = current.columnId;
			int shown = 0;

			for (int i = 0; i < 8; i++)
			{
				int targetRow = baseRow + KnightOffsets[i, 0];
				int targetColumn = baseColumn + KnightOffsets[i, 1];

				if (targetRow <= 0 || targetRow > maxRow || targetColumn <= 0 || targetColumn > maxColumn)
				{
					continue;
				}

				LandEntity land = LevelUtils.GetLand(targetRow, targetColumn);
				if (land == null || !CheckMove(land))
				{
					continue;
				}

				if (shown >= rangeItemObjList.Count)
				{
					continue;
				}

				GameObject indicator = rangeItemObjList[shown];
				if (indicator == null)
				{
					return;
				}

				indicator.SetActive(true);
				Transform indicatorTransform = indicator.transform;
				Vector3 local = indicatorTransform.localPosition;
				indicatorTransform.localPosition = new Vector3(
					KnightOffsets[i, 0] * cellScaleX,
					KnightOffsets[i, 1] * cellScaleY,
					local.z);
				shown++;
			}
		}

		private const int BoardMaxRow = 9;

		private const int BoardMaxColumn = 9;

		private const float BoardCellScaleX = 1f;

		private const float BoardCellScaleY = 1f;
	}
}
