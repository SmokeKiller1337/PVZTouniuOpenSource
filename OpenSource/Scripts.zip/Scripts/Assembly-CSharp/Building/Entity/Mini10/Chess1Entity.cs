using Land.Entity;
using Level.Util;
using UnityEngine;

namespace Building.Entity.Mini10
{
	public class Chess1Entity : ChessEntity
	{
		[Tooltip("是否附带爆炸")]
		public bool isExplode;

		protected override bool CheckMove(LandEntity targetLand)
		{
			LandEntity currentLand = currentLandEntity;
			if (currentLand == null || targetLand == null)
			{
				return false;
			}
			int selfRow = currentLand.rowId;
			int selfColumn = currentLand.columnId;
			int targetRow = targetLand.rowId;
			int targetColumn = targetLand.columnId;
			// Must share a row or a column, otherwise the move is illegal.
			if (selfRow != targetRow && selfColumn != targetColumn)
			{
				return false;
			}
			int betweenCount = 0;
			bool targetHasChess = HasChess(targetLand);
			bool counted = false;
			if (selfRow == targetRow)
			{
				// Same row: scan the columns strictly between source and target.
				int min = (targetColumn <= selfColumn) ? targetColumn : selfColumn;
				int max = (selfColumn <= targetColumn) ? targetColumn : selfColumn;
				for (int column = min + 1; column < max; column++)
				{
					LandEntity land = LevelUtils.GetLand(selfRow, column);
					if (land != null && HasChess(land))
					{
						betweenCount++;
					}
				}
				counted = min + 1 < max;
			}
			else if (selfColumn == targetColumn)
			{
				// Same column: scan the rows strictly between source and target.
				int min = (targetRow <= selfRow) ? targetRow : selfRow;
				int max = (selfRow <= targetRow) ? targetRow : selfRow;
				for (int row = min + 1; row < max; row++)
				{
					LandEntity land = LevelUtils.GetLand(row, selfColumn);
					if (land != null && HasChess(land))
					{
						betweenCount++;
					}
				}
				counted = min + 1 < max;
			}
			if (counted && betweenCount != 0)
			{
				// A capture requires exactly one chess in between and a chess on the target.
				return targetHasChess && betweenCount == 1;
			}
			// Path between is clear: a plain move is allowed only onto an empty land.
			if (!targetHasChess)
			{
				return true;
			}
			return targetHasChess && betweenCount == 1;
		}

		protected override void EatChess(LandEntity targetLand)
		{
			base.EatChess(targetLand);
			if (!isExplode)
			{
				return;
			}
			// TODO: reconstruct — when isExplode is set the original spawns an explosion
			// effect at this chess' position and calls Bullet.Util.DamageUtils.Explosion.
			// The effect asset, blast radius/damage constants and layer-mask string are
			// resolved from an unidentified config singleton in the decompilation and
			// cannot be recovered reliably, so the explosion is intentionally left unimplemented.
		}
	}
}
