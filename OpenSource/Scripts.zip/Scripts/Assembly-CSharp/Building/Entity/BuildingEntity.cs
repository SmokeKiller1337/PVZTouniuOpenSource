using System;
using Land.Entity;
using UnityEngine;
using UnityEngine.Rendering;

namespace Building.Entity
{
	public class BuildingEntity : MonoBehaviour
	{
		[Tooltip("编号")]
		public int id;

		[Tooltip("名称")]
		public string title;

		[Tooltip("优先级")]
		public int priority;

		[HideInInspector]
		public LandEntity currentLandEntity;

		private Rigidbody2D _rigidbody;

		private SortingGroup _sortingGroup;

		[HideInInspector]
		public int addSortingOrder;

		public Action OnDeathAction;

		public LandEntity CurrentLandEntity
		{
			get
			{
				// get_CurrentLandEntity: return *(param_1 + 0x38) == currentLandEntity
				return currentLandEntity;
			}
			set
			{
				// set_CurrentLandEntity: *(param_1 + 0x38) = value
				currentLandEntity = value;
			}
		}

		public SortingGroup SortingGroup
		{
			get
			{
				// get_SortingGroup: return *(param_1 + 0x48) == _sortingGroup
				return _sortingGroup;
			}
			set
			{
				// set_SortingGroup: *(param_1 + 0x48) = value
				_sortingGroup = value;
			}
		}

		public virtual void Reset()
		{
			// RVA 0x381980 — shared empty body (same address as the empty .ctor stub).
		}

		protected virtual void Awake()
		{
			// _rigidbody (0x40) = GetComponentInChildren<Rigidbody2D>()
			_rigidbody = GetComponentInChildren<Rigidbody2D>();
		}

		protected virtual void Start()
		{
			// RVA 0x381980 — shared empty body.
		}

		protected virtual void Update()
		{
			// _rigidbody (0x40): if null, do nothing.
			if (_rigidbody == null)
			{
				return;
			}

			// Base Y from the rigidbody world position; if this building sits on a land
			// tile, use that tile's cached originalPosition.y (LandEntity+0x64) instead.
			float y = _rigidbody.position.y;
			if (currentLandEntity != null)
			{
				y = currentLandEntity.originalPosition.y;
			}

			// _sortingGroup (0x48): recompute sorting order from Y.
			// order = RoundToInt(-y * scale) + addSortingOrder  (addSortingOrder @ 0x50)
			if (_sortingGroup != null)
			{
				int order = Mathf.RoundToInt(-y * SortingOrderScale) + addSortingOrder;
				_sortingGroup.sortingOrder = order;
			}
		}

		public virtual void Death()
		{
			// Virtual slot 0x1c8 -> DeathHandle (slot 9); slot 0x1e8 -> ClearLand (slot 11);
			// then Destroy(this.gameObject). Mirrors PlantEntity.Death().
			DeathHandle();
			ClearLand();
			UnityEngine.Object.Destroy(gameObject);
		}

		public virtual void DeathHandle()
		{
			// OnDeathAction (0x58) invocation.
			if (OnDeathAction != null)
			{
				OnDeathAction();
			}
		}

		public virtual void Clear()
		{
			// Virtual slot 0x1b8 -> Death (slot 8).
			Death();
		}

		public virtual void ClearLand()
		{
			// currentLandEntity (0x38): detach this building from its land tile.
			if (currentLandEntity != null)
			{
				// If the tile still points back to this building (LandEntity.masterBuilding @ 0x50), clear it.
				if (currentLandEntity.masterBuilding == this)
				{
					currentLandEntity.masterBuilding = null;
				}
				currentLandEntity = null;
			}
		}

		public virtual void OnBuildingClick()
		{
			// RVA 0x381980 — shared empty body.
		}

		public virtual void OnBuildingEnter()
		{
			// RVA 0x381980 — shared empty body.
		}

		public virtual void OnBuildingExit()
		{
			// RVA 0x381980 — shared empty body.
		}

		// TODO: unresolved global constant (_DAT_18252cb6c) used to convert world Y to
		// sorting order. Matches PlantEntity's SortingOrderScale = 100f pattern.
		private const float SortingOrderScale = 100f; // TODO: reconstruct constant
	}
}
