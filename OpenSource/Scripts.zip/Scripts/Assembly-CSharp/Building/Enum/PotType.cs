namespace Building.Enum
{
	public enum PotType
	{
		Common = 0,
		Plant = 1,
		Zombie = 2,
		Reform = 3
	}
}
