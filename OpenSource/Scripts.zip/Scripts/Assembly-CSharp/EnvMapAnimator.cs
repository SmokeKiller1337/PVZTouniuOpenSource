using System.Collections;
using TMPro;
using UnityEngine;

public class EnvMapAnimator : MonoBehaviour
{
	public Vector3 RotationSpeeds;

	private TMP_Text m_textMeshPro;

	private Material m_material;

	private void Awake()
	{
		this.m_textMeshPro = base.GetComponent<TMP_Text>();
	}

	private IEnumerator Start()
	{
		// 每帧根据旋转速度更新材质的环境贴图旋转矩阵，直到材质为空
		Matrix4x4 matrix = default(Matrix4x4);
		while (true)
		{
			Vector3 euler = new Vector3(RotationSpeeds.x * Time.time, RotationSpeeds.y * Time.time, RotationSpeeds.z * Time.time);
			matrix.SetTRS(Vector3.zero, Quaternion.Euler(euler), Vector3.one);
			if (m_material == null)
			{
				break;
			}
			m_material.SetMatrix("_EnvMapRotation", matrix);
			yield return null;
		}
	}
}
