using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using TMPro;
using UnityEngine;

public class EnvMapAnimator : MonoBehaviour
{
	[CompilerGenerated]
	private sealed class _003CStart_003Ed__4 : IEnumerator<object>, IEnumerator, IDisposable
	{
		private int _003C_003E1__state;

		private object _003C_003E2__current;

		public EnvMapAnimator _003C_003E4__this;

		private Matrix4x4 _003Cmatrix_003E5__2;

		object IEnumerator<object>.Current
		{
			[DebuggerHidden]
			get
			{
				return this._003C_003E2__current;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return this._003C_003E2__current;
			}
		}

		[DebuggerHidden]
		public _003CStart_003Ed__4(int _003C_003E1__state)
		{
			this._003C_003E1__state = _003C_003E1__state;
		}

		[DebuggerHidden]
		void IDisposable.Dispose()
		{
		}

		private bool MoveNext()
		{
			int num = this._003C_003E1__state;
			EnvMapAnimator envMapAnimator = this._003C_003E4__this;
			if (num != 0)
			{
				if (num != 1)
				{
					return false;
				}
				this._003C_003E1__state = -1;
			}
			else
			{
				this._003C_003E1__state = -1;
				this._003Cmatrix_003E5__2 = default(Matrix4x4);
			}
			Vector3 s = new Vector3(envMapAnimator.RotationSpeeds.x * Time.time, envMapAnimator.RotationSpeeds.y * Time.time, envMapAnimator.RotationSpeeds.z * Time.time);
			this._003Cmatrix_003E5__2.SetTRS(Vector3.zero, Quaternion.Euler(s), Vector3.one);
			if (envMapAnimator.m_material != null)
			{
				// TODO: reconstruct - shader property name is a string literal not recoverable from project artifacts (uses canonical AllIn1SpriteShader name)
				envMapAnimator.m_material.SetMatrix("_EnvMapRotation", this._003Cmatrix_003E5__2);
				this._003C_003E2__current = null;
				this._003C_003E1__state = 1;
				return true;
			}
			return false;
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			return this.MoveNext();
		}

		[DebuggerHidden]
		void IEnumerator.Reset()
		{
			throw new NotSupportedException();
		}
	}

	public Vector3 RotationSpeeds;

	private TMP_Text m_textMeshPro;

	private Material m_material;

	private void Awake()
	{
		this.m_textMeshPro = base.GetComponent<TMP_Text>();
	}

	[IteratorStateMachine(typeof(_003CStart_003Ed__4))]
	private IEnumerator Start()
	{
		return new _003CStart_003Ed__4(0)
		{
			_003C_003E4__this = this
		};
	}
}
