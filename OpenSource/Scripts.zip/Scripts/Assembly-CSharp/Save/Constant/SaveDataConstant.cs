using Save.Data;

namespace Save.Constant
{
	public static class SaveDataConstant
	{
		public static ConstantData ConstantData;

		public static GameMenuData GameMenuData;

		public static AreaData AreaData;

		public static UnLockData UnLockData;

		public static TeachData TeachData;

		public static ValueShopData ValueShopData;
	}
}
