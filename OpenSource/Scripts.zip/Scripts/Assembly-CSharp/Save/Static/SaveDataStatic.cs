using Save.Data;

namespace Save.Static
{
	public static class SaveDataStatic
	{
		public static float OldVersion;

		public static float CurrentVersion;

		public static void LoadAll()
		{
		}

		public static void SaveAll()
		{
		}

		public static void Load(string saveName)
		{
		}

		public static void Save(SaveData saveData)
		{
		}

		public static void Init(string saveName)
		{
		}

		public static bool CheckVersion()
		{
			// 原逻辑比较存档版本(OldVersion)与当前版本(CurrentVersion)判断是否兼容。
			// 存档系统尚为桩(LoadAll/Init 未实现)，当前版本无旧存档冲突，返回 true 放行启动。
			// TODO: 存档系统重建后改为 OldVersion == CurrentVersion 之类的真实比较。
			return true;
		}
	}
}
