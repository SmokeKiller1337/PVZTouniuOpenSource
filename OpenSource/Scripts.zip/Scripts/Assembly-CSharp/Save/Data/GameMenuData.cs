using System;

namespace Save.Data
{
	[Serializable]
	public class GameMenuData : SaveData
	{
		public int menuMode;

		public float masterVolume;

		public float musicVolume;

		public float effectVolume;

		public float voiceVolume;

		public float uiVolume;

		public bool lowMode0;

		public bool lowMode1;

		public bool lowMode2;

		public bool lowFrame;

		public bool cardSlotMode0;

		public bool cardSlotMode1;

		public bool speed1;

		public bool speed2;

		public bool speed3;

		public bool autoSpeed;

		public int resolution;

		public bool showHealth;

		public bool showDamage;

		public bool showPowerText;

		public bool showEventValue;

		public override void InitUpdate()
		{
		}
	}
}
