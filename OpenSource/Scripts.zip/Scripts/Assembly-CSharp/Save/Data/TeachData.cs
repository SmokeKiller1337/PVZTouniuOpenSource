using System;
using System.Collections.Generic;

namespace Save.Data
{
	[Serializable]
	public class TeachData : SaveData
	{
		public Dictionary<int, bool> itemDic;

		public override void InitUpdate()
		{
		}
	}
}
