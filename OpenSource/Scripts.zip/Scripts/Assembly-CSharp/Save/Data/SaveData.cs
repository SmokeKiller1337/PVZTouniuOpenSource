namespace Save.Data
{
	public abstract class SaveData
	{
		public bool isAutoSave;

		public string savePath;

		public abstract void InitUpdate();
	}
}
