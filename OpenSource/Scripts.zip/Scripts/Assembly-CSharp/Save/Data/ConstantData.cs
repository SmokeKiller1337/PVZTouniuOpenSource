using System;
using System.Collections.Generic;

namespace Save.Data
{
	[Serializable]
	public class ConstantData : SaveData
	{
		public int difficulty;

		public int touniuDifficulty;

		public int challengeDifficulty;

		public int randomMode;

		public List<int> preparationCardIdList;

		public override void InitUpdate()
		{
		}
	}
}
