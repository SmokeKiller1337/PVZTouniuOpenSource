using System;

namespace Save.Data
{
	[Serializable]
	public class ValueShopData : SaveData
	{
		private static readonly string s_Key1;

		private static readonly string s_Key2;

		private static readonly int s_SplitPosition;

		public string str1;

		public string str2;

		public string str3;

		public string str4;

		public int Value
		{
			get
			{
				return 0;
			}
			set
			{
			}
		}

		public override void InitUpdate()
		{
		}

		public void EncryptInt(int number)
		{
		}

		public int DecryptInt()
		{
			return 0;
		}

		private byte[] PositionConfusion(byte[] bytes, bool encrypt)
		{
			return null;
		}

		private byte[] AddRandomNoise(byte[] bytes, int noiseCount)
		{
			return null;
		}

		private byte[] RemoveRandomNoise(byte[] bytes, int noiseCount)
		{
			return null;
		}

		private string ReverseString(string s)
		{
			return null;
		}

		private void Version047Handle(float oldVersion, float currentVersion)
		{
		}
	}
}
