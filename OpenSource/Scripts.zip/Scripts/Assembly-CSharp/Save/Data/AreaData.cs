using System;
using System.Collections.Generic;

namespace Save.Data
{
	[Serializable]
	public class AreaData : SaveData
	{
		[Serializable]
		public class AreaItemData
		{
			public List<LevelData> levelList;
		}

		[Serializable]
		public class LevelData
		{
			public int id;

			public int difficulty;

			public int touniuDifficulty;

			public int challengeDifficulty;

			public int successTime;
		}

		public Dictionary<int, AreaItemData> adventureAreaDic;

		public Dictionary<int, AreaItemData> challengeAreaDic;

		public Dictionary<int, AreaItemData> miniAreaDic;

		public int value;

		public override void InitUpdate()
		{
		}

		private void CheckData()
		{
		}

		private static void Version014Handle(float oldVersion, float currentVersion)
		{
		}

		private void Version044Handle(float oldVersion, float currentVersion)
		{
		}
	}
}
