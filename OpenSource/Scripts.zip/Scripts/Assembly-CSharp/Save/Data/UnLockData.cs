using System;
using System.Collections.Generic;

namespace Save.Data
{
	[Serializable]
	public class UnLockData : SaveData
	{
		public Dictionary<int, bool> cardDic;

		public Dictionary<int, bool> guestDic;

		public override void InitUpdate()
		{
		}

		private void VersionHandle()
		{
		}
	}
}
