using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Bullet.Entity;
using UnityEngine;
using Zombie.Entity;

namespace Guest.Entity
{
	public class Guest1Entity : GuestEntity
	{
		[CompilerGenerated]
		private sealed class _003CAttack_003Ed__6 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public Guest1Entity _003C_003E4__this;

			private List<ZombieEntity> _003CzombieList_003E5__2;

			private List<Vector2> _003Clist_003E5__3;

			private int _003Cj_003E5__4;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CAttack_003Ed__6(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		public BulletAttr bulletAttr;

		[Tooltip("子弹计时器")]
		public float timer;

		public int count;

		protected override void Awake()
		{
		}

		protected override void Start()
		{
		}

		protected override void Update()
		{
		}

		[IteratorStateMachine(typeof(_003CAttack_003Ed__6))]
		private IEnumerator Attack()
		{
			return null;
		}
	}
}
