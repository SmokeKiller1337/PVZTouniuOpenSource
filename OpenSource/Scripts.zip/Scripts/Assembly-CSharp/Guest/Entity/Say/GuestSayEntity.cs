using UnityEngine;
using cfg.common;

namespace Guest.Entity.Say
{
	public abstract class GuestSayEntity : MonoBehaviour
	{
		[Tooltip("编号")]
		public int id;

		[Tooltip("内容")]
		public string content;

		[Tooltip("颜色")]
		public ColorType colorType;

		[Tooltip("动画名称")]
		public string sayAnimName;

		protected float _durationTime;

		protected float _durationTimer;

		protected virtual void Awake()
		{
		}

		protected virtual void Start()
		{
		}

		protected virtual void Update()
		{
		}

		public void End()
		{
		}

		public virtual float GetDurationTime()
		{
			return 0f;
		}

		protected abstract void TimeOut();
	}
}
