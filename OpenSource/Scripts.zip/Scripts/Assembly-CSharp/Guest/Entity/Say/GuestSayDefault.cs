namespace Guest.Entity.Say
{
	public class GuestSayDefault : GuestSayEntity
	{
		protected override void TimeOut()
		{
		}
	}
}
