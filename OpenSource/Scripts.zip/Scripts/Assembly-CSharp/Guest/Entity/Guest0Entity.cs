namespace Guest.Entity
{
	public class Guest0Entity : GuestEntity
	{
		protected override void Awake()
		{
		}

		protected override void Start()
		{
		}

		protected override void Update()
		{
		}
	}
}
