namespace Guest.Entity
{
	public class Guest2Entity : GuestEntity
	{
		protected override void Awake()
		{
		}

		protected override void Start()
		{
		}

		protected override void Update()
		{
		}
	}
}
