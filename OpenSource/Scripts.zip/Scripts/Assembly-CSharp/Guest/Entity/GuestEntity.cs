using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using FairyGUI;
using Guest.Entity.Say;
using UnityEngine;

namespace Guest.Entity
{
	public abstract class GuestEntity : MonoBehaviour
	{
		[CompilerGenerated]
		private sealed class _003CStunHandle_003Ed__28 : IEnumerator<object>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private object _003C_003E2__current;

			public GuestEntity _003C_003E4__this;

			object IEnumerator<object>.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CStunHandle_003Ed__28(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[Tooltip("编号")]
		public int id;

		[Tooltip("名称")]
		public string title;

		[Tooltip("简介")]
		public string simpleDesc;

		[Tooltip("描述")]
		[TextArea]
		public string desc;

		[Tooltip("默认解锁")]
		public bool defaultUnLock;

		[Tooltip("赞助卡牌编号")]
		public int guestCardId;

		[Tooltip("默认说话音频")]
		public List<AudioClip> defaultSaySoundList;

		protected Animator _animator;

		protected GComponent _dialogCom;

		protected Transition _t0;

		protected SpriteRenderer _spriteRenderer;

		protected bool _isHighlight;

		protected bool _isFlicker;

		protected bool _isStun;

		protected bool _isStunFirstFrame;

		protected Coroutine _stunCoroutine;

		public Animator Animator
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		protected virtual void Awake()
		{
		}

		protected virtual void Start()
		{
		}

		protected virtual void Update()
		{
		}

		public GuestSayEntity TalkStart(int sayId)
		{
			return null;
		}

		public void TalkEnd()
		{
		}

		protected virtual void OnTalkStart()
		{
		}

		protected virtual void OnTalkEnd()
		{
		}

		public void Highlight(bool isHighlight = true)
		{
		}

		public void Stun()
		{
		}

		[IteratorStateMachine(typeof(_003CStunHandle_003Ed__28))]
		private IEnumerator StunHandle()
		{
			return null;
		}
	}
}
