using System;
using UnityEngine;

[Serializable]
public class PotRewardEntity : ICloneable
{
	[Tooltip("阳光数")]
	public int sunValue;

	[Tooltip("钻石数")]
	public int diamondValue;

	[Tooltip("锤子数")]
	public int hammerValue;

	[Tooltip("植物卡牌")]
	public int plantCardId;

	[Tooltip("僵尸卡牌")]
	public int zombieCardId;

	[Tooltip("是否是魅惑卡牌")]
	public bool isHypnosisCard;

	[Tooltip("是好罐子")]
	public bool isGoodCustom;

	[Tooltip("是坏罐子")]
	public bool isBadCustom;

	[Tooltip("是中立罐子")]
	public bool isNeutralCustom;

	[Tooltip("自定义标题")]
	public string customTitle;

	public object Clone()
	{
		return MemberwiseClone();
	}
}
