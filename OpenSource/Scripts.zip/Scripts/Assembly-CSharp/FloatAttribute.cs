public class FloatAttribute
{
	public float Value { get; private set; }

	public float BaseValue { get; private set; }

	public float Addition0 { get; private set; }

	public int PctAddion0 { get; private set; }

	public float Addition1 { get; private set; }

	public int PctAddion1 { get; private set; }

	public FloatAttribute(float baseValue = 0f)
	{
		BaseValue = baseValue;
		Addition0 = 0f;
		PctAddion0 = 0;
		Addition1 = 0f;
		PctAddion1 = 0;
		Value = 0f;
	}

	public void Reset()
	{
		Value = 0f;
		BaseValue = 0f;
		Addition0 = 0f;
		PctAddion0 = 0;
		Addition1 = 0f;
		PctAddion1 = 0;
	}

	public void SetBaseValue(float value)
	{
		BaseValue = value;
		UpdateValue();
	}

	public void ModifyValue(float value)
	{
		BaseValue += value;
		UpdateValue();
	}

	public void ModifyAddition0(float value)
	{
		Addition0 += value;
		UpdateValue();
	}

	public void ModifyAddition1(float value)
	{
		Addition1 += value;
		UpdateValue();
	}

	public void ModifyPctAddition0(int value)
	{
		PctAddion0 += value;
		UpdateValue();
	}

	public void ModifyPctAddition1(int value)
	{
		PctAddion1 += value;
		UpdateValue();
	}

	private void UpdateValue()
	{
		Value = (((Addition0 + BaseValue) * ((float)PctAddion0 + 100f) / 100f + Addition1) * ((float)PctAddion1 + 100f)) / 100f;
	}
}
