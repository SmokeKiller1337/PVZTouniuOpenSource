using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

namespace Audio.Manager
{
	public class AudioManager : MonoBehaviour
	{
		private struct CHANNEL
		{
			public AudioSource channel;

			public float keyOnTime;
		}

		[Tooltip("背景音乐")]
		public AudioSource backgroundMusicAudioSource;

		[Tooltip("头牛说话")]
		public AudioSource touniuSayAudioSource;

		[Tooltip("音效输出的音轨")]
		public AudioMixerGroup effectAudioGroup;

		public AudioMixerGroup voiceAudioGroup;

		[Tooltip("UI输出的音轨")]
		public AudioMixerGroup uiAudioGroup;

		[Tooltip("音频轨道")]
		public AudioMixer audioMixer;

		private AudioClip defaultBackgroundMusic;

		private const int AUDIO_CHANNEL_NUM = 32;

		private const int AUDIO_CHANNEL_NUM1 = 4;

		private const int AUDIO_CHANNEL_NUM2 = 4;

		private CHANNEL[] m_channels;

		private CHANNEL[] m_channels1;

		private CHANNEL[] m_channels2;

		private Dictionary<AudioClip, List<float>> _clipPlayRecords;

		private const float PLAY_RECORD_DURATION = 0.5f;

		public static AudioManager Instance { get; private set; }

		private void Awake()
		{
		}

		private void Start()
		{
		}

		public int PlayOneShot(List<AudioClip> clipList, float pitchRange = 0f, float volume = -1f, float pan = 0f, float pitch = 1f)
		{
			return 0;
		}

		public int PlayOneShot(AudioClip clip, float pitchRange = 0f, float volume = -1f, float pan = 0f, float pitch = 1f)
		{
			return 0;
		}

		public int PlayLoop(AudioClip clip, float volume, float pan, float pitch = 1f)
		{
			return 0;
		}

		public void StopAllEffect()
		{
		}

		public void StopAllUI()
		{
		}

		public void StopEffect(int id)
		{
		}

		public void UpdateVolume()
		{
		}

		public void PlayMusic(AudioClip newBackgroundMusic = null)
		{
		}

		public int PlayVoice(List<AudioClip> clipList)
		{
			return 0;
		}

		public int PlayVoice(AudioClip clip)
		{
			return 0;
		}

		public int PlayUI(List<AudioClip> clipList, float pitchRange = 0f, float volume = -1f, float pan = 0f, float pitch = 1f)
		{
			return 0;
		}

		public int PlayUI(AudioClip clip, float pitchRange = 0f, float volume = -1f, float pan = 0f, float pitch = 1f)
		{
			return 0;
		}

		private float Remap01ToDB(float x)
		{
			return 0f;
		}

		private void RecordClipPlay(AudioClip clip)
		{
		}

		private int GetRecentPlayCount(AudioClip clip)
		{
			return 0;
		}
	}
}
