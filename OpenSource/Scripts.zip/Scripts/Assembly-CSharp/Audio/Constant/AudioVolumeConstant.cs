namespace Audio.Constant
{
	public class AudioVolumeConstant
	{
	}
}
