namespace Audio.Constant
{
	public class VolumeConstant
	{
		public static float musicVolume;

		public static float effectVolume;

		public static float sayVolume;
	}
}
