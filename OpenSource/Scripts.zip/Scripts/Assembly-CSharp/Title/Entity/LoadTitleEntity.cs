using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using FGUI.Static;
using FairyGUI;
using Save.Static;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Title.Entity
{
	public class LoadTitleEntity : MonoBehaviour
	{
		// 目标标题场景。原始字符串字面量为 "Title"，本工程导出后名为 "level1"。
		private const string TitleSceneName = "level1";

		// Unity 场景加载进度在未 allowSceneActivation 时封顶 0.9f。
		private const float SceneReadyProgress = 0.9f;

		[HideInInspector]
		public bool isStart;

		public UIPanel loadUI;

		private GProgressBar _progressBar;

		private float _maxTimer;

		private bool _isLoadFinish;

		private int _platform;

		private void Awake()
		{
			_platform = ((Application.platform == RuntimePlatform.Android) ? 1 : 0);
		}

		private void Start()
		{
			Debug.Log("[LTE-DIAG] Start entered. loadUI=" + (loadUI == null ? "NULL" : "ok"));
			if (loadUI == null)
			{
				Debug.LogError("[LTE-DIAG] loadUI is NULL -> boot stops here (加载UI引用丢失)");
				return;
			}
			GComponent ui = loadUI.ui;
			Debug.Log("[LTE-DIAG] loadUI.ui=" + (ui == null ? "NULL" : ("ok, name=" + ui.name)));
			if (ui == null)
			{
				Debug.LogError("[LTE-DIAG] loadUI.ui is NULL -> UIPanel 没创建出 LoadTitleBox");
				return;
			}
			Debug.Log("[LTE-DIAG] Start proceeding to button wiring + NextSuccess");

			// 绑定加载界面上的按钮点击(对应 <>c 的 5 个 lambda b__7_0..4)。
			GObject copy1 = ui.GetChild("copy1");
			if (copy1 != null && copy1.asButton != null)
			{
				copy1.onClick.Set((EventCallback0)delegate
				{
					// b__7_0: 复制识别串到系统剪贴板
					if (TitleDateCheckEntity.Instance != null)
					{
						GUIUtility.systemCopyBuffer = TitleDateCheckEntity.Instance.path1Str;
					}
				});
			}
			GObject copy2 = ui.GetChild("copy2");
			if (copy2 != null && copy2.asButton != null)
			{
				copy2.onClick.Set((EventCallback0)delegate
				{
					// b__7_1
					if (TitleDateCheckEntity.Instance != null)
					{
						GUIUtility.systemCopyBuffer = TitleDateCheckEntity.Instance.path2Str;
					}
				});
			}
			GObject closeButton = ui.GetChild("closeButton");
			if (closeButton != null && closeButton.asButton != null)
			{
				// b__7_2: 退出游戏
				closeButton.onClick.Set((EventCallback0)delegate
				{
					Application.Quit();
				});
			}
			GObject closeButton1 = ui.GetChild("closeButton1");
			if (closeButton1 != null && closeButton1.asButton != null)
			{
				// b__7_3: 退出游戏
				closeButton1.onClick.Set((EventCallback0)delegate
				{
					Application.Quit();
				});
			}
			GObject removeSave = ui.GetChild("removeSave");
			if (removeSave != null && removeSave.asButton != null)
			{
				// b__7_4: 删除存档文件后退出(字符串 "Save.json")
				removeSave.onClick.Set((EventCallback0)delegate
				{
					ES3.DeleteFile("Save.json");
					Application.Quit();
				});
			}

			// 初始隐藏三个分组(g0=加载内容, g1=校验失败提示, g2=其它)。
			GObject g0 = ui.GetChild("g0");
			if (g0 != null)
			{
				g0.visible = false;
			}
			GObject g1 = ui.GetChild("g1");
			if (g1 != null)
			{
				g1.visible = false;
			}
			GObject g2 = ui.GetChild("g2");
			if (g2 != null)
			{
				g2.visible = false;
			}

			// 清空标题/对话文本。
			GObject titleObj = ui.GetChild("title");
			if (titleObj != null && titleObj.asTextField != null)
			{
				titleObj.asTextField.text = "";
			}
			GObject dialogObj = ui.GetChild("dialog");
			if (dialogObj != null && dialogObj.asLabel != null)
			{
				dialogObj.asLabel.text = "";
			}

			// 取进度条并初始化 min=0 max=100 value=0。
			GObject loadObj = ui.GetChild("load");
			if (loadObj != null)
			{
				_progressBar = loadObj.asProgress;
			}
			if (_progressBar != null)
			{
				_progressBar.min = 0.0;
				_progressBar.max = 100.0;
				_progressBar.value = 0.0;
			}

			// 非 Android(或已解锁) 直接进入加载; 否则做日期/设备解锁校验。
			if (!IsCheck())
			{
				NextSuccess();
				return;
			}

			// ---- 解锁校验路径(仅 Android 且未解锁时执行) ----
			ES3Settings settings = GetSaveSettings();
			if (!ES3.KeyExists("z", settings))
			{
				// 首次: 依配置日期区间校验
				TitleDateCheckEntity inst = TitleDateCheckEntity.Instance;
				if (inst != null && inst.IsCurrentDateInRange())
				{
					DateTime today = DateTime.Today;
					DateTime start = new DateTime(inst.startYear, inst.startMoon, inst.startDay);
					DateTime end = new DateTime(inst.endYear, inst.endMoon, inst.endDay);
					if (today >= start && today <= end)
					{
						ESaveTitle();
						NextSuccess();
						return;
					}
				}
				NextError();
				return;
			}

			// 已写入解锁标记: 校验设备 id
			if (E1LoadTitle())
			{
				ES3Settings deviceSettings = GetSaveSettings();
				if (ES3.KeyExists("a", deviceSettings))
				{
					string savedId = ES3.Load<string>("a", deviceSettings);
					if (savedId == SystemInfo.deviceUniqueIdentifier)
					{
						NextSuccess();
						return;
					}
					NextError();
					return;
				}
				// 无设备 id 记录: 视为通过
				NextSuccess();
				return;
			}
			NextError();
		}

		private bool IsCheck()
		{
			// instance.isUnlock(偏移 0x58)==false 且 _platform!=0 时返回 true(需要解锁校验)。
			TitleDateCheckEntity inst = TitleDateCheckEntity.Instance;
			if (inst == null)
			{
				return false;
			}
			return !inst.isUnlock && _platform != 0;
		}

		public void NextSuccess()
		{
			// 校验通过: 显示 g0, 版本正常则随机一句提示 + 异步加载标题场景 + 启动进度协程 + 初始化 FGUI。
			if (loadUI == null)
			{
				return;
			}
			GComponent ui = loadUI.ui;
			if (ui == null)
			{
				return;
			}
			GObject g0 = ui.GetChild("g0");
			if (g0 == null)
			{
				return;
			}
			g0.visible = true;

			if (SaveDataStatic.CheckVersion())
			{
				// 加载提示语列表(17 条, 均从二进制 stringliteral 解出, 顺序与原始一致)。
				List<string> tips = new List<string>
				{
					"我帮你加载游戏。",
					"你加载太慢了，我给你加速一下。",
					"借给你50%加载进度，下次加载你得还我。",
					"你把进度条借我，30秒后还你。",
					"给我100阳光，我给你加载进度条拉满。",
					"我估计你也没见过进度条，我给你介绍一下。",
					"我给你强化一下进度条。",
					"好了，你该还我100%加载进度了。",
					"我先吃一口再帮你加载游戏。",
					"我给你表演个加载游戏。",
					"加载游戏太赖了，我把你进度条禁了。",
					"作为补偿，我给你进度条拉满吧。",
					"对了，你还得给我利息80%加载进度。",
					"坏了，进度条卡住了。",
					"坏消息是：游戏还没加载好。",
					"估计你也不着急，等会再帮你加载。",
					"哎呦喂。"
				};
				GObject dialogObj = ui.GetChild("dialog");
				int index = UnityEngine.Random.Range(0, tips.Count);
				if (dialogObj != null && dialogObj.asLabel != null)
				{
					dialogObj.asLabel.text = tips[index];
				}

				// 异步加载标题场景, 先禁止自动激活, 用协程控制进度与切换时机。
				Debug.Log("[LTE-DIAG] NextSuccess: CheckVersion=true, loading scene='" + TitleSceneName + "'");
				AsyncOperation asyncLoad = SceneManager.LoadSceneAsync(TitleSceneName);
				Debug.Log("[LTE-DIAG] LoadSceneAsync returned " + (asyncLoad == null ? "NULL(场景没在Build列表?)" : "ok"));
				if (asyncLoad != null)
				{
					asyncLoad.allowSceneActivation = false;
					StartCoroutine(LoadSceneWithProgress(asyncLoad));
					// 目标场景加载前预初始化 FGUI(创建全部 UI 组件)。
					FGUIStatic.InitAwake();
					Debug.Log("[LTE-DIAG] FGUIStatic.InitAwake() done, coroutine started, isStart=true");
					isStart = true;
				}
			}
			else
			{
				// 版本不匹配: 提示更新, 进度归零, 不加载。
				GObject titleObj = ui.GetChild("title");
				if (titleObj != null && titleObj.asTextField != null)
				{
					titleObj.asTextField.text = "请使用最新版进入游戏，避免存档损坏。";
				}
				GObject loadObj = ui.GetChild("load");
				if (loadObj != null && loadObj.asProgress != null)
				{
					loadObj.asProgress.value = 0.0;
				}
			}
		}

		public void NextError()
		{
			// 校验失败: 显示 g1 提示分组。
			if (loadUI == null)
			{
				return;
			}
			GComponent ui = loadUI.ui;
			if (ui == null)
			{
				return;
			}
			GObject g1 = ui.GetChild("g1");
			if (g1 != null)
			{
				g1.visible = true;
			}
		}

		private void Update()
		{
			// 加载中的搞笑进度条动画: 逐步填充, 满后短暂停顿再回落, 循环,
			// 直到 _isLoadFinish(协程判定真实加载就绪) 后直接拉满。
			// (原始逐区间的浮点曲线/常量为纯视觉效果, 此处按行为等价简化重建。)
			if (!isStart)
			{
				return;
			}
			if (_progressBar == null)
			{
				return;
			}
			if (_isLoadFinish)
			{
				_progressBar.value = _progressBar.max;
				return;
			}

			double value = _progressBar.value;
			double max = _progressBar.max;

			if (_maxTimer > 1f)
			{
				// 回落阶段(把借走的进度"还回来"的桥段)
				value -= Time.deltaTime * 60.0;
				if (value <= 0.0)
				{
					value = 0.0;
					_maxTimer = 0f;
				}
				_progressBar.value = value;
				return;
			}
			if (value >= max)
			{
				// 到顶: 停顿累计
				_maxTimer += Time.deltaTime;
				return;
			}
			// 填充阶段
			value += Time.deltaTime * 40.0;
			if (value > max)
			{
				value = max;
			}
			_progressBar.value = value;
		}

		private IEnumerator LoadSceneWithProgress(AsyncOperation asyncLoad)
		{
			// d__12 状态机行为: 等待真实进度到 0.9(封顶值), 保持片刻让视觉进度条追上,
			// 置 _isLoadFinish=true(Update 拉满进度), 稍候后 allowSceneActivation=true 完成场景切换。
			float time = 0f;
			while (!asyncLoad.isDone)
			{
				if (asyncLoad.progress < SceneReadyProgress)
				{
					yield return null;
				}
				else
				{
					time += Time.deltaTime;
					if (time <= 0.5f)
					{
						yield return null;
					}
					else
					{
						break;
					}
				}
			}
			_isLoadFinish = true;
			yield return new WaitForSeconds(0.5f);
			asyncLoad.allowSceneActivation = true;
		}

		private void ESaveTitle()
		{
			// 写入解锁标记与设备指纹到加密存档。key: z/a/b/c。
			ES3Settings settings = GetSaveSettings();
			ES3.Save<string>("z", "Success", settings);
			ES3.Save<string>("a", SystemInfo.deviceUniqueIdentifier, settings);
			TitleDateCheckEntity inst = TitleDateCheckEntity.Instance;
			if (inst != null)
			{
				ES3.Save<int>("b", inst.startMoon, settings);
				ES3.Save<int>("c", inst.startDay, settings);
			}
		}

		public static bool E1LoadTitle()
		{
			// 校验存档中的 b/c 是否与配置一致(防篡改)。都为 0 视为首启通过。
			ES3Settings settings = GetSaveSettings();
			int b = 0;
			int c = 0;
			if (ES3.KeyExists("b", settings))
			{
				b = ES3.Load<int>("b", settings);
			}
			if (ES3.KeyExists("c", settings))
			{
				c = ES3.Load<int>("c", settings);
			}
			if (b == 0 && c == 0)
			{
				return true;
			}
			TitleDateCheckEntity inst = TitleDateCheckEntity.Instance;
			if (inst == null)
			{
				return false;
			}
			return b == inst.startMoon && c == inst.startDay;
		}

		public static bool E2LoadTitle()
		{
			// 设备指纹校验: 无记录视为通过, 否则须与当前设备一致。
			ES3Settings settings = GetSaveSettings();
			if (!ES3.KeyExists("a", settings))
			{
				return true;
			}
			string savedId = ES3.Load<string>("a", settings);
			return savedId == SystemInfo.deviceUniqueIdentifier;
		}

		public static bool E3LoadTitle()
		{
			// 解锁标记 "z" 不存在时返回 true(尚未解锁)。
			ES3Settings settings = GetSaveSettings();
			return !ES3.KeyExists("z", settings);
		}

		private static ES3Settings GetSaveSettings()
		{
			ES3Settings settings = new ES3Settings();
			settings.encryptionType = (ES3.EncryptionType)1;
			settings.location = (ES3.Location)0;
			TitleDateCheckEntity inst = TitleDateCheckEntity.Instance;
			if (inst != null)
			{
				settings.encryptionPassword = inst.password;
				settings.path = Path.Combine(Application.persistentDataPath, inst.key);
			}
			return settings;
		}
	}
}
