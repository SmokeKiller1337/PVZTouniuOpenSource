using UnityEngine;

namespace Title.Entity
{
	public class TitleDateCheckEntity : MonoBehaviour
	{
		[Header("Key")]
		public string key;

		[Header("Password")]
		public string password;

		public string path1Str;

		public string path2Str;

		public int startYear;

		public int startMoon;

		public int startDay;

		public int endYear;

		public int endMoon;

		public int endDay;

		[Header("更最新版本后用")]
		[Tooltip("是否无需解锁")]
		public bool isUnlock;

		[Tooltip("是否为测试版")]
		public bool isBeta;

		public static TitleDateCheckEntity Instance { get; private set; }

		private void Awake()
		{
		}

		private void Start()
		{
		}

		public bool IsCurrentDateInRange()
		{
			return false;
		}

		private bool IsDateValid()
		{
			return false;
		}
	}
}
