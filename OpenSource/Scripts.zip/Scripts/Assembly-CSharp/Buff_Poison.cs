using NoSLoofah.BuffSystem;
using UnityEngine;

public class Buff_Poison : Buff
{
	[SerializeField]
	private int poisonDamage;

	[SerializeField]
	private float poisonTimeInterval;

	[SerializeField]
	private GameObject effect;

	private Entity1 targetEntity;

	public override void OnBuffDestroy()
	{
		// TODO: reconstruct
		// RVA 0x4079E0's decompiled body only touches inherited private Buff state
		// (mutilAddType @0x48, tmpLayer @0x60, Layer @0x28, layerModified @0x64,
		// isEffective @0xB0) plus a virtual dispatch. None of these are accessible
		// from the subclass, so the real body cannot be reconstructed with real
		// members and is left as a stub.
	}

	public override void OnBuffModifyLayer(int change)
	{
	}

	public override void OnBuffRemove()
	{
	}

	public override void OnBuffStart()
	{
		targetEntity = Target.GetComponent<Entity1>();
		StartBuffTickEffect(poisonTimeInterval);
	}

	public override void Reset()
	{
	}

	protected override void OnBuffTickEffect()
	{
		if (targetEntity != null)
		{
			targetEntity.ModifyHealth(-(poisonDamage * Layer));
			GameObject gameObject = Object.Instantiate(effect);
			if (gameObject != null && Target != null)
			{
				gameObject.transform.position = Target.transform.position;
			}
		}
	}
}
