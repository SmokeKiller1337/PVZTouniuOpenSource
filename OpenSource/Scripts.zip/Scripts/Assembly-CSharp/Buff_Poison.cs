using NoSLoofah.BuffSystem;
using UnityEngine;

public class Buff_Poison : Buff
{
	[SerializeField]
	private int poisonDamage;

	[SerializeField]
	private float poisonTimeInterval;

	[SerializeField]
	private GameObject effect;

	private Entity1 targetEntity;

	public override void OnBuffDestroy()
	{
	}

	public override void OnBuffModifyLayer(int change)
	{
	}

	public override void OnBuffRemove()
	{
	}

	public override void OnBuffStart()
	{
		targetEntity = Target.GetComponent<Entity1>();
		StartBuffTickEffect(poisonTimeInterval);
	}

	public override void Reset()
	{
	}

	protected override void OnBuffTickEffect()
	{
		if (targetEntity != null)
		{
			targetEntity.ModifyHealth(-(poisonDamage * Layer));
			GameObject gameObject = Object.Instantiate(effect);
			if (gameObject != null && Target != null)
			{
				gameObject.transform.position = Target.transform.position;
			}
		}
	}
}
